-- ============================================================
-- Mini Centrino Lite v1.8.0 — SIMPLE AUTH SETUP (LAN-only)
-- ============================================================
-- Run this ONCE in the Supabase SQL Editor (Dashboard → SQL → New Query)
-- to wire up the v1.8 simple localStorage-based auth.
--
-- What this does:
--   1. Disables RLS on web_users + outlets (so the webapp can read with anon key)
--   2. Removes any Supabase Auth trigger that might have been installed by v1.7
--   3. Creates the `role_permissions` table for fine-grained RBAC
--   4. Inserts default permissions for owner/manager/cashier/viewer roles
--   5. Creates the default admin user (admin@sudhamrit.com / admin123)
--
-- After running, sign in with:
--   Email:    admin@sudhamrit.com
--   Password: admin123
--
-- ⚠️ CHANGE THE ADMIN PASSWORD IMMEDIATELY after first login
--    via the Users page → Reset Password.
-- ============================================================

-- ────────────────────────────────────────────────────────────
-- 1. Remove Supabase Auth artifacts (if v1.7 was previously installed)
-- ────────────────────────────────────────────────────────────
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
DROP FUNCTION IF EXISTS public.handle_new_auth_user();

-- ────────────────────────────────────────────────────────────
-- 2. Disable RLS on web_users + outlets
-- ────────────────────────────────────────────────────────────
-- The webapp reads these tables directly with the anon key (no Supabase Auth
-- session). RLS would block all reads.
ALTER TABLE public.web_users DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.outlets DISABLE ROW LEVEL SECURITY;

-- Drop any policies that v1.7 might have created (idempotent)
DROP POLICY IF EXISTS "web_users_select_own_or_owner" ON public.web_users;
DROP POLICY IF EXISTS "web_users_modify_owner_only" ON public.web_users;
DROP POLICY IF EXISTS "outlets_select_authenticated" ON public.outlets;
DROP POLICY IF EXISTS "outlets_modify_owner_only" ON public.outlets;

-- ────────────────────────────────────────────────────────────
-- 3. Create the role_permissions table
-- ────────────────────────────────────────────────────────────
-- One row per (role, module, action) combination.
-- Module names match NAV_MODULE_MAP in src/lib/permissions.ts:
--   dashboard | kots | bills | menu | reports | outlets | packaging | users | settings
-- Actions: view | create | edit | delete
CREATE TABLE IF NOT EXISTS public.role_permissions (
    id         UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    role       TEXT NOT NULL,           -- owner | manager | cashier | viewer
    module     TEXT NOT NULL,           -- dashboard | kots | bills | menu | reports | outlets | packaging | users | settings
    action     TEXT NOT NULL,           -- view | create | edit | delete
    allowed    BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE (role, module, action)
);

COMMENT ON TABLE public.role_permissions IS
    'Role-based access control matrix used by the webapp. Owner role bypasses all checks (always allowed). Other roles check this table at runtime via can(module, action).';

-- ────────────────────────────────────────────────────────────
-- 4. Insert default permissions for each role
-- ────────────────────────────────────────────────────────────
-- Owner is NOT inserted here — owner bypasses all checks in code.
-- We only seed permissions for manager / cashier / viewer.

-- Clear existing rows so re-running is idempotent
DELETE FROM public.role_permissions WHERE role IN ('manager', 'cashier', 'viewer');

-- ── Manager: full read access + can edit bills, kots, menu, packaging ──
-- Cannot manage users or outlets (no create/edit/delete on those).
INSERT INTO public.role_permissions (role, module, action, allowed) VALUES
    ('manager', 'dashboard',  'view',   true),
    ('manager', 'kots',       'view',   true),
    ('manager', 'kots',       'edit',   true),
    ('manager', 'bills',      'view',   true),
    ('manager', 'bills',      'edit',   true),
    ('manager', 'menu',       'view',   true),
    ('manager', 'menu',       'create', true),
    ('manager', 'menu',       'edit',   true),
    ('manager', 'menu',       'delete', true),
    ('manager', 'reports',    'view',   true),
    ('manager', 'packaging',  'view',   true),
    ('manager', 'packaging',  'edit',   true),
    ('manager', 'settings',   'view',   true);

-- ── Cashier: can see dashboard, bills, kots; can edit KOT status; nothing else ──
INSERT INTO public.role_permissions (role, module, action, allowed) VALUES
    ('cashier', 'dashboard',  'view', true),
    ('cashier', 'kots',       'view', true),
    ('cashier', 'kots',       'edit', true),     -- change KOT status (pending → preparing → ready → served)
    ('cashier', 'bills',      'view', true);

-- ── Viewer: read-only access to most pages, no edits anywhere ──
INSERT INTO public.role_permissions (role, module, action, allowed) VALUES
    ('viewer', 'dashboard',  'view', true),
    ('viewer', 'kots',       'view', true),
    ('viewer', 'bills',      'view', true),
    ('viewer', 'menu',       'view', true),
    ('viewer', 'reports',    'view', true),
    ('viewer', 'packaging',  'view', true),
    ('viewer', 'settings',   'view', true);

-- ────────────────────────────────────────────────────────────
-- 5. Create / update the default admin user
-- ────────────────────────────────────────────────────────────
-- Password stored as `plain:admin123`. CHANGE THIS IMMEDIATELY after first login.
INSERT INTO public.web_users (email, full_name, password_hash, role, is_active, outlet_id)
VALUES (
    'admin@sudhamrit.com',
    'Outlet Owner',
    'plain:admin123',
    'owner',
    true,
    NULL
)
ON CONFLICT (email) DO UPDATE
    SET password_hash = 'plain:admin123',
        role          = 'owner',
        full_name     = COALESCE(public.web_users.full_name, 'Outlet Owner'),
        is_active     = true;

-- ────────────────────────────────────────────────────────────
-- 6. VERIFY
-- ────────────────────────────────────────────────────────────
SELECT
    'web_users RLS disabled' AS check_name,
    NOT relrowsecurity AS ok
FROM pg_class
WHERE relname = 'web_users'
UNION ALL
SELECT
    'outlets RLS disabled',
    NOT relrowsecurity
FROM pg_class
WHERE relname = 'outlets'
UNION ALL
SELECT
    'role_permissions table exists',
    EXISTS (SELECT 1 FROM pg_tables WHERE schemaname = 'public' AND tablename = 'role_permissions')
UNION ALL
SELECT
    'default admin exists',
    EXISTS (
        SELECT 1 FROM public.web_users
        WHERE email = 'admin@sudhamrit.com'
          AND role = 'owner'
          AND is_active = true
    )
UNION ALL
SELECT
    'manager permissions count',
    (SELECT COUNT(*) FROM public.role_permissions WHERE role = 'manager') = 13
UNION ALL
SELECT
    'cashier permissions count',
    (SELECT COUNT(*) FROM public.role_permissions WHERE role = 'cashier') = 4
UNION ALL
SELECT
    'viewer permissions count',
    (SELECT COUNT(*) FROM public.role_permissions WHERE role = 'viewer') = 7;

-- Expected output (all rows should show `true`):
--   web_users RLS disabled          | true
--   outlets RLS disabled            | true
--   role_permissions table exists   | true
--   default admin exists            | true
--   manager permissions count       | true
--   cashier permissions count       | true
--   viewer permissions count        | true

-- ────────────────────────────────────────────────────────────
-- 7. Quick reference: how to add a custom permission
-- ────────────────────────────────────────────────────────────
-- Example: allow cashiers to view the reports page
--   INSERT INTO public.role_permissions (role, module, action, allowed)
--   VALUES ('cashier', 'reports', 'view', true)
--   ON CONFLICT (role, module, action) DO UPDATE SET allowed = true;

-- Example: deny cashiers from editing KOTs (revoke the cashier.kots.edit permission)
--   DELETE FROM public.role_permissions
--   WHERE role = 'cashier' AND module = 'kots' AND action = 'edit';
