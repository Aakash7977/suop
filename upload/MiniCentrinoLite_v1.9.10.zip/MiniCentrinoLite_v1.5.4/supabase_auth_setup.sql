-- ============================================================
-- Mini Centrino Lite v1.7.0 — SUPABASE AUTH SETUP
-- ============================================================
-- Run this ONCE in the Supabase SQL Editor (Dashboard → SQL → New Query)
-- to wire up authentication for the Next.js HQ webapp.
--
-- After running:
--   1. Any user you create in Supabase Dashboard → Authentication → Users
--      will automatically get a web_users row inserted (role='viewer' by default).
--   2. You can then UPDATE web_users to give them a real role (owner/manager/cashier).
--   3. RLS policies below ensure each user can only read/write data they're
--      authorized for, based on their web_users.role and web_users.outlet_id.
-- ============================================================

-- ────────────────────────────────────────────────────────────
-- 1. Auto-create web_users row when a new auth.users entry is created
-- ────────────────────────────────────────────────────────────
-- This trigger fires when you add a user via Supabase Auth Dashboard.
-- The new web_users row defaults to role='viewer', is_active=true,
-- outlet_id=NULL. An admin should then UPDATE it to assign a real role.

CREATE OR REPLACE FUNCTION public.handle_new_auth_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.web_users (email, full_name, password_hash, role, is_active, outlet_id)
  VALUES (
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'full_name', split_part(NEW.email, '@', 1)),
    'managed-by-supabase-auth',  -- sentinel; real password lives in auth.users
    'viewer',                    -- default role; admin upgrades via UPDATE
    true,
    NULL                         -- no outlet assigned yet
  )
  ON CONFLICT (email) DO NOTHING;  -- if web_users row already exists, leave it alone
  RETURN NEW;
END;
$$;

-- Drop the trigger if it exists, then recreate (idempotent)
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_auth_user();

-- ────────────────────────────────────────────────────────────
-- 2. Re-enable Row-Level Security on web_users + outlets
-- ────────────────────────────────────────────────────────────
-- v1.5.x had RLS disabled on all tables (the old "open" webapp).
-- v1.7.0 re-enables RLS on the user-management tables.
-- The data tables (bills, kots, etc.) keep RLS disabled for now
-- because the Hub pushes data with the anon key — adding RLS there
-- would break sync. They're protected by the webapp's role-based UI
-- filtering instead.

ALTER TABLE public.web_users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.outlets ENABLE ROW LEVEL SECURITY;

-- web_users: a user can read their own row + any row if they're an owner.
-- Owners can read all web_users (they manage the team).
-- Other roles can only read their own row.
DROP POLICY IF EXISTS "web_users_select_own_or_owner" ON public.web_users;
CREATE POLICY "web_users_select_own_or_owner" ON public.web_users
  FOR SELECT USING (
    email = auth.jwt() ->> 'email'
    OR EXISTS (
      SELECT 1 FROM public.web_users wu
      WHERE wu.email = auth.jwt() ->> 'email'
        AND wu.role = 'owner'
        AND wu.is_active = true
    )
  );

-- Only owners can insert/update/delete web_users rows.
DROP POLICY IF EXISTS "web_users_modify_owner_only" ON public.web_users;
CREATE POLICY "web_users_modify_owner_only" ON public.web_users
  FOR ALL USING (
    EXISTS (
      SELECT 1 FROM public.web_users wu
      WHERE wu.email = auth.jwt() ->> 'email'
        AND wu.role = 'owner'
        AND wu.is_active = true
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.web_users wu
      WHERE wu.email = auth.jwt() ->> 'email'
        AND wu.role = 'owner'
        AND wu.is_active = true
    )
  );

-- outlets: any authenticated user can read (needed to populate dropdowns).
DROP POLICY IF EXISTS "outlets_select_authenticated" ON public.outlets;
CREATE POLICY "outlets_select_authenticated" ON public.outlets
  FOR SELECT USING (auth.role() = 'authenticated');

-- Only owners can modify outlets.
DROP POLICY IF EXISTS "outlets_modify_owner_only" ON public.outlets;
CREATE POLICY "outlets_modify_owner_only" ON public.outlets
  FOR ALL USING (
    EXISTS (
      SELECT 1 FROM public.web_users wu
      WHERE wu.email = auth.jwt() ->> 'email'
        AND wu.role = 'owner'
        AND wu.is_active = true
    )
  );

-- ────────────────────────────────────────────────────────────
-- 3. Create the default owner profile (so the admin can sign in)
-- ────────────────────────────────────────────────────────────
-- After you create the auth.users entry in Supabase Dashboard
-- (Authentication → Users → Add user → admin@sudhamrit.com / your_password),
-- the trigger above will auto-create a web_users row with role='viewer'.
-- This UPDATE promotes it to 'owner'.

INSERT INTO public.web_users (email, full_name, password_hash, role, is_active, outlet_id)
VALUES ('admin@sudhamrit.com', 'Administrator', 'managed-by-supabase-auth', 'owner', true, NULL)
ON CONFLICT (email) DO UPDATE
  SET role = 'owner',
      full_name = COALESCE(public.web_users.full_name, 'Administrator'),
      is_active = true,
      password_hash = 'managed-by-supabase-auth';

-- ────────────────────────────────────────────────────────────
-- 4. VERIFY
-- ────────────────────────────────────────────────────────────
-- Run this SELECT to confirm everything is set up correctly.
SELECT
  'trigger exists' AS check_name,
  EXISTS (
    SELECT 1 FROM pg_trigger
    WHERE tgname = 'on_auth_user_created'
      AND tgrelid = 'auth.users'::regclass
  ) AS ok
UNION ALL
SELECT
  'web_users RLS enabled',
  relrowsecurity
FROM pg_class
WHERE relname = 'web_users'
UNION ALL
SELECT
  'outlets RLS enabled',
  relrowsecurity
FROM pg_class
WHERE relname = 'outlets'
UNION ALL
SELECT
  'default owner exists',
  EXISTS (
    SELECT 1 FROM public.web_users
    WHERE email = 'admin@sudhamrit.com'
      AND role = 'owner'
      AND is_active = true
  );

-- Expected output:
--   trigger exists           | true
--   web_users RLS enabled    | true
--   outlets RLS enabled      | true
--   default owner exists     | true
