# Mini Centrino Lite v1.2

### Multi-POS ERP for Outlet Operations
**Sudhamrit Food Joint | Sri Ma Trust**
_Part of the Centrino ERP Family_

---

## What's New in v1.2

| # | Feature | What it does |
|---|---------|--------------|
| 1 | **Multi-POS Hub Architecture** | All 3 POS + 3 KDS connect to one central hub. Any POS sees all orders live. |
| 2 | **Single Price Menu** | No more Dine-in / Parcel toggle. One price per item (middle of old prices, rounded to ₹5). |
| 3 | **Packaging Checkbox at Checkout** | One checkbox: **"Packaging required"**. If checked → kitchen packs it (PACK badge). If unchecked → kitchen plates it (PLATE badge). |
| 4 | **Live Menu Sync** | Change price / add item / delete item on any POS or the Hub → all machines update within ~1 second. |
| 5 | **PIN-Protected Menu Editing** | Default PIN `1234`. Cashiers must enter PIN to add / edit / delete menu items. |
| 6 | **Hub Admin UI** | Dedicated dashboard for menu manager, reports, held bills, day-close, backup, KOT monitor. |

---

## Architecture (v1.2 Hub-and-Spoke)

```
                    ┌──────────────────────────┐
                    │   HUB  (mini-PC or one   │
                    │   of the POS machines)   │
                    │                          │
                    │   - SQLite DB lives here │
                    │   - TCP server on 9999   │
                    │   - Pushes every event   │
                    │     to ALL clients       │
                    │   - Admin UI for menu,   │
                    │     reports, settings    │
                    └────────────┬─────────────┘
                                 │
        ┌────────────┬───────────┼───────────┬────────────┐
        │            │           │           │            │
     POS-1        POS-2        POS-3       KDS-1       KDS-2  KDS-3
     (client)    (client)     (client)    (client)    (client)(client)
```

### What each POS sees

| Tab | Sees |
|-----|------|
| New Order | Only that POS's current cart (private to cashier) |
| KOT Monitor | KOTs from ALL POS — live updates |
| Bills | Bills from ALL POS |
| Held Bills | Held bills from ALL POS (any cashier can recall any held bill) |
| Reports | Combined revenue from all POS |
| Menu Manager | PIN-protected — changes broadcast to all POS + KDS |

---

## Deployment Options

### Option A — Dedicated mini-PC (RECOMMENDED)

- Buy a mini-PC (~₹15-20k Windows box)
- Plug into your LAN switch
- Run only the Hub service on it (no cashier sits here)
- **Best stability**: POS-1 crash doesn't affect anyone else
- Admin uses it for menu changes, reports, day-close

### Option B — POS-1 doubles as hub

- POS-1 runs Hub service (background) + POS UI (foreground)
- Cashier 1 bills normally at POS-1
- Hub is a separate process — POS UI crash doesn't kill hub
- Only full machine reboot takes everything down
- **Migration path**: Start with Option B now, buy mini-PC later, no code change needed

---

## Quick Start

### First time setup

1. Build the .exes on a dev machine (see "Building .exe" below)
2. Choose your hub machine:
   - **Option A**: Dedicated mini-PC → copy `dist\MiniCentrinoLite_Hub\` to it
   - **Option B**: POS-1 → copy both `dist\MiniCentrinoLite_Hub\` AND `dist\MiniCentrinoLite\` to it
3. On the hub machine:
   - Open Windows Firewall → allow inbound TCP **9999**
   - Run `MiniCentrinoLite_Hub.exe`
4. On each POS machine:
   - Copy `dist\MiniCentrinoLite\` folder
   - Run `MiniCentrinoLite.exe --setup`
   - Set: Mode = `terminal`, Hub IP = hub machine's LAN IP, Terminal ID = 1/2/3
5. On each KDS machine:
   - Copy `dist\MiniCentrinoLite_KDS\` folder
   - Run `MiniCentrinoLite_KDS.exe --setup`
   - Set: Mode = `kds`, Hub IP = hub machine's LAN IP

### Run from source

```bash
pip install pywin32          # Windows thermal printing (optional)

python main.py --hub         # Hub service (run on hub machine)
python main.py               # POS terminal (run on each POS)
python main.py --kds         # KDS (run on each KDS)
python main.py --setup       # First-run setup wizard
```

---

## Building .exe (Windows)

```bash
pip install pyinstaller pywin32 pillow
build_windows.bat
```

Produces three builds:

- `dist\MiniCentrinoLite_Hub\MiniCentrinoLite_Hub.exe` → Hub service + admin UI
- `dist\MiniCentrinoLite\MiniCentrinoLite.exe` → POS terminal
- `dist\MiniCentrinoLite_KDS\MiniCentrinoLite_KDS.exe` → Kitchen display

No Python install needed on target machines — just copy the dist folder.

---

## v1.2 Checkout Flow (Packaging Checkbox)

1. Cashier adds items to cart (no Dine-in / Parcel toggle — single price)
2. Cashier hits **Ctrl+B** (or clicks Bill button)
3. **Checkout dialog** appears:
   - Item count + subtotal summary
   - **☐ Packaging required** checkbox (default unchecked)
   - Helper text: "Kitchen will plate this order" or "Kitchen will pack this order"
   - Continue / Cancel buttons
4. If checkbox is checked:
   - KOT card on KDS shows **"PACK"** badge
   - Bill prints **"Packaging: Yes"**
   - Kitchen packs the order
5. If unchecked:
   - KOT card shows **"PLATE"** (or table number)
   - Bill prints **"Packaging: No"**
   - Kitchen plates the order
6. Continue → standard payment dialog (Cash / Card / UPI / Split / Other)
7. Bill generated, printed, broadcast to hub → all POS see it live

### Optional: Packaging Charge

Configure in Hub Admin → Settings:
- **Mode**: `none` (default) / `fixed` / `per_item`
- **Amount**: amount in rupees

When "Packaging required" is checked at checkout:
- `none` → no extra charge
- `fixed` → add flat amount per order
- `per_item` → add amount × total quantity

---

## Menu Sync

Any POS can edit the menu (after PIN entry):
- Add new item → appears on all POS + KDS within ~1 sec
- Change price → all POS show new price immediately
- Delete item → disappears from all POS
- Toggle inactive (out of stock) → greyed out on all POS
- Add new section → new tab appears on all POS

Default PIN: `1234`. Change in Hub Admin → Settings → Menu PIN.

---

## Network Setup (Terminal ↔ Hub ↔ KDS)

```
┌──────────────────────┐         LAN / Wi-Fi          ┌─────────────────────┐
│   HUB MACHINE        │ ──────────────────────────── │   POS / KDS         │
│                      │                               │                     │
│  MiniCentrinoLite    │  TCP port 9999                │  MiniCentrinoLite   │
│  _Hub.exe            │ ◄── KOTs / bills / menu ──►   │  .exe or _KDS.exe   │
│                      │ ◄── status updates ──►        │                     │
│  IP: 192.168.1.10    │                               │  IP: 192.168.1.20+  │
└──────────────────────┘                               └─────────────────────┘
```

### Hub settings (Hub Admin → Settings):
- Hub Port: **9999** (firewall must allow this inbound)

### POS settings (POS Setup):
- Mode: `terminal`
- Hub IP: **192.168.1.10** (actual IP of hub machine)
- Hub Port: **9999**
- Terminal ID: **1** (unique per POS — 1, 2, 3 …)
- Terminal Name: `POS-1` (human-friendly)

### KDS settings (KDS Setup):
- Mode: `kds`
- Hub IP: **192.168.1.10**
- Hub Port: **9999**
- KDS Station ID: `KDS-01` (unique per KDS — KDS-01, KDS-02, KDS-03 …)

Multiple POS and KDS screens can connect simultaneously. All receive the same KOT stream.

---

## Thermal Printer Setup (Windows)

1. Install your 80mm thermal printer driver in Windows
2. Note the printer name from Devices & Printers
3. In Hub Admin → Settings → Printer Name → enter exact name
4. If left blank, the default Windows printer is used

**Fallback:** If no printer driver is found, a Notepad print dialog opens.

---

## Data Storage

All data stored locally on the hub machine:
- **Windows:** `C:\Users\<you>\AppData\Roaming\MiniCentrinoLite\data.db`
- **Linux/Mac:** `~/.mini_centrino_lite/data.db`

SQLite database — back up this file to preserve billing history.
Use Hub Admin → Settings → **Backup Database to File** for one-click backup.

---

## File Structure (v1.2)

```
mini_centrino_lite_v1.2/
├── main.py             # Launcher (--hub, --kds, --setup flags)
├── hub.py              # Hub service (TCP server + DB owner)        [NEW in v1.2]
├── hub_admin.py        # Hub admin UI (menu, reports, settings)     [NEW in v1.2]
├── pos_client.py       # POS → Hub client with auto-reconnect       [NEW in v1.2]
├── terminal.py         # Main POS GUI (orders, bills, reports, settings)
├── kds.py              # Kitchen Display System GUI
├── kds_launcher.py     # Entry point for KDS .exe build
├── database.py         # SQLite data layer + v1.2 migrations
├── menu_data.py        # Full Sudhamrit menu (single price, v1.2)
├── network.py          # HubServer + legacy TerminalServer + KDSClient
├── printer.py          # 80mm thermal formatting (PACK/PLATE badges)
├── pinelabs.py         # Pine Labs EDC integration
├── config.py           # Configuration management (v1.2 settings)
├── locales.py          # English / Hindi / Marathi translations
├── requirements.txt    # Python dependencies
├── build_windows.bat   # One-click .exe builder (3 exes)
├── Run_Hub.bat         # Launch hub service                    [NEW in v1.2]
├── Run_POS.bat         # Launch POS terminal
├── Run_KDS.bat         # Launch KDS
├── README.md           # This file
└── assets/icon.ico     # App icon
```

---

## Keyboard Shortcuts (Terminal)

| Key | Action |
|-----|--------|
| `Ctrl+K` | Generate KOT (with packaging checkbox prompt) |
| `Ctrl+B` | Generate Bill (shows packaging dialog → payment) |
| `Ctrl+N` | New / Clear order |
| `Esc` | Clear search |

---

## Bill / KOT Numbering (v1.2)

- Hub assigns bill numbers centrally — no collisions across POS
- Sequential across all POS: `#0001, #0002, #0003 …`
- Same for KOT numbers
- No more `terminal_id` prefix workaround needed

---

## Migration from v1.1 to v1.2

1. **Backup** your existing `data.db` (POS-1's database)
2. Stop all POS / KDS instances
3. Copy existing `data.db` to the hub machine's data directory
4. Install v1.2 builds on all machines (Hub, POS, KDS)
5. Run Hub first, then POS-1/2/3, then KDS-1/2/3
6. v1.2 migrations run automatically on first hub start:
   - Adds `price` column to `menu_items` (populated from middle of old dine-in/parcel)
   - Adds `packaging_required` column to `bills`, `kots`, `held_bills`
   - Creates `hub_sync_log` table
7. Old bills/KOTs display as before. New ones use the v1.2 schema.

---

## Roadmap (future versions)

- [x] v1.2: Multi-POS hub architecture
- [x] v1.2: Single price + packaging checkbox
- [x] v1.2: Live menu sync
- [x] v1.2: PIN-protected menu editing
- [x] v1.2: Hub admin UI
- [ ] v1.3: Offline mode (POS continues if hub dies, syncs on reconnect)
- [ ] v1.3: Customer display (pole display or second monitor)
- [ ] v1.3: Day-close / shift summary on hub
- [ ] v1.3: Item modifiers / special instructions
- [ ] v1.3: Inventory basic tracking
- [ ] v1.4: Cloud backup integration (optional)
- [ ] v1.4: Aggregator (Zomato/Swiggy) auto-import → packaging_required=True
- [ ] v2.0: Upgrade path to Mini Centrino

---

*Mini Centrino Lite v1.2.0 — Built for Sudhamrit Food Joint, Sri Ma Trust, Thane*
