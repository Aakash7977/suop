with open('terminal.py', 'r', encoding='utf-8') as f:
    lines = f.readlines()

for i, line in enumerate(lines):
    if 'def _build_meta' in line or '_build_meta' in line:
        safe_line = line.encode('ascii', errors='replace').decode('ascii').strip()
        print(f"{i+1}: {safe_line}")
