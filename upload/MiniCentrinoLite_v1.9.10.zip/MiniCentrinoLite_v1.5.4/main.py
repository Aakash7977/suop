"""
Mini Centrino Lite v1.2 — Launcher

Usage:
  python main.py            → Main terminal (POS) — client of hub
  python main.py --kds      → Kitchen Display System — client of hub
  python main.py --hub      → Hub service (run on hub machine, dedicated or POS-1)
  python main.py --hub --headless  → Hub service without admin UI (system service)
  python main.py --setup    → First-time setup wizard

On Windows after building:
  MiniCentrinoLite.exe          → Terminal (POS)
  MiniCentrinoLite.exe --kds    → KDS
  MiniCentrinoLite.exe --hub    → Hub
  MiniCentrinoLite_Hub.exe      → Hub (standalone build)
  MiniCentrinoLite_KDS.exe      → KDS
"""
import sys, tkinter as tk, tkinter.messagebox as mb
from config import CFG, save as save_config

APP_NAME    = "Mini Centrino Lite"
APP_VERSION = "1.5.6"
BUILD_FOR   = "Sudhamrit Food Joint | Sri Ma Trust"

# ─────────────────────────────── Splash screen ──────────────

def _show_splash(root: tk.Tk, subtitle: str = None):
    """Show branded splash while app loads, auto-destroy after 1.3 s."""
    splash = tk.Toplevel(root)
    splash.overrideredirect(True)
    splash.configure(bg="#1A0A00")
    w, h = 460, 200
    sw = root.winfo_screenwidth()
    sh = root.winfo_screenheight()
    splash.geometry(f"{w}x{h}+{(sw-w)//2}+{(sh-h)//2}")
    tk.Label(splash, text=APP_NAME,
             font=("Segoe UI", 22, "bold"),
             bg="#1A0A00", fg="#FFD700").pack(expand=True, pady=(30, 4))
    sub = subtitle or f"v{APP_VERSION}  •  {BUILD_FOR}"
    tk.Label(splash, text=sub,
             font=("Segoe UI", 9), bg="#1A0A00", fg="#AAAA66").pack(pady=(0, 20))
    splash.update()
    splash.after(1300, splash.destroy)

# ─────────────────────────────── Launchers ──────────────────

def launch_terminal():
    root = tk.Tk()
    root.withdraw()                       # hide until app is ready
    _try_icon(root)
    _show_splash(root, f"v{APP_VERSION}  •  POS Terminal")
    root.after(1350, lambda: _open_terminal(root))
    root.mainloop()

def _open_terminal(root: tk.Tk):
    from terminal import TerminalApp
    root.deiconify()
    app = TerminalApp(root)
    root.protocol("WM_DELETE_WINDOW", lambda: _on_close(root, app))

def launch_kds():
    from kds import KDSApp
    root = tk.Tk()
    if "--fullscreen" in sys.argv:
        root.attributes("-fullscreen", True)
    _try_icon(root)
    app = KDSApp(root)
    root.protocol("WM_DELETE_WINDOW", root.destroy)
    root.mainloop()

def launch_hub():
    """v1.2: Launch the Hub service (with admin UI by default)."""
    headless = "--headless" in sys.argv
    from hub import launch_hub as _launch
    _launch(headless=headless)

def launch_setup():
    """First-run / reconfigure dialog."""
    import tkinter.ttk as ttk
    root = tk.Tk()
    root.title(f"{APP_NAME} — Setup")
    root.geometry("560x560")
    root.resizable(False, False)
    _try_icon(root)

    tk.Label(root, text=f"Welcome to {APP_NAME}",
             font=("Segoe UI", 14, "bold"), pady=10).pack()
    tk.Label(root, text=f"{BUILD_FOR}  •  v{APP_VERSION}",
             font=("Segoe UI", 9), fg="gray").pack()

    frm = tk.Frame(root, pady=10)
    frm.pack()
    fields = [
        ("Restaurant Name",          "restaurant_name"),
        ("Address",                  "restaurant_address"),
        ("Terminal ID (1-99)",       "terminal_id"),
        ("Terminal Name (POS-1)",    "terminal_name"),
        ("KDS Station ID (KDS-01)",  "kds_station_id"),
        ("Mode",                     "mode"),
        ("Hub IP  (for POS/KDS)",    "hub_ip"),
        ("Hub Port",                 "hub_port"),
        ("Menu PIN",                 "menu_pin"),
        ("UI Layout Scale",          "ui_scale"),
    ]
    vars_: dict[str, tk.Variable] = {}
    for label, key in fields:
        row = tk.Frame(frm)
        row.pack(fill=tk.X, pady=3)
        tk.Label(row, text=label, width=28, anchor=tk.E).pack(side=tk.LEFT, padx=6)
        if key == "mode":
            v = tk.StringVar(value=CFG.get(key, "terminal"))
            ttk.Combobox(row, textvariable=v,
                         values=["terminal", "kds", "hub"], width=20).pack(side=tk.LEFT)
        elif key == "ui_scale":
            v = tk.StringVar(value=CFG.get(key, "auto"))
            ttk.Combobox(row, textvariable=v,
                         values=["auto", "standard", "compact"], width=20).pack(side=tk.LEFT)
        else:
            v = tk.StringVar(value=str(CFG.get(key, "")))
            tk.Entry(row, textvariable=v, width=24).pack(side=tk.LEFT)
        vars_[key] = v

    def save_and_launch():
        for key, var in vars_.items():
            val = var.get().strip()
            if key in ("hub_port", "server_port", "kds_terminal_port", "terminal_id"):
                try:
                    CFG[key] = int(val)
                except ValueError:
                    pass
            else:
                CFG[key] = val
        CFG["setup_done"] = True   # v1.2.1: mark setup as complete
        save_config(CFG)
        root.destroy()
        mode = CFG.get("mode", "terminal")
        if mode == "kds":
            launch_kds()
        elif mode == "hub":
            launch_hub()
        else:
            launch_terminal()

    tk.Button(root, text="Launch", font=("Segoe UI", 11, "bold"),
              bg="#6B2E00", fg="white", relief=tk.FLAT,
              padx=24, pady=8, command=save_and_launch).pack(pady=16)

    # Help text
    help_txt = tk.Label(root, text=(
        "v1.2 HUB ARCHITECTURE\n"
        "• Run 'hub' mode on the hub machine (dedicated mini-PC or POS-1)\n"
        "• Run 'terminal' mode on each POS — set Hub IP to hub machine's LAN IP\n"
        "• Run 'kds' mode on each KDS — set Hub IP to hub machine's LAN IP\n"
        "• All POS see all orders live. Menu changes sync automatically.\n"
        "• Menu edits require PIN (default 1234)\n\n"
        "v1.2.1 — Setup will run automatically on first launch\n"
        "of any mode (Hub / POS / KDS) until you complete this wizard."
    ), font=("Segoe UI", 9), fg="gray", justify=tk.LEFT)
    help_txt.pack(pady=8)

    root.mainloop()

# ─────────────────────────────── Helpers ────────────────────

def _try_icon(root: tk.Tk):
    try:
        root.iconbitmap("assets/icon.ico")
    except Exception:
        pass

def _on_close(root: tk.Tk, app):
    if mb.askyesno("Exit", "Close Mini Centrino Lite?"):
        try:
            if hasattr(app, "server") and app.server:
                app.server.stop()
        except Exception:
            pass
        try:
            if hasattr(app, "terminal_client") and app.terminal_client:
                app.terminal_client.stop()
        except Exception:
            pass
        try:
            if hasattr(app, "pos_client") and app.pos_client:
                app.pos_client.stop()
        except Exception:
            pass
        try:
            if hasattr(app, "agg_server") and app.agg_server:
                app.agg_server.shutdown()
        except Exception:
            pass
        root.destroy()

# ─────────────────────────────── Entry point ────────────────

if __name__ == "__main__":
    if "--hub" in sys.argv:
        # v1.2.1: Hub also needs setup if not done
        if not CFG.get("setup_done", False) and "--setup" not in sys.argv:
            launch_setup()
        else:
            launch_hub()
    elif "--kds" in sys.argv:
        # v1.2.1: KDS also needs setup if not done
        if not CFG.get("setup_done", False) and "--setup" not in sys.argv:
            launch_setup()
        else:
            launch_kds()
    elif "--setup" in sys.argv:
        launch_setup()
    else:
        mode = CFG.get("mode", "terminal")
        # v1.2.1: Auto-route to setup on first run
        if not CFG.get("setup_done", False) and mode != "setup":
            launch_setup()
        elif mode == "kds":
            launch_kds()
        elif mode == "hub":
            launch_hub()
        elif mode == "setup":
            launch_setup()
        else:
            launch_terminal()
