"""
Mini Centrino Lite v1.2 — Hub Admin UI

The admin UI that runs on the hub machine (alongside the hub service).
Provides:
  - Dashboard (live counts: connected clients, today's bills/KOTs, revenue)
  - Menu Manager (add/edit/delete items, change prices — broadcasts to all POS)
  - Reports (combined revenue from all POS, item-wise sales)
  - Held Bills overview (recall any held bill from any POS)
  - Day-close summary
  - Settings (restaurant info, GST, packaging charge, PIN, etc.)
  - Backup DB to file
  - Live KOT Monitor (read-only — see all kitchen orders across all POS)
  - User management (placeholder — set menu PIN)
"""
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog, filedialog
import datetime, shutil, threading, os

from config import CFG, save as save_config, APP_VERSION, APP_NAME, BUILD_FOR
import database as db
from locales import t


# Hub admin color palette (dark amber, similar to terminal but darker)
HC = {
    "bg":        "#1F1410",
    "panel":     "#2A1B14",
    "header":    "#3D2410",
    "header_fg": "#FFD700",
    "accent":    "#E65C00",
    "text":      "#FFF8F0",
    "muted":     "#AAAA66",
    "border":    "#5A3A20",
    "ok":        "#1E6B1E",
    "warn":      "#D48B06",
    "err":       "#AA2020",
    "row_alt":   "#332218",
}

HFONT_TITLE  = ("Segoe UI", 14, "bold")
HFONT_H2     = ("Segoe UI", 11, "bold")
HFONT_BOLD   = ("Segoe UI", 10, "bold")
HFONT_NORMAL = ("Segoe UI", 10)
HFONT_SMALL  = ("Segoe UI", 9)
HFONT_MONO   = ("Courier New", 10)


class HubAdminApp:
    def __init__(self, root: tk.Tk, hub_service):
        self.root = root
        self.hub = hub_service

        # Window setup
        if os.name == 'nt':
            self.root.state('zoomed')
        else:
            self.root.geometry("1280x780")
        self.root.minsize(1100, 700)
        self.root.configure(bg=HC["bg"])

        try:
            self.root.iconbitmap("assets/icon.ico")
        except Exception:
            pass

        self._build_ui()
        self._tick()  # start refresh loop

    # ─────────────────────────────────── UI scaffolding ──────────

    def _build_ui(self):
        if hasattr(self, "main_container") and self.main_container:
            try: self.main_container.destroy()
            except: pass
        self.main_container = tk.Frame(self.root, bg=HC["bg"])
        self.main_container.pack(fill=tk.BOTH, expand=True)

        # Header
        hdr = tk.Frame(self.main_container, bg=HC["header"], height=56)
        hdr.pack(side=tk.TOP, fill=tk.X)
        hdr.pack_propagate(False)
        tk.Label(hdr, text=f"{APP_NAME}  •  Hub Admin",
                 font=HFONT_TITLE, bg=HC["header"], fg=HC["header_fg"]).pack(side=tk.LEFT, padx=12)
        tk.Label(hdr, text=f"v{APP_VERSION}  •  {BUILD_FOR}",
                 font=HFONT_SMALL, bg=HC["header"], fg=HC["muted"]).pack(side=tk.LEFT, padx=8)

        self._status_lbl = tk.Label(hdr, text="● 0 clients",
                                     font=HFONT_NORMAL, bg=HC["header"], fg="#FFAA44")
        self._status_lbl.pack(side=tk.RIGHT, padx=12)

        # Tab bar
        # v1.3.1 fix: Use 'clam' theme explicitly — the default Windows theme
        # ('vista' / 'winnative') does NOT honor custom ttk.Style colors,
        # leaving tab text invisible (white-on-white). 'clam' is cross-platform
        # and respects all style customizations.
        style = ttk.Style()
        try:
            style.theme_use('clam')
        except Exception:
            pass  # fall back to default if 'clam' not available
        self.tabs = ttk.Notebook(self.main_container)
        self.tabs.pack(fill=tk.BOTH, expand=True, padx=8, pady=8)
        # Apply tab styling AFTER switching to clam theme
        style.configure("TNotebook", background=HC["bg"], borderwidth=0, tabmargins=(2, 5, 2, 0))
        style.configure("TNotebook.Tab",
                        background=HC["panel"],
                        foreground=HC["text"],
                        padding=(18, 10),
                        font=HFONT_NORMAL,
                        borderwidth=0)
        style.map("TNotebook.Tab",
                  background=[("selected", HC["accent"]),
                              ("active", HC["header"])],
                  foreground=[("selected", "white"),
                              ("active", "white")])
        # v1.3.1: Style Treeview (used in Menu / KOT / Held Bills tabs) so it
        # shows white text on dark background — default ttk.Treeview is white
        # background with black text, which is fine, but headings need styling.
        style.configure("Treeview",
                        background=HC["panel"],
                        foreground=HC["text"],
                        fieldbackground=HC["panel"],
                        borderwidth=0,
                        font=HFONT_NORMAL,
                        rowheight=24)
        style.configure("Treeview.Heading",
                        background=HC["header"],
                        foreground=HC["header_fg"],
                        font=HFONT_BOLD,
                        padding=(6, 6),
                        borderwidth=0)
        style.map("Treeview",
                  background=[("selected", HC["accent"])],
                  foreground=[("selected", "white")])
        style.map("Treeview.Heading",
                  background=[("active", HC["accent"])])
        # Style ttk.Combobox, Entry, Button for dark theme
        style.configure("TCombobox",
                        background=HC["panel"],
                        foreground=HC["text"],
                        fieldbackground=HC["panel"],
                        arrowcolor=HC["header_fg"],
                        padding=4)
        style.configure("TEntry",
                        background=HC["panel"],
                        foreground=HC["text"],
                        fieldbackground=HC["panel"],
                        padding=4)
        style.configure("TButton",
                        background=HC["header"],
                        foreground="white",
                        padding=(10, 6),
                        font=HFONT_NORMAL,
                        borderwidth=0)
        style.map("TButton",
                  background=[("active", HC["accent"])])

        # Build each tab
        self._build_dashboard_tab()
        self._build_menu_tab()
        self._build_kot_monitor_tab()
        self._build_reports_tab()
        self._build_held_bills_tab()
        self._build_backup_tab()
        self._build_settings_tab()

    # ─────────────────────────────────── Dashboard tab ───────────

    def _build_dashboard_tab(self):
        self.dash = tk.Frame(self.tabs, bg=HC["bg"])
        self.tabs.add(self.dash, text=t("Dashboard", "Dashboard"))

        top = tk.Frame(self.dash, bg=HC["bg"])
        top.pack(fill=tk.X, padx=12, pady=12)

        self._dash_cards = {}
        for key, label, color in [
            ("clients", "Connected Clients", HC["accent"]),
            ("bills",   "Bills Today",        HC["ok"]),
            ("kots",    "KOTs Today",         HC["warn"]),
            ("revenue", "Revenue Today",      HC["header_fg"]),
        ]:
            card = tk.Frame(top, bg=HC["panel"], bd=1, relief=tk.SOLID,
                            highlightbackground=color, highlightthickness=2)
            card.pack(side=tk.LEFT, padx=8, expand=True, fill=tk.X)
            tk.Label(card, text=label, font=HFONT_SMALL, bg=HC["panel"], fg=HC["muted"]).pack(pady=(12, 0))
            self._dash_cards[key] = tk.Label(card, text="—", font=("Segoe UI", 22, "bold"),
                                              bg=HC["panel"], fg=color)
            self._dash_cards[key].pack(pady=(4, 12))

        # Status panel
        bot = tk.Frame(self.dash, bg=HC["bg"])
        bot.pack(fill=tk.BOTH, expand=True, padx=12, pady=8)

        tk.Label(bot, text=t("Hub Status", "Hub Status"), font=HFONT_H2,
                 bg=HC["bg"], fg=HC["text"]).pack(anchor=tk.W)
        self._status_text = tk.Text(bot, height=12, bg=HC["panel"], fg=HC["text"],
                                    font=HFONT_MONO, relief=tk.FLAT, padx=12, pady=8)
        self._status_text.pack(fill=tk.BOTH, expand=True, pady=6)

    def _refresh_dashboard(self):
        # Update client count
        if self.hub and self.hub.server:
            n = self.hub.server.client_count
            self._status_lbl.config(text=f"● {n} clients",
                                     fg="#AAFFAA" if n > 0 else "#FFAA44")
            self._dash_cards["clients"].config(text=str(n))

        # Today's stats
        try:
            bills = db.get_all_bills_today()
            kots  = db.get_all_kots_today()
            revenue = sum(b.get("total", 0) for b in bills if not b.get("pl_voided", 0))
            self._dash_cards["bills"].config(text=str(len(bills)))
            self._dash_cards["kots"].config(text=str(len(kots)))
            self._dash_cards["revenue"].config(text=f"₹{revenue:.0f}")
        except Exception as e:
            print(f"[dashboard refresh] {e}")

        # Status text
        if hasattr(self, "_status_text"):
            lines = []
            lines.append(f"Hub Service: {'RUNNING' if self.hub and self.hub._running else 'STOPPED'}")
            lines.append(f"Listening on: {self.hub.host}:{self.hub.port}" if self.hub else "")
            lines.append(f"Database: {db.DB_PATH}")
            lines.append("")
            lines.append(f"Connected clients: {self.hub.server.client_count if self.hub and self.hub.server else 0}")
            lines.append("")
            lines.append(f"Today's date: {datetime.date.today().isoformat()}")
            lines.append(f"Last refresh: {datetime.datetime.now().strftime('%H:%M:%S')}")
            self._status_text.config(state=tk.NORMAL)
            self._status_text.delete("1.0", tk.END)
            self._status_text.insert("1.0", "\n".join(lines))
            self._status_text.config(state=tk.DISABLED)

    # ─────────────────────────────────── Menu Manager tab ────────

    def _build_menu_tab(self):
        self.menu_tab = tk.Frame(self.tabs, bg=HC["bg"])
        self.tabs.add(self.menu_tab, text=t("Menu Manager", "Menu Manager"))

        # Top toolbar
        tb = tk.Frame(self.menu_tab, bg=HC["bg"])
        tb.pack(fill=tk.X, padx=8, pady=6)
        tk.Label(tb, text=t("Section:", "Section:"), font=HFONT_NORMAL,
                 bg=HC["bg"], fg=HC["text"]).pack(side=tk.LEFT)
        self._menu_sec_var = tk.StringVar()
        self._menu_sec_cb = ttk.Combobox(tb, textvariable=self._menu_sec_var, width=25, state="readonly")
        self._menu_sec_cb.pack(side=tk.LEFT, padx=8)
        self._menu_sec_cb.bind("<<ComboboxSelected>>", lambda e: self._refresh_menu_items())

        tk.Button(tb, text=t("+ Add Item", "+ Add Item"), font=HFONT_NORMAL,
                  bg=HC["accent"], fg="white", relief=tk.FLAT, padx=10, pady=4,
                  command=self._add_item_dialog).pack(side=tk.LEFT, padx=4)
        tk.Button(tb, text=t("+ Add Section", "+ Add Section"), font=HFONT_NORMAL,
                  bg=HC["panel"], fg=HC["text"], relief=tk.FLAT, padx=10, pady=4,
                  command=self._add_section_dialog).pack(side=tk.LEFT, padx=4)
        tk.Button(tb, text=t("Refresh", "Refresh"), font=HFONT_NORMAL,
                  bg=HC["panel"], fg=HC["text"], relief=tk.FLAT, padx=10, pady=4,
                  command=self._refresh_menu_items).pack(side=tk.LEFT, padx=4)

        # Items tree
        cols = ("id", "name", "price", "code", "active")
        tree_frame = tk.Frame(self.menu_tab, bg=HC["bg"])
        tree_frame.pack(fill=tk.BOTH, expand=True, padx=8, pady=6)
        self._menu_tree = ttk.Treeview(tree_frame, columns=cols, show="headings", height=20)
        for c, w in zip(cols, (60, 350, 80, 80, 80)):
            self._menu_tree.heading(c, text=t(c.capitalize(), c.capitalize()))
            self._menu_tree.column(c, width=w, anchor=tk.W if c != "price" else tk.E)
        self._menu_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        # Vert scrollbar
        sb = ttk.Scrollbar(tree_frame, orient=tk.VERTICAL, command=self._menu_tree.yview)
        self._menu_tree.configure(yscrollcommand=sb.set)
        sb.pack(side=tk.RIGHT, fill=tk.Y)

        # Context menu (right-click)
        self._ctx = tk.Menu(self.menu_tab, tearoff=0)
        self._ctx.add_command(label="Edit Price", command=self._edit_price)
        self._ctx.add_command(label="Edit Item", command=self._edit_item_dialog)
        self._ctx.add_command(label="Toggle Active", command=self._toggle_active)
        self._ctx.add_separator()
        self._ctx.add_command(label="Delete Item", command=self._delete_item)
        self._menu_tree.bind("<Button-3>", self._on_tree_right_click)

        # Action buttons below
        bb = tk.Frame(self.menu_tab, bg=HC["bg"])
        bb.pack(fill=tk.X, padx=8, pady=6)
        tk.Button(bb, text="Edit Price", font=HFONT_NORMAL,
                  bg=HC["accent"], fg="white", relief=tk.FLAT, padx=12, pady=4,
                  command=self._edit_price).pack(side=tk.LEFT, padx=4)
        tk.Button(bb, text="Toggle Active", font=HFONT_NORMAL,
                  bg=HC["panel"], fg=HC["text"], relief=tk.FLAT, padx=12, pady=4,
                  command=self._toggle_active).pack(side=tk.LEFT, padx=4)
        tk.Button(bb, text="Delete", font=HFONT_NORMAL,
                  bg=HC["err"], fg="white", relief=tk.FLAT, padx=12, pady=4,
                  command=self._delete_item).pack(side=tk.LEFT, padx=4)

        # Populate sections dropdown
        self._refresh_menu_sections()

    def _refresh_menu_sections(self):
        sections = db.get_sections_db()
        names = [s["name"] for s in sections]
        self._menu_sec_cb["values"] = names
        if names and not self._menu_sec_var.get():
            self._menu_sec_var.set(names[0])
            self._refresh_menu_items()

    def _refresh_menu_items(self):
        for it in self._menu_tree.get_children():
            self._menu_tree.delete(it)
        sec_name = self._menu_sec_var.get()
        if not sec_name:
            return
        sections = db.get_sections_db()
        sec_id = None
        for s in sections:
            if s["name"] == sec_name:
                sec_id = s["id"]
                break
        if sec_id is None:
            return
        items = db.get_items_for_section(sec_id)
        for it in items:
            self._menu_tree.insert("", tk.END, values=(
                it["id"], it["name"],
                it.get("price") or it.get("dine_in_price") or 0,
                it.get("code") or "",
                "Yes" if it.get("is_active") else "No"
            ))

    def _on_tree_right_click(self, event):
        item = self._menu_tree.identify_row(event.y)
        if item:
            self._menu_tree.selection_set(item)
            self._ctx.post(event.x_root, event.y_root)

    def _selected_item_id(self):
        sel = self._menu_tree.selection()
        if not sel:
            messagebox.showwarning("No selection", "Please select an item first.")
            return None
        return int(self._menu_tree.item(sel[0])["values"][0])

    def _add_section_dialog(self):
        name = simpledialog.askstring("Add Section", "New section name:")
        if name and name.strip():
            db.add_section(name.strip())
            # Broadcast to all POS
            self._broadcast_menu_update("add_section", {"name": name.strip()})
            self._refresh_menu_sections()
            messagebox.showinfo("Added", f"Section '{name}' added and synced to all POS.")

    def _add_item_dialog(self):
        sec_name = self._menu_sec_var.get()
        if not sec_name:
            messagebox.showwarning("No section", "Pick a section first.")
            return
        name = simpledialog.askstring("Add Item", f"Item name (in {sec_name}):")
        if not name or not name.strip():
            return
        price_str = simpledialog.askstring("Price", "Item price (Rs.):", initialvalue="0")
        try:
            price = int(float(price_str))
        except (ValueError, TypeError):
            messagebox.showerror("Invalid price", "Price must be a number.")
            return
        # Find section id
        sections = db.get_sections_db()
        sec_id = next((s["id"] for s in sections if s["name"] == sec_name), None)
        if sec_id is None:
            return
        item_id = db.add_item(sec_id, name.strip(), price=price)
        # Broadcast
        self._broadcast_menu_update("add_item", {
            "section": sec_name, "name": name.strip(), "price": price
        })
        self._refresh_menu_items()
        messagebox.showinfo("Added", f"'{name}' added at Rs.{price} and synced to all POS.")

    def _edit_price(self):
        item_id = self._selected_item_id()
        if item_id is None:
            return
        new_price_str = simpledialog.askstring("Edit Price", "New price (Rs.):")
        try:
            new_price = int(float(new_price_str))
        except (ValueError, TypeError):
            messagebox.showerror("Invalid price", "Price must be a number.")
            return
        db.update_item_price(item_id, new_price)
        self._broadcast_menu_update("price_change", {"item_id": item_id, "new_price": new_price})
        self._refresh_menu_items()
        messagebox.showinfo("Updated", f"Price updated to Rs.{new_price} and synced to all POS.")

    def _edit_item_dialog(self):
        item_id = self._selected_item_id()
        if item_id is None:
            return
        new_name = simpledialog.askstring("Edit Name", "New item name:")
        if not new_name:
            return
        new_price_str = simpledialog.askstring("Edit Price", "New price (Rs.):")
        try:
            new_price = int(float(new_price_str))
        except (ValueError, TypeError):
            return
        db.update_item(item_id, new_name.strip(), price=new_price)
        self._broadcast_menu_update("price_change", {"item_id": item_id, "new_price": new_price})
        self._refresh_menu_items()

    def _toggle_active(self):
        item_id = self._selected_item_id()
        if item_id is None:
            return
        # Find current state
        sections = db.get_sections_db()
        for s in sections:
            for it in db.get_items_for_section(s["id"]):
                if it["id"] == item_id:
                    new_active = 0 if it["is_active"] else 1
                    db.toggle_item_active(item_id, new_active)
                    self._broadcast_menu_update("toggle_active",
                                                {"item_id": item_id, "is_active": new_active})
                    self._refresh_menu_items()
                    return

    def _delete_item(self):
        item_id = self._selected_item_id()
        if item_id is None:
            return
        if not messagebox.askyesno("Confirm", "Delete this item? This cannot be undone."):
            return
        db.delete_item(item_id)
        self._broadcast_menu_update("delete_item", {"item_id": item_id})
        self._refresh_menu_items()

    def _broadcast_menu_update(self, action: str, payload: dict):
        """Send a menu_update to all connected POS and KDS clients."""
        if self.hub and self.hub.server:
            self.hub.server.broadcast({"type": "menu_update", "action": action, "payload": payload})

    # ─────────────────────────────────── KOT Monitor tab ─────────

    def _build_kot_monitor_tab(self):
        self.kot_tab = tk.Frame(self.tabs, bg=HC["bg"])
        self.tabs.add(self.kot_tab, text=t("KOT Monitor", "KOT Monitor"))

        tk.Label(self.kot_tab, text="Live KOT Monitor (read-only across all POS)",
                 font=HFONT_H2, bg=HC["bg"], fg=HC["muted"]).pack(anchor=tk.W, padx=12, pady=6)

        cols = ("kot_no", "terminal", "table", "items", "status", "time")
        tree_frame = tk.Frame(self.kot_tab, bg=HC["bg"])
        tree_frame.pack(fill=tk.BOTH, expand=True, padx=8, pady=6)
        self._kot_tree = ttk.Treeview(tree_frame, columns=cols, show="headings", height=20)
        for c, w in zip(cols, (70, 80, 80, 400, 100, 80)):
            self._kot_tree.heading(c, text=t(c.replace("_", " ").title(), c.replace("_", " ").title()))
            self._kot_tree.column(c, width=w, anchor=tk.W)
        self._kot_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        sb = ttk.Scrollbar(tree_frame, orient=tk.VERTICAL, command=self._kot_tree.yview)
        self._kot_tree.configure(yscrollcommand=sb.set)
        sb.pack(side=tk.RIGHT, fill=tk.Y)

    def _refresh_kot_monitor(self):
        if not hasattr(self, "_kot_tree"):
            return
        for it in self._kot_tree.get_children():
            self._kot_tree.delete(it)
        kots = db.get_all_kots_today()
        for k in kots:
            items_summary = ", ".join(
                f"{it.get('item_name','')}×{it.get('quantity') or it.get('qty',1)}"
                for it in k.get("items", [])
            )[:80]
            self._kot_tree.insert("", tk.END, values=(
                k.get("kot_no", ""),
                f"T{k.get('terminal_id', 1)}",
                k.get("table_no", "") or "—",
                items_summary,
                k.get("status", "pending"),
                k.get("time", "")
            ))

    # ─────────────────────────────────── Reports tab ─────────────

    def _build_reports_tab(self):
        self.rep_tab = tk.Frame(self.tabs, bg=HC["bg"])
        self.tabs.add(self.rep_tab, text=t("Reports", "Reports"))

        top = tk.Frame(self.rep_tab, bg=HC["bg"])
        top.pack(fill=tk.X, padx=12, pady=8)
        tk.Label(top, text="Date:", font=HFONT_NORMAL,
                 bg=HC["bg"], fg=HC["text"]).pack(side=tk.LEFT)
        # v1.3.1: Default to DD/MM/YYYY format (matches how bills are saved)
        import datetime as _dt
        self._rep_date_var = tk.StringVar(value=_dt.date.today().strftime("%d/%m/%Y"))
        tk.Entry(top, textvariable=self._rep_date_var, width=14,
                 font=HFONT_NORMAL).pack(side=tk.LEFT, padx=6)
        tk.Label(top, text="(DD/MM/YYYY)", font=HFONT_SMALL,
                 bg=HC["bg"], fg=HC["muted"]).pack(side=tk.LEFT, padx=2)
        tk.Button(top, text="Generate", font=HFONT_NORMAL,
                  bg=HC["accent"], fg="white", relief=tk.FLAT, padx=12, pady=4,
                  command=self._generate_report).pack(side=tk.LEFT, padx=6)

        # Report text area
        self._rep_text = tk.Text(self.rep_tab, bg=HC["panel"], fg=HC["text"],
                                 font=HFONT_MONO, relief=tk.FLAT, padx=12, pady=12)
        self._rep_text.pack(fill=tk.BOTH, expand=True, padx=8, pady=6)

    def _generate_report(self):
        date = self._rep_date_var.get().strip()
        if not date:
            return
        # v1.3.1 fix: Bills are saved with date format DD/MM/YYYY (db.today()).
        # If user typed ISO format (YYYY-MM-DD), convert it. Otherwise pass through.
        if len(date) == 10 and date[4] == '-' and date[7] == '-':
            # ISO format → DD/MM/YYYY
            try:
                import datetime as _dt
                d = _dt.date.fromisoformat(date)
                date = d.strftime("%d/%m/%Y")
            except Exception:
                pass
        try:
            rpt = db.daily_report(date)
            # v1.3.1 fix: also fetch item-wise sales
            items = db.get_item_sales_report(date)
            rpt['items'] = items
        except Exception as e:
            messagebox.showerror("Report error", str(e))
            return
        self._rep_text.config(state=tk.NORMAL)
        self._rep_text.delete("1.0", tk.END)
        lines = [
            f"DAILY SALES REPORT  —  {date}",
            "=" * 60,
            f"Bills issued    : {rpt.get('bills', 0)}",
            f"KOTs raised     : {rpt.get('kots', 0)}",
            f"Voided bills    : {rpt.get('voided', 0)}",
            "-" * 60,
            f"Gross revenue   : Rs. {rpt.get('total', 0):.2f}",
            f"GST collected   : Rs. {rpt.get('gst', 0):.2f}",
            f"Net subtotal    : Rs. {rpt.get('subtotal', 0):.2f}",
            "-" * 60,
            f"Cash sales      : Rs. {rpt.get('cash', 0):.2f}",
            f"Card/UPI sales  : Rs. {rpt.get('card', 0):.2f}",
            "",
            "ITEM-WISE SALES",
            "-" * 60,
        ]
        for it in rpt.get("items", []):
            lines.append(f"{it['item_name']:<30} {it['quantity']:>4}  Rs. {it['amount']:>8.2f}")
        if not rpt.get("items"):
            lines.append("(no item sales recorded for this date)")
        lines.append("=" * 60)
        self._rep_text.insert("1.0", "\n".join(lines))
        self._rep_text.config(state=tk.DISABLED)

    # ─────────────────────────────────── Held Bills tab ──────────

    def _build_held_bills_tab(self):
        self.held_tab = tk.Frame(self.tabs, bg=HC["bg"])
        self.tabs.add(self.held_tab, text=t("Held Bills", "Held Bills"))

        tk.Label(self.held_tab, text="All held bills across all POS terminals",
                 font=HFONT_H2, bg=HC["bg"], fg=HC["muted"]).pack(anchor=tk.W, padx=12, pady=6)

        cols = ("id", "date", "time", "table", "customer", "total", "terminal")
        tree_frame = tk.Frame(self.held_tab, bg=HC["bg"])
        tree_frame.pack(fill=tk.BOTH, expand=True, padx=8, pady=6)
        self._held_tree = ttk.Treeview(tree_frame, columns=cols, show="headings", height=15)
        for c, w in zip(cols, (60, 100, 80, 80, 200, 100, 80)):
            self._held_tree.heading(c, text=t(c.capitalize(), c.capitalize()))
            self._held_tree.column(c, width=w, anchor=tk.W)
        self._held_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        sb = ttk.Scrollbar(tree_frame, orient=tk.VERTICAL, command=self._held_tree.yview)
        self._held_tree.configure(yscrollcommand=sb.set)
        sb.pack(side=tk.RIGHT, fill=tk.Y)

    def _refresh_held_bills(self):
        if not hasattr(self, "_held_tree"):
            return
        for it in self._held_tree.get_children():
            self._held_tree.delete(it)
        try:
            held = db.get_held_bills()
            for h in held:
                self._held_tree.insert("", tk.END, values=(
                    h.get("id", ""), h.get("date", ""), h.get("time", ""),
                    h.get("table_no", "") or "—", h.get("customer_name", "") or "—",
                    f"Rs.{h.get('total', 0):.2f}", f"T{h.get('terminal_id', 1)}"
                ))
        except Exception as e:
            print(f"[held bills refresh] {e}")

    # ─────────────────────────────────── Backup tab (v1.5.3) ──────

    def _build_backup_tab(self):
        """v1.5.3: Auto-backup management tab."""
        self.bak_tab = tk.Frame(self.tabs, bg=HC["bg"])
        self.tabs.add(self.bak_tab, text=t("Backup", "Backup"))

        # Header
        tk.Label(self.bak_tab, text=t("Automatic Database Backup", "Automatic Database Backup"),
                 font=HFONT_H2, bg=HC["bg"], fg=HC["header_fg"]).pack(anchor=tk.W, padx=12, pady=(12, 4))
        tk.Label(self.bak_tab,
                 text=t("Hub automatically backs up data.db every 24 hours (configurable).\n"
                        "Backups are kept for 30 days (older ones auto-deleted).",
                        "Hub automatically backs up data.db every 24 hours (configurable).\n"
                        "Backups are kept for 30 days (older ones auto-deleted)."),
                 font=HFONT_NORMAL, bg=HC["bg"], fg=HC["muted"], justify=tk.LEFT
                 ).pack(anchor=tk.W, padx=12, pady=(0, 8))

        # Status panel
        status_frm = tk.Frame(self.bak_tab, bg=HC["panel"], bd=1, relief=tk.SOLID)
        status_frm.pack(fill=tk.X, padx=12, pady=6)
        self._bak_status_lbl = tk.Label(status_frm, text="Loading...",
                                         font=HFONT_NORMAL, bg=HC["panel"], fg=HC["text"],
                                         anchor=tk.W, justify=tk.LEFT, padx=12, pady=10)
        self._bak_status_lbl.pack(fill=tk.X)

        # Settings panel
        set_frm = tk.Frame(self.bak_tab, bg=HC["panel"], bd=1, relief=tk.SOLID)
        set_frm.pack(fill=tk.X, padx=12, pady=6)

        tk.Label(set_frm, text=t("Backup Settings", "Backup Settings"),
                 font=HFONT_BOLD, bg=HC["panel"], fg=HC["header_fg"]
                 ).grid(row=0, column=0, columnspan=3, sticky=tk.W, padx=12, pady=(10, 4))

        # Auto-backup enabled checkbox
        tk.Label(set_frm, text=t("Enable auto-backup", "Enable auto-backup"),
                 font=HFONT_NORMAL, bg=HC["panel"], fg=HC["text"]
                 ).grid(row=1, column=0, sticky=tk.W, padx=12, pady=4)
        self._bak_enabled_var = tk.IntVar(value=1 if CFG.get("auto_backup_enabled", True) else 0)
        tk.Checkbutton(set_frm, variable=self._bak_enabled_var,
                       bg=HC["panel"], fg=HC["text"],
                       selectcolor=HC["bg"],
                       activebackground=HC["panel"], activeforeground=HC["text"]
                       ).grid(row=1, column=1, sticky=tk.W, padx=4, pady=4)

        # Interval
        tk.Label(set_frm, text=t("Backup interval (hours)", "Backup interval (hours)"),
                 font=HFONT_NORMAL, bg=HC["panel"], fg=HC["text"]
                 ).grid(row=2, column=0, sticky=tk.W, padx=12, pady=4)
        self._bak_interval_var = tk.StringVar(value=str(CFG.get("auto_backup_interval_hours", 24)))
        tk.Entry(set_frm, textvariable=self._bak_interval_var, width=8,
                 font=HFONT_NORMAL, bg=HC["bg"], fg=HC["text"], insertbackground=HC["text"]
                 ).grid(row=2, column=1, sticky=tk.W, padx=4, pady=4)

        # Keep days
        tk.Label(set_frm, text=t("Keep last N days", "Keep last N days"),
                 font=HFONT_NORMAL, bg=HC["panel"], fg=HC["text"]
                 ).grid(row=3, column=0, sticky=tk.W, padx=12, pady=4)
        self._bak_keep_var = tk.StringVar(value=str(CFG.get("auto_backup_keep_days", 30)))
        tk.Entry(set_frm, textvariable=self._bak_keep_var, width=8,
                 font=HFONT_NORMAL, bg=HC["bg"], fg=HC["text"], insertbackground=HC["text"]
                 ).grid(row=3, column=1, sticky=tk.W, padx=4, pady=4)

        # Backup folder
        tk.Label(set_frm, text=t("Backup folder", "Backup folder"),
                 font=HFONT_NORMAL, bg=HC["panel"], fg=HC["text"]
                 ).grid(row=4, column=0, sticky=tk.W, padx=12, pady=4)
        self._bak_folder_var = tk.StringVar(value=CFG.get("auto_backup_folder", ""))
        folder_entry = tk.Entry(set_frm, textvariable=self._bak_folder_var, width=40,
                                font=HFONT_NORMAL, bg=HC["bg"], fg=HC["text"],
                                insertbackground=HC["text"])
        folder_entry.grid(row=4, column=1, sticky=tk.W, padx=4, pady=4)
        tk.Button(set_frm, text=t("Browse...", "Browse..."),
                  font=HFONT_SMALL, bg=HC["header"], fg="white", relief=tk.FLAT,
                  command=self._browse_backup_folder
                  ).grid(row=4, column=2, padx=4, pady=4)
        tk.Label(set_frm,
                 text=t("Leave blank to use: C:\\Users\\<you>\\MiniCentrinoLite_Backups\\",
                         "Leave blank to use: C:\\Users\\<you>\\MiniCentrinoLite_Backups\\"),
                 font=HFONT_SMALL, bg=HC["panel"], fg=HC["muted"]
                 ).grid(row=5, column=0, columnspan=3, sticky=tk.W, padx=12, pady=(0, 8))

        # Save + Backup Now buttons
        btn_frm = tk.Frame(self.bak_tab, bg=HC["bg"])
        btn_frm.pack(fill=tk.X, padx=12, pady=8)
        tk.Button(btn_frm, text=t("Save Settings", "Save Settings"),
                  font=HFONT_BOLD, bg=HC["accent"], fg="white", relief=tk.FLAT,
                  padx=14, pady=6, command=self._save_backup_settings
                  ).pack(side=tk.LEFT, padx=4)
        tk.Button(btn_frm, text=t("Backup Now", "Backup Now"),
                  font=HFONT_BOLD, bg=HC["ok"], fg="white", relief=tk.FLAT,
                  padx=14, pady=6, command=self._backup_now
                  ).pack(side=tk.LEFT, padx=4)
        tk.Button(btn_frm, text=t("Open Backup Folder", "Open Backup Folder"),
                  font=HFONT_NORMAL, bg=HC["header"], fg="white", relief=tk.FLAT,
                  padx=14, pady=6, command=self._open_backup_folder
                  ).pack(side=tk.LEFT, padx=4)

        # List of existing backups
        tk.Label(self.bak_tab, text=t("Existing Backups", "Existing Backups"),
                 font=HFONT_BOLD, bg=HC["bg"], fg=HC["header_fg"]
                 ).pack(anchor=tk.W, padx=12, pady=(8, 2))
        list_frm = tk.Frame(self.bak_tab, bg=HC["bg"])
        list_frm.pack(fill=tk.BOTH, expand=True, padx=12, pady=4)
        cols = ("filename", "size", "modified")
        self._bak_tree = ttk.Treeview(list_frm, columns=cols, show="headings", height=10)
        for c, w, h in [("filename", 320, "Filename"), ("size", 100, "Size"),
                         ("modified", 160, "Modified")]:
            self._bak_tree.heading(c, text=t(h, h))
            self._bak_tree.column(c, width=w, anchor=tk.W)
        self._bak_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        sb = ttk.Scrollbar(list_frm, orient=tk.VERTICAL, command=self._bak_tree.yview)
        self._bak_tree.configure(yscrollcommand=sb.set)
        sb.pack(side=tk.RIGHT, fill=tk.Y)

    def _browse_backup_folder(self):
        folder = filedialog.askdirectory(title="Select Backup Folder")
        if folder:
            self._bak_folder_var.set(folder)

    def _save_backup_settings(self):
        try:
            CFG["auto_backup_enabled"] = bool(self._bak_enabled_var.get())
            CFG["auto_backup_interval_hours"] = int(self._bak_interval_var.get())
            CFG["auto_backup_keep_days"] = int(self._bak_keep_var.get())
            CFG["auto_backup_folder"] = self._bak_folder_var.get().strip()
            save_config(CFG)
            messagebox.showinfo("Saved", "Backup settings saved. Changes take effect immediately.")
        except ValueError:
            messagebox.showerror("Invalid", "Interval and days must be whole numbers.")
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def _backup_now(self):
        """Trigger an immediate backup (in background so UI doesn't freeze)."""
        def do_it():
            from auto_backup import do_backup_now
            result = do_backup_now()
            self.root.after(0, lambda: self._after_backup_now(result))
        threading.Thread(target=do_it, daemon=True).start()
        self._bak_status_lbl.config(text="Backup in progress...")

    def _after_backup_now(self, result: dict):
        if result.get("success"):
            messagebox.showinfo("Backup OK",
                                f"Database backed up to:\n{result.get('path')}\n\n"
                                f"Size: {result.get('size_bytes', 0):,} bytes")
        else:
            messagebox.showerror("Backup failed", result.get("error", "Unknown error"))
        self._refresh_backup_status()

    def _open_backup_folder(self):
        """Open the backup folder in Windows Explorer."""
        from auto_backup import _resolve_backup_folder
        folder = _resolve_backup_folder()
        try:
            if os.name == 'nt':
                os.startfile(str(folder))
            else:
                import subprocess
                subprocess.Popen(["xdg-open", str(folder)])
        except Exception as e:
            messagebox.showerror("Cannot open", f"Could not open folder:\n{folder}\n\n{e}")

    def _refresh_backup_status(self):
        """Update the status label + treeview of existing backups."""
        if not hasattr(self, "_bak_status_lbl"):
            return
        from auto_backup import _resolve_backup_folder
        try:
            folder = _resolve_backup_folder()
            enabled = CFG.get("auto_backup_enabled", True)
            interval = CFG.get("auto_backup_interval_hours", 24)
            keep = CFG.get("auto_backup_keep_days", 30)
            last = None
            if self.hub and hasattr(self.hub, "backup_worker") and self.hub.backup_worker:
                last = self.hub.backup_worker.last_backup_info()
            lines = []
            lines.append(f"Auto-backup: {'ENABLED' if enabled else 'DISABLED'}")
            lines.append(f"Interval: every {interval} hours    Keep: last {keep} days")
            lines.append(f"Backup folder: {folder}")
            if last:
                ts = last.get("timestamp", "")
                if ts:
                    try:
                        from datetime import datetime as _dt
                        dt = _dt.fromisoformat(ts)
                        ts = dt.strftime("%Y-%m-%d %H:%M:%S")
                    except Exception:
                        pass
                lines.append(f"Last backup: {ts}")
                if last.get("success"):
                    size = last.get("size_bytes", 0)
                    lines.append(f"  Status: OK ({size:,} bytes)")
                    lines.append(f"  Path: {last.get('path', '')}")
                else:
                    lines.append(f"  Status: FAILED — {last.get('error', '')}")
            else:
                lines.append("Last backup: (none yet — first backup runs 1 minute after hub start)")
            self._bak_status_lbl.config(text="\n".join(lines))

            # Refresh treeview of existing backups
            for it in self._bak_tree.get_children():
                self._bak_tree.delete(it)
            import glob
            for fpath in sorted(glob.glob(str(folder / "backup_*.db")), reverse=True):
                try:
                    stat = os.stat(fpath)
                    size_kb = stat.st_size / 1024
                    if size_kb > 1024:
                        size_str = f"{size_kb/1024:.1f} MB"
                    else:
                        size_str = f"{size_kb:.0f} KB"
                    import datetime as _dt
                    mod = _dt.datetime.fromtimestamp(stat.st_mtime).strftime("%Y-%m-%d %H:%M:%S")
                    self._bak_tree.insert("", tk.END, values=(
                        os.path.basename(fpath), size_str, mod
                    ))
                except Exception:
                    pass
        except Exception as e:
            self._bak_status_lbl.config(text=f"Status refresh error: {e}")

    # ─────────────────────────────────── Settings tab ────────────

    def _build_settings_tab(self):
        self.set_tab = tk.Frame(self.tabs, bg=HC["bg"])
        self.tabs.add(self.set_tab, text=t("Settings", "Settings"))

        frm = tk.Frame(self.set_tab, bg=HC["panel"], bd=1, relief=tk.SOLID)
        frm.pack(fill=tk.BOTH, expand=True, padx=12, pady=12)

        rows = [
            ("Restaurant Name",     "restaurant_name",     "str"),
            ("Address",             "restaurant_address",  "str"),
            ("GSTIN",               "gstin",               "str"),
            ("FSSAI No.",           "fssai_no",            "str"),
            ("Tagline",             "tagline",             "str"),
            ("GST Rate %",          "gst_rate",            "float"),
            ("Menu PIN",            "menu_pin",            "str"),
            ("Packaging Charge Mode", "packaging_charge_mode", "choice:none|fixed|per_item"),
            ("Packaging Charge Amount", "packaging_charge_amount", "float"),
            ("Hub Port",            "hub_port",            "int"),
        ]
        self._set_vars = {}
        for i, (label, key, kind) in enumerate(rows):
            tk.Label(frm, text=label, font=HFONT_NORMAL,
                     bg=HC["panel"], fg=HC["text"]).grid(row=i, column=0, sticky=tk.W, padx=12, pady=6)
            v = tk.StringVar(value=str(CFG.get(key, "")))
            if kind.startswith("choice:"):
                options = kind.split(":", 1)[1].split("|")
                w = ttk.Combobox(frm, textvariable=v, values=options, width=24, state="readonly")
            else:
                w = tk.Entry(frm, textvariable=v, width=30, font=HFONT_NORMAL)
            w.grid(row=i, column=1, sticky=tk.W, padx=12, pady=6)
            self._set_vars[key] = (v, kind)

        tk.Button(frm, text="Save Settings", font=HFONT_H2,
                  bg=HC["accent"], fg="white", relief=tk.FLAT, padx=20, pady=8,
                  command=self._save_settings).grid(row=len(rows), column=0, columnspan=2, pady=12)

        # Backup button
        tk.Button(self.set_tab, text="Backup Database to File",
                  font=HFONT_NORMAL, bg=HC["panel"], fg=HC["text"],
                  relief=tk.FLAT, padx=14, pady=6,
                  command=self._backup_db).pack(pady=8)

    def _save_settings(self):
        for key, (var, kind) in self._set_vars.items():
            val = var.get().strip()
            if kind == "int":
                try: CFG[key] = int(val)
                except: pass
            elif kind == "float":
                try: CFG[key] = float(val)
                except: pass
            else:
                CFG[key] = val
        save_config(CFG)
        messagebox.showinfo("Saved", "Settings saved.")

    def _backup_db(self):
        path = filedialog.asksaveasfilename(
            defaultextension=".db",
            filetypes=[("SQLite DB", "*.db"), ("All files", "*.*")],
            initialfile=f"minicentrino_backup_{datetime.date.today().isoformat()}.db"
        )
        if not path:
            return
        try:
            shutil.copy2(str(db.DB_PATH), path)
            messagebox.showinfo("Backup OK", f"Database backed up to:\n{path}")
        except Exception as e:
            messagebox.showerror("Backup failed", str(e))

    # ─────────────────────────────────── Refresh loop ────────────

    def _tick(self):
        """Periodic refresh of dashboard, KOT monitor, held bills, backup status."""
        try:
            self._refresh_dashboard()
            self._refresh_kot_monitor()
            self._refresh_held_bills()
            self._refresh_backup_status()
        except Exception as e:
            print(f"[hub admin tick] {e}")
        self.root.after(3000, self._tick)  # every 3 seconds
