"""
Mini Centrino Lite — Main Terminal Window
Full POS: New Order | Bills | KOT Monitor | Reports | Settings
"""
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
import threading, datetime
from config import CFG, save as save_config
import database as db
import printer as pr
import pinelabs as pl_edc
from network import TerminalServer
from locales import t

# ─────────────────────────────────────── Colour palette ────
C = {
    "bg":        "#FDF6EC",
    "header":    "#6B2E00",
    "header_fg": "#FFF8F0",
    "accent":    "#E65C00",
    "bill_btn":  "#1E6B1E",
    "sec_active":"#6B2E00",
    "sec_fg":    "#FFFFFF",
    "sec_bg":    "#3A1800",
    "item_bg":   "#FFFFFF",
    "item_alt":  "#FEF9F2",
    "cart_bg":   "#FFF8F2",
    "border":    "#D9C8AA",
    "text":      "#2C1500",
    "muted":     "#7A5A30",
    "green":     "#1E6B1E",
    "red":       "#AA2020",
    "pending":   "#D4380D",
    "preparing": "#D48B06",
    "ready":     "#1E6B1E",
    "served":    "#888888",
}

FONT_NORMAL = ("Segoe UI", 10)
FONT_BOLD   = ("Segoe UI", 10, "bold")
FONT_LARGE  = ("Segoe UI", 12, "bold")
FONT_SMALL  = ("Segoe UI", 9)
FONT_XLARGE = ("Segoe UI", 14, "bold")
FONT_MONO   = ("Courier New", 9)

# Fonts for items in the order cart (increased sizes for better readability)
FONT_CART_QTY    = ("Segoe UI", 9, "bold")
FONT_CART_NAME   = ("Segoe UI", 9)
FONT_CART_PRICE  = ("Segoe UI", 9, "bold")
FONT_CART_TOGGLE = ("Segoe UI", 7, "bold")
FONT_CART_REMOVE = ("Segoe UI", 7)


class TerminalApp:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title(f"Mini Centrino Lite — {CFG['restaurant_name']}")
        
        # If layout profile is not chosen yet, prompt the user
        if not CFG.get("ui_scale_chosen", False):
            self._prompt_resolution_selection()
            # Reload configuration in-place to avoid name re-binding issues
            from config import load as load_config
            CFG.clear()
            CFG.update(load_config())

        # Optimize for screen sizes dynamically or via override
        ui_scale = CFG.get("ui_scale", "auto")
        use_compact = False
        if ui_scale == "auto":
            screen_width = self.root.winfo_screenwidth()
            screen_height = self.root.winfo_screenheight()
            if screen_width < 1280 or screen_height < 800:
                use_compact = True
        elif ui_scale == "compact":
            use_compact = True

        global FONT_NORMAL, FONT_BOLD, FONT_LARGE, FONT_SMALL, FONT_XLARGE
        global FONT_CART_QTY, FONT_CART_NAME, FONT_CART_PRICE, FONT_CART_TOGGLE, FONT_CART_REMOVE
        if use_compact:
            FONT_NORMAL = ("Segoe UI", 9)
            FONT_BOLD   = ("Segoe UI", 9, "bold")
            FONT_LARGE  = ("Segoe UI", 17, "bold")
            FONT_SMALL  = ("Segoe UI", 8)
            FONT_XLARGE = ("Segoe UI", 13, "bold")
            
            # Scaled fonts for compact ordered items
            FONT_CART_QTY    = ("Segoe UI", 10, "bold")
            FONT_CART_NAME   = ("Segoe UI", 10)
            FONT_CART_PRICE  = ("Segoe UI", 10, "bold")
            FONT_CART_TOGGLE = ("Segoe UI", 8, "bold")
            FONT_CART_REMOVE = ("Segoe UI", 8)
            
            self.sidebar_width = 300
            self.left_width = 100
            self.menu_manager_left_width = 130
            self.aggregators_left_width = 280
            self.scrollbar_width = 14
        else:
            FONT_NORMAL = ("Segoe UI", 10)
            FONT_BOLD   = ("Segoe UI", 10, "bold")
            FONT_LARGE  = ("Segoe UI", 18, "bold")
            FONT_SMALL  = ("Segoe UI", 9)
            FONT_XLARGE = ("Segoe UI", 14, "bold")
            
            # Scaled fonts for standard/larger ordered items
            FONT_CART_QTY    = ("Segoe UI", 12, "bold")
            FONT_CART_NAME   = ("Segoe UI", 12)
            FONT_CART_PRICE  = ("Segoe UI", 12, "bold")
            FONT_CART_TOGGLE = ("Segoe UI", 10, "bold")
            FONT_CART_REMOVE = ("Segoe UI", 10)
            
            self.sidebar_width = 380
            self.left_width = 120
            self.menu_manager_left_width = 180
            self.aggregators_left_width = 400
            self.scrollbar_width = 18

        import sys
        if sys.platform == "win32":
            self.root.state('zoomed')
        else:
            self.root.geometry("1200x750")
        self.root.minsize(900, 600)
        self.root.configure(bg=C["bg"])

        # Configure touch-friendly scrollbars
        style = ttk.Style()
        style.theme_use('clam')
        style.configure("Vertical.TScrollbar", width=self.scrollbar_width, arrowsize=self.scrollbar_width)
        style.configure("Horizontal.TScrollbar", width=self.scrollbar_width, arrowsize=self.scrollbar_width)

        db.init_db()

        # Load menu from database (seeded from menu_data.py on first run)
        self._menu = db.get_menu_db()

        # State
        self.cart: list[dict] = []
        self.order_type = tk.StringVar(value="dine-in")
        self.table_no   = tk.StringVar()
        self.customer   = tk.StringVar()
        self.order_notes = tk.StringVar()
        self.payment_mode = tk.StringVar(value="cash")
        # v1.2: per-order packaging flag (set by _show_packaging_dialog before KOT/bill)
        self.packaging_required_var = tk.BooleanVar(value=False)
        # v1.9.2 NEW: print-bill toggle in cart. Default UNCHECKED — cashier
        # explicitly opts in to printing each bill. State persists across bills
        # (so a run of "no print" bills requires only one uncheck, and a run
        # of "print" bills requires only one check).
        self.print_bill_var = tk.BooleanVar(value=False)
        self.active_section = tk.IntVar(value=0)
        self.search_var = tk.StringVar()
        self.search_var.trace_add("write", lambda *_: self._refresh_items())
        
        self.discount_pct = tk.StringVar(value="0")
        self.discount_flat = tk.StringVar(value="0")
        self.delivery_charges = tk.StringVar(value="0")
        
        # Trace these variables to update cart totals automatically
        self.discount_pct.trace_add("write", lambda *_: self._on_discount_pct_changed_manually())
        self.discount_flat.trace_add("write", lambda *_: self._on_discount_flat_changed_manually())
        self.delivery_charges.trace_add("write", lambda *_: self._refresh_totals_only())

        # Network server / client setup
        self.server = None
        self.terminal_client = None
        self.pos_client = None  # v1.2: hub client

        # v1.2: Always try to connect to hub if hub_ip is configured.
        # Also start the legacy TerminalServer if is_primary (for backward compat with v1.1 KDS).
        if CFG.get("is_primary", False):
            # Legacy: start TerminalServer (so v1.1 KDS can still connect directly)
            self.server = TerminalServer(
                host=CFG.get("server_host", "0.0.0.0"),
                port=int(CFG.get("server_port", 9999))
            )
            self.server.on_message = self._on_kds_message
            self.server.start()

            # Start aggregator webhook integration server
            self._start_aggregator_server()
        else:
            host = CFG.get("kds_terminal_ip", "127.0.0.1")
            port = int(CFG.get("kds_terminal_port", 9999))
            from network import KDSClient
            self.terminal_client = KDSClient(host, port)
            self.terminal_client.on_message = self._on_primary_message
            self.terminal_client.on_connect = self._on_primary_connect
            self.terminal_client.on_disconnect = self._on_primary_disconnect
            self.terminal_client.start()

        # v1.2: Always start POS→Hub client (hub_ip is required in multi-POS mode)
        hub_ip = CFG.get("hub_ip", "")
        if hub_ip and hub_ip != "0.0.0.0":
            try:
                from pos_client import POSClient
                self.pos_client = POSClient(
                    host=hub_ip,
                    port=int(CFG.get("hub_port_client", 9999)),
                    terminal_id=int(CFG.get("terminal_id", 1)),
                    terminal_name=CFG.get("terminal_name", f"POS-{CFG.get('terminal_id', 1)}"),
                )
                self.pos_client.on_kot_new       = lambda kot: self.root.after(0, lambda: self._hub_kot_received(kot))
                self.pos_client.on_bill_new      = lambda bill: self.root.after(0, lambda: self._hub_bill_received(bill))
                self.pos_client.on_status_update = lambda kn, st: self.root.after(0, lambda: self._hub_status_update(kn, st))
                self.pos_client.on_menu_update   = lambda act, pl: self.root.after(0, lambda: self._hub_menu_update(act, pl))
                self.pos_client.on_menu_snapshot = lambda menu: self.root.after(0, lambda: self._hub_menu_snapshot(menu))
                self.pos_client.on_initial_state = lambda st: self.root.after(0, lambda: self._hub_initial_state(st))
                self.pos_client.on_connect       = lambda: self.root.after(0, lambda: self._hub_connected())
                self.pos_client.on_disconnect    = lambda: self.root.after(0, lambda: self._hub_disconnected())
                self.pos_client.start()
            except Exception as e:
                print(f"[v1.2 POSClient] failed to start: {e}")

        self._build_ui()
        self._refresh_items()
        self._clock_tick()

        # ── Keyboard shortcuts (Ctrl+K = KOT, Ctrl+B = Bill, Ctrl+N = clear, Esc = search)
        self.root.bind("<Control-k>", lambda e: self._action_kot())
        self.root.bind("<Control-K>", lambda e: self._action_kot())
        self.root.bind("<Control-b>", lambda e: self._action_bill())
        self.root.bind("<Control-B>", lambda e: self._action_bill())
        self.root.bind("<Control-n>", lambda e: self._clear_cart())
        self.root.bind("<Control-N>", lambda e: self._clear_cart())
        self.root.bind("<Escape>",    lambda e: [self.search_var.set(""), self.search_entry.focus_set()])

    # ── DB-aware menu lookup helpers (fixes static menu_data dependency) ──

    def _lookup_price(self, item_name: str, order_type: str = None) -> int:
        """v1.2: Return single price from the live DB menu; 0 if not found.
        order_type arg kept for backward compat but ignored."""
        for sec, items in self._menu:
            for it in items:
                # v1.2 menu items are (name, price, code); v1.1 were (name, dine, parcel, code)
                if isinstance(it, tuple):
                    if it[0] == item_name:
                        if len(it) >= 3 and isinstance(it[2], str):
                            # v1.2 format: (name, price, code)
                            return it[1]
                        elif len(it) >= 3:
                            # v1.1 format: (name, dine, parcel, code) — return middle as single price
                            return (it[1] + it[2]) // 2
                        else:
                            return it[1]
        return 0

    def _lookup_section(self, item_name: str) -> str:
        """Return section name from the live DB menu; empty string if not found."""
        for sec, items in self._menu:
            for name, *_ in items:
                if name == item_name:
                    return sec
        return ""

    # ─────────────────────────────────── LAYOUT ────────────

    def _select_language(self, lang_code):
        CFG["language"] = lang_code
        save_config(CFG)
        self._build_ui()

    def _build_ui(self):
        active = self._active_tab.get() if hasattr(self, "_active_tab") else "order"

        if hasattr(self, "main_container") and self.main_container:
            try:
                self.main_container.destroy()
            except Exception:
                pass

        self.main_container = tk.Frame(self.root, bg=C["bg"])
        self.main_container.pack(fill=tk.BOTH, expand=True)

        # ── Top header bar
        hdr = tk.Frame(self.main_container, bg=C["header"], height=48)
        hdr.pack(side=tk.TOP, fill=tk.X)
        hdr.pack_propagate(False)

        tk.Label(hdr, text="Mini Centrino Lite", font=("Segoe UI", 14, "bold"),
                 bg=C["header"], fg=C["header_fg"]).pack(side=tk.LEFT, padx=12)
        tk.Label(hdr, text=f"│  {CFG['restaurant_name']}",
                 font=FONT_NORMAL, bg=C["header"], fg="#FFD9A8").pack(side=tk.LEFT)

        self._clock_lbl = tk.Label(hdr, text="", font=FONT_NORMAL,
                                   bg=C["header"], fg="#FFD9A8")
        self._clock_lbl.pack(side=tk.RIGHT, padx=12)

        # Language buttons
        lang_frm = tk.Frame(hdr, bg=C["header"])
        lang_frm.pack(side=tk.RIGHT, padx=8)
        
        self._lang_btns = {}
        curr_lang = CFG.get("language", "en")
        for lang_code, lang_lbl in [("en", "EN"), ("hi", "हिंदी"), ("mr", "मराठी")]:
            is_active = (lang_code == curr_lang)
            btn_bg = C["accent"] if is_active else "#5A2800"
            btn_fg = "white"
            btn = tk.Button(lang_frm, text=lang_lbl, font=FONT_SMALL, relief=tk.FLAT,
                            bg=btn_bg, fg=btn_fg, cursor="hand2", padx=6, pady=2)
            btn.pack(side=tk.LEFT, padx=2)
            btn.config(command=lambda c=lang_code: self._select_language(c))
            self._lang_btns[lang_code] = btn

        self._kds_lbl = tk.Label(hdr, text="KDS: 0 connected",
                                  font=FONT_SMALL, bg=C["header"], fg="#FFAA55")
        self._kds_lbl.pack(side=tk.RIGHT, padx=8)

        # Customer display button
        self._btn_cfd = tk.Button(hdr, text="📺 " + t("Customer Display", "Customer Display"), font=FONT_SMALL,
                                  bg="#5A1A8A", fg="white", relief=tk.FLAT, cursor="hand2",
                                  padx=8, pady=2, command=self._toggle_customer_display)
        self._btn_cfd.pack(side=tk.RIGHT, padx=8)

        # ── Tab strip
        tab_frame = tk.Frame(self.main_container, bg=C["sec_bg"], height=34)
        tab_frame.pack(side=tk.TOP, fill=tk.X)
        tab_frame.pack_propagate(False)

        self._tab_btns = {}
        self._pages    = {}
        self._active_tab = tk.StringVar(value=active)

        for tab_id, label in [("order", t("New Order", "New Order")), 
                               ("bills", t("Bills", "Bills")),
                               ("kots", t("KOT Monitor", "KOT Monitor")), 
                               ("reports", t("Reports", "Reports")),
                               ("menu", t("Menu Manager", "Menu Manager")),
                               ("packaging", t("Packaging", "Packaging")),
                               ("inventory", t("Inventory", "Inventory")),
                               ("aggregators", t("Aggregators", "Aggregators")), 
                               ("settings", t("Settings", "Settings"))]:
            btn = tk.Button(tab_frame, text=label, font=FONT_SMALL,
                            bg=C["sec_bg"], fg="#DDBBAA", relief=tk.FLAT,
                            padx=14, pady=6, cursor="hand2",
                            command=lambda t=tab_id: self._switch_tab(t))
            btn.pack(side=tk.LEFT)
            self._tab_btns[tab_id] = btn

        # ── Content area
        content = tk.Frame(self.main_container, bg=C["bg"])
        content.pack(side=tk.TOP, fill=tk.BOTH, expand=True)

        for tab_id, builder in [("order",   self._build_order_tab),
                                 ("bills",   self._build_bills_tab),
                                 ("kots",    self._build_kots_tab),
                                 ("reports", self._build_reports_tab),
                                 ("menu",    self._build_menu_tab),
                                 ("packaging", self._build_packaging_tab),
                                 ("inventory", self._build_inventory_tab),
                                 ("aggregators", self._build_aggregators_tab),
                                 ("settings",self._build_settings_tab)]:
            page = tk.Frame(content, bg=C["bg"])
            builder(page)
            self._pages[tab_id] = page

        self._switch_tab(active)

    def _switch_tab(self, tab_id):
        self._active_tab.set(tab_id)
        for tid, page in self._pages.items():
            page.pack_forget()
        self._pages[tab_id].pack(fill=tk.BOTH, expand=True)
        for tid, btn in self._tab_btns.items():
            if tid == tab_id:
                btn.config(bg="#7A3A00", fg="#FFFFFF", font=FONT_BOLD)
            else:
                btn.config(bg=C["sec_bg"], fg="#DDBBAA", font=FONT_SMALL)
        # Refresh data on tab open
        if tab_id == "order":      self._refresh_stock_and_items()
        if tab_id == "bills":     self._load_bills()
        if tab_id == "kots":      self._load_kots()
        if tab_id == "reports":   self._load_reports()
        if tab_id == "menu":      self._load_menu_manager()
        if tab_id == "packaging": self._load_packaging_tab()
        if tab_id == "inventory": self._load_inventory_tab()
        if tab_id == "aggregators": self._load_aggregators()

    # ─────────────────────────────────── ORDER TAB ─────────

    def _build_order_tab(self, parent):
        # Order type + details strip
        top = tk.Frame(parent, bg=C["header"], padx=8, pady=4)
        top.pack(fill=tk.X)

        # v1.2: "Type:" label hidden — no more Dine-in / Parcel toggle
        # tk.Label(top, text=t("Type:", "Type:"), bg=C["header"], fg=C["header_fg"],
        #          font=FONT_SMALL).pack(side=tk.LEFT, padx=(4, 2))
                 
        # v1.2: Dine-in / Parcel toggle HIDDEN — single price, single order type.
        # Packaging is decided per-order at checkout time via a checkbox.
        # The buttons are kept for backward compat but not displayed.
        self._order_type_btns = {}
        # for val, lbl in [("dine-in", "🍽 " + t("Dine-in", "Dine-in")), ("parcel", "📦 " + t("Parcel", "Parcel"))]:
        #     btn = tk.Button(top, text=lbl, relief=tk.FLAT, pady=6, padx=12, cursor="hand2", font=FONT_NORMAL)
        #     btn.pack(side=tk.LEFT, padx=3)
        #     btn.config(command=lambda v=val: self._select_order_type(v))
        #     self._order_type_btns[val] = btn
        # Force order_type to a single value for v1.2
        self.order_type.set("standard")

        sep = tk.Label(top, text=" │ ", bg=C["header"], fg="#AA7040"); sep.pack(side=tk.LEFT)
        tk.Label(top, text=t("Table:", "Table:"), bg=C["header"], fg=C["header_fg"],
                 font=FONT_SMALL).pack(side=tk.LEFT)
        tk.Entry(top, textvariable=self.table_no, width=6,
                 font=FONT_SMALL).pack(side=tk.LEFT, padx=2)


        # Main 3-panel layout
        body = tk.Frame(parent, bg=C["bg"])
        body.pack(fill=tk.BOTH, expand=True)

        # LEFT: section list
        left = tk.Frame(body, bg=C["sec_bg"], width=self.left_width)
        left.pack(side=tk.LEFT, fill=tk.Y)
        left.pack_propagate(False)

        tk.Label(left, text=t("SECTIONS", "SECTIONS"), bg=C["sec_bg"], fg="#FFAA66",
                 font=FONT_SMALL, pady=4).pack(fill=tk.X)

        self._sec_frame = tk.Frame(left, bg=C["sec_bg"])
        self._sec_frame.pack(fill=tk.BOTH, expand=True)

        self._sec_btns = []
        for i, (sec_name, _) in enumerate(self._menu):
            btn = tk.Button(self._sec_frame, text=t(sec_name), font=FONT_SMALL,
                            bg=C["sec_bg"], fg="#DDBBAA", relief=tk.FLAT,
                            padx=6, pady=10, anchor=tk.W, cursor="hand2",
                            wraplength=self.left_width-10, justify=tk.LEFT,
                            command=lambda idx=i: self._select_section(idx))
            btn.pack(fill=tk.X)
            self._sec_btns.append(btn)

        # CENTER: item list
        center = tk.Frame(body, bg=C["item_bg"])
        center.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        # Search bar
        sf = tk.Frame(center, bg=C["border"], pady=1)
        sf.pack(fill=tk.X)
        sfin = tk.Frame(sf, bg=C["item_bg"])
        sfin.pack(fill=tk.X)
        tk.Label(sfin, text="🔍", bg=C["item_bg"], font=("", 10)).pack(side=tk.LEFT, padx=4)
        self.search_entry = tk.Entry(sfin, textvariable=self.search_var, font=FONT_NORMAL,
                 relief=tk.FLAT, bg=C["item_bg"])
        self.search_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=4, pady=4)
        self.search_entry.bind("<Return>", self._on_search_enter)
        tk.Button(sfin, text="↻", font=FONT_BOLD, relief=tk.FLAT,
                  bg="#E8F5E9", fg="#2E7D32", cursor="hand2", padx=6,
                  command=self._refresh_stock_and_items
                  ).pack(side=tk.RIGHT, padx=2)
        tk.Button(sfin, text="✕", font=FONT_SMALL, relief=tk.FLAT,
                  bg=C["item_bg"], cursor="hand2",
                  command=lambda: self.search_var.set("")).pack(side=tk.RIGHT, padx=4)

        self._section_label = tk.Label(center, text="", bg="#FFF2E0",
                                        fg=C["header"], font=FONT_BOLD,
                                        anchor=tk.W, padx=8, pady=4)
        self._section_label.pack(fill=tk.X)

        # Item scroll area
        item_wrap = tk.Frame(center, bg=C["item_bg"])
        item_wrap.pack(fill=tk.BOTH, expand=True)

        scr = tk.Scrollbar(item_wrap, orient=tk.VERTICAL, width=self.scrollbar_width)
        scr.pack(side=tk.RIGHT, fill=tk.Y)
        self._item_canvas = tk.Canvas(item_wrap, bg=C["item_bg"],
                                      yscrollcommand=scr.set, highlightthickness=0)
        self._item_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scr.config(command=self._item_canvas.yview)

        self._item_frame = tk.Frame(self._item_canvas, bg=C["item_bg"])
        self._item_canvas_win = self._item_canvas.create_window(
            (0, 0), window=self._item_frame, anchor=tk.NW)
        self._item_frame.bind("<Configure>",
            lambda e: self._item_canvas.configure(
                scrollregion=self._item_canvas.bbox("all")))
        self._item_canvas.bind("<Configure>",
            lambda e: self._item_canvas.itemconfig(
                self._item_canvas_win, width=e.width))
        self._item_canvas.bind_all("<MouseWheel>",
            lambda e: self._item_canvas.yview_scroll(-1*(e.delta//120), "units"))

        # RIGHT: cart (Scaled sidebar width for touchscreen layout)
        right = tk.Frame(body, bg=C["cart_bg"], width=self.sidebar_width,
                         relief=tk.FLAT, bd=0)
        right.pack(side=tk.RIGHT, fill=tk.Y)
        right.pack_propagate(False)

        # ── ORDER header with item count badge
        hdr_bar = tk.Frame(right, bg=C["header"])
        hdr_bar.pack(fill=tk.X)
        tk.Label(hdr_bar, text=t("ORDER", "ORDER"), bg=C["header"], fg=C["header_fg"],
                 font=("Segoe UI", 11, "bold"), pady=3).pack(side=tk.LEFT, padx=6)
        self._cart_count_lbl = tk.Label(hdr_bar, text="0 " + t("items", "items"), bg=C["header"],
                                        fg="#FFAA55", font=("Segoe UI", 9))
        self._cart_count_lbl.pack(side=tk.RIGHT, padx=6)

        # ── Cart items scroll area (this gets ALL remaining space)
        cart_scroll_area = tk.Frame(right, bg=C["cart_bg"])
        cart_scroll_area.pack(fill=tk.BOTH, expand=True)

        cart_scr = tk.Scrollbar(cart_scroll_area, width=self.scrollbar_width)
        cart_scr.pack(side=tk.RIGHT, fill=tk.Y)
        self._cart_canvas = tk.Canvas(cart_scroll_area, bg=C["cart_bg"],
                                      yscrollcommand=cart_scr.set,
                                      highlightthickness=0)
        self._cart_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        cart_scr.config(command=self._cart_canvas.yview)

        self._cart_frame = tk.Frame(self._cart_canvas, bg=C["cart_bg"])
        self._cart_cwin = self._cart_canvas.create_window(
            (0, 0), window=self._cart_frame, anchor=tk.NW)
        self._cart_frame.bind("<Configure>",
            lambda e: self._cart_canvas.configure(
                scrollregion=self._cart_canvas.bbox("all")))
        self._cart_canvas.bind("<Configure>",
            lambda e: self._cart_canvas.itemconfig(self._cart_cwin, width=e.width))

        # ── Bottom panel: everything below the cart (fixed height, no expand)
        bottom_panel = tk.Frame(right, bg=C["cart_bg"])
        bottom_panel.pack(fill=tk.X, side=tk.BOTTOM)

        # ── Payment mode: single horizontal strip (4 buttons in 1 row)
        self._pay_btns = {}
        pay_strip = tk.Frame(bottom_panel, bg=C["cart_bg"])
        pay_strip.pack(fill=tk.X, padx=2, pady=(2, 0))
        for i in range(4):
            pay_strip.columnconfigure(i, weight=1)
        modes = [
            ("cash", t("Cash", "Cash")), ("card", t("Card", "Card")),
            ("upi", t("UPI", "UPI")), ("other", t("Other", "Other"))
        ]
        for idx, (m_id, label) in enumerate(modes):
            btn = tk.Button(pay_strip, text=label, relief=tk.FLAT, pady=3,
                            cursor="hand2", font=("Segoe UI", 9))
            btn.grid(row=0, column=idx, sticky="ew", padx=1)
            btn.config(command=lambda m=m_id: self._select_payment_mode(m))
            self._pay_btns[m_id] = btn
        self._select_payment_mode("cash")

        # ── Collapsible extras (Disc / Delivery) — v1.9.9: collapsed by default
        # to save vertical space on smaller screens. Previously expanded by
        # default, which pushed Pay Now / Recall buttons off-screen.
        # Cashier clicks "▸ Disc / Delivery" to expand when needed.
        self._extras_visible = False
        self._extras_toggle_btn = tk.Button(bottom_panel, text="▸ " + t("Disc / Delivery", "Disc / Delivery"),
                 font=("Segoe UI", 8), bg=C["cart_bg"], fg=C["muted"],
                 relief=tk.FLAT, cursor="hand2", anchor=tk.W,
                 command=self._toggle_extras)
        self._extras_toggle_btn.pack(fill=tk.X, padx=4)

        self._extras_frame = tk.Frame(bottom_panel, bg=C["cart_bg"])
        # v1.9.9: don't pack _extras_frame here — only pack when expanded.
        # Was: self._extras_frame.pack(fill=tk.X, padx=4, pady=(0, 2))
        # Now: _toggle_extras() handles packing/unpacking.
        
        self._extras_frame.columnconfigure(0, weight=1)
        self._extras_frame.columnconfigure(1, weight=1)
        self._extras_frame.columnconfigure(2, weight=1)

        # Row 0: Coupon label and Combobox
        coupon_lbl = tk.Label(self._extras_frame, text=t("Coupon:", "Coupon:"), font=("Segoe UI", 8, "bold"), bg=C["cart_bg"], fg=C["text"])
        coupon_lbl.grid(row=0, column=0, sticky="w", padx=3, pady=(2, 2))
        
        self.coupon_var = tk.StringVar(value="None")
        self._cb_coupon = ttk.Combobox(
            self._extras_frame, 
            textvariable=self.coupon_var, 
            values=self._get_coupon_combobox_values(),
            state="readonly",
            font=("Segoe UI", 9)
        )
        self._cb_coupon.grid(row=0, column=1, columnspan=2, sticky="ew", padx=3, pady=(2, 2))
        self._cb_coupon.bind("<<ComboboxSelected>>", self._on_coupon_selected)

        # Row 1: Labels
        dp_lbl = tk.Label(self._extras_frame, text=t("Discount (%)", "Disc %"), font=("Segoe UI", 8), bg=C["cart_bg"], fg=C["muted"])
        dp_lbl.grid(row=1, column=0, sticky="w", padx=3)
        
        df_lbl = tk.Label(self._extras_frame, text=t("Discount (Flat)", "Disc ₹"), font=("Segoe UI", 8), bg=C["cart_bg"], fg=C["muted"])
        df_lbl.grid(row=1, column=1, sticky="w", padx=3)
        
        del_lbl = tk.Label(self._extras_frame, text=t("Delivery Charges", "Del ₹"), font=("Segoe UI", 8), bg=C["cart_bg"], fg=C["muted"])
        del_lbl.grid(row=1, column=2, sticky="w", padx=3)

        # Row 2: Entries
        self._ent_disc_pct = tk.Entry(self._extras_frame, textvariable=self.discount_pct, font=("Segoe UI", 9), justify=tk.CENTER, width=5)
        self._ent_disc_pct.grid(row=2, column=0, padx=3, pady=(0, 2), sticky="ew")
        
        self._ent_disc_flat = tk.Entry(self._extras_frame, textvariable=self.discount_flat, font=("Segoe UI", 9), justify=tk.CENTER, width=5)
        self._ent_disc_flat.grid(row=2, column=1, padx=3, pady=(0, 2), sticky="ew")
        
        self._ent_delivery = tk.Entry(self._extras_frame, textvariable=self.delivery_charges, font=("Segoe UI", 9), justify=tk.CENTER, width=5)
        self._ent_delivery.grid(row=2, column=2, padx=3, pady=(0, 2), sticky="ew")

        # Row 3: Quick buttons for discount %
        quick_pct_frm = tk.Frame(self._extras_frame, bg=C["cart_bg"])
        quick_pct_frm.grid(row=3, column=0, sticky="ew", padx=3, pady=(1, 2))
        
        for p in [5, 10, 15, 20]:
            btn = tk.Button(
                quick_pct_frm,
                text=f"{p}%",
                font=("Segoe UI", 7, "bold"),
                bg="#EEDDCC",
                fg=C["text"],
                relief=tk.FLAT,
                bd=0,
                padx=1,
                pady=0,
                cursor="hand2"
            )
            btn.config(command=lambda pct=p: self._set_quick_discount_pct(pct))
            btn.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=1)

        # Customer Note in Cart sidebar (Pay Now section)
        self._notes_grid = tk.Frame(bottom_panel, bg=C["cart_bg"])
        self._notes_grid.pack(fill=tk.X, padx=4, pady=2)
        self._notes_grid.columnconfigure(1, weight=1)

        lbl_notes = tk.Label(
            self._notes_grid,
            text=t("Customer Note:", "Customer Note:"),
            font=("Segoe UI", 9, "bold"),
            bg=C["cart_bg"],
            fg=C["text"],
            anchor=tk.W
        )
        lbl_notes.grid(row=0, column=0, sticky="ew", padx=2, pady=1)

        self._ent_cart_notes = tk.Entry(
            self._notes_grid,
            textvariable=self.order_notes,
            font=("Segoe UI", 9),
            bg="white",
            fg="black",
            relief=tk.SOLID,
            bd=1
        )
        self._ent_cart_notes.grid(row=0, column=1, sticky="ew", padx=2, pady=1)

        # v1.3.1: Packaging checkbox ON THE CART PAGE itself (not in checkout dialog).
        # User checks this as soon as they decide it's a parcel/takeaway order.
        # When checked → packaging_required=True → KOT shows PACK badge on KDS,
        # bill prints "Packaging: Yes", and packaging stock is deducted on bill save.
        pkg_chk_row = tk.Frame(bottom_panel, bg=C["cart_bg"])
        pkg_chk_row.pack(fill=tk.X, padx=4, pady=(2, 1))
        self._cart_packaging_chk = tk.Checkbutton(
            pkg_chk_row,
            text="📦 " + t("Packaging required (parcel / takeaway)", "Packaging required (parcel / takeaway)"),
            variable=self.packaging_required_var,
            font=("Segoe UI", 10, "bold"),
            bg=C["cart_bg"],
            fg=C["header"],
            activebackground=C["cart_bg"],
            activeforeground=C["header"],
            selectcolor="white",
            padx=6,
            pady=4,
            command=self._on_packaging_toggle,
            cursor="hand2",
        )
        self._cart_packaging_chk.pack(anchor=tk.W)

        # v1.9.2 NEW: Print Bill toggle — default UNCHECKED. Cashier checks
        # this when they want a physical thermal print of the bill. When unchecked,
        # the bill is still saved to DB + synced to hub + pushed to Supabase,
        # but no print job is sent to the thermal printer. Saves paper.
        # State persists across bills (so cashier can leave it unchecked for
        # a whole shift, or check it for a run of bills that need printing).
        print_chk_row = tk.Frame(bottom_panel, bg=C["cart_bg"])
        print_chk_row.pack(fill=tk.X, padx=4, pady=(1, 2))
        self._cart_print_bill_chk = tk.Checkbutton(
            print_chk_row,
            text="🖨  Print Bill",
            variable=self.print_bill_var,
            font=("Segoe UI", 10, "bold"),
            bg=C["cart_bg"],
            fg=C["header"],
            activebackground=C["cart_bg"],
            activeforeground=C["header"],
            selectcolor="white",
            padx=6,
            pady=4,
            cursor="hand2",
        )
        self._cart_print_bill_chk.pack(anchor=tk.W)

        # ── Totals — compact: only show TOTAL prominently, details on one line
        tot = tk.Frame(bottom_panel, bg="#FFF0DC", bd=1, relief=tk.SUNKEN)
        tot.pack(fill=tk.X, padx=3, pady=(1, 0))

        # Single summary line: Sub ₹X | GST ₹X | Disc -₹X
        self._lbl_summary = tk.Label(tot, text="Sub ₹0 | GST ₹0 | Disc -₹0",
                                      bg="#FFF0DC", fg=C["muted"], font=("Segoe UI", 8), anchor=tk.E)
        self._lbl_summary.pack(fill=tk.X, padx=4, pady=(1, 0))
        # Hidden labels kept for compatibility with _refresh_totals_only
        self._lbl_sub = tk.Label(tot); self._lbl_disc = tk.Label(tot)
        self._lbl_gst = tk.Label(tot); self._lbl_delivery = tk.Label(tot)

        self._lbl_total = tk.Label(tot, text="TOTAL : ₹0.00",
                                    bg="#FFF0DC", fg=C["header"], font=("Segoe UI", 13, "bold"), anchor=tk.E)
        self._lbl_total.pack(fill=tk.X, padx=6, pady=(0, 2))

        # ── Action buttons — compact 2×2 grid with tight padding
        # v1.9.9 FIX: pack action buttons FIRST with side=BOTTOM so they're
        # always visible at the bottom of the cart, even on small screens where
        # the extras/totals above might get squeezed. Previously they were packed
        # last (at the top of bottom_panel's stack), so on small screens they
        # got pushed off-screen by the extras + totals + checkboxes above.
        ab = tk.Frame(bottom_panel, bg=C["cart_bg"])
        ab.pack(fill=tk.X, side=tk.BOTTOM)  # ← side=BOTTOM is the fix
        ab.columnconfigure(0, weight=1)
        ab.columnconfigure(1, weight=1)

        self._btn_bill = tk.Button(ab, text="💳 " + t("Pay Now", "Pay Now"), font=("Segoe UI", 10, "bold"),
                                    bg=C["bill_btn"], fg="white", relief=tk.FLAT,
                                    pady=8, cursor="hand2",
                                    command=self._action_bill)
        self._btn_bill.grid(row=0, column=0, sticky="ew", padx=(3,1), pady=(2,1))

        self._btn_hold = tk.Button(ab, text="⏸ " + t("Pay Later", "Pay Later"), font=("Segoe UI", 10, "bold"),
                                   bg="#D48B06", fg="white", relief=tk.FLAT,
                                   pady=8, cursor="hand2",
                                   command=self._action_hold)
        self._btn_hold.grid(row=0, column=1, sticky="ew", padx=(1,3), pady=(2,1))

        self._btn_recall = tk.Button(ab, text="📂 " + t("Recall", "Recall"), font=("Segoe UI", 9, "bold"),
                                     bg="#3A1800", fg="white", relief=tk.FLAT,
                                     pady=5, cursor="hand2",
                                     command=self._action_recall)
        self._btn_recall.grid(row=1, column=0, sticky="ew", padx=(3,1), pady=(1,2))

        tk.Button(ab, text=t("Clear", "Clear"), font=("Segoe UI", 9, "bold"),
                  bg="#EEDDCC", fg=C["muted"], relief=tk.FLAT,
                  pady=5, cursor="hand2", command=self._clear_cart).grid(
                  row=1, column=1, sticky="ew", padx=(1,3), pady=(1,2))

        self._select_order_type(self.order_type.get())
        self._select_section(0)

    def _on_type_change(self):
        """Update items display based on order type, but do not override individual cart item types."""
        self._refresh_items()

    def _select_section(self, idx):
        self.active_section.set(idx)
        self.search_var.set("")
        for i, btn in enumerate(self._sec_btns):
            if i == idx:
                btn.config(bg=C["sec_active"], fg=C["sec_fg"], font=FONT_BOLD)
            else:
                btn.config(bg=C["sec_bg"], fg="#DDBBAA", font=FONT_SMALL)
        self._refresh_items()

    def _reload_menu(self):
        """Reload menu from DB and rebuild section sidebar."""
        self._menu = db.get_menu_db()
        for w in self._sec_frame.winfo_children():
            w.destroy()
        self._sec_btns = []
        for i, (sec_name, _) in enumerate(self._menu):
            btn = tk.Button(self._sec_frame, text=sec_name, font=FONT_SMALL,
                            bg=C["sec_bg"], fg="#DDBBAA", relief=tk.FLAT,
                            padx=6, pady=10, anchor=tk.W, cursor="hand2",
                            wraplength=120, justify=tk.LEFT,
                            command=lambda idx=i: self._select_section(idx))
            btn.pack(fill=tk.X)
            self._sec_btns.append(btn)
        if self._menu:
            self._select_section(0)
        self._refresh_items()

    def _on_search_enter(self, event=None):
        sq = self.search_var.get().strip().lower()
        if not sq:
            return
            
        ot = self.order_type.get()
        matched_item = None
        matched_price = None
        
        # 1. Look for exact match by code (e.g. 1001)
        for sec, items in self._menu:
            for it in items:
                # v1.2: items are (name, price, code)
                if len(it) >= 3:
                    name, price, code = it[0], it[1], it[2]
                else:
                    name, price, code = it[0], it[1], ""
                if code.lower() == sq:
                    matched_item = name
                    matched_price = price
                    break
            if matched_item:
                break
                
        # 2. If no exact code match, check if there is exactly 1 match in the filtered items
        if not matched_item:
            matches = []
            for sec, items in self._menu:
                for it in items:
                    if len(it) >= 3:
                        name, price, code = it[0], it[1], it[2]
                    else:
                        name, price, code = it[0], it[1], ""
                    if sq in name.lower() or sq == code.lower():
                        matches.append((name, price))
            if len(matches) == 1:
                matched_item, matched_price = matches[0]
                
        # If we have a single match, add it to the cart and clear search
        if matched_item:
            self._add_item(matched_item, matched_price)
            self.search_var.set("")

    def _refresh_stock_and_items(self):
        """Refresh the order screen with latest stock data from DB.
        Called by the ↻ refresh button and when switching to order tab."""
        # Reload menu from DB to get latest prices/items
        self._menu = db.get_menu_db()
        # Refresh the item display (which also refreshes stock badges)
        if hasattr(self, '_item_frame'):
            self._refresh_items()
        # Refresh cart totals (in case anything changed)
        if hasattr(self, 'cart'):
            self._refresh_cart()

    def _refresh_items(self):
        for w in self._item_frame.winfo_children():
            w.destroy()

        sq = self.search_var.get().strip().lower()
        ot = self.order_type.get()

        if sq:
            # v1.5.6 FIX: Handle both 3-tuple (name, price, code) and 4-tuple (name, dine, parcel, code)
            display = []
            for sec, items in self._menu:
                matched = []
                for it in items:
                    if len(it) >= 4:
                        n, d, p, c = it
                    elif len(it) >= 3:
                        n, p, c = it
                    else:
                        n, p, c = it[0], it[1], ""
                    if sq in n.lower() or (c and sq == c.lower()):
                        matched.append(it)
                if matched:
                    display.append((sec, matched))
            self._section_label.config(text=t("Search item...", "Search") + f': "{sq}"')
        else:
            idx = self.active_section.get()
            if idx >= len(self._menu):
                idx = 0
            sec, items = self._menu[idx]
            display = [(sec, items)]
            self._section_label.config(text=f"  {t(sec)}")

        # Batch-fetch stock for all items to avoid N+1 queries
        stock_map = {}
        try:
            all_inv = db.get_inventory()
            for inv_item in all_inv:
                stock_map[inv_item["name"]] = inv_item
        except Exception:
            pass

        row = 0
        for sec_name, items in display:
            if sq and items:
                tk.Label(self._item_frame, text=f"  {t(sec_name)}",
                         bg="#FFF2E0", fg=C["header"], font=FONT_BOLD,
                         anchor=tk.W).grid(row=row, column=0, columnspan=5,
                                           sticky="ew", ipady=2)
                row += 1

            for it in items:
                # v1.2: items are (name, price, code) or legacy (name, dine, parcel, code)
                if len(it) >= 4:
                    name, dine, parcel, code = it
                    price = (dine + parcel) // 2  # legacy fallback
                elif len(it) >= 3:
                    name, price, code = it
                else:
                    name, price, code = it[0], it[1], ""
                bg = C["item_bg"] if row % 2 == 0 else C["item_alt"]

                display_name = f"[{code}] {t(name)}" if code else t(name)
                tk.Label(self._item_frame, text=display_name, bg=bg, fg=C["text"],
                         font=FONT_NORMAL, anchor=tk.W, padx=6,
                         wraplength=max(160, self.root.winfo_screenwidth() - self.sidebar_width - self.left_width - 240), justify=tk.LEFT
                         ).grid(row=row, column=0, sticky="ew", ipady=4)
                tk.Label(self._item_frame, text=f"₹{price}", bg=bg,
                         fg=C["green"], font=FONT_BOLD, width=6
                         ).grid(row=row, column=1, padx=2)

                # Stock indicator badge
                inv_info = stock_map.get(name)
                if inv_info and inv_info.get("stock_quantity", -1) >= 0:
                    stock_qty = inv_info["stock_quantity"]
                    threshold = inv_info.get("low_stock_threshold", 10)
                    in_cart = self._get_cart_qty(name)
                    remaining = max(0, stock_qty - in_cart)
                    if remaining <= 0:
                        stock_text = "❌ 0"
                        stock_fg = "#D32F2F"  # Red
                    elif remaining <= threshold:
                        stock_text = f"⚠ {remaining}"
                        stock_fg = "#E65100"  # Orange
                    else:
                        stock_text = f"✓ {remaining}"
                        stock_fg = "#2E7D32"  # Green
                    tk.Label(self._item_frame, text=stock_text, bg=bg,
                             fg=stock_fg, font=("Segoe UI", 9, "bold"), width=5,
                             anchor=tk.CENTER
                             ).grid(row=row, column=2, padx=2)
                else:
                    # Untracked item — no stock badge
                    tk.Label(self._item_frame, text="", bg=bg, width=5
                             ).grid(row=row, column=2, padx=2)

                # Qty controls
                qty = self._get_cart_qty(name, ot)
                # Check if item is out of stock (tracked and stock = 0, minus what's in cart)
                is_out_of_stock = False
                inv_data = stock_map.get(name)
                if inv_data and inv_data.get("stock_quantity", -1) >= 0:
                    remaining = max(0, inv_data["stock_quantity"] - self._get_cart_qty(name))
                    if remaining <= 0 and qty == 0:
                        is_out_of_stock = True

                ctrl = tk.Frame(self._item_frame, bg=bg)
                ctrl.grid(row=row, column=3, padx=4, pady=1)

                if is_out_of_stock:
                    tk.Button(ctrl, text="❌ OUT", font=FONT_BOLD,
                              bg="#880000", fg="white", relief=tk.FLAT,
                              padx=8, pady=6, cursor="hand2",
                              command=lambda n=name, pr=price: self._add_item(n, pr)
                              ).pack()
                elif qty == 0:
                    tk.Button(ctrl, text=t("Add", "Add"), font=FONT_BOLD,
                              bg=C["header"], fg="white", relief=tk.FLAT,
                              padx=14, pady=6, cursor="hand2",
                              command=lambda n=name, pr=price: self._add_item(n, pr)
                              ).pack()
                else:
                    tk.Button(ctrl, text="−", font=FONT_BOLD,
                              bg="#FFDDCC", fg=C["red"], relief=tk.FLAT, width=3,
                              pady=4, cursor="hand2",
                              command=lambda n=name, ot_type=ot: self._change_qty(n, ot_type, -1)
                              ).pack(side=tk.LEFT)
                    tk.Label(ctrl, text=str(qty), font=FONT_BOLD,
                             bg=bg, width=4, anchor=tk.CENTER).pack(side=tk.LEFT)
                    tk.Button(ctrl, text="+", font=FONT_BOLD,
                              bg="#CCFFCC", fg=C["green"], relief=tk.FLAT, width=3,
                              pady=4, cursor="hand2",
                              command=lambda n=name, ot_type=ot: self._change_qty(n, ot_type, 1)
                              ).pack(side=tk.LEFT)

                row += 1

        self._item_frame.columnconfigure(0, weight=1)

    def _get_cart_qty(self, name, item_type=None):
        if item_type is None:
            return sum(c['qty'] for c in self.cart if c['name'] == name)
        return sum(c['qty'] for c in self.cart if c['name'] == name and c.get('type', 'dine-in') == item_type)

    def _check_stock_before_add(self, name, requested_qty=1):
        """
        Check if stock is available for the requested quantity.
        Returns: ('ok', None) if stock is fine or untracked,
                 ('insufficient', stock_info) if not enough stock,
                 ('out_of_stock', stock_info) if stock is 0.
                 ('packaging_out', pkg_info) if packaging stock is 0 for parcel item.
        FAILS CLOSED: If DB error, treats as out_of_stock (blocks ordering).
        """
        try:
            stock_info = db.get_item_stock(name)
        except Exception as e:
            # DB error — fail closed (block ordering on error)
            print(f"[STOCK CHECK ERROR] get_item_stock('{name}'): {e}")
            return ("out_of_stock", {"id": None, "name": name, "stock_quantity": 0,
                                     "low_stock_threshold": 10, "is_tracked": True,
                                     "available": 0, "in_cart": 0, "requested": requested_qty})

        if not stock_info.get("is_tracked", False):
            # Item stock not tracked — still check packaging if parcel
            ot = self.order_type.get()
            if ot == 'parcel':
                pkg_status = self._check_packaging_stock(name, requested_qty)
                if pkg_status[0] != "ok":
                    return pkg_status
            return ("ok", None)

        available = stock_info.get("stock_quantity", -1)
        # Total qty already in cart for this item (any order type)
        in_cart = self._get_cart_qty(name)
        # If we're adding more, check if total exceeds stock
        if available <= 0 and in_cart <= 0:
            return ("out_of_stock", {**stock_info, "available": max(0, available),
                                     "in_cart": in_cart, "requested": requested_qty})
        if in_cart + requested_qty > available:
            return ("insufficient", {**stock_info, "available": available,
                                     "in_cart": in_cart, "requested": requested_qty})

        # Also check packaging stock for parcel items
        ot = self.order_type.get()
        if ot == 'parcel':
            pkg_status = self._check_packaging_stock(name, requested_qty)
            if pkg_status[0] != "ok":
                return pkg_status

        return ("ok", None)

    def _check_packaging_stock(self, name, requested_qty=1):
        """
        Check if packaging stock is available for a parcel item.
        Returns: ('ok', None) or ('packaging_out', pkg_info)
        """
        try:
            pkg_info = db.get_packaging_stock_for_item(name)
        except Exception as e:
            print(f"[PACKAGING STOCK CHECK ERROR] '{name}': {e}")
            return ("ok", None)  # Don't block on packaging check error

        if not pkg_info.get("is_tracked", False):
            return ("ok", None)

        if pkg_info.get("stock_quantity", -1) <= 0:
            return ("packaging_out", {**pkg_info, "requested": requested_qty,
                                      "item_name": name})

        return ("ok", None)

    def _show_stock_alert(self, name, stock_info, requested_qty=1):
        """
        Show stock alert dialog when insufficient stock.
        Returns: 'add_available' | 'quick_restock' | 'cancel'
        """
        available = stock_info.get("available", 0)
        in_cart = stock_info.get("in_cart", 0)
        shortage = (in_cart + requested_qty) - available

        if available <= 0:
            msg = (f"⚠ OUT OF STOCK!\n\n"
                   f"'{name}' is currently out of stock (0 available).\n\n"
                   f"Options:\n"
                   f"• Quick Restock — Add inventory now and take order\n"
                   f"• Cancel — Don't add to cart")
        else:
            msg = (f"⚠ LOW STOCK ALERT!\n\n"
                   f"'{name}' — Only {available} in stock.\n"
                   f"Cart already has {in_cart}. Need {shortage} more.\n\n"
                   f"Tell customer:\n"
                   f"\"Only {available} ready now. If you wait, we'll prepare more.\"\n\n"
                   f"Options:\n"
                   f"• Add Available ({available}) — Only add what's in stock\n"
                   f"• Quick Restock (+{shortage}) — Add {shortage} to inventory & full order\n"
                   f"• Cancel — Don't add to cart")

        win = tk.Toplevel(self.root)
        win.title("Stock Alert")
        win.geometry("480x350")
        win.grab_set()
        win.configure(bg=C["bg"])
        win.resizable(False, False)
        win.transient(self.root)

        result = {"action": "cancel"}

        tk.Label(win, text="⚠ Stock Alert", font=("Segoe UI", 16, "bold"),
                 bg=C["bg"], fg="#D32F2F", pady=10).pack(fill=tk.X)

        # Message frame
        msg_frame = tk.Frame(win, bg="#FFF3E0", relief=tk.GROOVE, bd=1)
        msg_frame.pack(fill=tk.X, padx=16, pady=6)
        tk.Label(msg_frame, text=msg, font=FONT_NORMAL, bg="#FFF3E0",
                 fg=C["text"], justify=tk.LEFT, wraplength=440,
                 padx=12, pady=10).pack(fill=tk.X)

        # Buttons frame
        btn_frame = tk.Frame(win, bg=C["bg"])
        btn_frame.pack(fill=tk.X, padx=16, pady=12)

        def on_add_available():
            result["action"] = "add_available"
            win.destroy()

        def on_quick_restock():
            result["action"] = "quick_restock"
            win.destroy()

        def on_cancel():
            result["action"] = "cancel"
            win.destroy()

        if available > 0:
            tk.Button(btn_frame, text=f"✓ Add Available ({available})",
                      font=FONT_BOLD, bg="#4CAF50", fg="white",
                      relief=tk.FLAT, padx=12, pady=8, cursor="hand2",
                      command=on_add_available).pack(side=tk.LEFT, padx=4, expand=True, fill=tk.X)

        tk.Button(btn_frame, text=f"+ Quick Restock (+{shortage})",
                  font=FONT_BOLD, bg="#FF9800", fg="white",
                  relief=tk.FLAT, padx=12, pady=8, cursor="hand2",
                  command=on_quick_restock).pack(side=tk.LEFT, padx=4, expand=True, fill=tk.X)

        tk.Button(btn_frame, text="✕ Cancel",
                  font=FONT_BOLD, bg="#9E9E9E", fg="white",
                  relief=tk.FLAT, padx=12, pady=8, cursor="hand2",
                  command=on_cancel).pack(side=tk.LEFT, padx=4, expand=True, fill=tk.X)

        win.protocol("WM_DELETE_WINDOW", on_cancel)
        # Center the dialog
        win.update_idletasks()
        x = self.root.winfo_x() + (self.root.winfo_width() - win.winfo_width()) // 2
        y = self.root.winfo_y() + (self.root.winfo_height() - win.winfo_height()) // 2
        win.geometry(f"+{max(0,x)}+{max(0,y)}")

        self.root.wait_window(win)
        return result["action"]

    def _quick_restock_item(self, name, add_qty):
        """Quick add stock for an item from the order screen."""
        stock_info = db.get_item_stock(name)
        if stock_info["id"] is None:
            return False
        if not stock_info["is_tracked"]:
            # Item not tracked yet, initialize it
            db.init_stock_for_item(stock_info["id"], add_qty, stock_info["low_stock_threshold"])
        else:
            db.adjust_stock(stock_info["id"], add_qty)
        # Refresh items to show updated stock badges
        self._refresh_items()
        return True

    def _add_item(self, name, price):
        ot = self.order_type.get()
        # ── Stock check before adding ──
        status, stock_info = self._check_stock_before_add(name, 1)
        if status == "out_of_stock":
            action = self._show_stock_alert(name, stock_info, 1)
            if action == "quick_restock":
                shortage = stock_info.get("in_cart", 0) + 1 - stock_info.get("available", 0)
                if shortage < 1:
                    shortage = 1
                self._quick_restock_item(name, shortage)
                # Re-verify stock after restock before proceeding
                recheck_status, _ = self._check_stock_before_add(name, 1)
                if recheck_status != "ok" and recheck_status != "insufficient":
                    return  # Still can't add after restock attempt
            elif action == "add_available":
                return  # Can't add if out of stock (0 available)
            else:
                return
        elif status == "packaging_out":
            pkg_name = stock_info.get("packaging_type_name", "Unknown")
            action = messagebox.askyesno(
                "Packaging Out of Stock",
                f"⚠ Packaging '{pkg_name}' is out of stock!\n\n"
                f"This item needs '{pkg_name}' for parcel packaging.\n"
                f"Options:\n"
                f"• Yes = Quick Restock packaging & add to cart\n"
                f"• No = Cancel (switch to dine-in or restock packaging first)",
                parent=self.root
            )
            if action:
                # Quick restock packaging
                pkg_type_id = stock_info.get("packaging_type_id")
                if pkg_type_id:
                    add_qty = stock_info.get("requested", 1) + 5  # Add extra buffer
                    try:
                        pkg_current = db.get_packaging_stock(pkg_type_id)
                        if not pkg_current.get("is_tracked", False):
                            db.adjust_packaging_stock(pkg_type_id, add_qty)
                        else:
                            db.adjust_packaging_stock(pkg_type_id, add_qty)
                    except Exception:
                        pass
                # Re-check
                recheck_status, _ = self._check_stock_before_add(name, 1)
                if recheck_status == "packaging_out":
                    return  # Still can't add
            else:
                return
        elif status == "insufficient":
            action = self._show_stock_alert(name, stock_info, 1)
            if action == "quick_restock":
                shortage = stock_info.get("in_cart", 0) + 1 - stock_info.get("available", 0)
                if shortage < 1:
                    shortage = 1
                self._quick_restock_item(name, shortage)
                # Re-verify stock after restock
                recheck_status, _ = self._check_stock_before_add(name, 1)
                if recheck_status not in ("ok", "insufficient"):
                    return
            elif action == "add_available":
                # Add only up to available stock — only if item not already at max in cart
                in_cart = stock_info.get("in_cart", 0)
                available = stock_info.get("available", 0)
                if in_cart >= available:
                    messagebox.showinfo("Stock Limit",
                        f"'{name}' — Already at maximum available ({available}) in cart.")
                    return
                # Fall through to normal add (will hit the max next time)
            else:
                return

        for c in self.cart:
            if c['name'] == name and c.get('type', 'dine-in') == ot:
                c['qty'] += 1
                c['total'] = c['price'] * c['qty']
                self._refresh_cart()
                self._refresh_items()
                return
        self.cart.append({'name': name, 'section': self._lookup_section(name),
                          'price': price, 'qty': 1, 'total': price, 'type': ot})
        self._refresh_cart()
        self._refresh_items()

    def _change_qty(self, name, item_type, delta):
        # If increasing qty (+1), check stock first
        if delta > 0:
            status, stock_info = self._check_stock_before_add(name, delta)
            if status == "out_of_stock":
                action = self._show_stock_alert(name, stock_info, delta)
                if action == "quick_restock":
                    shortage = stock_info.get("in_cart", 0) + delta - stock_info.get("available", 0)
                    if shortage < 1:
                        shortage = 1
                    self._quick_restock_item(name, shortage)
                    # Re-verify after restock
                    recheck_status, _ = self._check_stock_before_add(name, delta)
                    if recheck_status == "out_of_stock":
                        return  # Still can't add
                elif action == "add_available":
                    # Only add what's available
                    available = stock_info.get("available", 0)
                    in_cart = stock_info.get("in_cart", 0)
                    can_add = max(0, available - in_cart)
                    if can_add <= 0:
                        messagebox.showinfo("Stock Limit",
                            f"'{name}' — Already at maximum available ({available}) in cart.")
                        return
                    delta = can_add  # Adjust delta to only add what's available
                else:
                    return
            elif status == "packaging_out":
                pkg_name = stock_info.get("packaging_type_name", "Unknown")
                action = messagebox.askyesno(
                    "Packaging Out of Stock",
                    f"⚠ Packaging '{pkg_name}' is out of stock!\n\n"
                    f"This item needs '{pkg_name}' for parcel packaging.\n"
                    f"• Yes = Quick Restock packaging\n"
                    f"• No = Cancel",
                    parent=self.root
                )
                if action:
                    pkg_type_id = stock_info.get("packaging_type_id")
                    if pkg_type_id:
                        try:
                            db.adjust_packaging_stock(pkg_type_id, delta + 5)
                        except Exception:
                            pass
                    recheck_status, _ = self._check_stock_before_add(name, delta)
                    if recheck_status == "packaging_out":
                        return
                else:
                    return
            elif status == "insufficient":
                action = self._show_stock_alert(name, stock_info, delta)
                if action == "quick_restock":
                    shortage = stock_info.get("in_cart", 0) + delta - stock_info.get("available", 0)
                    if shortage < 1:
                        shortage = 1
                    self._quick_restock_item(name, shortage)
                    recheck_status, _ = self._check_stock_before_add(name, delta)
                    if recheck_status == "out_of_stock":
                        return
                elif action == "add_available":
                    available = stock_info.get("available", 0)
                    in_cart = stock_info.get("in_cart", 0)
                    can_add = max(0, available - in_cart)
                    if can_add <= 0:
                        messagebox.showinfo("Stock Limit",
                            f"'{name}' — Already at maximum available ({available}) in cart.")
                        return
                    delta = can_add
                else:
                    return

        for i, c in enumerate(self.cart):
            if c['name'] == name and c.get('type', 'dine-in') == item_type:
                new_qty = c['qty'] + delta
                if new_qty <= 0:
                    self.cart.pop(i)
                else:
                    c['qty']  = new_qty
                    c['total'] = c['price'] * new_qty
                break
        self._refresh_cart()
        self._refresh_items()

    def _toggle_extras(self):
        """Show/hide the discount & delivery charge fields."""
        if self._extras_visible:
            self._extras_frame.pack_forget()
            self._extras_toggle_btn.config(text="▸ Disc / Delivery")
            self._extras_visible = False
        else:
            self._extras_frame.pack(fill=tk.X, padx=4, pady=(0, 2),
                                    after=self._extras_toggle_btn)
            self._extras_toggle_btn.config(text="▾ Disc / Delivery")
            self._extras_visible = True

    def _on_coupon_selected(self, event=None):
        self._updating_discount_from_coupon = True
        try:
            val = self.coupon_var.get()
            if val == "None" or not val:
                self.discount_pct.set("0")
                self.discount_flat.set("0")
            else:
                code = val.split(" ")[0]
                coupons = CFG.get("coupons", [])
                matched = next((c for c in coupons if c.get("code") == code), None)
                if matched:
                    v = f"{matched.get('value', 0.0):.2f}"
                    if v.endswith(".00"):
                        v = v[:-3]
                    elif v.endswith("0") and "." in v:
                        v = v[:-1]
                        
                    if matched.get("type") == "percentage":
                        self.discount_pct.set(v)
                        self.discount_flat.set("0")
                    else:
                        self.discount_pct.set("0")
                        self.discount_flat.set(v)
                else:
                    self.discount_pct.set("0")
                    self.discount_flat.set("0")
        finally:
            self._updating_discount_from_coupon = False
        self._refresh_totals_only()

    def _set_quick_discount_pct(self, pct):
        self._updating_discount_from_coupon = True
        try:
            self.discount_pct.set(str(pct))
            self.discount_flat.set("0")
            self.coupon_var.set("None")
        finally:
            self._updating_discount_from_coupon = False
        self._refresh_totals_only()

    def _on_discount_pct_changed_manually(self):
        if not hasattr(self, "_updating_discount_from_coupon") or not self._updating_discount_from_coupon:
            self.coupon_var.set("None")
        self._refresh_totals_only()

    def _on_discount_flat_changed_manually(self):
        if not hasattr(self, "_updating_discount_from_coupon") or not self._updating_discount_from_coupon:
            self.coupon_var.set("None")
        self._refresh_totals_only()

    def _refresh_totals_only(self):
        sub   = sum(c['total'] for c in self.cart)

        # Calculate packaging charges for parcel items using assigned packaging type
        FLAT_PKG_CHARGE = 5.0
        packaging_charge = 0.0
        for c in self.cart:
            if c.get('type', 'dine-in') == 'parcel':
                packaging_charge += FLAT_PKG_CHARGE * c['qty']

        try:
            disc_pct = float(self.discount_pct.get() or "0")
        except ValueError:
            disc_pct = 0.0

        try:
            disc_flat = float(self.discount_flat.get() or "0")
        except ValueError:
            disc_flat = 0.0

        try:
            del_chg = float(self.delivery_charges.get() or "0")
        except ValueError:
            del_chg = 0.0

        discount_amount = round(sub * (disc_pct / 100.0) + disc_flat, 2)
        discount_amount = min(discount_amount, sub)
        taxable_value = max(0.0, sub - discount_amount)

        gst_rate = CFG.get("gst_rate", 5)
        gst = round(taxable_value * gst_rate / 100, 2)
        total = round(taxable_value + gst + packaging_charge + del_chg, 2)

        # Compact summary line
        parts = [f"{t('Subtotal', 'Sub')} ₹{sub:.0f}"]
        if discount_amount > 0:
            parts.append(f"{t('Discount', 'Disc')} -₹{discount_amount:.0f}")
        parts.append(f"{t('GST')} ₹{gst:.0f}")
        if packaging_charge > 0:
            parts.append(f"{t('Packaging', 'Pkg')} ₹{packaging_charge:.0f}")
        if del_chg > 0:
            parts.append(f"{t('Delivery Charges', 'Del')} ₹{del_chg:.0f}")
        self._lbl_summary.config(text=" | ".join(parts))
        self._lbl_total.config(text=f"{t('Total', 'TOTAL')} : ₹{total:.2f}")
        
        # Update hidden labels for backward-compat (bill preview, etc.)
        self._lbl_sub.config(text=f"{t('Subtotal')} : ₹{sub:.2f}")
        pct_lbl = f" ({disc_pct}%)" if disc_pct > 0 else ""
        self._lbl_disc.config(text=f"{t('Discount')}{pct_lbl} : -₹{discount_amount:.2f}")
        self._lbl_gst.config(text=f"GST({gst_rate}%)  : ₹{gst:.2f}")
        self._lbl_delivery.config(text=f"{t('Delivery Charges', 'Delivery')} : ₹{del_chg:.2f}")
        
        # Update cart count badge
        n = sum(c['qty'] for c in self.cart)
        if hasattr(self, '_cart_count_lbl'):
            item_lbl = t("items", "items") if n != 1 else t("item", "item")
            self._cart_count_lbl.config(text=f"{n} {item_lbl}")
        
        self._update_customer_display()

    def _refresh_cart(self):
        for w in self._cart_frame.winfo_children():
            w.destroy()

        if not self.cart:
            tk.Label(self._cart_frame, text="No items in order",
                     bg=C["cart_bg"], fg=C["muted"],
                     font=FONT_CART_NAME, pady=16).pack()
        else:
            for item in self.cart:
                # ── Single compact row per item ──
                row = tk.Frame(self._cart_frame, bg=C["cart_bg"], pady=1, padx=3)
                row.pack(fill=tk.X)
                row.columnconfigure(1, weight=1)  # name column stretches

                # Qty controls: compact [-][N][+] block
                qty_frm = tk.Frame(row, bg=C["cart_bg"])
                qty_frm.grid(row=0, column=0, padx=(0, 2))
                tk.Button(qty_frm, text="−", font=FONT_CART_QTY, relief=tk.FLAT,
                          bg="#FFDDCC", fg=C["red"], width=2, pady=0, cursor="hand2",
                          command=lambda n=item['name'], t=item.get('type', 'dine-in'): self._change_qty(n, t, -1)
                          ).pack(side=tk.LEFT)
                tk.Label(qty_frm, text=str(item['qty']), font=FONT_CART_QTY,
                         bg=C["cart_bg"], width=2, anchor=tk.CENTER).pack(side=tk.LEFT)
                tk.Button(qty_frm, text="+", font=FONT_CART_QTY, relief=tk.FLAT,
                          bg="#CCFFCC", fg=C["green"], width=2, pady=0, cursor="hand2",
                          command=lambda n=item['name'], t=item.get('type', 'dine-in'): self._change_qty(n, t, 1)
                          ).pack(side=tk.LEFT)

                # Item name (truncated) — v1.5.2: wider, no OTC/Pcl toggle
                tk.Label(row, text=item['name'][:24], bg=C["cart_bg"],
                         fg=C["text"], font=FONT_CART_NAME, anchor=tk.W
                         ).grid(row=0, column=1, sticky="ew", padx=2, columnspan=2)

                # Price
                tk.Label(row, text=f"₹{item['total']}", font=FONT_CART_PRICE,
                         bg=C["cart_bg"], fg=C["green"], anchor=tk.E
                         ).grid(row=0, column=3, padx=(2, 0))

                # Remove button
                tk.Button(row, text="✕", font=FONT_CART_REMOVE, relief=tk.FLAT,
                          bg=C["cart_bg"], fg=C["red"], cursor="hand2", width=2, pady=0,
                          command=lambda n=item['name'], t=item.get('type', 'dine-in'): self._remove_item(n, t)
                          ).grid(row=0, column=4)

                # Row 1: Note to Chef (item-wise note)
                note_var = tk.StringVar(value=item.get('notes', ''))
                def make_save_note(n=item['name'], itype=item.get('type', 'dine-in'), v=note_var):
                    for c in self.cart:
                        if c['name'] == n and c.get('type', 'dine-in') == itype:
                            c['notes'] = v.get().strip()
                note_var.trace_add("write", lambda *args, f=make_save_note: f())

                note_frame = tk.Frame(row, bg=C["cart_bg"])
                note_frame.grid(row=1, column=1, columnspan=4, sticky="ew", pady=(1, 2))

                tk.Label(
                    note_frame,
                    text=t("Notes", "Note") + ":",
                    font=("Segoe UI", 8, "italic"),
                    bg=C["cart_bg"],
                    fg=C["muted"]
                ).pack(side=tk.LEFT, padx=(0, 2))

                note_ent = tk.Entry(
                    note_frame,
                    textvariable=note_var,
                    font=("Segoe UI", 8),
                    bg="white",
                    fg="black",
                    relief=tk.SOLID,
                    bd=1,
                    highlightthickness=0
                )
                note_ent.pack(side=tk.LEFT, fill=tk.X, expand=True)

                # Thin separator
                tk.Frame(self._cart_frame, bg=C["border"], height=1).pack(fill=tk.X)

        # Update totals
        self._refresh_totals_only()

    def _remove_item(self, name, item_type):
        self.cart = [c for c in self.cart if not (c['name'] == name and c.get('type', 'dine-in') == item_type)]
        self._refresh_cart()
        self._refresh_items()

    def _toggle_cart_item_type(self, name, item_type):
        curr_idx = -1
        for i, c in enumerate(self.cart):
            if c['name'] == name and c.get('type', 'dine-in') == item_type:
                curr_idx = i
                break
        if curr_idx != -1:
            c = self.cart[curr_idx]
            new_type = 'parcel' if item_type == 'dine-in' else 'dine-in'
            # Check if there is already an entry for this name and new_type
            merge_idx = -1
            for j, c_other in enumerate(self.cart):
                if j != curr_idx and c_other['name'] == name and c_other.get('type', 'dine-in') == new_type:
                    merge_idx = j
                    break
            if merge_idx != -1:
                # Merge quantities
                self.cart[merge_idx]['qty'] += c['qty']
                price = self._lookup_price(name, new_type)
                if price > 0:
                    self.cart[merge_idx]['price'] = price
                self.cart[merge_idx]['total'] = self.cart[merge_idx]['price'] * self.cart[merge_idx]['qty']
                # Remove the old one
                self.cart.pop(curr_idx)
            else:
                # Just toggle it
                c['type'] = new_type
                price = self._lookup_price(name, new_type)
                if price > 0:
                    c['price'] = price
                c['total'] = c['price'] * c['qty']
        self._refresh_cart()
        self._refresh_items()

    def _clear_cart(self):
        self.cart.clear()
        self.table_no.set("")
        self.customer.set("")
        self.order_notes.set("")
        self.discount_pct.set("0")
        self.discount_flat.set("0")
        self.delivery_charges.set("0")
        self._select_order_type("dine-in")
        self._refresh_cart()
        self._refresh_items()

    def _select_payment_mode(self, mode):
        self.payment_mode.set(mode)
        for m_id, btn in getattr(self, "_pay_btns", {}).items():
            if m_id == mode:
                btn.config(bg=C["accent"], fg="white", font=("Segoe UI", 9, "bold"))
            else:
                btn.config(bg="#EEDDCC", fg=C["text"], font=("Segoe UI", 9))

    def _select_order_type(self, val):
        self.order_type.set(val)
        self._on_type_change()
        for k, btn in getattr(self, "_order_type_btns", {}).items():
            if k == val:
                btn.config(bg=C["accent"], fg="white", font=FONT_BOLD)
            else:
                btn.config(bg="#FFE4CC", fg=C["text"], font=FONT_NORMAL)

    def _import_menu(self):
        import os
        from tkinter import filedialog
        file_path = filedialog.askopenfilename(
            title="Import Menu Card",
            filetypes=[
                ("All Menu Files", "*.csv *.xlsx *.pdf"),
                ("CSV Files", "*.csv"),
                ("Excel Files", "*.xlsx"),
                ("PDF Files", "*.pdf")
            ]
        )
        if not file_path:
            return
            
        ext = os.path.splitext(file_path)[1].lower()
        try:
            if ext == '.csv':
                secs, items = db.import_menu_from_csv(file_path)
            elif ext == '.xlsx':
                secs, items = db.import_menu_from_excel(file_path)
            elif ext == '.pdf':
                secs, items = db.import_menu_from_pdf(file_path)
            else:
                messagebox.showerror("Unsupported File", "Please select a .csv, .xlsx, or .pdf file.")
                return
                
            messagebox.showinfo("Import Success", f"Successfully imported:\nSections added: {secs}\nItems added: {items}")
            self._load_menu_manager()
            self._reload_menu()
        except Exception as e:
            messagebox.showerror("Import Error", f"Failed to import menu:\n{e}")

    def _download_template(self):
        import os
        from tkinter import filedialog
        file_path = filedialog.asksaveasfilename(
            title="Save Menu Template",
            defaultextension=".csv",
            filetypes=[("CSV Files", "*.csv"), ("Excel Files", "*.xlsx")],
            initialfile="menu_template.csv"
        )
        if not file_path:
            return
            
        ext = os.path.splitext(file_path)[1].lower()
        try:
            if ext == '.csv':
                import csv
                with open(file_path, 'w', newline='', encoding='utf-8') as f:
                    writer = csv.writer(f)
                    writer.writerow(["Section", "Item Name", "Dine-in Price", "Parcel Price"])
                    writer.writerow(["Snackpur", "Punjabi Samosa", "20", "25"])
                    writer.writerow(["Snackpur", "Vada Pav", "15", "20"])
                    writer.writerow(["Tawa & Tandoor", "Cheese Kulcha", "135", "170"])
                messagebox.showinfo("Success", f"CSV Menu template downloaded successfully to:\n{file_path}")
            elif ext == '.xlsx':
                try:
                    import openpyxl
                    wb = openpyxl.Workbook()
                    ws = wb.active
                    ws.title = "Menu Template"
                    ws.append(["Section", "Item Name", "Dine-in Price", "Parcel Price"])
                    ws.append(["Snackpur", "Punjabi Samosa", 20, 25])
                    ws.append(["Snackpur", "Vada Pav", 15, 20])
                    ws.append(["Tawa & Tandoor", "Cheese Kulcha", 135, 170])
                    wb.save(file_path)
                    messagebox.showinfo("Success", f"Excel Menu template downloaded successfully to:\n{file_path}")
                except ImportError:
                    messagebox.showerror("Dependency Error", "To download Excel (.xlsx) templates, please install openpyxl first via: pip install openpyxl\nAlternatively, download as CSV.")
            else:
                messagebox.showerror("Unsupported File", "Please select a .csv or .xlsx file extension.")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to save template:\n{e}")



    def _build_kot_items(self):
        """Build KOT items list with packaging type info for each parcel item."""
        kot_items = []
        for c in self.cart:
            item = {'name': c['name'], 'qty': c['qty'], 'type': c.get('type', 'dine-in'), 'notes': c.get('notes', '')}
            # Add packaging type info for parcel items
            if c.get('type', 'dine-in') == 'parcel':
                try:
                    pkg_info = db.get_packaging_for_item(c['name'], 'parcel')
                    item['packaging_type'] = pkg_info.get('packaging_type_name', '')
                except Exception:
                    item['packaging_type'] = ''
            kot_items.append(item)
        return kot_items

    def _build_bill_items(self):
        """Build bill items list with packaging type info for each parcel item."""
        bill_items = []
        for c in self.cart:
            item = {'name': c['name'], 'section': c.get('section',''),
                    'price': c['price'], 'qty': c['qty'],
                    'type': c.get('type', 'dine-in'), 'notes': c.get('notes', '')}
            # Add packaging type info for parcel items
            if c.get('type', 'dine-in') == 'parcel':
                try:
                    pkg_info = db.get_packaging_for_item(c['name'], 'parcel')
                    item['packaging_type'] = pkg_info.get('packaging_type_name', '')
                except Exception:
                    item['packaging_type'] = ''
            bill_items.append(item)
        return bill_items

    def _build_meta(self):
        sub  = sum(c['total'] for c in self.cart)

        # v1.2: Packaging charge — based on per-order packaging_required flag
        # (not per-item parcel anymore). Configured in Settings:
        #   packaging_charge_mode: "none" | "fixed" | "per_item"
        #   packaging_charge_amount: float
        packaging_charge = 0.0
        packaging_details = []
        if getattr(self, 'packaging_required_var', None) and self.packaging_required_var.get():
            mode = CFG.get("packaging_charge_mode", "none")
            amount = float(CFG.get("packaging_charge_amount", 0.0))
            if mode == "fixed" and amount > 0:
                packaging_charge = amount
            elif mode == "per_item" and amount > 0:
                packaging_charge = amount * sum(c['qty'] for c in self.cart)
            packaging_details.append({
                'mode': mode,
                'amount': amount,
                'items_count': sum(c['qty'] for c in self.cart),
            })

        # Apply discount before GST
        try:
            disc_pct = float(self.discount_pct.get() or "0")
        except ValueError:
            disc_pct = 0.0
        try:
            disc_flat = float(self.discount_flat.get() or "0")
        except ValueError:
            disc_flat = 0.0
        try:
            del_chg = float(self.delivery_charges.get() or "0")
        except ValueError:
            del_chg = 0.0

        discount_amount = round(sub * (disc_pct / 100.0) + disc_flat, 2)
        discount_amount = min(discount_amount, sub)
        taxable_value = max(0.0, sub - discount_amount)

        gst  = CFG.get("gst_rate", 5)
        cgst = round(taxable_value * gst / 200, 2)
        sgst = round(taxable_value * gst / 200, 2)

        # v1.2: packaging_required flag — read from checkbox var if available
        pkg_req = False
        if hasattr(self, 'packaging_required_var') and self.packaging_required_var:
            pkg_req = bool(self.packaging_required_var.get())

        # v1.3: order_source — defaults to "walkin". Aggregator orders (Swiggy, Zomato, etc.)
        # will set this via the aggregator UI / webhook when that feature ships.
        # For now, all manual POS orders are walkin.
        order_source = 'walkin'
        if hasattr(self, 'order_source_var') and self.order_source_var:
            order_source = str(self.order_source_var.get() or 'walkin')
        aggregator_order_id = ''
        if hasattr(self, 'aggregator_order_id_var') and self.aggregator_order_id_var:
            aggregator_order_id = str(self.aggregator_order_id_var.get() or '')

        return {
            'order_type':        'standard',  # v1.2: single order type
            'table_no':          self.table_no.get().strip(),
            'customer_name':     self.customer.get().strip(),
            'payment_mode':      self.payment_mode.get(),
            'date':              db.today(),
            'time':              db.now_time(),
            'subtotal':          round(sub, 2),
            'discount_percentage': disc_pct,
            'discount_amount':   discount_amount,
            'cgst':              cgst,
            'sgst':              sgst,
            'packaging_charge':  round(packaging_charge, 2),
            'delivery_charges':  del_chg,
            'total':             round(taxable_value + cgst + sgst + packaging_charge + del_chg, 2),
            'terminal_id':       int(CFG.get("terminal_id", 1)),
            'notes':             self.order_notes.get().strip(),
            'packaging_details': packaging_details,
            'packaging_required': pkg_req,  # v1.2
            'order_source':       order_source,           # v1.3: walkin / swiggy / zomato / etc.
            'aggregator_order_id': aggregator_order_id,   # v1.3: aggregator's order reference
        }

    def _show_packaging_dialog(self) -> bool:
        """v1.3.1: Simplified confirmation dialog.
        - Packaging checkbox is now ON THE CART PAGE (not here).
        - Swiggy/Zomato dropdown REMOVED — aggregator orders will come
          via webhook in v1.4 and auto-set order_source + packaging.
        - This dialog just shows the current packaging state and asks
          'Continue to Payment?' or 'Cancel'.
        Returns True if user clicked Continue, False if cancelled."""
        dlg = tk.Toplevel(self.root)
        dlg.title(t("Checkout", "Checkout"))
        dlg.geometry("440x260")
        dlg.resizable(False, False)
        dlg.configure(bg=C["bg"])
        dlg.transient(self.root)
        dlg.grab_set()

        # Header
        tk.Label(dlg, text=t("Checkout", "Checkout"),
                 font=("Segoe UI", 14, "bold"), bg=C["bg"], fg=C["header"]).pack(pady=(16, 4))

        # Cart summary
        sub = sum(c['total'] for c in self.cart)
        summary_text = f"{t('Items', 'Items')}: {sum(c['qty'] for c in self.cart)}    {t('Subtotal', 'Subtotal')}: Rs.{sub:.2f}"
        tk.Label(dlg, text=summary_text, font=FONT_NORMAL,
                 bg=C["bg"], fg=C["text"]).pack(pady=4)

        # Show current packaging state (read-only — user changes it on cart page)
        if self.packaging_required_var.get():
            state_text = "📦 " + t("Packaging: YES (kitchen will pack this order)",
                                    "Packaging: YES (kitchen will pack this order)")
            state_color = C["accent"]
        else:
            state_text = "🍽️ " + t("Packaging: NO (kitchen will plate this order)",
                                    "Packaging: NO (kitchen will plate this order)")
            state_color = C["muted"]
        tk.Label(dlg, text=state_text, font=("Segoe UI", 11, "bold"),
                 bg=C["bg"], fg=state_color).pack(pady=8)

        # Hint to user
        tk.Label(dlg, text=t("(To change, use the Packaging checkbox on the cart page)",
                              "(To change, use the Packaging checkbox on the cart page)"),
                 font=FONT_SMALL, bg=C["bg"], fg=C["muted"]).pack(pady=2)

        # Buttons
        btn_frame = tk.Frame(dlg, bg=C["bg"])
        btn_frame.pack(pady=14)
        result = {'ok': False}

        def on_continue():
            result['ok'] = True
            dlg.destroy()

        def on_cancel():
            result['ok'] = False
            dlg.destroy()

        tk.Button(btn_frame, text=t("Continue to Payment", "Continue to Payment"),
                  font=("Segoe UI", 11, "bold"),
                  bg=C["bill_btn"], fg="white", relief=tk.FLAT,
                  padx=20, pady=8, command=on_continue).pack(side=tk.LEFT, padx=8)
        tk.Button(btn_frame, text=t("Cancel", "Cancel"),
                  font=FONT_NORMAL,
                  bg=C["sec_bg"], fg=C["header_fg"], relief=tk.FLAT,
                  padx=16, pady=8, command=on_cancel).pack(side=tk.LEFT, padx=8)

        dlg.bind("<Escape>", lambda e: on_cancel())
        self.root.wait_window(dlg)
        return result['ok']

    def _on_packaging_toggle(self):
        """Update helper label when packaging checkbox is toggled."""
        if hasattr(self, '_packaging_helper_lbl') and self._packaging_helper_lbl:
            if self.packaging_required_var.get():
                txt = t("Kitchen will pack this order (parcel / takeaway).",
                        "Kitchen will pack this order (parcel / takeaway).")
            else:
                txt = t("Kitchen will plate this order (dine-in).",
                        "Kitchen will plate this order (dine-in).")
            self._packaging_helper_lbl.config(text=txt)

    # ── v1.2: Hub callback handlers ─────────────────────────────

    def _hub_connected(self):
        """Called when POS→Hub client connects."""
        # v1.2.1: refresh the status label immediately
        try:
            self._refresh_kds_connection_count()
        except Exception:
            pass

    def _hub_disconnected(self):
        """Called when POS→Hub client disconnects."""
        # v1.2.1: refresh the status label immediately
        try:
            self._refresh_kds_connection_count()
        except Exception:
            pass

    def _hub_kot_received(self, kot: dict):
        """Called when another POS raises a KOT — add it to our KOT Monitor."""
        try:
            # Refresh the KOT monitor view if it's visible
            if hasattr(self, '_kots_tree') and self._active_tab.get() == "kots":
                self._load_kots()
        except Exception as e:
            print(f"[hub kot recv] {e}")

    def _hub_bill_received(self, bill: dict):
        """Called when another POS generates a bill — add it to our Bills tab."""
        try:
            if hasattr(self, '_bills_tree') and self._active_tab.get() == "bills":
                self._load_bills()
        except Exception as e:
            print(f"[hub bill recv] {e}")

    def _hub_status_update(self, kot_no: int, status: str):
        """Called when another POS/KDS updates KOT status."""
        try:
            if hasattr(self, '_kots_tree') and self._active_tab.get() == "kots":
                self._load_kots()
        except Exception as e:
            print(f"[hub status recv] {e}")

    def _hub_menu_update(self, action: str, payload: dict):
        """Called when another POS edits the menu — apply locally and refresh."""
        try:
            db.apply_menu_update(action, payload)
            # Reload menu in memory
            self._menu = db.get_menu_db()
            # Refresh the order screen if visible
            if hasattr(self, '_item_frame') and self._active_tab.get() == "order":
                self._refresh_items()
            # Refresh Menu Manager if visible
            if self._active_tab.get() == "menu":
                self._load_menu_manager()
        except Exception as e:
            print(f"[hub menu update recv] {e}")

    def _hub_menu_snapshot(self, menu: dict):
        """Called when hub sends the full menu snapshot on connect."""
        try:
            # Just reload from DB (the hub applied changes before sending)
            self._menu = db.get_menu_db()
            if hasattr(self, '_item_frame') and self._active_tab.get() == "order":
                self._refresh_items()
        except Exception as e:
            print(f"[hub menu snapshot recv] {e}")

    def _hub_initial_state(self, state: dict):
        """Called when hub sends today's KOTs and bills on connect."""
        try:
            if self._active_tab.get() == "kots":
                self._load_kots()
            if self._active_tab.get() == "bills":
                self._load_bills()
        except Exception as e:
            print(f"[hub initial state recv] {e}")

    def _action_kot(self):
        if not self.cart:
            messagebox.showwarning("Empty order", "Add items before generating KOT.")
            return
        # v1.2: skip packaging stock check (no per-item parcel concept anymore)
        # if not self._check_packaging_stock_before_action():
        #     return
        meta  = self._build_meta()
        items = self._build_kot_items()
        kot   = db.save_kot_with_packaging(meta, items)  # v1.2: includes packaging_required

        # Broadcast to KDS (legacy protocol)
        self._network_broadcast({"type": "new_kot", "kot": kot})
        self._refresh_kds_connection_count()

        # v1.2: Also send to hub (so other POS see it in their KOT monitor)
        if self.pos_client and self.pos_client.connected:
            self.pos_client.send_kot(kot)

        # Print
        text = pr.format_kot(kot)
        pr.print_text(text, CFG.get("printer_name", ""),
                      copies=int(CFG.get("print_copies_kot", 1)))

        # Deduct stock for KOT items (kitchen is preparing)
        # v1.2: still useful for inventory tracking
        try:
            self._deduct_stock_for_items(items)
        except Exception:
            pass

        self._clear_cart()

    def _check_packaging_stock_before_action(self) -> bool:
        """
        Check if packaging stock is available for all parcel items in cart.
        Returns True if OK to proceed, False if user cancels.
        Shows warning dialog with options if any packaging is out of stock.
        """
        parcel_items = [(c['name'], c['qty']) for c in self.cart if c.get('type', 'dine-in') == 'parcel']
        if not parcel_items:
            return True

        low_packaging = []
        out_packaging = []
        for name, qty in parcel_items:
            try:
                pkg_info = db.get_packaging_stock_for_item(name)
                if pkg_info.get("is_tracked", False):
                    pkg_stock = pkg_info.get("stock_quantity", -1)
                    pkg_name = pkg_info.get("packaging_type_name", "Unknown")
                    if pkg_stock <= 0:
                        out_packaging.append((name, pkg_name, pkg_stock))
                    elif pkg_stock < qty:
                        low_packaging.append((name, pkg_name, pkg_stock, qty))
            except Exception:
                pass

        if not out_packaging and not low_packaging:
            return True

        # Build warning message
        msg = "⚠ PACKAGING STOCK WARNING!\n\n"
        if out_packaging:
            msg += "OUT OF STOCK packaging:\n"
            for item_name, pkg_name, stock in out_packaging:
                msg += f"  • {item_name} → {pkg_name} (0 left)\n"
            msg += "\n"
        if low_packaging:
            msg += "LOW STOCK packaging:\n"
            for item_name, pkg_name, stock, needed in low_packaging:
                msg += f"  • {item_name} → {pkg_name} (only {stock}, need {needed})\n"
            msg += "\n"

        msg += "Kitchen will be notified but packaging may run out.\n\n"
        msg += "Proceed anyway?"

        return messagebox.askyesno("Packaging Stock Warning", msg, parent=self.root)

    def _action_bill(self):
        if not self.cart:
            messagebox.showwarning("Empty order", "Add items before generating Bill.")
            return
        # v1.2: skip packaging stock check (no per-item parcel concept)
        # if not self._check_packaging_stock_before_action():
        #     return
        meta  = self._build_meta()
        items = self._build_bill_items()

        # v1.2: Show pre-checkout dialog with "Packaging required" checkbox
        if not self._show_packaging_dialog():
            return  # user cancelled
        # Rebuild meta with updated packaging_required flag
        meta = self._build_meta()

        # 1. Generate & Save KOT first
        kot_items = self._build_kot_items()
        kot = db.save_kot_with_packaging(meta, kot_items)  # v1.2: with packaging_required

        # 2. Broadcast KOT to KDS (legacy)
        self._network_broadcast({"type": "new_kot", "kot": kot})
        self._refresh_kds_connection_count()

        # v1.2: Also send to hub
        if self.pos_client and self.pos_client.connected:
            self.pos_client.send_kot(kot)

        # 3. Print KOT directly
        # v1.9.4 FIX: gate KOT print behind the same "🖨 Print Bill" checkbox.
        # When unchecked (default), NO print happens at all — no KOT, no bill,
        # no Save As dialog from PDF Architect / Notepad fallback. The KOT is
        # still saved to DB + broadcast to hub + shown on KDS screen.
        # When checked, KOT prints to the thermal printer.
        if getattr(self, 'print_bill_var', None) and self.print_bill_var.get():
            kot_text = pr.format_kot(kot)
            pr.print_text(kot_text, CFG.get("printer_name", ""),
                          copies=int(CFG.get("print_copies_kot", 1)))
        else:
            print(f"[v1.9.4] KOT #{kot.get('kot_no', '?')} saved but not printed (Print Bill checkbox unchecked).")

        # 4. Launch Checkout Assistance Dialog
        pl_enabled = str(CFG.get("pl_enabled", False)).lower() in ("true", "1")
        pl_ip = CFG.get("pl_edc_ip", "").strip()
        default_pm = meta.get('payment_mode', 'cash')

        # Validate Pine Labs EDC terminal IP early if enabled and about to use card/upi
        if default_pm in ("card", "upi") and pl_enabled and not pl_ip:
            messagebox.showerror(
                "Pine Labs Configuration Error",
                "Pine Labs EDC integration is enabled, but the EDC Terminal IP is not configured in Settings.\n\n"
                "Please configure the IP in Settings or disable the integration to proceed."
            )
            return

        def on_complete_checkout(payment_mode, splits, meta_enrich):
            # Update meta with payment mode, splits, and Pine Labs transaction details
            final_meta = {**meta, 'payment_mode': payment_mode, **splits, **meta_enrich}
            self._finalize_bill(final_meta, items)

        CheckoutAssistanceDialog(
            parent=self.root,
            total_amount=meta['total'],
            terminal_ip=pl_ip,
            pl_enabled=pl_enabled,
            default_mode=default_pm,
            on_complete=on_complete_checkout,
            customer_name=meta.get('customer_name', ''),
            notes=meta.get('notes', '')
        )


    def _action_bill_pinelabs(self, meta: dict, items: list):
        """
        Launch the Pine Labs payment dialog.
        On approval  → finalize bill with transaction details.
        On decline   → show error, keep cart intact so staff can retry or switch to cash.
        """
        preview_no = f"BILL{db._next.__doc__ and ''}{meta['date'].replace('/','')}T{meta['time'].replace(':','')}"
        dlg = PineLabsPaymentDialog(
            self.root,
            amount=meta['total'],
            invoice_ref=f"MCL{db.today().replace('/','')}-{preview_no[-6:]}",
        )
        result, err = dlg.result, dlg.error

        if err:
            messagebox.showerror("Payment failed", err)
            return                               # keep cart, allow retry

        if result and result.get("approved"):
            # Enrich meta with transaction details before saving
            meta.update({
                'pl_txn_id':        result.get("txn_id", ""),
                'pl_approval_code': result.get("approval_code", ""),
                'pl_card_scheme':   result.get("card_scheme", ""),
                'pl_masked_card':   result.get("masked_card", ""),
                'pl_invoice_no':    result.get("pl_invoice_no", ""),
                'pl_batch_no':      result.get("batch_no", ""),
            })
            self._finalize_bill(meta, items)
        else:
            # Declined or cancelled
            msg = result.get("message", "Transaction declined") if result else "Transaction cancelled"
            rc  = result.get("response_code", "") if result else ""
            messagebox.showwarning(
                "Payment declined",
                f"{msg}\n\nResponse code: {rc}\n\n"
                "You can retry or switch payment mode to Cash."
            )

    def _finalize_bill(self, meta: dict, items: list):
        """Save, print and clear cart for any fully-approved/cash bill.
        v1.2: Also sends bill to hub for live multi-POS sync.
        v1.3.1: Deducts packaging stock if packaging_required=True (based on
                each item's mapped packaging types in product_packaging table).
        v1.9.2: Bill printing is now gated by the cart's "🖨 Print Bill"
                checkbox. When unchecked (default), the bill is still saved
                to DB + synced to hub + pushed to Supabase, but NO thermal
                print job is sent. Saves paper when cashier doesn't need
                a physical receipt. KOT printing is unaffected (still always
                prints so the kitchen gets their ticket)."""
        bill = db.save_bill_with_packaging(meta, items)  # v1.2: with packaging_required
        # v1.9.2: only print the bill if the cart's Print Bill checkbox is checked.
        # Default is unchecked — cashier must explicitly opt in to printing.
        if getattr(self, 'print_bill_var', None) and self.print_bill_var.get():
            text = pr.format_bill(bill)
            pr.print_text(text, CFG.get("printer_name", ""),
                          copies=int(CFG.get("print_copies_bill", 1)))
        else:
            print(f"[v1.9.2] Bill #{bill.get('bill_no', '?')} saved but not printed (Print Bill checkbox unchecked).")
        # ── Auto-deduct stock for billed items ──
        try:
            self._deduct_stock_for_items(items)
        except Exception:
            pass
        # v1.3.1: Auto-deduct packaging stock when packaging_required is True
        if meta.get('packaging_required'):
            try:
                deductions = db.deduct_packaging_stock_for_order(items)
                if deductions:
                    print(f"[v1.3.1] Packaging stock deducted for {len(deductions)} item(s):")
                    for d in deductions:
                        print(f"  - {d['item_name']} x{d['qty']} → {d['pkg_name']} (-{d['pkg_deducted']}, {d['pkg_remaining']} left)")
            except Exception as e:
                print(f"[v1.3.1 packaging stock deduction] error: {e}")
        # v1.2: Send to hub so other POS see it in their Bills tab
        if self.pos_client and self.pos_client.connected:
            try:
                self.pos_client.send_bill(bill)
            except Exception as e:
                print(f"[v1.2 send_bill to hub] {e}")
        self._clear_cart()

    def _deduct_stock_for_items(self, items: list):
        """Auto-deduct stock for all items in a bill/KOT/hold. Only deducts if stock is tracked.
        Also deducts packaging stock for parcel items."""
        for it in items:
            name = it.get('name', '')
            qty = it.get('qty', 0)
            if not name or qty <= 0:
                continue
            # Deduct product stock
            stock_info = db.get_item_stock(name)
            if stock_info["is_tracked"] and stock_info["id"] is not None:
                db.adjust_stock(stock_info["id"], -qty)
            # Deduct packaging stock for parcel items
            itype = it.get('type', 'dine-in')
            if itype == 'parcel':
                try:
                    pkg_info = db.get_packaging_for_item(name, 'parcel')
                    pkg_type_id = pkg_info.get('packaging_type_id')
                    if pkg_type_id:
                        pkg_stock = db.get_packaging_stock(pkg_type_id)
                        if pkg_stock.get('is_tracked', False):
                            db.adjust_packaging_stock(pkg_type_id, -qty)
                except Exception:
                    pass  # Don't fail billing if packaging stock deduction fails

    def _restore_stock_for_items(self, items: list):
        """Restore stock for items (used when a held bill is deleted/discarded).
        Also restores packaging stock for parcel items."""
        for it in items:
            name = it.get('item_name', '') or it.get('name', '')
            qty = it.get('quantity', 0) or it.get('qty', 0)
            if not name or qty <= 0:
                continue
            # Restore product stock
            stock_info = db.get_item_stock(name)
            if stock_info["is_tracked"] and stock_info["id"] is not None:
                db.adjust_stock(stock_info["id"], qty)
            # Restore packaging stock for parcel items
            itype = it.get('item_type', '') or it.get('type', 'dine-in')
            if itype == 'parcel':
                try:
                    pkg_info = db.get_packaging_for_item(name, 'parcel')
                    pkg_type_id = pkg_info.get('packaging_type_id')
                    if pkg_type_id:
                        pkg_stock = db.get_packaging_stock(pkg_type_id)
                        if pkg_stock.get('is_tracked', False):
                            db.adjust_packaging_stock(pkg_type_id, qty)
                except Exception:
                    pass

    def _show_calendar(self, target_var, on_change=None):
        def on_select(date_str):
            target_var.set(date_str)
            if on_change:
                on_change()
        CalendarPopup(self.root, target_var.get(), on_select)

    def _show_preview(self, title, text):
        win = tk.Toplevel(self.root)
        win.title(title)
        win.geometry("500x520")
        win.grab_set()
        tk.Label(win, text=title, font=FONT_LARGE, pady=6).pack()
        txt = tk.Text(win, font=FONT_MONO, width=48, wrap=tk.WORD)
        txt.pack(fill=tk.BOTH, expand=True, padx=8, pady=4)
        txt.insert("1.0", text)
        txt.config(state=tk.DISABLED)
        tk.Button(win, text="Close", command=win.destroy,
                  font=FONT_NORMAL, padx=20, pady=4).pack(pady=6)

    def _action_hold(self):
        if not self.cart:
            messagebox.showwarning("Empty order", "Add items before holding order.")
            return
        # Check packaging stock before proceeding
        if not self._check_packaging_stock_before_action():
            return
        meta  = self._build_meta()
        items = self._build_bill_items()
        
        # 1. Generate & Save KOT first
        kot_items = self._build_kot_items()
        kot = db.save_kot(meta, kot_items)
        
        # 2. Broadcast KOT to KDS
        self._network_broadcast({"type": "new_kot", "kot": kot})
        self._refresh_kds_connection_count()
        
        # 3. Print KOT directly
        # v1.9.4 FIX: gate KOT print behind the same "🖨 Print Bill" checkbox.
        # When unchecked (default), NO print happens at all — no KOT, no bill,
        # no Save As dialog from PDF Architect / Notepad fallback. The KOT is
        # still saved to DB + broadcast to hub + shown on KDS screen.
        # When checked, KOT prints to the thermal printer.
        if getattr(self, 'print_bill_var', None) and self.print_bill_var.get():
            kot_text = pr.format_kot(kot)
            pr.print_text(kot_text, CFG.get("printer_name", ""),
                          copies=int(CFG.get("print_copies_kot", 1)))
        else:
            print(f"[v1.9.4] KOT #{kot.get('kot_no', '?')} saved but not printed (Print Bill checkbox unchecked).")

        # 4. Save held bill
        held_id = db.save_held_bill(meta, items)
        
        # 5. Print held bill if configured
        if CFG.get("print_on_hold"):
            held_bill = {**meta, 'id': held_id, 'items': items}
            text = pr.format_held_bill(held_bill)
            pr.print_text(text, CFG.get("printer_name", ""))

        # 6. Deduct stock for held items (kitchen is preparing)
        self._deduct_stock_for_items(items)

        self._clear_cart()

    def _action_recall(self):
        held_bills = db.get_held_bills()
        if not held_bills:
            messagebox.showinfo("Recall", "No held orders found.")
            return

        win = tk.Toplevel(self.root)
        win.title("Recall Held Order")
        win.geometry("600x400")
        win.grab_set()
        win.configure(bg=C["bg"])

        tk.Label(win, text="Held Orders", font=FONT_LARGE, bg=C["bg"], fg=C["header"], pady=8).pack()

        # Treeview to list held bills
        cols = ("id", "terminal", "time", "type", "table", "customer", "items", "total")
        
        # Sub-frame for Recall Treeview and Scrollbar side-by-side
        tree_frame_recall = tk.Frame(win)
        tree_frame_recall.pack(fill=tk.BOTH, expand=True, padx=12, pady=8)
        
        tree = ttk.Treeview(tree_frame_recall, columns=cols, show="headings", selectmode="browse")
        for col, w, hdr in [("id", 80, "Ref #"), ("terminal", 60, "Term"), ("time", 80, "Time"),
                             ("type", 80, "Type"), ("table", 70, "Table"),
                             ("customer", 110, "Customer"), ("items", 60, "Items"),
                             ("total", 80, "Total")]:
            tree.heading(col, text=t(hdr, hdr))
            tree.column(col, width=w, anchor=tk.CENTER)
        
        tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        # Scrollbar for tree
        scr = ttk.Scrollbar(tree_frame_recall, orient=tk.VERTICAL, command=tree.yview)
        scr.pack(side=tk.RIGHT, fill=tk.Y)
        tree.configure(yscrollcommand=scr.set)


        # Populate tree
        for hb in held_bills:
            item_count = sum(it['quantity'] for it in hb['items'])
            tree.insert("", tk.END, iid=str(hb['id']), values=(
                f"#H{hb['id']:04d}", f"T{hb.get('terminal_id', 1)}", hb['time'], hb['order_type'],
                hb.get('table_no','─'), hb.get('customer_name','─'),
                item_count, f"₹{hb['total']:.2f}"
            ))

        def load_selected():
            sel = tree.selection()
            if not sel:
                messagebox.showinfo("Select", "Select an order to recall.", parent=win)
                return
            held_id = int(sel[0])
            hb = db.get_held_bill(held_id)
            if hb:
                # Load to cart
                if self.cart:
                    if not messagebox.askyesno("Confirm Overwrite", 
                                                "Current cart is not empty. Overwrite cart with held order?", parent=win):
                        return
                
                # Clear and load
                self._clear_cart()
                self._select_order_type(hb.get('order_type', 'dine-in'))
                self.table_no.set(hb.get('table_no', ''))
                self.customer.set(hb.get('customer_name', ''))
                self.order_notes.set(hb.get('notes', ''))
                self.payment_mode.set(hb.get('payment_mode', 'cash'))
                
                # Load new fields
                disc_pct = hb.get('discount_percentage', 0.0)
                disc_total = hb.get('discount_amount', 0.0)
                subtotal = hb.get('subtotal', 0.0)
                flat_val = max(0.0, round(disc_total - (subtotal * disc_pct / 100.0), 2))
                self.discount_pct.set(str(disc_pct))
                self.discount_flat.set(str(flat_val))
                self.delivery_charges.set(str(hb.get('delivery_charges', 0.0)))
                
                # Load items
                self.cart = []
                for it in hb['items']:
                    self.cart.append({
                        'name': it['item_name'],
                        'section': it.get('section', ''),
                        'price': it['unit_price'],
                        'qty': it['quantity'],
                        'total': it['unit_price'] * it['quantity'],
                        'type': it.get('item_type', 'dine-in'),
                        'notes': it.get('notes', '')
                    })
                
                self._refresh_cart()
                self._refresh_items()
                
                # Restore stock that was deducted during hold (will be re-deducted on bill finalize)
                self._restore_stock_for_items(hb['items'])

                # Delete from held bills
                db.delete_held_bill(held_id)
                win.destroy()
                messagebox.showinfo("Loaded", f"Held order #H{held_id:04d} recalled.")
            else:
                messagebox.showerror("Error", "Held order not found.", parent=win)

        def delete_selected():
            sel = tree.selection()
            if not sel:
                messagebox.showinfo("Select", "Select an order to delete.", parent=win)
                return
            held_id = int(sel[0])
            if messagebox.askyesno("Confirm Delete", f"Delete held order #H{held_id:04d} permanently?", parent=win):
                # Restore stock that was deducted during hold before deleting
                hb = db.get_held_bill(held_id)
                if hb and hb.get('items'):
                    self._restore_stock_for_items(hb['items'])
                db.delete_held_bill(held_id)
                tree.delete(str(held_id))
                if not tree.get_children():
                    win.destroy()

        btn_row = tk.Frame(win, bg=C["bg"])
        btn_row.pack(pady=8)

        tk.Button(btn_row, text="📂 Load Order", font=FONT_BOLD,
                  bg=C["bill_btn"], fg="white", relief=tk.FLAT,
                  padx=16, pady=6, cursor="hand2", command=load_selected).pack(side=tk.LEFT, padx=8)

        tk.Button(btn_row, text="✕ Delete", font=FONT_NORMAL,
                  bg=C["red"], fg="white", relief=tk.FLAT,
                  padx=12, pady=6, cursor="hand2", command=delete_selected).pack(side=tk.LEFT, padx=8)

        tk.Button(btn_row, text="Cancel", font=FONT_NORMAL,
                  bg="#CCCCCC", relief=tk.FLAT,
                  padx=12, pady=6, cursor="hand2", command=win.destroy).pack(side=tk.LEFT, padx=8)

        # Bind double click to load
        tree.bind("<Double-1>", lambda e: load_selected())

    # ─────────────────────────────────── BILLS TAB ─────────

    def _build_bills_tab(self, parent):
        top = tk.Frame(parent, bg=C["header"], padx=8, pady=4)
        top.pack(fill=tk.X)
        tk.Label(top, text="Bill History", font=FONT_LARGE,
                 bg=C["header"], fg=C["header_fg"]).pack(side=tk.LEFT)
        self._bill_date_var = tk.StringVar(value=db.today())
        tk.Label(top, text=t("Date:", "Date:"), bg=C["header"], fg=C["header_fg"],
                 font=FONT_SMALL).pack(side=tk.RIGHT, padx=(0,4))
                 
        btn_cal = tk.Button(top, text=f"📅 {self._bill_date_var.get()}", font=FONT_SMALL, relief=tk.FLAT,
                            bg="#5A2800", fg="#FFEECC", cursor="hand2", padx=8, pady=4,
                            command=lambda: self._show_calendar(self._bill_date_var, self._load_bills))
        btn_cal.pack(side=tk.RIGHT, padx=2)
        self._btn_bill_cal = btn_cal
        
        def update_bill_cal(*args):
            if hasattr(self, '_btn_bill_cal'):
                self._btn_bill_cal.config(text=f"📅 {self._bill_date_var.get()}")
        self._bill_date_var.trace_add("write", update_bill_cal)
        
        tk.Button(top, text="Load", font=FONT_SMALL, relief=tk.FLAT,
                  bg="#FFCC88", cursor="hand2",
                  command=self._load_bills).pack(side=tk.RIGHT, padx=4)

        cols = ("bill_no","terminal","date","time","order_type","table","customer","items","total","payment")
        
        # Sub-frame for Bills Treeview and Scrollbar side-by-side
        tree_frame_bill = tk.Frame(parent)
        tree_frame_bill.pack(fill=tk.BOTH, expand=True, padx=4, pady=4)
        
        self._bill_tree = ttk.Treeview(tree_frame_bill, columns=cols, show="headings",
                                        selectmode="browse")
        for col, w, hdr in [("bill_no",70,"Bill #"),("terminal",50,"Term"),("date",90,"Date"),("time",60,"Time"),
                              ("order_type",80,"Type"),("table",60,"Table"),
                              ("customer",110,"Customer"),("items",50,"Items"),
                              ("total",80,"Total"),("payment",70,"Payment")]:
            self._bill_tree.heading(col, text=t(hdr, hdr))
            self._bill_tree.column(col, width=w, anchor=tk.CENTER)
            
        self._bill_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        self._bill_tree.bind("<Double-1>", self._on_bill_dblclick)

        scr = ttk.Scrollbar(tree_frame_bill, orient=tk.VERTICAL,
                             command=self._bill_tree.yview)
        scr.pack(side=tk.RIGHT, fill=tk.Y)
        self._bill_tree.configure(yscrollcommand=scr.set)


        bot = tk.Frame(parent, bg=C["bg"], pady=4)
        bot.pack(fill=tk.X)
        self._bill_summary = tk.Label(bot, text="", font=FONT_NORMAL,
                                       bg=C["bg"], fg=C["muted"])
        self._bill_summary.pack(side=tk.LEFT, padx=8)
        tk.Button(bot, text="Void card payment (Pine Labs)",
                  font=FONT_SMALL, bg="#8B0000", fg="white",
                  relief=tk.FLAT, padx=8, cursor="hand2",
                  command=self._void_bill_pinelabs).pack(side=tk.RIGHT, padx=4)
        tk.Button(bot, text="Reprint selected", font=FONT_SMALL,
                  bg=C["header"], fg="white", relief=tk.FLAT, padx=8,
                  cursor="hand2", command=self._reprint_bill).pack(side=tk.RIGHT, padx=8)

    def _load_bills(self):
        date = self._bill_date_var.get().strip()
        bills = db.get_bills(date)
        for row in self._bill_tree.get_children():
            self._bill_tree.delete(row)
        total_rev = 0
        for b in bills:
            total_rev += b['total']
            self._bill_tree.insert("", tk.END, iid=str(b['bill_no']), values=(
                f"#{b['bill_no']:04d}", f"T{b.get('terminal_id', 1)}", b['date'], b['time'],
                b['order_type'], b.get('table_no','─'), b.get('customer_name','─'),
                len(b['items']), f"₹{b['total']:.2f}", b.get('payment_mode','─')
            ))
        self._bill_summary.config(
            text=f"{len(bills)} bills  |  Total revenue: ₹{total_rev:.2f}")

    def _on_bill_dblclick(self, event):
        sel = self._bill_tree.selection()
        if not sel:
            return
        bill_no = int(sel[0])
        bill = db.get_bill(bill_no)
        if bill:
            self._show_preview(f"Bill #{bill_no:04d}", pr.format_bill(bill))

    def _reprint_bill(self):
        sel = self._bill_tree.selection()
        if not sel:
            messagebox.showinfo("Select", "Select a bill to reprint.")
            return
        bill_no = int(sel[0])
        bill = db.get_bill(bill_no)
        if bill:
            text = pr.format_bill(bill)
            pr.print_text(text, CFG.get("printer_name",""))
            messagebox.showinfo("Reprinted", f"Bill #{bill_no:04d} sent to printer.")

    def _void_bill_pinelabs(self):
        """Void a Pine Labs card transaction for the selected bill."""
        sel = self._bill_tree.selection()
        if not sel:
            messagebox.showinfo("Select", "Select a bill to void.")
            return
        bill_no = int(sel[0])
        bill = db.get_bill(bill_no)
        if not bill:
            return
        if not bill.get("pl_txn_id") and not bill.get("pl_approval_code"):
            messagebox.showinfo("Not a card bill",
                "This bill has no Pine Labs transaction attached.\n"
                "Only card/UPI bills paid through the EDC can be voided here.")
            return
        if bill.get("pl_voided"):
            messagebox.showinfo("Already voided",
                f"Bill #{bill_no:04d} has already been voided.")
            return
        if not messagebox.askyesno("Confirm void",
                f"Void Pine Labs transaction for Bill #{bill_no:04d}?\n"
                f"Amount: ₹{bill['total']:.2f}  |  {bill.get('pl_card_scheme','')}\n"
                f"Approval: {bill.get('pl_approval_code','')}\n\n"
                "This reverses the charge to the customer's card.\n"
                "Must be done on the same settlement day."):
            return

        if not (CFG.get("pl_edc_ip") and CFG.get("pl_store_id")):
            messagebox.showerror("Not configured",
                "Pine Labs EDC is not configured.\n"
                "Go to Settings → Pine Labs EDC and fill in the details.")
            return

        try:
            result = pl_edc.void(
                original_invoice_no = str(bill_no),
                pl_invoice_no       = bill.get("pl_invoice_no", ""),
                batch_no            = bill.get("pl_batch_no", ""),
                amount_rupees       = bill["total"],
                store_id            = CFG.get("pl_store_id", ""),
                terminal_sn         = CFG.get("pl_terminal_sn", ""),
                ip                  = CFG.get("pl_edc_ip", ""),
                port                = int(CFG.get("pl_edc_port", 4002)),
            )
            if result.get("approved"):
                db.mark_bill_voided(bill_no)
                self._load_bills()
                messagebox.showinfo("Void successful",
                    f"Bill #{bill_no:04d} voided successfully.\n"
                    f"Approval: {result.get('approval_code','')}")
            else:
                messagebox.showerror("Void declined",
                    f"{result.get('message','Void declined')}\n"
                    "Contact Pine Labs or your bank if the issue persists.")
        except pl_edc.EDCError as e:
            messagebox.showerror("EDC error", str(e))

    # ─────────────────────────────────── PINE LABS DIALOG ───

    # ─────────────────────────────────── KOTs TAB ──────────

    def _build_kots_tab(self, parent):
        top = tk.Frame(parent, bg="#3A0000", padx=8, pady=4)
        top.pack(fill=tk.X)
        tk.Label(top, text="KOT Monitor", font=FONT_LARGE,
                 bg="#3A0000", fg="#FFEECC").pack(side=tk.LEFT)
        self._kot_date_var = tk.StringVar(value=db.today())
        tk.Label(top, text=t("Date:", "Date:"), bg="#3A0000", fg="#FFEECC",
                 font=FONT_SMALL).pack(side=tk.RIGHT, padx=(0,4))
                 
        btn_cal = tk.Button(top, text=f"📅 {self._kot_date_var.get()}", font=FONT_SMALL, relief=tk.FLAT,
                            bg="#5A1A1A", fg="#FFEECC", cursor="hand2", padx=8, pady=4,
                            command=lambda: self._show_calendar(self._kot_date_var, self._load_kots))
        btn_cal.pack(side=tk.RIGHT, padx=2)
        self._btn_kot_cal = btn_cal
        
        def update_kot_cal(*args):
            if hasattr(self, '_btn_kot_cal'):
                self._btn_kot_cal.config(text=f"📅 {self._kot_date_var.get()}")
        self._kot_date_var.trace_add("write", update_kot_cal)
        
        tk.Button(top, text="Load", font=FONT_SMALL, relief=tk.FLAT,
                  bg="#FFCC88", cursor="hand2",
                  command=self._load_kots).pack(side=tk.RIGHT, padx=4)

        # Status filter (segmented touchable buttons)
        self._kot_status_var = tk.StringVar(value="all")
        self._kot_status_btns = {}
        
        tk.Label(top, text="  Filter:", bg="#3A0000", fg="#FFEECC", font=FONT_NORMAL).pack(side=tk.LEFT, padx=(10, 2))
        
        for val, lbl in [("all","All"),("pending","Pending"),
                          ("preparing","Preparing"),("ready","Ready"),("served","Served")]:
            btn = tk.Button(top, text=t(lbl, lbl), relief=tk.FLAT, pady=6, padx=14, cursor="hand2", font=FONT_NORMAL)
            btn.pack(side=tk.LEFT, padx=3)
            btn.config(command=lambda v=val: self._select_kot_status_filter(v))
            self._kot_status_btns[val] = btn

        cols = ("kot_no", "terminal", "date", "time", "type", "table", "customer", "items", "notes", "status", "updated")
        
        # Sub-frame for KOT Treeview and Scrollbars
        tree_frame_kot = tk.Frame(parent)
        tree_frame_kot.pack(fill=tk.BOTH, expand=True, padx=4, pady=4)
        
        tree_frame_kot.grid_rowconfigure(0, weight=1)
        tree_frame_kot.grid_columnconfigure(0, weight=1)
        
        self._kot_tree = ttk.Treeview(tree_frame_kot, columns=cols, show="headings",
                                       selectmode="browse")
        for col, w, hdr in [("kot_no",80,"KOT #"),("terminal",70,"Term"),("date",90,"Date"),("time",60,"Time"),
                              ("type",80,"Type"),("table",60,"Table"),("customer",120,"Customer"),
                              ("items",360,"Items (summary)"),("notes",150,"Notes"),
                              ("status",80,"Status"),("updated",130,"Updated")]:
            self._kot_tree.heading(col, text=t(hdr, hdr))
            self._kot_tree.column(col, width=w)
            
        self._kot_tree.grid(row=0, column=0, sticky="nsew")
        self._kot_tree.bind("<Double-1>", self._on_kot_dblclick)
        
        scr_kot = ttk.Scrollbar(tree_frame_kot, orient=tk.VERTICAL,
                                 command=self._kot_tree.yview)
        scr_kot.grid(row=0, column=1, sticky="ns")
        self._kot_tree.configure(yscrollcommand=scr_kot.set)

        scr_kot_x = ttk.Scrollbar(tree_frame_kot, orient=tk.HORIZONTAL,
                                   command=self._kot_tree.xview)
        scr_kot_x.grid(row=1, column=0, sticky="ew")
        self._kot_tree.configure(xscrollcommand=scr_kot_x.set)


        bot = tk.Frame(parent, bg=C["bg"], pady=4)
        bot.pack(fill=tk.X)
        for status, label, color in [("preparing","Mark Preparing","#D48B06"),
                                      ("ready","Mark Ready","#1E6B1E"),
                                      ("served","Mark Served","#555555")]:
            tk.Button(bot, text=label, font=FONT_BOLD, bg=color, fg="white",
                      relief=tk.FLAT, padx=16, pady=10, cursor="hand2",
                      command=lambda s=status: self._update_kot_status(s)
                      ).pack(side=tk.LEFT, padx=6, pady=4)
        tk.Button(bot, text="Reprint KOT", font=FONT_BOLD,
                  bg=C["header"], fg="white", relief=tk.FLAT, padx=16, pady=10,
                  cursor="hand2", command=self._reprint_kot).pack(side=tk.RIGHT, padx=8, pady=4)
                  
        # Select initial filter state after the entire UI and treeview are built
        self._select_kot_status_filter("all")

    def _select_kot_status_filter(self, val):
        self._kot_status_var.set(val)
        self._load_kots()
        for k, btn in getattr(self, "_kot_status_btns", {}).items():
            if k == val:
                btn.config(bg=C["accent"], fg="white", font=FONT_BOLD)
            else:
                btn.config(bg="#5A1A1A", fg="#FFEECC", font=FONT_NORMAL)

    def _load_kots(self):
        date   = self._kot_date_var.get().strip()
        status = self._kot_status_var.get()
        kots   = db.get_kots(date=date, status=None if status == "all" else status)
        for row in self._kot_tree.get_children():
            self._kot_tree.delete(row)
        STATUS_COLORS = {"pending":C["pending"],"preparing":C["preparing"],
                         "ready":C["ready"],"served":C["served"]}
        for k in kots:
            item_parts = []
            for i in k.get('items', []):
                name = i.get('item_name', '')
                translated_name = t(name, name)
                qty = i.get('quantity', 1)
                itype = i.get('item_type') or i.get('type', 'dine-in')
                type_suffix = " (P)" if itype == "parcel" else ""
                item_str = f"{translated_name}{type_suffix} ×{qty}"
                if i.get('notes'):
                    item_str += f" [{i['notes']}]"
                item_parts.append(item_str)
            item_summary = ", ".join(item_parts)
            
            iid = self._kot_tree.insert("", tk.END, iid=str(k['kot_no']), values=(
                f"#{k['kot_no']:04d}", f"T{k.get('terminal_id', 1)}", k['date'], k['time'],
                k['order_type'], k.get('table_no','─'), k.get('customer_name','─'),
                item_summary, k.get('notes','─'),
                k.get('status','─').upper(),
                k.get('updated_at','─')[:16] if k.get('updated_at') else '─'
            ))

    def _on_kot_dblclick(self, event):
        sel = self._kot_tree.selection()
        if not sel:
            return
        kot_no = int(sel[0])
        kot = db.get_kot_by_no(kot_no)
        if kot:
            self._show_preview(f"KOT #{kot_no:04d}", pr.format_kot(kot))

    def _update_kot_status(self, status):
        sel = self._kot_tree.selection()
        if not sel:
            messagebox.showinfo("Select", "Select a KOT first.")
            return
        kot_no = int(sel[0])
        db.update_kot_status(kot_no, status)
        self._network_broadcast({"type": "kot_status", "kot_no": kot_no, "status": status})
        self._load_kots()

    def _reprint_kot(self):
        sel = self._kot_tree.selection()
        if not sel:
            messagebox.showinfo("Select", "Select a KOT to reprint.")
            return
        kot_no = int(sel[0])
        kot = db.get_kot_by_no(kot_no)
        if kot:
            text = pr.format_kot(kot)
            pr.print_text(text, CFG.get("printer_name",""))
            messagebox.showinfo("Reprinted", f"KOT #{kot_no:04d} sent to printer.")
        else:
            messagebox.showerror("Not found", f"KOT #{kot_no:04d} not found in database.")

    # ─────────────────────────────────── REPORTS TAB ───────

    def _build_reports_tab(self, parent):
        top = tk.Frame(parent, bg="#1A3A1A", padx=8, pady=4)
        top.pack(fill=tk.X)
        tk.Label(top, text=t("Daily Reports", "Daily Reports"), font=FONT_LARGE,
                 bg="#1A3A1A", fg="#CCFFCC").pack(side=tk.LEFT)
        self._rep_date_var = tk.StringVar(value=db.today())
        
        tk.Label(top, text=t("Date:", "Date:"), bg="#1A3A1A", fg="#CCFFCC",
                 font=FONT_SMALL).pack(side=tk.LEFT, padx=(20, 4))
                 
        btn_cal = tk.Button(top, text=f"📅 {self._rep_date_var.get()}", font=FONT_SMALL, relief=tk.FLAT,
                            bg="#2A5A2A", fg="#CCFFCC", cursor="hand2", padx=8, pady=4,
                            command=lambda: self._show_calendar(self._rep_date_var, self._load_reports))
        btn_cal.pack(side=tk.LEFT, padx=2)
        self._btn_rep_cal = btn_cal
        
        def update_rep_cal(*args):
            if hasattr(self, '_btn_rep_cal'):
                self._btn_rep_cal.config(text=f"📅 {self._rep_date_var.get()}")
        self._rep_date_var.trace_add("write", update_rep_cal)
        
        tk.Button(top, text=t("Generate", "Generate"), font=FONT_SMALL, relief=tk.FLAT,
                  bg="#88CC88", cursor="hand2",
                  command=self._load_reports).pack(side=tk.LEFT, padx=10)

        # Print & Export on the right
        tk.Button(top, text="📥 " + t("Export CSV", "Export CSV"), font=FONT_SMALL, relief=tk.FLAT,
                  bg="#007ACC", fg="white", cursor="hand2", padx=10,
                  command=self._export_sales_report).pack(side=tk.RIGHT, padx=4)
        tk.Button(top, text="🖨 " + t("Print Report", "Print Report"), font=FONT_SMALL, relief=tk.FLAT,
                  bg="#1E6B1E", fg="white", cursor="hand2", padx=10,
                  command=self._print_sales_report).pack(side=tk.RIGHT, padx=4)

        self._rep_frame = tk.Frame(parent, bg=C["bg"])
        self._rep_frame.pack(fill=tk.BOTH, expand=True, padx=16, pady=16)

    def _load_reports(self):
        for w in self._rep_frame.winfo_children():
            w.destroy()
        date   = self._rep_date_var.get().strip()
        report = db.daily_report(date)

        stats = [
            (t("Bills Issued", "Bills Issued"),  str(report['bills']),      "#1A3A8A"),
            (t("Voided Bills", "Voided Bills"),  str(report.get('voided', 0)), "#AA2020"),
            (t("KOTs Raised", "KOTs Raised"),   str(report['kots']),       "#5A1A8A"),
            (t("Gross Revenue", "Gross Revenue"), f"₹{report['total']:.2f}", "#1A6A1A"),
            (t("GST Collected", "GST Collected"), f"₹{report['gst']:.2f}",  "#8A3A00"),
            (t("Net Subtotal", "Net Subtotal"),  f"₹{report['subtotal']:.2f}", "#5A5A5A"),
            (t("Cash Sales", "Cash Sales"),    f"₹{report['cash']:.2f}",  "#1A5A1A"),
            (t("Card / UPI", "Card / UPI"),    f"₹{report['card']:.2f}",  "#1A1A8A"),
        ]
        for i, (label, value, color) in enumerate(stats):
            r, c = divmod(i, 4)
            box = tk.Frame(self._rep_frame, bg=C["item_bg"],
                           relief=tk.SOLID, bd=1, padx=14, pady=12)
            box.grid(row=r, column=c, padx=8, pady=8, sticky="ew")
            tk.Label(box, text=label, bg=C["item_bg"], fg=C["muted"],
                     font=FONT_SMALL).pack()
            tk.Label(box, text=value, bg=C["item_bg"], fg=color,
                     font=("Segoe UI", 20, "bold")).pack()
        for col in range(4):
            self._rep_frame.columnconfigure(col, weight=1)

        # ─── ITEM-WISE SALES TABLE ───
        table_frame = tk.Frame(self._rep_frame, bg=C["bg"])
        table_frame.grid(row=2, column=0, columnspan=4, padx=8, pady=(16, 8), sticky="nsew")
        self._rep_frame.rowconfigure(2, weight=1)

        tk.Label(table_frame, text="Item-Wise Sales Tally", font=("Segoe UI", 12, "bold"),
                 bg=C["bg"], fg=C["accent"]).pack(anchor="w", pady=(0, 6))

        inner_frame = tk.Frame(table_frame, bg=C["bg"])
        inner_frame.pack(fill=tk.BOTH, expand=True)

        cols = ("item", "qty", "amount")
        self._rep_item_tree = ttk.Treeview(inner_frame, columns=cols, show="headings", selectmode="browse", height=8)

        self._rep_item_tree.heading("item", text=t("Item Name", "Item Name"), anchor=tk.W)
        self._rep_item_tree.heading("qty", text=t("Qty Sold", "Qty Sold"), anchor=tk.CENTER)
        self._rep_item_tree.heading("amount", text=t("Total Revenue (₹)", "Total Revenue (₹)"), anchor=tk.E)

        self._rep_item_tree.column("item", minwidth=150, width=250, anchor=tk.W)
        self._rep_item_tree.column("qty", minwidth=60, width=100, anchor=tk.CENTER)
        self._rep_item_tree.column("amount", minwidth=100, width=150, anchor=tk.E)

        scr = ttk.Scrollbar(inner_frame, orient=tk.VERTICAL, command=self._rep_item_tree.yview)
        self._rep_item_tree.configure(yscrollcommand=scr.set)

        self._rep_item_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scr.pack(side=tk.RIGHT, fill=tk.Y)

        # Populate the treeview
        item_sales = db.get_item_sales_report(date)
        for row in self._rep_item_tree.get_children():
            self._rep_item_tree.delete(row)

        for it in item_sales:
            self._rep_item_tree.insert("", tk.END, values=(
                it['item_name'],
                it['quantity'],
                f"₹{it['amount']:.2f}"
            ))

    def _print_sales_report(self):
        date = self._rep_date_var.get().strip()
        report = db.daily_report(date)
        item_sales = db.get_item_sales_report(date)
        if not report:
            messagebox.showerror("Error", f"No data found for date {date}")
            return
        
        text = pr.format_sales_report(report, item_sales)
        printer_name = CFG.get("printer_name", "")
        success = pr.print_text(text, printer_name)
        if success:
            messagebox.showinfo("Success", "Daily sales report sent to printer.")
        else:
            messagebox.showerror("Printer Error", "Could not print. Please check printer configuration.")

    def _export_sales_report(self):
        from tkinter import filedialog
        import csv
        
        date = self._rep_date_var.get().strip()
        report = db.daily_report(date)
        item_sales = db.get_item_sales_report(date)
        
        if not report:
            messagebox.showerror("Error", "No report data to export.")
            return
            
        clean_date = date.replace("/", "-")
        default_filename = f"sales_report_{clean_date}.csv"
        
        file_path = filedialog.asksaveasfilename(
            defaultextension=".csv",
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")],
            initialfile=default_filename,
            title="Export Daily Sales Report"
        )
        
        if not file_path:
            return
            
        try:
            with open(file_path, mode="w", newline="", encoding="utf-8") as f:
                writer = csv.writer(f)
                writer.writerow(["DAILY SALES REPORT"])
                writer.writerow(["Date", report["date"]])
                writer.writerow(["Exported At", datetime.datetime.now().strftime("%d/%m/%Y %H:%M:%S")])
                writer.writerow([])
                
                writer.writerow(["SUMMARY METRICS"])
                writer.writerow(["Metric", "Value"])
                writer.writerow(["Bills Issued", report["bills"]])
                writer.writerow(["Voided Bills", report.get("voided", 0)])
                writer.writerow(["KOTs Raised", report["kots"]])
                writer.writerow(["Gross Revenue", f"{report['total']:.2f}"])
                writer.writerow(["GST Collected", f"{report['gst']:.2f}"])
                writer.writerow(["Net Subtotal", f"{report['subtotal']:.2f}"])
                writer.writerow(["Cash Sales", f"{report['cash']:.2f}"])
                writer.writerow(["Card / UPI Sales", f"{report['card']:.2f}"])
                writer.writerow([])
                
                writer.writerow(["ITEM-WISE SALES"])
                writer.writerow(["Item Name", "Quantity Sold", "Total Revenue"])
                for it in item_sales:
                    writer.writerow([it["item_name"], it["quantity"], f"{it['amount']:.2f}"])
                    
            messagebox.showinfo("Success", f"Report exported successfully to:\n{file_path}")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to export report: {e}")


    # ─────────────────────────────────── MENU MANAGER TAB ──

    def _build_menu_tab(self, parent):
        top = tk.Frame(parent, bg="#00264D", padx=8, pady=5)
        top.pack(fill=tk.X)
        tk.Label(top, text="Menu Manager", font=FONT_LARGE,
                 bg="#00264D", fg="#AADDFF").pack(side=tk.LEFT)
        tk.Label(top, text="Add · Edit · Delete  sections and items",
                 font=FONT_SMALL, bg="#00264D", fg="#88BBDD").pack(side=tk.LEFT, padx=12)
        tk.Button(top, text="↺  Refresh", font=FONT_SMALL, relief=tk.FLAT,
                  bg="#005599", fg="white", padx=8, cursor="hand2",
                  command=self._load_menu_manager).pack(side=tk.RIGHT, padx=4)
        tk.Button(top, text="📄  Download Template", font=FONT_SMALL, relief=tk.FLAT,
                  bg="#4A2E80", fg="white", padx=8, cursor="hand2",
                  command=self._download_template).pack(side=tk.RIGHT, padx=4)
        tk.Button(top, text="📥  Import Menu", font=FONT_SMALL, relief=tk.FLAT,
                  bg="#007ACC", fg="white", padx=8, cursor="hand2",
                  command=self._import_menu).pack(side=tk.RIGHT, padx=4)

        body = tk.Frame(parent, bg=C["bg"])
        body.pack(fill=tk.BOTH, expand=True)

        # ── LEFT: section list
        left = tk.Frame(body, bg=C["sec_bg"], width=self.menu_manager_left_width)
        left.pack(side=tk.LEFT, fill=tk.Y)
        left.pack_propagate(False)

        tk.Label(left, text="SECTIONS", bg=C["sec_bg"], fg="#FFAA66",
                 font=FONT_SMALL, pady=4).pack(fill=tk.X)

        # Section listbox with scrollbar
        sf = tk.Frame(left, bg=C["sec_bg"])
        sf.pack(fill=tk.BOTH, expand=True)
        sec_scr = tk.Scrollbar(sf, width=self.scrollbar_width)
        sec_scr.pack(side=tk.RIGHT, fill=tk.Y)
        self._menu_sec_lb = tk.Listbox(sf, yscrollcommand=sec_scr.set,
                                        bg="#2A1000", fg="#FFDDAA",
                                        selectbackground=C["sec_active"],
                                        selectforeground="white",
                                        font=FONT_NORMAL, borderwidth=0,
                                        highlightthickness=0)
        self._menu_sec_lb.pack(fill=tk.BOTH, expand=True)
        sec_scr.config(command=self._menu_sec_lb.yview)
        self._menu_sec_lb.bind("<<ListboxSelect>>", self._on_menu_sec_select)

        # Section action buttons
        sec_btns = tk.Frame(left, bg=C["sec_bg"], pady=4)
        sec_btns.pack(fill=tk.X)
        for label, cmd in [("+ Add Section",  self._menu_add_section),
                            ("✎ Rename",       self._menu_rename_section),
                            ("▲ Up",           lambda: self._menu_move_sec("up")),
                            ("▼ Down",         lambda: self._menu_move_sec("down")),
                            ("✕ Delete",       self._menu_delete_section)]:
            tk.Button(sec_btns, text=label, font=FONT_SMALL,
                      bg=C["sec_bg"] if "Add" not in label else "#004488",
                      fg="white" if "Add" in label else "#DDBBAA",
                      relief=tk.FLAT, cursor="hand2", padx=4, pady=3,
                      command=cmd).pack(fill=tk.X, padx=4, pady=1)

        # ── RIGHT: items in selected section
        right = tk.Frame(body, bg=C["bg"])
        right.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        item_hdr = tk.Frame(right, bg="#FFF2E0", pady=3)
        item_hdr.pack(fill=tk.X)
        self._menu_sec_lbl = tk.Label(item_hdr, text="Select a section →",
                                       bg="#FFF2E0", fg=C["header"], font=FONT_BOLD,
                                       anchor=tk.W, padx=8)
        self._menu_sec_lbl.pack(side=tk.LEFT)

        # Items treeview
        item_wrap = tk.Frame(right, bg=C["bg"])
        item_wrap.pack(fill=tk.BOTH, expand=True)

        # v1.3.1: Single "Price" column (was "Dine-in ₹" + "Parcel ₹")
        cols = ("code", "name", "price", "stock", "active")
        self._menu_item_tree = ttk.Treeview(item_wrap, columns=cols,
                                             show="headings", selectmode="browse")
        for col, w, hdr_text in [("code", 70, "Code"), ("name", 240, "Item Name"), ("price", 100, "Price ₹"),
                                  ("stock", 100, "Stock"), ("active", 70, "Active")]:
            self._menu_item_tree.heading(col, text=hdr_text)
            self._menu_item_tree.column(col, width=w,
                                         anchor=tk.W if col in ("name", "code") else tk.CENTER)
        self._menu_item_tree.pack(fill=tk.BOTH, expand=True, side=tk.LEFT)
        item_scr = ttk.Scrollbar(item_wrap, orient=tk.VERTICAL,
                                  command=self._menu_item_tree.yview)
        item_scr.pack(side=tk.RIGHT, fill=tk.Y)
        self._menu_item_tree.configure(yscrollcommand=item_scr.set)
        self._menu_item_tree.bind("<Double-1>", lambda e: self._menu_edit_item())

        # Item action buttons
        item_btn_bar = tk.Frame(right, bg=C["bg"], pady=4)
        item_btn_bar.pack(fill=tk.X)
        for label, cmd, color in [
                ("+ Add Item",    self._menu_add_item,    "#004422"),
                ("✎ Edit",        self._menu_edit_item,   C["header"]),
                ("▲ Up",          lambda: self._menu_move_item("up"),  "#555"),
                ("▼ Down",        lambda: self._menu_move_item("down"),"#555"),
                ("Toggle Active", self._menu_toggle_item, "#664400"),
                ("✕ Delete Item", self._menu_delete_item, "#660000")]:
            tk.Button(item_btn_bar, text=label, font=FONT_SMALL,
                      bg=color, fg="white", relief=tk.FLAT,
                      padx=10, pady=4, cursor="hand2",
                      command=cmd).pack(side=tk.LEFT, padx=3)

        # Store section id list for lookup
        self._menu_sec_ids: list[int] = []

    def _load_menu_manager(self):
        secs = db.get_sections_db()
        self._menu_sec_ids = [s["id"] for s in secs]
        self._menu_sec_lb.delete(0, tk.END)
        for s in secs:
            label = f"  {'✓' if s['is_active'] else '✗'}  {s['name']}"
            self._menu_sec_lb.insert(tk.END, label)
        # Clear items pane
        for row in self._menu_item_tree.get_children():
            self._menu_item_tree.delete(row)
        self._menu_sec_lbl.config(text="Select a section →")

    def _check_menu_pin(self) -> bool:
        """v1.2: Prompt for menu PIN before allowing add/edit/delete.
        Returns True if PIN is correct or PIN disabled, False otherwise."""
        if not CFG.get("menu_pin_enabled", True):
            return True
        stored_pin = str(CFG.get("menu_pin", "1234"))
        # Use simpledialog.askstring with show='*' for password-like input
        from tkinter import simpledialog
        entered = simpledialog.askstring(
            "Menu PIN",
            "Enter PIN to edit menu:",
            parent=self.root,
            show="*"
        )
        if entered is None:
            return False  # user cancelled
        if entered.strip() == stored_pin:
            return True
        messagebox.showerror("Wrong PIN", "Incorrect PIN. Menu edit denied.")
        return False

    def _selected_section_id(self):
        sel = self._menu_sec_lb.curselection()
        if not sel:
            return None, None
        idx = sel[0]
        if idx >= len(self._menu_sec_ids):
            return None, None
        secs = db.get_sections_db()
        return self._menu_sec_ids[idx], secs[idx]["name"]

    def _on_menu_sec_select(self, event=None):
        sec_id, sec_name = self._selected_section_id()
        if sec_id is None:
            return
        self._menu_sec_lbl.config(text=f"  Items in:  {sec_name}")
        self._refresh_menu_items(sec_id)

    def _refresh_menu_items(self, sec_id):
        for row in self._menu_item_tree.get_children():
            self._menu_item_tree.delete(row)
        items = db.get_items_for_section(sec_id)
        for it in items:
            stock_qty = it.get("stock_quantity", -1)
            if stock_qty < 0:
                stock_text = "—"
            elif stock_qty == 0:
                stock_text = "❌ 0"
            elif stock_qty <= it.get("low_stock_threshold", 10):
                stock_text = f"⚠ {stock_qty}"
            else:
                stock_text = f"✓ {stock_qty}"
            # v1.3.1: Use single `price` column (was dine_in_price + parcel_price)
            price_val = it.get("price")
            if not price_val or price_val == 0:
                # Fallback for legacy rows: middle of dine_in + parcel
                price_val = it.get("dine_in_price") or it.get("parcel_price") or 0
            self._menu_item_tree.insert("", tk.END, iid=str(it["id"]), values=(
                it.get("code") or "", it["name"], f"₹{price_val}",
                stock_text, "Yes" if it["is_active"] else "No"
            ))

    def _selected_item_id(self):
        sel = self._menu_item_tree.selection()
        if not sel:
            return None
        return int(sel[0])

    # ── Section operations ──

    def _menu_add_section(self):
        name = simpledialog.askstring("New Section", "Section name:", parent=self.root)
        if name and name.strip():
            db.add_section(name.strip())
            self._load_menu_manager()
            self._reload_menu()

    def _menu_rename_section(self):
        sec_id, sec_name = self._selected_section_id()
        if sec_id is None:
            messagebox.showinfo("Select", "Select a section first.")
            return
        new_name = simpledialog.askstring("Rename Section",
                                           f"New name for '{sec_name}':",
                                           initialvalue=sec_name, parent=self.root)
        if new_name and new_name.strip():
            db.update_section(sec_id, new_name.strip())
            self._load_menu_manager()
            self._reload_menu()

    def _menu_move_sec(self, direction):
        sec_id, _ = self._selected_section_id()
        if sec_id is None:
            return
        db.reorder_section(sec_id, direction)
        self._load_menu_manager()
        self._reload_menu()

    def _menu_delete_section(self):
        sec_id, sec_name = self._selected_section_id()
        if sec_id is None:
            messagebox.showinfo("Select", "Select a section first.")
            return
        items = db.get_items_for_section(sec_id)
        if not messagebox.askyesno("Delete Section",
                f"Delete section '{sec_name}' and its {len(items)} items?\nThis cannot be undone."):
            return
        db.delete_section(sec_id)
        self._load_menu_manager()
        self._reload_menu()

    # ── Item operations ──

    def _menu_add_item(self):
        if not self._check_menu_pin():  # v1.2: PIN protection
            return
        sec_id, sec_name = self._selected_section_id()
        if sec_id is None:
            messagebox.showinfo("Select", "Select a section first.")
            return
        self._item_dialog(sec_id=sec_id)

    def _menu_edit_item(self):
        if not self._check_menu_pin():  # v1.2: PIN protection
            return
        item_id = self._selected_item_id()
        if item_id is None:
            messagebox.showinfo("Select", "Select an item to edit.")
            return
        sec_id, _ = self._selected_section_id()
        # Get current values from DB (more reliable than parsing tree display values)
        items = db.get_items_for_section(sec_id) if sec_id else []
        item_data = None
        for it in items:
            if it["id"] == item_id:
                item_data = it
                break
        if not item_data:
            # Fallback to tree values (v1.3.1: single price column)
            vals = self._menu_item_tree.item(str(item_id))["values"]
            code   = str(vals[0])
            name   = vals[1]
            price  = int(str(vals[2]).replace("₹",""))
            stock  = -1
            threshold = 10
        else:
            code   = item_data.get("code") or ""
            name   = item_data["name"]
            # v1.3.1: Use single `price` field (fallback to middle of dine_in+parcel for legacy)
            price  = item_data.get("price")
            if not price or price == 0:
                dine = item_data.get("dine_in_price") or 0
                parcel = item_data.get("parcel_price") or 0
                price = (dine + parcel) // 2 if (dine or parcel) else 0
            stock  = item_data.get("stock_quantity", -1)
            threshold = item_data.get("low_stock_threshold", 10)
        self._item_dialog(item_id=item_id, code=code, name=name, price=price,
                          sec_id=sec_id, stock=stock, threshold=threshold)

    def _item_dialog(self, sec_id=None, item_id=None,
                      code="", name="", price=0, stock=-1, threshold=10,
                      dine=None, parcel=None):
        """Shared Add/Edit dialog for menu items with stock management.
        v1.3.1: Single Price field (was Dine-in + Parcel prices).
        dine/parcel args kept for backward-compat but ignored."""
        dlg = tk.Toplevel(self.root)
        dlg.title("Edit Item" if item_id else "Add Item")
        dlg.geometry("420x420")
        dlg.resizable(False, False)
        dlg.grab_set()
        dlg.configure(bg=C["bg"])

        v_code   = tk.StringVar(value=code)
        v_name   = tk.StringVar(value=name)
        # v1.3.1: Single Price field
        # If caller passes legacy dine/parcel args (e.g. _menu_add_item default), use middle as price
        if price == 0 and (dine or parcel):
            price = (dine + parcel) // 2
        v_price  = tk.StringVar(value=str(price))
        v_stock  = tk.StringVar(value=str(stock))
        v_threshold = tk.StringVar(value=str(threshold))
        v_untracked = tk.IntVar(value=1 if stock < 0 else 0)

        # Auto-prefill next available 4-digit code for new items
        if not item_id and not code:
            v_code.set(db.get_next_item_code())

        tk.Label(dlg, text="Edit Item" if item_id else "New Menu Item",
                 font=FONT_LARGE, bg=C["bg"], fg=C["header"], pady=8).pack()

        frm = tk.Frame(dlg, bg=C["bg"]); frm.pack(padx=20)
        # v1.3.1: Single Price field (no more Dine-in price / Parcel price)
        for label, var, width in [
                ("Code (4-digit)", v_code,   10),
                ("Item name",      v_name,   30),
                ("Price ₹",        v_price,  10)]:
            row = tk.Frame(frm, bg=C["bg"]); row.pack(fill=tk.X, pady=4)
            tk.Label(row, text=label, width=16, anchor=tk.E,
                     bg=C["bg"], font=FONT_NORMAL).pack(side=tk.LEFT, padx=4)
            tk.Entry(row, textvariable=var, width=width,
                     font=FONT_NORMAL).pack(side=tk.LEFT)

        # ── Stock section separator
        sep = tk.Frame(frm, bg=C["border"], height=1)
        sep.pack(fill=tk.X, pady=(10, 4))
        tk.Label(frm, text="📦 Inventory", font=FONT_BOLD,
                 bg=C["bg"], fg="#1A5C8C", anchor=tk.W).pack(fill=tk.X)

        # Untracked checkbox
        chk_row = tk.Frame(frm, bg=C["bg"]); chk_row.pack(fill=tk.X, pady=2)
        tk.Label(chk_row, text="", width=16, bg=C["bg"]).pack(side=tk.LEFT, padx=4)
        stock_entry_widgets = []

        def toggle_untracked():
            if v_untracked.get():
                v_stock.set("-1")
                for w in stock_entry_widgets:
                    w.config(state=tk.DISABLED)
            else:
                if v_stock.get() == "-1":
                    v_stock.set("50")
                for w in stock_entry_widgets:
                    w.config(state=tk.NORMAL)

        tk.Checkbutton(chk_row, text="Not tracked (unlimited)", variable=v_untracked,
                       bg=C["bg"], font=FONT_NORMAL, command=toggle_untracked).pack(side=tk.LEFT)

        # Stock quantity
        for label, var, width in [
                ("Stock quantity", v_stock,     10),
                ("Low stock alert", v_threshold, 10)]:
            row = tk.Frame(frm, bg=C["bg"]); row.pack(fill=tk.X, pady=3)
            tk.Label(row, text=label, width=16, anchor=tk.E,
                     bg=C["bg"], font=FONT_NORMAL).pack(side=tk.LEFT, padx=4)
            e = tk.Entry(row, textvariable=var, width=width, font=FONT_NORMAL)
            e.pack(side=tk.LEFT)
            stock_entry_widgets.append(e)

        # Apply initial state
        toggle_untracked()

        def save():
            c_val = v_code.get().strip()
            n = v_name.get().strip()
            
            # Validation: code must be exactly 4 digits
            if not c_val.isdigit() or len(c_val) != 4:
                messagebox.showwarning("Invalid Code", "Item code must be exactly 4 digits.", parent=dlg)
                return
                
            # Validation: check for duplicate code
            if db.check_duplicate_code(c_val, item_id):
                messagebox.showwarning("Duplicate Code", f"Code '{c_val}' is already assigned to another item.", parent=dlg)
                return

            if not n:
                messagebox.showwarning("Required", "Item name is required.", parent=dlg)
                return
            try:
                # v1.3.1: Single Price field
                p = int(v_price.get())
            except ValueError:
                messagebox.showwarning("Invalid", "Price must be a whole number.", parent=dlg)
                return

            # Save menu item — v1.3.1: single price via `price=` kwarg
            if item_id:
                db.update_item(item_id, n, price=p, code=c_val)
                target_id = item_id
            else:
                target_id = db.add_item(sec_id, n, price=p, code=c_val)

            # Save stock settings
            try:
                s = int(v_stock.get())
                th = int(v_threshold.get())
                if v_untracked.get():
                    s = -1
                db.init_stock_for_item(target_id, s, th)
            except ValueError:
                pass  # Skip stock update if invalid

            dlg.destroy()
            if sec_id:
                self._refresh_menu_items(sec_id)
            self._reload_menu()

        btn_row = tk.Frame(dlg, bg=C["bg"]); btn_row.pack(pady=10)
        tk.Button(btn_row, text="Save", font=FONT_BOLD,
                  bg=C["bill_btn"], fg="white", relief=tk.FLAT,
                  padx=20, pady=5, cursor="hand2",
                  command=save).pack(side=tk.LEFT, padx=8)
        tk.Button(btn_row, text="Cancel", font=FONT_NORMAL,
                  bg="#CCCCCC", relief=tk.FLAT, padx=12, pady=5,
                  command=dlg.destroy).pack(side=tk.LEFT)

        dlg.bind("<Return>", lambda e: save())

    def _menu_move_item(self, direction):
        item_id = self._selected_item_id()
        if item_id is None:
            return
        sec_id, _ = self._selected_section_id()
        db.reorder_item(item_id, direction)
        if sec_id:
            self._refresh_menu_items(sec_id)
        self._reload_menu()

    def _menu_toggle_item(self):
        item_id = self._selected_item_id()
        if item_id is None:
            messagebox.showinfo("Select", "Select an item first.")
            return
        # Columns: code(0), name(1), dine_in(2), parcel(3), stock(4), active(5)
        vals = self._menu_item_tree.item(str(item_id))["values"]
        code   = str(vals[0])
        name   = vals[1]
        dine   = int(str(vals[2]).replace("₹",""))
        parcel = int(str(vals[3]).replace("₹",""))
        active = 0 if vals[5] == "Yes" else 1
        db.update_item(item_id, name, dine, parcel, code, active)
        sec_id, _ = self._selected_section_id()
        if sec_id:
            self._refresh_menu_items(sec_id)
        self._reload_menu()

    def _menu_delete_item(self):
        if not self._check_menu_pin():  # v1.2: PIN protection
            return
        item_id = self._selected_item_id()
        if item_id is None:
            messagebox.showinfo("Select", "Select an item to delete.")
            return
        vals = self._menu_item_tree.item(str(item_id))["values"]
        if not messagebox.askyesno("Delete Item",
                f"Delete '{vals[1]}'? This cannot be undone."):
            return
        db.delete_item(item_id)
        # v1.2: Broadcast to hub so other POS remove this item
        if self.pos_client and self.pos_client.connected:
            try:
                self.pos_client.send_menu_update("delete_item", {"item_id": item_id})
            except Exception:
                pass
        sec_id, _ = self._selected_section_id()
        if sec_id:
            self._refresh_menu_items(sec_id)
        self._reload_menu()

    # ─────────────────────────────────── PACKAGING TAB ──────

    def _build_packaging_tab(self, parent):
        """Packaging management: Types, Section-wise, Product-wise."""
        # ── Top header
        top = tk.Frame(parent, bg="#1A4D2E", padx=8, pady=5)
        top.pack(fill=tk.X)
        tk.Label(top, text=t("Packaging Manager", "Packaging Manager"), font=FONT_LARGE,
                 bg="#1A4D2E", fg="#AAFFCC").pack(side=tk.LEFT)
        self._pkg_alert_lbl = tk.Label(top, text="", font=FONT_BOLD,
                                        bg="#1A4D2E", fg="#FF6666")
        self._pkg_alert_lbl.pack(side=tk.RIGHT, padx=8)
        tk.Button(top, text="↺  Refresh", font=FONT_SMALL, relief=tk.FLAT,
                  bg="#006644", fg="white", padx=8, cursor="hand2",
                  command=self._load_packaging_tab).pack(side=tk.RIGHT, padx=4)

        # ── Sub-tab strip (3 views: Types | Section Packaging | Product Packaging)
        sub_tab_frame = tk.Frame(parent, bg="#0D3319", height=32)
        sub_tab_frame.pack(fill=tk.X)
        sub_tab_frame.pack_propagate(False)

        self._pkg_sub_tab = tk.StringVar(value="types")
        self._pkg_sub_btns = {}
        for sub_id, label in [("types", t("Packaging Types", "Packaging Types")),
                               ("sections", t("Section Packaging", "Section Packaging")),
                               ("products", t("Product Packaging", "Product Packaging"))]:
            btn = tk.Button(sub_tab_frame, text=label, font=FONT_SMALL,
                            bg="#0D3319", fg="#88BBAA", relief=tk.FLAT,
                            padx=12, pady=5, cursor="hand2",
                            command=lambda s=sub_id: self._switch_pkg_sub_tab(s))
            btn.pack(side=tk.LEFT)
            self._pkg_sub_btns[sub_id] = btn

        # ── Content container (3 sub-pages)
        self._pkg_pages = {}
        content = tk.Frame(parent, bg=C["bg"])
        content.pack(fill=tk.BOTH, expand=True)

        for sub_id, builder in [("types", self._build_pkg_types_page),
                                ("sections", self._build_pkg_sections_page),
                                ("products", self._build_pkg_products_page)]:
            page = tk.Frame(content, bg=C["bg"])
            builder(page)
            self._pkg_pages[sub_id] = page

        self._switch_pkg_sub_tab("types")

    def _switch_pkg_sub_tab(self, sub_id):
        self._pkg_sub_tab.set(sub_id)
        for sid, page in self._pkg_pages.items():
            page.pack_forget()
        self._pkg_pages[sub_id].pack(fill=tk.BOTH, expand=True)
        for sid, btn in self._pkg_sub_btns.items():
            if sid == sub_id:
                btn.config(bg="#1A6644", fg="#FFFFFF", font=FONT_BOLD)
            else:
                btn.config(bg="#0D3319", fg="#88BBAA", font=FONT_SMALL)
        # Refresh data
        if sub_id == "types":
            self._load_pkg_types()
        elif sub_id == "sections":
            self._load_pkg_sections()
        elif sub_id == "products":
            self._load_pkg_products()

    def _load_packaging_tab(self):
        """Refresh the currently visible packaging sub-tab and update packaging stock alerts."""
        # Update packaging stock alert banner
        if hasattr(self, '_pkg_alert_lbl'):
            try:
                pkg_summary = db.get_packaging_stock_summary()
                out_count = pkg_summary.get("out_of_stock_count", 0)
                low_count = pkg_summary.get("low_stock_count", 0)
                if out_count > 0:
                    self._pkg_alert_lbl.config(
                        text=f"⚠ {out_count} Out of Stock! | {low_count} Low",
                        fg="#FF4444")
                elif low_count > 0:
                    self._pkg_alert_lbl.config(
                        text=f"⚠ {low_count} Low Stock",
                        fg="#FF9900")
                else:
                    self._pkg_alert_lbl.config(text="✓ All Packaging OK", fg="#66FF66")
            except Exception:
                self._pkg_alert_lbl.config(text="", fg="#FF6666")

        sub = getattr(self, '_pkg_sub_tab', None)
        if sub:
            self._switch_pkg_sub_tab(sub.get())

    # ── Packaging Types Page ──

    def _build_pkg_types_page(self, parent):
        # Treeview for packaging types (charge column temporarily hidden)
        cols = ("code", "name", "stock", "description", "active")
        self._pkg_type_tree = ttk.Treeview(parent, columns=cols, show="headings", selectmode="browse")
        for col, w, hdr_text in [("code", 90, t("Code", "Code")),
                                  ("name", 140, t("Name", "Name")),
                                  ("stock", 80, t("Stock", "Stock")),
                                  ("description", 240, t("Description", "Description")),
                                  ("active", 70, t("Active", "Active"))]:
            self._pkg_type_tree.heading(col, text=hdr_text)
            self._pkg_type_tree.column(col, width=w,
                                       anchor=tk.W if col in ("name", "description", "code") else tk.CENTER)
        self._pkg_type_tree.pack(fill=tk.BOTH, expand=True, side=tk.LEFT)
        scr = ttk.Scrollbar(parent, orient=tk.VERTICAL, command=self._pkg_type_tree.yview)
        scr.pack(side=tk.RIGHT, fill=tk.Y)
        self._pkg_type_tree.configure(yscrollcommand=scr.set)

        btn_bar = tk.Frame(parent, bg=C["bg"], pady=4)
        btn_bar.pack(fill=tk.X, side=tk.BOTTOM)
        for label, cmd, color in [
                ("+ Add Type",     self._pkg_add_type,     "#004422"),
                ("✎ Edit",         self._pkg_edit_type,    C["header"]),
                ("Toggle Active",  self._pkg_toggle_type,  "#664400"),
                ("📦 Set Stock",   self._pkg_set_stock,    "#003366"),
                ("✕ Delete Type",  self._pkg_delete_type, "#660000")]:
            tk.Button(btn_bar, text=label, font=FONT_SMALL,
                      bg=color, fg="white", relief=tk.FLAT,
                      padx=10, pady=4, cursor="hand2",
                      command=cmd).pack(side=tk.LEFT, padx=3)

        self._pkg_type_ids = []

    def _load_pkg_types(self):
        if not hasattr(self, '_pkg_type_tree'):
            return
        for row in self._pkg_type_tree.get_children():
            self._pkg_type_tree.delete(row)
        types = db.get_packaging_types()
        self._pkg_type_ids = []
        for pt in types:
            self._pkg_type_ids.append(pt["id"])
            stock_qty = pt.get("stock_quantity", -1)
            if stock_qty is None:
                stock_qty = -1
            if stock_qty >= 0:
                threshold = pt.get("low_stock_threshold", 10)
                if stock_qty <= 0:
                    stock_text = f"❌ 0"
                elif stock_qty <= threshold:
                    stock_text = f"⚠ {stock_qty}"
                else:
                    stock_text = f"✓ {stock_qty}"
            else:
                stock_text = "—"
            self._pkg_type_tree.insert("", tk.END, iid=str(pt["id"]), values=(
                pt.get("code", ""), pt["name"], stock_text,
                pt["description"],
                "Yes" if pt["is_active"] else "No"
            ))

    def _selected_pkg_type_id(self):
        sel = self._pkg_type_tree.selection()
        if not sel:
            return None
        return int(sel[0])

    def _pkg_add_type(self):
        self._pkg_type_dialog()

    def _pkg_edit_type(self):
        pkg_id = self._selected_pkg_type_id()
        if pkg_id is None:
            messagebox.showinfo("Select", "Select a packaging type first.")
            return
        vals = self._pkg_type_tree.item(str(pkg_id))["values"]
        code = vals[0]
        name = vals[1]
        # vals[2] is stock display — skip it
        desc = vals[3]
        is_active = 1 if vals[4] == "Yes" else 0
        # Get charge from DB since it's hidden from treeview
        pkg_types = db.get_packaging_types()
        charge = 0.0
        for pt in pkg_types:
            if pt["id"] == pkg_id:
                charge = pt["charge"]
                break
        self._pkg_type_dialog(pkg_id=pkg_id, name=name, desc=desc, charge=charge, is_active=is_active, code=code)

    def _pkg_type_dialog(self, pkg_id=None, name="", desc="", charge=0.0, is_active=1, code=""):
        dlg = tk.Toplevel(self.root)
        dlg.title("Edit Packaging Type" if pkg_id else "New Packaging Type")
        dlg.geometry("420x300")
        dlg.resizable(False, False)
        dlg.grab_set()
        dlg.configure(bg=C["bg"])

        if not code and not pkg_id:
            code = db.get_next_packaging_code()

        v_name = tk.StringVar(value=name)
        v_code = tk.StringVar(value=code)
        v_desc = tk.StringVar(value=desc)
        v_charge = tk.StringVar(value=str(charge))
        v_active = tk.IntVar(value=is_active)

        tk.Label(dlg, text="Edit Packaging Type" if pkg_id else "New Packaging Type",
                 font=FONT_LARGE, bg=C["bg"], fg=C["header"], pady=8).pack()

        frm = tk.Frame(dlg, bg=C["bg"]); frm.pack(padx=20)
        for label, var, width in [
                ("Code",        v_code,  15),
                ("Name",        v_name,  30),
                ("Description", v_desc,  30)]:
            row = tk.Frame(frm, bg=C["bg"]); row.pack(fill=tk.X, pady=4)
            tk.Label(row, text=label, width=14, anchor=tk.E,
                     bg=C["bg"], font=FONT_NORMAL).pack(side=tk.LEFT, padx=4)
            entry = tk.Entry(row, textvariable=var, width=width,
                     font=FONT_NORMAL)
            entry.pack(side=tk.LEFT)

        # Charge field temporarily hidden
        # row_charge = tk.Frame(frm, bg=C["bg"]); row_charge.pack(fill=tk.X, pady=4)
        # tk.Label(row_charge, text="Charge (₹)", width=14, anchor=tk.E,
        #          bg=C["bg"], font=FONT_NORMAL).pack(side=tk.LEFT, padx=4)
        # tk.Entry(row_charge, textvariable=v_charge, width=10,
        #          font=FONT_NORMAL).pack(side=tk.LEFT)

        row_active = tk.Frame(frm, bg=C["bg"]); row_active.pack(fill=tk.X, pady=4)
        tk.Label(row_active, text="Active", width=14, anchor=tk.E,
                 bg=C["bg"], font=FONT_NORMAL).pack(side=tk.LEFT, padx=4)
        tk.Checkbutton(row_active, text="Yes", variable=v_active,
                       bg=C["bg"], font=FONT_NORMAL).pack(side=tk.LEFT)

        def save():
            n = v_name.get().strip()
            c_code = v_code.get().strip()
            if not n:
                messagebox.showwarning("Required", "Name is required.", parent=dlg)
                return
            try:
                c = float(v_charge.get())
            except ValueError:
                c = 0.0
            if pkg_id:
                db.update_packaging_type(pkg_id, n, v_desc.get().strip(), c, v_active.get(), c_code)
            else:
                db.add_packaging_type(n, v_desc.get().strip(), c, c_code)
            dlg.destroy()
            self._load_pkg_types()

        btn_row = tk.Frame(dlg, bg=C["bg"]); btn_row.pack(pady=10)
        tk.Button(btn_row, text="Save", font=FONT_BOLD,
                  bg=C["bill_btn"], fg="white", relief=tk.FLAT,
                  padx=20, pady=5, cursor="hand2", command=save).pack(side=tk.LEFT, padx=8)
        tk.Button(btn_row, text="Cancel", font=FONT_NORMAL,
                  bg="#CCCCCC", relief=tk.FLAT, padx=12, pady=5,
                  command=dlg.destroy).pack(side=tk.LEFT)
        dlg.bind("<Return>", lambda e: save())

    def _pkg_toggle_type(self):
        pkg_id = self._selected_pkg_type_id()
        if pkg_id is None:
            messagebox.showinfo("Select", "Select a packaging type first.")
            return
        vals = self._pkg_type_tree.item(str(pkg_id))["values"]
        code = vals[0]
        name = vals[1]
        desc = vals[2]
        new_active = 0 if vals[3] == "Yes" else 1
        # Get charge from DB
        pkg_types = db.get_packaging_types()
        charge = 0.0
        for pt in pkg_types:
            if pt["id"] == pkg_id:
                charge = pt["charge"]
                break
        db.update_packaging_type(pkg_id, name, desc, charge, new_active, code)
        self._load_pkg_types()

    def _pkg_delete_type(self):
        pkg_id = self._selected_pkg_type_id()
        if pkg_id is None:
            messagebox.showinfo("Select", "Select a packaging type first.")
            return
        vals = self._pkg_type_tree.item(str(pkg_id))["values"]
        if not messagebox.askyesno("Delete", f"Delete packaging type '{vals[1]}'?"):
            return
        db.delete_packaging_type(pkg_id)
        self._load_pkg_types()

    def _pkg_set_stock(self):
        """Set or adjust stock quantity for a packaging type."""
        pkg_id = self._selected_pkg_type_id()
        if pkg_id is None:
            messagebox.showinfo("Select", "Select a packaging type first.")
            return
        pkg_stock = db.get_packaging_stock(pkg_id)
        pkg_name = pkg_stock.get("name", "")
        current = pkg_stock.get("stock_quantity", -1)

        win = tk.Toplevel(self.root)
        win.title(f"Packaging Stock: {pkg_name}")
        win.geometry("380x260")
        win.resizable(False, False)
        win.grab_set()
        win.configure(bg=C["bg"])
        win.transient(self.root)

        tk.Label(win, text=f"📦 {pkg_name}", font=FONT_BOLD, bg=C["bg"], fg=C["header"]).pack(pady=(10,4))
        current_text = f"Current Stock: {current}" if current >= 0 else "Current Stock: Not tracked"
        tk.Label(win, text=current_text, font=FONT_NORMAL, bg=C["bg"], fg=C["text"]).pack(pady=4)

        # Action buttons
        action_frame = tk.Frame(win, bg=C["bg"])
        action_frame.pack(fill=tk.X, padx=16, pady=4)

        qty_var = tk.StringVar(value="50")
        tk.Label(action_frame, text="Quantity:", bg=C["bg"], fg=C["text"], font=FONT_NORMAL).grid(row=0, column=0, sticky=tk.W)
        tk.Entry(action_frame, textvariable=qty_var, width=10, font=FONT_NORMAL).grid(row=0, column=1, padx=4)
        tk.Label(action_frame, text="(−1 = not tracked)", bg=C["bg"], fg="#999999", font=("Segoe UI", 8)).grid(row=1, column=0, columnspan=2, sticky=tk.W)

        threshold_var = tk.StringVar(value="10")
        tk.Label(action_frame, text="Low Stock Alert:", bg=C["bg"], fg=C["text"], font=FONT_NORMAL).grid(row=2, column=0, sticky=tk.W, pady=(8,0))
        tk.Entry(action_frame, textvariable=threshold_var, width=10, font=FONT_NORMAL).grid(row=2, column=1, padx=4, pady=(8,0))

        # Quick add buttons
        quick_frame = tk.Frame(win, bg=C["bg"])
        quick_frame.pack(fill=tk.X, padx=16, pady=8)
        tk.Label(quick_frame, text="Quick Add:", bg=C["bg"], fg=C["text"], font=FONT_SMALL).pack(side=tk.LEFT)
        for amt in [10, 25, 50, 100]:
            tk.Button(quick_frame, text=f"+{amt}", font=FONT_SMALL,
                      bg="#003366", fg="white", relief=tk.FLAT, padx=8, pady=2, cursor="hand2",
                      command=lambda a=amt: self._pkg_quick_add(pkg_id, a, win)
                      ).pack(side=tk.LEFT, padx=3)

        def on_set():
            try:
                qty = int(qty_var.get())
                threshold = int(threshold_var.get())
            except ValueError:
                messagebox.showerror("Invalid", "Enter valid numbers.", parent=win)
                return
            conn = db.get_conn()
            conn.execute("UPDATE packaging_types SET stock_quantity=?, low_stock_threshold=? WHERE id=?",
                         (qty, threshold, pkg_id))
            conn.commit()
            conn.close()
            self._load_pkg_types()
            win.destroy()

        tk.Button(win, text="✓ Set Stock", font=FONT_BOLD,
                  bg="#4CAF50", fg="white", relief=tk.FLAT, padx=16, pady=6, cursor="hand2",
                  command=on_set).pack(pady=4)

    def _pkg_quick_add(self, pkg_id, qty, parent_win):
        """Quick add stock to a packaging type."""
        db.adjust_packaging_stock(pkg_id, qty)
        self._load_pkg_types()
        parent_win.destroy()

    # ── Section Packaging Page ──

    def _build_pkg_sections_page(self, parent):
        body = tk.Frame(parent, bg=C["bg"])
        body.pack(fill=tk.BOTH, expand=True)

        # LEFT: section list
        left = tk.Frame(body, bg=C["sec_bg"], width=200)
        left.pack(side=tk.LEFT, fill=tk.Y)
        left.pack_propagate(False)

        tk.Label(left, text="SECTIONS", bg=C["sec_bg"], fg="#FFAA66",
                 font=FONT_SMALL, pady=4).pack(fill=tk.X)

        sf = tk.Frame(left, bg=C["sec_bg"])
        sf.pack(fill=tk.BOTH, expand=True)
        sec_scr = tk.Scrollbar(sf, width=self.scrollbar_width)
        sec_scr.pack(side=tk.RIGHT, fill=tk.Y)
        self._pkg_sec_lb = tk.Listbox(sf, yscrollcommand=sec_scr.set,
                                       bg="#2A1000", fg="#FFDDAA",
                                       selectbackground=C["sec_active"],
                                       selectforeground="white",
                                       font=FONT_NORMAL, borderwidth=0,
                                       highlightthickness=0)
        self._pkg_sec_lb.pack(fill=tk.BOTH, expand=True)
        sec_scr.config(command=self._pkg_sec_lb.yview)
        self._pkg_sec_lb.bind("<<ListboxSelect>>", self._on_pkg_sec_select)

        # RIGHT: packaging for selected section
        right = tk.Frame(body, bg=C["bg"])
        right.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        hdr = tk.Frame(right, bg="#FFF2E0", pady=3)
        hdr.pack(fill=tk.X)
        self._pkg_sec_lbl = tk.Label(hdr, text="Select a section →",
                                      bg="#FFF2E0", fg=C["header"], font=FONT_BOLD,
                                      anchor=tk.W, padx=8)
        self._pkg_sec_lbl.pack(side=tk.LEFT)

        # Section packaging treeview
        cols = ("pkg_code", "pkg_name", "pkg_charge", "is_default", "pkg_desc")
        self._sec_pkg_tree = ttk.Treeview(right, columns=cols, show="headings", selectmode="browse")
        for col, w, hdr_text in [("pkg_code", 90, t("Code", "Code")),
                                  ("pkg_name", 140, t("Packaging Type", "Packaging Type")),
                                  ("pkg_charge", 100, t("Charge ₹", "Charge ₹")),
                                  ("is_default", 100, t("Default", "Default")),
                                  ("pkg_desc", 200, t("Description", "Description"))]:
            self._sec_pkg_tree.heading(col, text=hdr_text)
            self._sec_pkg_tree.column(col, width=w,
                                       anchor=tk.W if col == "pkg_desc" else tk.CENTER)
        self._sec_pkg_tree.pack(fill=tk.BOTH, expand=True, side=tk.LEFT)
        sec_pkg_scr = ttk.Scrollbar(right, orient=tk.VERTICAL, command=self._sec_pkg_tree.yview)
        sec_pkg_scr.pack(side=tk.RIGHT, fill=tk.Y)
        self._sec_pkg_tree.configure(yscrollcommand=sec_pkg_scr.set)

        # Action buttons
        btn_bar = tk.Frame(right, bg=C["bg"], pady=4)
        btn_bar.pack(fill=tk.X, side=tk.BOTTOM)
        for label, cmd, color in [
                ("+ Assign Packaging", self._sec_pkg_add,      "#004422"),
                ("Set as Default",     self._sec_pkg_set_default, "#004488"),
                ("✕ Remove",           self._sec_pkg_remove,   "#660000")]:
            tk.Button(btn_bar, text=label, font=FONT_SMALL,
                      bg=color, fg="white", relief=tk.FLAT,
                      padx=10, pady=4, cursor="hand2",
                      command=cmd).pack(side=tk.LEFT, padx=3)

        self._pkg_sec_ids = []
        self._sec_pkg_sp_ids = []

    def _load_pkg_sections(self):
        if not hasattr(self, '_pkg_sec_lb'):
            return
        secs = db.get_sections_db()
        self._pkg_sec_ids = [s["id"] for s in secs]
        self._pkg_sec_lb.delete(0, tk.END)
        for s in secs:
            self._pkg_sec_lb.insert(tk.END, f"  {s['name']}")
        # Clear right pane
        if hasattr(self, '_sec_pkg_tree'):
            for row in self._sec_pkg_tree.get_children():
                self._sec_pkg_tree.delete(row)
        self._pkg_sec_lbl.config(text="Select a section →")

    def _selected_pkg_section_id(self):
        sel = self._pkg_sec_lb.curselection()
        if not sel:
            return None, None
        idx = sel[0]
        if idx >= len(self._pkg_sec_ids):
            return None, None
        secs = db.get_sections_db()
        return self._pkg_sec_ids[idx], secs[idx]["name"]

    def _on_pkg_sec_select(self, event=None):
        sec_id, sec_name = self._selected_pkg_section_id()
        if sec_id is None:
            return
        self._pkg_sec_lbl.config(text=f"  Packaging for:  {sec_name}")
        self._refresh_sec_packaging(sec_id)

    def _refresh_sec_packaging(self, sec_id):
        if not hasattr(self, '_sec_pkg_tree'):
            return
        for row in self._sec_pkg_tree.get_children():
            self._sec_pkg_tree.delete(row)
        pkgs = db.get_section_packaging(sec_id)
        self._sec_pkg_sp_ids = []
        for p in pkgs:
            self._sec_pkg_sp_ids.append(p["id"])
            self._sec_pkg_tree.insert("", tk.END, iid=str(p["id"]), values=(
                p.get("pkg_code", ""), p["pkg_name"], f"₹{p['pkg_charge']:.2f}",
                "★ Default" if p["is_default"] else "",
                p["pkg_desc"]
            ))

    def _sec_pkg_add(self):
        sec_id, sec_name = self._selected_pkg_section_id()
        if sec_id is None:
            messagebox.showinfo("Select", "Select a section first.")
            return
        # Get available packaging types
        pkg_types = db.get_active_packaging_types()
        if not pkg_types:
            messagebox.showinfo("No Types", "Create packaging types first (in Types tab).")
            return
        # Get already-assigned type IDs
        existing = db.get_section_packaging(sec_id)
        existing_ids = {p["packaging_type_id"] for p in existing}
        available = [p for p in pkg_types if p["id"] not in existing_ids]
        if not available:
            messagebox.showinfo("All Assigned", "All packaging types are already assigned to this section.")
            return

        dlg = tk.Toplevel(self.root)
        dlg.title(f"Assign Packaging to {sec_name}")
        dlg.geometry("350x180")
        dlg.resizable(False, False)
        dlg.grab_set()
        dlg.configure(bg=C["bg"])

        v_pkg = tk.StringVar()
        v_default = tk.IntVar(value=0)

        tk.Label(dlg, text=f"Assign packaging to: {sec_name}",
                 font=FONT_BOLD, bg=C["bg"], fg=C["header"], pady=8).pack()

        frm = tk.Frame(dlg, bg=C["bg"]); frm.pack(padx=20)
        row1 = tk.Frame(frm, bg=C["bg"]); row1.pack(fill=tk.X, pady=4)
        tk.Label(row1, text="Packaging:", width=12, anchor=tk.E,
                 bg=C["bg"], font=FONT_NORMAL).pack(side=tk.LEFT, padx=4)
        cb = ttk.Combobox(row1, textvariable=v_pkg,
                          values=[f"{p['name']} (₹{p['charge']:.2f})" for p in available],
                          state="readonly", width=25)
        cb.pack(side=tk.LEFT)
        if available:
            cb.current(0)

        row2 = tk.Frame(frm, bg=C["bg"]); row2.pack(fill=tk.X, pady=4)
        tk.Label(row2, text="Set as Default:", width=12, anchor=tk.E,
                 bg=C["bg"], font=FONT_NORMAL).pack(side=tk.LEFT, padx=4)
        tk.Checkbutton(row2, text="Yes", variable=v_default,
                       bg=C["bg"], font=FONT_NORMAL).pack(side=tk.LEFT)

        def save():
            idx = cb.current()
            if idx < 0:
                return
            pkg = available[idx]
            db.add_section_packaging(sec_id, pkg["id"], v_default.get())
            if v_default.get():
                db.set_section_default_packaging(sec_id, pkg["id"])
            dlg.destroy()
            self._refresh_sec_packaging(sec_id)

        btn_row = tk.Frame(dlg, bg=C["bg"]); btn_row.pack(pady=10)
        tk.Button(btn_row, text="Assign", font=FONT_BOLD,
                  bg=C["bill_btn"], fg="white", relief=tk.FLAT,
                  padx=16, pady=4, cursor="hand2", command=save).pack(side=tk.LEFT, padx=6)
        tk.Button(btn_row, text="Cancel", font=FONT_NORMAL,
                  bg="#CCCCCC", relief=tk.FLAT, padx=12, pady=4,
                  command=dlg.destroy).pack(side=tk.LEFT)

    def _sec_pkg_set_default(self):
        sec_id, _ = self._selected_pkg_section_id()
        sel = self._sec_pkg_tree.selection()
        if not sel or sec_id is None:
            messagebox.showinfo("Select", "Select a packaging entry first.")
            return
        sp_id = int(sel[0])
        # Find packaging_type_id for this mapping
        pkgs = db.get_section_packaging(sec_id)
        for p in pkgs:
            if p["id"] == sp_id:
                db.set_section_default_packaging(sec_id, p["packaging_type_id"])
                break
        self._refresh_sec_packaging(sec_id)

    def _sec_pkg_remove(self):
        sec_id, _ = self._selected_pkg_section_id()
        sel = self._sec_pkg_tree.selection()
        if not sel:
            messagebox.showinfo("Select", "Select a packaging entry first.")
            return
        sp_id = int(sel[0])
        db.remove_section_packaging(sp_id)
        if sec_id:
            self._refresh_sec_packaging(sec_id)

    # ── Product Packaging Page ──

    def _build_pkg_products_page(self, parent):
        body = tk.Frame(parent, bg=C["bg"])
        body.pack(fill=tk.BOTH, expand=True)

        # LEFT: section + item selector
        left = tk.Frame(body, bg=C["sec_bg"], width=240)
        left.pack(side=tk.LEFT, fill=tk.Y)
        left.pack_propagate(False)

        tk.Label(left, text="SELECT PRODUCT", bg=C["sec_bg"], fg="#FFAA66",
                 font=FONT_SMALL, pady=4).pack(fill=tk.X)

        # Section dropdown
        sec_frm = tk.Frame(left, bg=C["sec_bg"])
        sec_frm.pack(fill=tk.X, padx=4, pady=2)
        tk.Label(sec_frm, text="Section:", bg=C["sec_bg"], fg="#DDBBAA",
                 font=FONT_SMALL).pack(anchor=tk.W)
        self._pkg_prod_sec_var = tk.StringVar()
        self._pkg_prod_sec_cb = ttk.Combobox(sec_frm, textvariable=self._pkg_prod_sec_var,
                                              state="readonly", width=28)
        self._pkg_prod_sec_cb.pack(fill=tk.X)
        self._pkg_prod_sec_cb.bind("<<ComboboxSelected>>", self._on_pkg_prod_sec_change)

        # Items listbox
        tk.Label(left, text="Items:", bg=C["sec_bg"], fg="#DDBBAA",
                 font=FONT_SMALL).pack(anchor=tk.W, padx=4, pady=(4,0))
        item_frm = tk.Frame(left, bg=C["sec_bg"])
        item_frm.pack(fill=tk.BOTH, expand=True, padx=4, pady=2)
        item_scr = tk.Scrollbar(item_frm, width=self.scrollbar_width)
        item_scr.pack(side=tk.RIGHT, fill=tk.Y)
        self._pkg_prod_item_lb = tk.Listbox(item_frm, yscrollcommand=item_scr.set,
                                             bg="#2A1000", fg="#FFDDAA",
                                             selectbackground=C["sec_active"],
                                             selectforeground="white",
                                             font=FONT_SMALL, borderwidth=0,
                                             highlightthickness=0)
        self._pkg_prod_item_lb.pack(fill=tk.BOTH, expand=True)
        item_scr.config(command=self._pkg_prod_item_lb.yview)
        self._pkg_prod_item_lb.bind("<<ListboxSelect>>", self._on_pkg_prod_item_select)

        # RIGHT: packaging for selected product
        right = tk.Frame(body, bg=C["bg"])
        right.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        hdr = tk.Frame(right, bg="#FFF2E0", pady=3)
        hdr.pack(fill=tk.X)
        self._pkg_prod_lbl = tk.Label(hdr, text="Select a product →",
                                       bg="#FFF2E0", fg=C["header"], font=FONT_BOLD,
                                       anchor=tk.W, padx=8)
        self._pkg_prod_lbl.pack(side=tk.LEFT)

        # Product packaging treeview
        cols = ("pkg_code", "pkg_name", "pkg_charge", "charge_override", "is_default", "pkg_desc")
        self._prod_pkg_tree = ttk.Treeview(right, columns=cols, show="headings", selectmode="browse")
        for col, w, hdr_text in [("pkg_code", 80, t("Code", "Code")),
                                  ("pkg_name", 130, t("Packaging Type", "Packaging Type")),
                                  ("pkg_charge", 80, t("Std Charge ₹", "Std Charge ₹")),
                                  ("charge_override", 90, t("Override ₹", "Override ₹")),
                                  ("is_default", 80, t("Default", "Default")),
                                  ("pkg_desc", 150, t("Description", "Description"))]:
            self._prod_pkg_tree.heading(col, text=hdr_text)
            self._prod_pkg_tree.column(col, width=w,
                                       anchor=tk.W if col == "pkg_desc" else tk.CENTER)
        self._prod_pkg_tree.pack(fill=tk.BOTH, expand=True, side=tk.LEFT)
        prod_pkg_scr = ttk.Scrollbar(right, orient=tk.VERTICAL, command=self._prod_pkg_tree.yview)
        prod_pkg_scr.pack(side=tk.RIGHT, fill=tk.Y)
        self._prod_pkg_tree.configure(yscrollcommand=prod_pkg_scr.set)

        # Action buttons
        btn_bar = tk.Frame(right, bg=C["bg"], pady=4)
        btn_bar.pack(fill=tk.X, side=tk.BOTTOM)
        for label, cmd, color in [
                ("+ Assign Packaging", self._prod_pkg_add,       "#004422"),
                ("Set as Default",     self._prod_pkg_set_default, "#004488"),
                ("✕ Remove",           self._prod_pkg_remove,    "#660000")]:
            tk.Button(btn_bar, text=label, font=FONT_SMALL,
                      bg=color, fg="white", relief=tk.FLAT,
                      padx=10, pady=4, cursor="hand2",
                      command=cmd).pack(side=tk.LEFT, padx=3)

        self._pkg_prod_item_ids = []
        self._prod_pkg_pp_ids = []

    def _load_pkg_products(self):
        if not hasattr(self, '_pkg_prod_sec_cb'):
            return
        secs = db.get_sections_db()
        self._pkg_prod_sec_data = secs
        self._pkg_prod_sec_cb['values'] = [s["name"] for s in secs]
        if secs:
            self._pkg_prod_sec_cb.current(0)
            self._on_pkg_prod_sec_change()
        # Clear right pane
        if hasattr(self, '_prod_pkg_tree'):
            for row in self._prod_pkg_tree.get_children():
                self._prod_pkg_tree.delete(row)
        self._pkg_prod_lbl.config(text="Select a product →")

    def _on_pkg_prod_sec_change(self, event=None):
        idx = self._pkg_prod_sec_cb.current()
        if idx < 0 or idx >= len(self._pkg_prod_sec_data):
            return
        sec_id = self._pkg_prod_sec_data[idx]["id"]
        items = db.get_items_for_section(sec_id)
        self._pkg_prod_item_lb.delete(0, tk.END)
        self._pkg_prod_item_ids = []
        for it in items:
            code = it.get('code', '') or ''
            display = f"  [{code}] {it['name']}" if code else f"  {it['name']}"
            self._pkg_prod_item_lb.insert(tk.END, display)
            self._pkg_prod_item_ids.append(it["id"])
        # Clear product packaging view
        if hasattr(self, '_prod_pkg_tree'):
            for row in self._prod_pkg_tree.get_children():
                self._prod_pkg_tree.delete(row)
        self._pkg_prod_lbl.config(text="Select a product →")

    def _selected_pkg_product_id(self):
        sel = self._pkg_prod_item_lb.curselection()
        if not sel:
            return None, None
        idx = sel[0]
        if idx >= len(self._pkg_prod_item_ids):
            return None, None
        item_id = self._pkg_prod_item_ids[idx]
        item_name = self._pkg_prod_item_lb.get(idx).strip()
        return item_id, item_name

    def _on_pkg_prod_item_select(self, event=None):
        item_id, item_name = self._selected_pkg_product_id()
        if item_id is None:
            return
        self._pkg_prod_lbl.config(text=f"  Packaging for:  {item_name}")
        self._refresh_prod_packaging(item_id)

    def _refresh_prod_packaging(self, item_id):
        if not hasattr(self, '_prod_pkg_tree'):
            return
        for row in self._prod_pkg_tree.get_children():
            self._prod_pkg_tree.delete(row)
        pkgs = db.get_product_packaging(item_id)
        self._prod_pkg_pp_ids = []
        for p in pkgs:
            self._prod_pkg_pp_ids.append(p["id"])
            override_str = f"₹{p['charge_override']:.2f}" if p['charge_override'] is not None else ""
            self._prod_pkg_tree.insert("", tk.END, iid=str(p["id"]), values=(
                p.get("pkg_code", ""), p["pkg_name"], f"₹{p['pkg_charge']:.2f}",
                override_str,
                "★ Default" if p["is_default"] else "",
                p["pkg_desc"]
            ))

    def _prod_pkg_add(self):
        item_id, item_name = self._selected_pkg_product_id()
        if item_id is None:
            messagebox.showinfo("Select", "Select a product first.")
            return
        pkg_types = db.get_active_packaging_types()
        if not pkg_types:
            messagebox.showinfo("No Types", "Create packaging types first (in Types tab).")
            return
        existing = db.get_product_packaging(item_id)
        existing_ids = {p["packaging_type_id"] for p in existing}
        available = [p for p in pkg_types if p["id"] not in existing_ids]
        if not available:
            messagebox.showinfo("All Assigned", "All packaging types are already assigned to this product.")
            return

        dlg = tk.Toplevel(self.root)
        dlg.title(f"Assign Packaging to {item_name}")
        dlg.geometry("400x240")
        dlg.resizable(False, False)
        dlg.grab_set()
        dlg.configure(bg=C["bg"])

        v_pkg = tk.StringVar()
        v_override = tk.StringVar(value="")
        v_default = tk.IntVar(value=0)

        tk.Label(dlg, text=f"Assign packaging to: {item_name}",
                 font=FONT_BOLD, bg=C["bg"], fg=C["header"], pady=8).pack()

        frm = tk.Frame(dlg, bg=C["bg"]); frm.pack(padx=20)
        row1 = tk.Frame(frm, bg=C["bg"]); row1.pack(fill=tk.X, pady=4)
        tk.Label(row1, text="Packaging:", width=14, anchor=tk.E,
                 bg=C["bg"], font=FONT_NORMAL).pack(side=tk.LEFT, padx=4)
        cb = ttk.Combobox(row1, textvariable=v_pkg,
                          values=[f"{p['name']} (₹{p['charge']:.2f})" for p in available],
                          state="readonly", width=25)
        cb.pack(side=tk.LEFT)
        if available:
            cb.current(0)

        row2 = tk.Frame(frm, bg=C["bg"]); row2.pack(fill=tk.X, pady=4)
        tk.Label(row2, text="Charge Override:", width=14, anchor=tk.E,
                 bg=C["bg"], font=FONT_NORMAL).pack(side=tk.LEFT, padx=4)
        tk.Entry(row2, textvariable=v_override, width=10,
                 font=FONT_NORMAL).pack(side=tk.LEFT)
        tk.Label(row2, text="(leave blank to use std charge)",
                 font=("Segoe UI", 8), bg=C["bg"], fg=C["muted"]).pack(side=tk.LEFT, padx=4)

        row3 = tk.Frame(frm, bg=C["bg"]); row3.pack(fill=tk.X, pady=4)
        tk.Label(row3, text="Set as Default:", width=14, anchor=tk.E,
                 bg=C["bg"], font=FONT_NORMAL).pack(side=tk.LEFT, padx=4)
        tk.Checkbutton(row3, text="Yes", variable=v_default,
                       bg=C["bg"], font=FONT_NORMAL).pack(side=tk.LEFT)

        def save():
            idx = cb.current()
            if idx < 0:
                return
            pkg = available[idx]
            override_val = None
            ov_str = v_override.get().strip()
            if ov_str:
                try:
                    override_val = float(ov_str)
                except ValueError:
                    messagebox.showwarning("Invalid", "Override charge must be a number.", parent=dlg)
                    return
            db.add_product_packaging(item_id, pkg["id"], override_val, v_default.get())
            if v_default.get():
                db.set_product_default_packaging(item_id, pkg["id"])
            dlg.destroy()
            self._refresh_prod_packaging(item_id)

        btn_row = tk.Frame(dlg, bg=C["bg"]); btn_row.pack(pady=10)
        tk.Button(btn_row, text="Assign", font=FONT_BOLD,
                  bg=C["bill_btn"], fg="white", relief=tk.FLAT,
                  padx=16, pady=4, cursor="hand2", command=save).pack(side=tk.LEFT, padx=6)
        tk.Button(btn_row, text="Cancel", font=FONT_NORMAL,
                  bg="#CCCCCC", relief=tk.FLAT, padx=12, pady=4,
                  command=dlg.destroy).pack(side=tk.LEFT)

    def _prod_pkg_set_default(self):
        item_id, _ = self._selected_pkg_product_id()
        sel = self._prod_pkg_tree.selection()
        if not sel or item_id is None:
            messagebox.showinfo("Select", "Select a packaging entry first.")
            return
        pp_id = int(sel[0])
        pkgs = db.get_product_packaging(item_id)
        for p in pkgs:
            if p["id"] == pp_id:
                db.set_product_default_packaging(item_id, p["packaging_type_id"])
                break
        self._refresh_prod_packaging(item_id)

    def _prod_pkg_remove(self):
        item_id, _ = self._selected_pkg_product_id()
        sel = self._prod_pkg_tree.selection()
        if not sel:
            messagebox.showinfo("Select", "Select a packaging entry first.")
            return
        pp_id = int(sel[0])
        db.remove_product_packaging(pp_id)
        if item_id:
            self._refresh_prod_packaging(item_id)

    # ─────────────────────────────────── SETTINGS TAB ──────

    def _build_settings_tab(self, parent):
        canvas = tk.Canvas(parent, bg=C["bg"], highlightthickness=0)
        scr    = ttk.Scrollbar(parent, orient=tk.VERTICAL, command=canvas.yview)
        canvas.configure(yscrollcommand=scr.set)
        scr.pack(side=tk.RIGHT, fill=tk.Y)
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        frm = tk.Frame(canvas, bg=C["bg"])
        cwin = canvas.create_window((0,0), window=frm, anchor=tk.NW)
        frm.bind("<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.bind("<Configure>",
            lambda e: canvas.itemconfig(cwin, width=e.width))

        self._setting_vars = {}
        fields = [
            ("Restaurant Info", [
                ("restaurant_name",    "Restaurant Name"),
                ("restaurant_address", "Address"),
                ("restaurant_phone",   "Phone"),
                ("gstin",              "GSTIN"),
                ("fssai_no",           "FSSAI No."),
                ("tagline",            "Tagline"),
            ]),
            ("Network / KDS", [
                ("terminal_id",       "Terminal ID (unique integer 1-99)"),
                ("server_port",       "Terminal Server Port"),
                ("kds_terminal_ip",   "Terminal IP (set on KDS machine)"),
                ("kds_terminal_port", "Terminal Port (set on KDS machine)"),
                ("kds_station_id",    "KDS Station ID"),
                ("ui_scale",          "UI Layout Scale"),
            ]),
            ("Printing", [
                ("printer_name",       "Printer Name (blank = default)"),
                ("print_copies_bill",  "Bill Copies"),
                ("print_copies_kot",   "KOT Copies"),
                ("thermal_chars",      "Characters/line (80mm = 42)"),
                ("print_on_hold",      "Print Hold Bills"),
            ]),
            ("Tax", [
                ("gst_rate", "GST Rate %"),
            ]),
            ("Pine Labs EDC  (card / UPI via terminal)", [
                ("pl_edc_ip",     "EDC Terminal IP"),
                ("pl_edc_port",   "EDC Port (default 4002)"),
                ("pl_store_id",   "Merchant Store ID"),
                ("pl_terminal_sn","Terminal Serial Number"),
                ("pl_timeout",    "Payment timeout (seconds)"),
            ]),
        ]
        for section, items in fields:
            is_pl = section.startswith("Pine Labs")
            sec_bg = "#001A33" if is_pl else C["bg"]
            sec_fg = "#66AAFF" if is_pl else C["header"]
            tk.Label(frm, text=t(section, section), bg=sec_bg, fg=sec_fg,
                     font=FONT_LARGE, pady=8, padx=8).grid(
                row=len(self._setting_vars)*2, column=0,
                columnspan=3, sticky=tk.EW, padx=0)

            # Pine Labs enabled toggle
            if is_pl:
                pl_row = len(self._setting_vars) * 2 + 1
                pl_var = tk.BooleanVar(value=bool(CFG.get("pl_enabled", False)))
                self._setting_vars["pl_enabled"] = pl_var
                tk.Checkbutton(frm, text=t("Enable Pine Labs EDC integration", "Enable Pine Labs EDC integration"),
                               variable=pl_var, bg=sec_bg, fg="#AADDFF",
                               selectcolor="#003366", activebackground=sec_bg,
                               font=FONT_NORMAL
                               ).grid(row=pl_row, column=0, columnspan=2,
                                      sticky=tk.W, padx=16)
                # Test connection button
                tk.Button(frm, text=t("Test Connection", "Test Connection"), font=FONT_SMALL,
                          bg="#003366", fg="white", relief=tk.FLAT,
                          cursor="hand2", padx=8,
                          command=self._test_pinelabs_connection
                          ).grid(row=pl_row, column=2, padx=8, sticky=tk.W)

            for key, label in items:
                row = len(self._setting_vars) * 2 + 1
                tk.Label(frm, text=t(label, label), bg=sec_bg, fg=C["text"] if not is_pl else "#CCDDEE",
                         font=FONT_NORMAL, anchor=tk.E, width=32
                         ).grid(row=row, column=0, padx=(16,4), pady=3, sticky=tk.E)
                
                if key == "printer_name":
                    var = tk.StringVar(value=str(CFG.get(key, "")))
                    printers = [""] + pr.get_printers()
                    cb = ttk.Combobox(frm, textvariable=var, values=printers,
                                      font=FONT_NORMAL, width=30, state="readonly")
                    cb.grid(row=row, column=1, padx=(0,16), pady=3, sticky=tk.W)
                    self._setting_vars[key] = var
                elif key == "ui_scale":
                    var = tk.StringVar(value=str(CFG.get(key, "auto")))
                    cb = ttk.Combobox(frm, textvariable=var, values=["auto", "standard", "compact"],
                                      font=FONT_NORMAL, width=30, state="readonly")
                    cb.grid(row=row, column=1, padx=(0,16), pady=3, sticky=tk.W)
                    self._setting_vars[key] = var
                elif key == "print_on_hold":
                    var = tk.BooleanVar(value=bool(CFG.get(key, False)))
                    tk.Checkbutton(frm, text=t("Print receipt when holding a bill", "Print receipt when holding a bill"),
                                   variable=var, bg=sec_bg, fg=C["text"] if not is_pl else "#CCDDEE",
                                   selectcolor="#FFFFFF" if not is_pl else "#003366",
                                   activebackground=sec_bg, font=FONT_NORMAL
                                   ).grid(row=row, column=1, padx=(0,16), pady=3, sticky=tk.W)
                    self._setting_vars[key] = var
                else:
                    var = tk.StringVar(value=str(CFG.get(key, "")))
                    tk.Entry(frm, textvariable=var, font=FONT_NORMAL, width=32
                             ).grid(row=row, column=1, padx=(0,16), pady=3, sticky=tk.W)
                    self._setting_vars[key] = var


        frm.columnconfigure(1, weight=1)
        
        # Row 998: Manage Coupons button
        tk.Button(frm, text="🎫 " + t("Manage Discount Coupons", "Manage Discount Coupons"), font=FONT_BOLD,
                  bg="#5A1A8A", fg="white", relief=tk.FLAT,
                  padx=20, pady=8, cursor="hand2",
                  command=self._manage_coupons_dialog).grid(
                  row=998, column=0, columnspan=3, pady=(16, 0))

        tk.Button(frm, text=t("Save Settings", "Save Settings"), font=FONT_BOLD,
                  bg=C["bill_btn"], fg="white", relief=tk.FLAT,
                  padx=20, pady=8, cursor="hand2",
                  command=self._save_settings).grid(
                  row=999, column=0, columnspan=3, pady=16)

    def _save_settings(self):
        for key, var in self._setting_vars.items():
            if isinstance(var, tk.BooleanVar):
                CFG[key] = var.get()
            else:
                val = var.get().strip()
                if key in ("terminal_id", "server_port", "kds_terminal_port", "print_copies_bill",
                           "print_copies_kot", "thermal_chars",
                           "pl_edc_port", "pl_timeout"):
                    try:
                        CFG[key] = int(val)
                    except ValueError:
                        pass
                elif key == "gst_rate":
                    try:
                        CFG[key] = float(val)
                    except ValueError:
                        pass
                else:
                    CFG[key] = val
        CFG["ui_scale_chosen"] = True
        save_config(CFG)
        pr.W = CFG.get("thermal_chars", 42)
        messagebox.showinfo(t("Saved", "Saved"),
            t("Settings saved.\n"
              "Network changes (KDS port, Pine Labs) take effect on next restart.",
              "Settings saved.\n"
              "Network changes (KDS port, Pine Labs) take effect on next restart."))

    def _test_pinelabs_connection(self):
        ip   = self._setting_vars.get("pl_edc_ip",  type("", (), {"get": lambda s: CFG.get("pl_edc_ip","")})()).get()
        port = self._setting_vars.get("pl_edc_port", type("", (), {"get": lambda s: str(CFG.get("pl_edc_port",4002))})()).get()
        # Use current field values
        ip_val = ip if ip else CFG.get("pl_edc_ip", "")
        try:
            port_val = int(port) if port else int(CFG.get("pl_edc_port", 4002))
        except ValueError:
            port_val = 4002
        if not ip_val:
            messagebox.showwarning("Missing IP", "Enter the EDC Terminal IP address first.")
            return
        ok, msg = pl_edc.test_connection(ip_val, port_val, timeout=5)
        if ok:
            messagebox.showinfo("Connected", msg)
        else:
            messagebox.showerror("Connection failed", msg)

    def _get_coupon_combobox_values(self):
        coupons = CFG.get("coupons", [])
        vals = ["None"]
        for c in coupons:
            code = c.get("code", "")
            val = c.get("value", 0.0)
            t_type = c.get("type", "percentage")
            if t_type == "percentage":
                vals.append(f"{code} ({val:.0f}%)")
            else:
                vals.append(f"{code} (Flat ₹{val:.0f})")
        return vals

    def _refresh_coupon_combobox(self):
        if hasattr(self, "_cb_coupon") and self._cb_coupon:
            self._cb_coupon.config(values=self._get_coupon_combobox_values())
            self.coupon_var.set("None")

    def _manage_coupons_dialog(self):
        dlg = tk.Toplevel(self.root)
        dlg.title(t("Manage Coupons", "Manage Coupons"))
        dlg.geometry("500x420")
        dlg.configure(bg=C["bg"])
        dlg.grab_set()
        dlg.resizable(False, False)
        
        # Center dialog
        try:
            dlg.update_idletasks()
            pw = self.root.winfo_width()
            ph = self.root.winfo_height()
            px = self.root.winfo_x()
            py = self.root.winfo_y()
            w, h = 500, 420
            x = px + (pw - w) // 2
            y = py + (ph - h) // 2
            dlg.geometry(f"{w}x{h}+{x}+{y}")
        except Exception:
            pass

        tk.Label(
            dlg, 
            text=t("MANAGE DISCOUNT COUPONS", "MANAGE DISCOUNT COUPONS"), 
            font=("Segoe UI", 12, "bold"), 
            bg=C["header"], 
            fg=C["header_fg"],
            pady=8
        ).pack(fill=tk.X)

        # Main frame
        main_frm = tk.Frame(dlg, bg=C["bg"], padx=12, pady=12)
        main_frm.pack(fill=tk.BOTH, expand=True)

        # Treeview for existing coupons
        tree_frame = tk.Frame(main_frm, bg=C["bg"])
        tree_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))

        cols = ("code", "type", "value")
        tree = ttk.Treeview(tree_frame, columns=cols, show="headings", height=8)
        tree.heading("code", text=t("Code", "Code"))
        tree.heading("type", text=t("Type", "Type"))
        tree.heading("value", text=t("Value", "Value"))
        
        tree.column("code", width=150, anchor=tk.W)
        tree.column("type", width=120, anchor=tk.CENTER)
        tree.column("value", width=100, anchor=tk.E)

        ysb = ttk.Scrollbar(tree_frame, orient=tk.VERTICAL, command=tree.yview)
        tree.configure(yscroll=ysb.set)
        tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        ysb.pack(side=tk.RIGHT, fill=tk.Y)

        # Form fields to Add/Edit
        form_frm = tk.Frame(main_frm, bg=C["bg"])
        form_frm.pack(fill=tk.X, pady=5)

        tk.Label(form_frm, text=t("Code:", "Code:"), font=FONT_SMALL, bg=C["bg"], fg=C["text"]).grid(row=0, column=0, sticky="w", padx=2, pady=2)
        code_var = tk.StringVar()
        code_ent = tk.Entry(form_frm, textvariable=code_var, font=FONT_NORMAL, width=12)
        code_ent.grid(row=0, column=1, sticky="w", padx=2, pady=2)

        tk.Label(form_frm, text=t("Type:", "Type:"), font=FONT_SMALL, bg=C["bg"], fg=C["text"]).grid(row=0, column=2, sticky="w", padx=2, pady=2)
        type_var = tk.StringVar(value="percentage")
        type_cb = ttk.Combobox(form_frm, textvariable=type_var, values=["percentage", "flat"], state="readonly", font=FONT_NORMAL, width=10)
        type_cb.grid(row=0, column=3, sticky="w", padx=2, pady=2)

        tk.Label(form_frm, text=t("Value:", "Value:"), font=FONT_SMALL, bg=C["bg"], fg=C["text"]).grid(row=0, column=4, sticky="w", padx=2, pady=2)
        val_var = tk.StringVar()
        val_ent = tk.Entry(form_frm, textvariable=val_var, font=FONT_NORMAL, width=8, justify=tk.RIGHT)
        val_ent.grid(row=0, column=5, sticky="w", padx=2, pady=2)

        # Load coupons into tree
        coupons_list = [c.copy() for c in CFG.get("coupons", [])]

        def refresh_tree():
            for item in tree.get_children():
                tree.delete(item)
            for c in coupons_list:
                tree.insert("", tk.END, values=(c["code"], c["type"], f"{c['value']:.2f}"))

        refresh_tree()

        # Selection binding to load values into form fields
        def on_tree_select(event):
            selected = tree.selection()
            if selected:
                code, c_type, val = tree.item(selected[0], "values")
                code_var.set(code)
                type_var.set(c_type)
                val_var.set(val)
        tree.bind("<<TreeviewSelect>>", on_tree_select)

        # Button action handlers
        def add_or_update_coupon():
            code = code_var.get().strip().upper()
            c_type = type_var.get()
            val_str = val_var.get().strip()
            
            if not code:
                messagebox.showwarning(t("Invalid Code", "Invalid Code"), t("Please enter a coupon code.", "Please enter a coupon code."), parent=dlg)
                return
            try:
                val = float(val_str)
                if val < 0: raise ValueError
            except ValueError:
                messagebox.showwarning(t("Invalid Value", "Invalid Value"), t("Please enter a positive numeric value.", "Please enter a positive numeric value."), parent=dlg)
                return

            # Check if coupon already exists
            existing = next((c for c in coupons_list if c["code"] == code), None)
            if existing:
                existing["type"] = c_type
                existing["value"] = val
            else:
                coupons_list.append({"code": code, "type": c_type, "value": val})

            code_var.set("")
            val_var.set("")
            refresh_tree()

        def delete_coupon():
            selected = tree.selection()
            if not selected:
                messagebox.showwarning(t("No Selection", "No Selection"), t("Please select a coupon to delete.", "Please select a coupon to delete."), parent=dlg)
                return
            code = tree.item(selected[0], "values")[0]
            nonlocal coupons_list
            coupons_list = [c for c in coupons_list if c["code"] != code]
            code_var.set("")
            val_var.set("")
            refresh_tree()

        def save_and_close():
            CFG["coupons"] = coupons_list
            save_config(CFG)
            self._refresh_coupon_combobox()
            dlg.destroy()
            messagebox.showinfo(t("Saved", "Saved"), t("Coupons saved successfully.", "Coupons saved successfully."))

        # Action Buttons frame
        btn_frm = tk.Frame(main_frm, bg=C["bg"])
        btn_frm.pack(fill=tk.X, pady=(10, 0))

        tk.Button(btn_frm, text=t("Add / Update", "Add / Update"), font=FONT_SMALL, bg="#2E7D32", fg="white", relief=tk.FLAT, padx=12, pady=4, cursor="hand2", command=add_or_update_coupon).pack(side=tk.LEFT, padx=3)
        tk.Button(btn_frm, text=t("Delete", "Delete"), font=FONT_SMALL, bg="#C62828", fg="white", relief=tk.FLAT, padx=12, pady=4, cursor="hand2", command=delete_coupon).pack(side=tk.LEFT, padx=3)
        tk.Button(btn_frm, text=t("Save & Close", "Save & Close"), font=FONT_SMALL, bg=C["bill_btn"], fg="white", relief=tk.FLAT, padx=16, pady=4, cursor="hand2", command=save_and_close).pack(side=tk.RIGHT, padx=3)

    # ─────────────────────────────────── NETWORK CALLBACKS ─

    def _on_kds_message(self, msg: dict, conn=None):
        mtype = msg.get("type")
        if mtype == "kot_status":
            kot_no = msg.get("kot_no")
            status = msg.get("status")
            if kot_no and status:
                db.update_kot_status(kot_no, status)
                self.root.after(0, self._load_kots)
                # Sync status change to all other KDS screens
                self.server.broadcast(msg)
        elif mtype == "new_kot":
            kot = msg.get("kot")
            if kot:
                db.save_kot_sync(kot)
            self.server.broadcast(msg)
            self.root.after(0, self._load_kots)
        elif mtype == "print_request":
            pass  # Terminal can handle reprint requests from KDS if needed
        elif mtype == "request_active_kots" and conn:
            active_kots = db.get_active_kots()
            self.server.send_to(conn, {"type": "active_kots", "kots": active_kots})
        self.root.after(0, self._refresh_kds_connection_count)

    # ─────────────────────────────────── CLOCK ─────────────

    def _clock_tick(self):
        now = datetime.datetime.now().strftime("%A, %d %b %Y  %H:%M:%S")
        self._clock_lbl.config(text=now)
        self._refresh_kds_connection_count()
        self.root.after(1000, self._clock_tick)

    # ─────────────────────────────────── AGGREGATORS & NETWORKING ────

    def _network_broadcast(self, msg):
        if CFG.get("is_primary", True):
            if hasattr(self, "server") and self.server:
                self.server.broadcast(msg)
        else:
            if hasattr(self, "terminal_client") and self.terminal_client:
                self.terminal_client.send(msg)

    def _refresh_kds_connection_count(self):
        """v1.2.1: Show hub connection status (replaces v1.1 'Terminal Server' label).
        Also shows legacy KDS count if running as primary."""
        # v1.2 priority: show hub connection status if pos_client exists
        if hasattr(self, "pos_client") and self.pos_client:
            if self.pos_client.connected:
                # Also show KDS count if we have legacy KDS clients connected
                kds_count = 0
                if hasattr(self, "server") and self.server:
                    try:
                        kds_count = self.server.client_count
                    except Exception:
                        pass
                if kds_count > 0:
                    text = f"● Hub: connected  |  KDS: {kds_count}"
                else:
                    text = "● Hub: connected"
                color = "#44FF44"
            else:
                text = "○ Hub: connecting…"
                color = "#FFAA44"
            try:
                self._kds_lbl.config(text=text, fg=color)
            except Exception:
                pass
            return

        # Legacy v1.1 fallback: show KDS client count if is_primary
        if CFG.get("is_primary", False):
            if hasattr(self, "server") and self.server:
                try:
                    self._kds_lbl.config(text=f"KDS: {self.server.client_count} connected", fg=C["header_fg"])
                except Exception:
                    pass
        else:
            if hasattr(self, "terminal_client") and self.terminal_client:
                status = "Connected" if self.terminal_client.connected else "Disconnected"
                color = "#44FF44" if self.terminal_client.connected else "#FF4444"
                try:
                    self._kds_lbl.config(text=f"Terminal Server: {status}", fg=color)
                except Exception:
                    pass

    def _on_primary_connect(self):
        self.root.after(0, self._refresh_kds_connection_count)
        if hasattr(self, "terminal_client") and self.terminal_client:
            self.terminal_client.send({"type": "request_active_kots"})

    def _on_primary_disconnect(self):
        self.root.after(0, self._refresh_kds_connection_count)

    def _on_primary_message(self, msg: dict):
        mtype = msg.get("type")
        if mtype == "new_kot":
            kot = msg.get("kot")
            if kot:
                db.save_kot_sync(kot)
            self.root.after(0, self._load_kots)
        elif mtype == "kot_status":
            kot_no = msg.get("kot_no")
            status = msg.get("status")
            if kot_no and status:
                db.update_kot_status(kot_no, status)
            self.root.after(0, self._load_kots)
        elif mtype == "active_kots":
            kots_list = msg.get("kots", [])
            for kot in kots_list:
                db.save_kot_sync(kot)
            self.root.after(0, self._load_kots)

    def _start_aggregator_server(self):
        import http.server
        
        # Simple HTTP handler wrapping process callback
        class AggregatorHandler(http.server.BaseHTTPRequestHandler):
            def log_message(self, format, *args):
                pass # Suppress console logs
                
            def do_POST(self):
                content_length = int(self.headers['Content-Length'])
                post_data = self.rfile.read(content_length)
                
                try:
                    order_data = json.loads(post_data.decode('utf-8'))
                    path = self.path.lower()
                    
                    platform = "online"
                    if "swiggy" in path:
                        platform = "swiggy"
                    elif "zomato" in path:
                        platform = "zomato"
                        
                    if hasattr(self.server, 'process_order_callback') and self.server.process_order_callback:
                        success, response_msg = self.server.process_order_callback(platform, order_data)
                        if success:
                            self.send_response(200)
                            self.send_header('Content-Type', 'application/json')
                            self.end_headers()
                            self.wfile.write(json.dumps({"status": "success", "message": response_msg}).encode('utf-8'))
                            return
                        else:
                            self.send_response(400)
                            self.send_header('Content-Type', 'application/json')
                            self.end_headers()
                            self.wfile.write(json.dumps({"status": "error", "message": response_msg}).encode('utf-8'))
                            return
                    
                    self.send_response(500)
                    self.end_headers()
                except Exception as e:
                    self.send_response(500)
                    self.send_header('Content-Type', 'application/json')
                    self.end_headers()
                    self.wfile.write(json.dumps({"status": "error", "message": str(e)}).encode('utf-8'))

        host = "0.0.0.0"
        port = 9990
        try:
            self.agg_server = http.server.HTTPServer((host, port), AggregatorHandler)
            self.agg_server.process_order_callback = self._process_aggregator_order
            t = threading.Thread(target=self.agg_server.serve_forever, daemon=True, name="agg-server")
            t.start()
        except Exception as e:
            print(f"Failed to start aggregator integration server: {e}")

    def _process_aggregator_order(self, platform, order_data):
        try:
            # 1. Save bill in database
            meta = {
                'order_type': 'online',
                'table_no': '',
                'customer_name': f"[{platform.upper()}] {order_data.get('customer_name', 'Guest')}",
                'subtotal': order_data.get('subtotal', 0.0),
                'cgst': order_data.get('cgst', 0.0),
                'sgst': order_data.get('sgst', 0.0),
                'total': order_data.get('total', 0.0),
                'payment_mode': platform,
                'notes': f"Order #{order_data.get('order_id', '')} via {platform.upper()}",
                'discount_percentage': order_data.get('discount_percentage', 0.0),
                'discount_amount': order_data.get('discount_amount', 0.0),
                'delivery_charges': order_data.get('delivery_charges', 0.0),
            }
            
            items = []
            for it in order_data.get('items', []):
                items.append({
                    'name': it['name'],
                    'section': it.get('section', ''),
                    'price': it['price'],
                    'qty': it.get('qty', 1),
                    'type': 'parcel'
                })
                
            bill = db.save_bill(meta, items)
            
            # 2. Save KOT in database
            kot_meta = {
                'order_type': 'online',
                'table_no': '',
                'customer_name': meta['customer_name'],
                'notes': meta['notes'],
                'bill_id': bill['bill_id']
            }
            kot_items = []
            for it in items:
                kot_items.append({
                    'name': it['name'],
                    'qty': it['qty'],
                    'type': 'parcel'
                })
                
            kot = db.save_kot(kot_meta, kot_items)
            
            # 3. Broadcast KOT to all KDS screens
            self._network_broadcast({"type": "new_kot", "kot": kot})
                
            # 4. Trigger UI update
            self.root.after(0, self._load_kots)
            self.root.after(0, self._load_aggregators)
            
            # Trigger alert popup
            self.root.after(0, lambda: messagebox.showinfo(
                "Aggregator Order", 
                f"New {platform.upper()} Order Received!\nID: {order_data.get('order_id')}\nCustomer: {order_data.get('customer_name')}"
            ))
            
            return True, f"Order {order_data.get('order_id')} saved successfully."
        except Exception as e:
            return False, str(e)

    def _simulate_aggregator_order(self, platform):
        def run_sim():
            import urllib.request
            import random
            
            order_id = f"AG-{random.randint(100000, 999999)}"
            items_pool = [
                {"name": "Masala Dosa", "price": 60.0},
                {"name": "Idli", "price": 40.0},
                {"name": "Medu Vada", "price": 50.0},
                {"name": "Filter Coffee", "price": 25.0},
                {"name": "Paneer Butter Masala", "price": 180.0},
                {"name": "Butter Naan", "price": 40.0}
            ]
            
            selected = random.sample(items_pool, k=random.randint(1, 3))
            order_items = []
            subtotal = 0.0
            for it in selected:
                qty = random.randint(1, 2)
                order_items.append({
                    "name": it["name"],
                    "price": it["price"],
                    "qty": qty,
                    "section": "South Indian" if "Dosa" in it["name"] or "Idli" in it["name"] or "Coffee" in it["name"] else "Punjabi"
                })
                subtotal += it["price"] * qty
                
            delivery_charges = 30.0
            gst = round(subtotal * 0.05, 2)
            total = subtotal + gst + delivery_charges
            
            names = ["Rahul Sharma", "Amit Patel", "Priya Nair", "Sunita Rao", "Karan Malhotra"]
            customer_name = random.choice(names)
            
            payload = {
                "order_id": order_id,
                "customer_name": customer_name,
                "items": order_items,
                "subtotal": subtotal,
                "cgst": round(gst / 2, 2),
                "sgst": round(gst / 2, 2),
                "delivery_charges": delivery_charges,
                "total": total,
                "discount_percentage": 0.0,
                "discount_amount": 0.0
            }
            
            try:
                data = json.dumps(payload).encode('utf-8')
                req = urllib.request.Request(
                    f"http://127.0.0.1:9990/orders/{platform}",
                    data=data,
                    headers={'Content-Type': 'application/json'}
                )
                with urllib.request.urlopen(req) as response:
                    res = json.loads(response.read().decode('utf-8'))
                    print("Simulation success:", res)
            except Exception as e:
                print("Simulation error:", e)
                
        threading.Thread(target=run_sim, daemon=True).start()

    # ─────────────────────────────────── INVENTORY TAB ─────────

    def _build_inventory_tab(self, parent):
        """Inventory management: section-wise stock tracking with low stock alerts."""
        # ── Top header with alert banner
        top = tk.Frame(parent, bg="#1A3D5C", padx=8, pady=5)
        top.pack(fill=tk.X)
        tk.Label(top, text=t("Inventory Manager", "Inventory Manager"), font=FONT_LARGE,
                 bg="#1A3D5C", fg="#AAD4FF").pack(side=tk.LEFT)
        self._inv_alert_lbl = tk.Label(top, text="", font=FONT_BOLD,
                                        bg="#1A3D5C", fg="#FF6666")
        self._inv_alert_lbl.pack(side=tk.RIGHT, padx=8)
        tk.Button(top, text="↺  Refresh", font=FONT_SMALL, relief=tk.FLAT,
                  bg="#004488", fg="white", padx=8, cursor="hand2",
                  command=self._load_inventory_tab).pack(side=tk.RIGHT, padx=4)

        # ── Summary bar
        summary = tk.Frame(parent, bg="#E8EEF4", pady=3)
        summary.pack(fill=tk.X)
        self._inv_summary_lbl = tk.Label(summary, text="", font=FONT_NORMAL,
                                          bg="#E8EEF4", fg=C["text"])
        self._inv_summary_lbl.pack(side=tk.LEFT, padx=8)

        # ── Main body: section sidebar + product grid
        body = tk.Frame(parent, bg=C["bg"])
        body.pack(fill=tk.BOTH, expand=True)

        # LEFT: section list
        left = tk.Frame(body, bg=C["sec_bg"], width=200)
        left.pack(side=tk.LEFT, fill=tk.Y)
        left.pack_propagate(False)

        tk.Label(left, text=t("SECTIONS", "SECTIONS"), bg=C["sec_bg"], fg="#88BBDD",
                 font=FONT_SMALL, pady=4).pack(fill=tk.X)

        sf = tk.Frame(left, bg=C["sec_bg"])
        sf.pack(fill=tk.BOTH, expand=True)
        sec_scr = tk.Scrollbar(sf, width=self.scrollbar_width)
        sec_scr.pack(side=tk.RIGHT, fill=tk.Y)
        self._inv_sec_lb = tk.Listbox(sf, yscrollcommand=sec_scr.set,
                                       bg="#0A1A2E", fg="#AADDFF",
                                       selectbackground="#1A5C8C",
                                       selectforeground="white",
                                       font=FONT_NORMAL, borderwidth=0,
                                       highlightthickness=0)
        self._inv_sec_lb.pack(fill=tk.BOTH, expand=True)
        sec_scr.config(command=self._inv_sec_lb.yview)
        self._inv_sec_lb.bind("<<ListboxSelect>>", self._on_inv_sec_select)

        # Init Stock button at bottom of section sidebar
        tk.Button(left, text="+ Init All Stock", font=FONT_SMALL,
                  bg="#004488", fg="white", relief=tk.FLAT,
                  padx=6, pady=4, cursor="hand2",
                  command=self._inv_init_section_stock).pack(fill=tk.X, padx=4, pady=4)

        # RIGHT: product inventory grid
        right = tk.Frame(body, bg=C["bg"])
        right.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        # Header for selected section
        hdr = tk.Frame(right, bg="#FFF2E0", pady=3)
        hdr.pack(fill=tk.X)
        self._inv_sec_lbl = tk.Label(hdr, text="Select a section →",
                                      bg="#FFF2E0", fg=C["header"], font=FONT_BOLD,
                                      anchor=tk.W, padx=8)
        self._inv_sec_lbl.pack(side=tk.LEFT)

        # Search bar for inventory
        search_frm = tk.Frame(right, bg=C["border"], pady=1)
        search_frm.pack(fill=tk.X)
        sfin = tk.Frame(search_frm, bg=C["item_bg"])
        sfin.pack(fill=tk.X)
        tk.Label(sfin, text="🔍", bg=C["item_bg"], font=("", 10)).pack(side=tk.LEFT, padx=4)
        self._inv_search_var = tk.StringVar()
        self._inv_search_var.trace_add("write", lambda *_: self._refresh_inv_items())
        tk.Entry(sfin, textvariable=self._inv_search_var, font=FONT_NORMAL,
                 relief=tk.FLAT, bg=C["item_bg"]).pack(side=tk.LEFT, fill=tk.X, expand=True, padx=4, pady=4)
        tk.Button(sfin, text="✕", font=FONT_SMALL, relief=tk.FLAT,
                  bg=C["item_bg"], cursor="hand2",
                  command=lambda: self._inv_search_var.set("")).pack(side=tk.RIGHT, padx=4)

        # Treeview for inventory items
        cols = ("code", "name", "stock", "threshold", "status")
        self._inv_tree = ttk.Treeview(right, columns=cols, show="headings", selectmode="browse")
        for col, w, hdr_text in [("code", 80, t("Code", "Code")),
                                  ("name", 220, t("Name", "Name")),
                                  ("stock", 100, t("Stock", "Stock")),
                                  ("threshold", 100, t("Threshold", "Threshold")),
                                  ("status", 120, t("Status", "Status"))]:
            self._inv_tree.heading(col, text=hdr_text)
            self._inv_tree.column(col, width=w,
                                       anchor=tk.W if col in ("name", "code") else tk.CENTER)
        inv_scr = ttk.Scrollbar(right, orient=tk.VERTICAL, command=self._inv_tree.yview)
        self._inv_tree.configure(yscrollcommand=inv_scr.set)
        self._inv_tree.pack(fill=tk.BOTH, expand=True, side=tk.LEFT)
        inv_scr.pack(side=tk.RIGHT, fill=tk.Y)

        # Action buttons at bottom
        btn_bar = tk.Frame(right, bg=C["bg"], pady=4)
        btn_bar.pack(fill=tk.X, side=tk.BOTTOM)
        for label, cmd, color in [
                ("+ Add Stock",     self._inv_add_stock,       "#004422"),
                ("- Reduce Stock",  self._inv_reduce_stock,    "#884400"),
                ("Set Stock",       self._inv_set_stock,       "#004488"),
                ("Set Threshold",   self._inv_set_threshold,   "#440088"),
                ("Init Stock",      self._inv_init_item_stock, "#006666")]:
            tk.Button(btn_bar, text=label, font=FONT_SMALL,
                      bg=color, fg="white", relief=tk.FLAT,
                      padx=8, pady=4, cursor="hand2",
                      command=cmd).pack(side=tk.LEFT, padx=3)

        self._inv_sec_ids = []
        self._inv_item_ids = []

    def _load_inventory_tab(self):
        """Load/refresh the inventory tab."""
        if not hasattr(self, '_inv_sec_lb'):
            return
        # Load sections
        secs = db.get_sections_db()
        self._inv_sec_ids = [s["id"] for s in secs]
        self._inv_sec_lb.delete(0, tk.END)
        for s in secs:
            self._inv_sec_lb.insert(tk.END, f"  {s['name']}")
        
        # Update low stock alert (product + packaging)
        low_items = db.get_low_stock_items()
        try:
            pkg_summary = db.get_packaging_stock_summary()
            pkg_out = pkg_summary.get("out_of_stock_count", 0)
            pkg_low = pkg_summary.get("low_stock_count", 0)
        except Exception:
            pkg_out, pkg_low = 0, 0

        alert_parts = []
        if low_items:
            alert_parts.append(f"⚠ {len(low_items)} Product Low Stock!")
        if pkg_out > 0:
            alert_parts.append(f"📦 {pkg_out} Packaging Out!")
        elif pkg_low > 0:
            alert_parts.append(f"📦 {pkg_low} Packaging Low")

        if alert_parts:
            self._inv_alert_lbl.config(text=" | ".join(alert_parts))
        else:
            self._inv_alert_lbl.config(text="✓ All Stock OK")
        
        # Update summary
        summary = db.get_stock_summary()
        self._inv_summary_lbl.config(
            text=f"Total: {summary['total_items']} | Tracked: {summary['tracked_items']} | "
                 f"Low Stock: {summary['low_stock_count']} | Out of Stock: {summary['out_of_stock_count']} | "
                 f"Untracked: {summary['untracked_count']}"
        )
        
        # Auto-select first section
        if secs:
            self._inv_sec_lb.selection_set(0)
            self._on_inv_sec_select()

    def _on_inv_sec_select(self, event=None):
        """When a section is selected in the inventory tab."""
        sel = self._inv_sec_lb.curselection()
        if not sel:
            return
        idx = sel[0]
        if idx >= len(self._inv_sec_ids):
            return
        sec_id = self._inv_sec_ids[idx]
        secs = db.get_sections_db()
        sec_name = secs[idx]["name"]
        self._inv_sec_lbl.config(text=f"  {t('Inventory for', 'Inventory for')}:  {sec_name}")
        self._inv_search_var.set("")
        self._refresh_inv_items(sec_id)

    def _refresh_inv_items(self, section_id=None):
        """Refresh the inventory item treeview."""
        if not hasattr(self, '_inv_tree'):
            return
        
        # If no section_id specified, try to get from selection
        if section_id is None:
            sel = self._inv_sec_lb.curselection()
            if sel and sel[0] < len(self._inv_sec_ids):
                section_id = self._inv_sec_ids[sel[0]]
            else:
                return
        
        for row in self._inv_tree.get_children():
            self._inv_tree.delete(row)
        
        search_term = self._inv_search_var.get().strip().lower() if hasattr(self, '_inv_search_var') else ""
        items = db.get_inventory(section_id)
        self._inv_item_ids = []
        
        for it in items:
            # Filter by search
            if search_term and search_term not in it['name'].lower() and search_term != (it.get('code') or '').lower():
                continue
            
            self._inv_item_ids.append(it["id"])
            stock_qty = it["stock_quantity"]
            threshold = it["low_stock_threshold"]
            
            # Status calculation
            if stock_qty == -1:
                status_text = "⚠ Not Tracked"
                status_color_tag = "untracked"
            elif stock_qty == 0:
                status_text = "✕ OUT OF STOCK"
                status_color_tag = "out"
            elif stock_qty <= threshold:
                status_text = "⚠ LOW STOCK"
                status_color_tag = "low"
            else:
                status_text = "✓ In Stock"
                status_color_tag = "ok"
            
            stock_display = str(stock_qty) if stock_qty >= 0 else "—"
            
            self._inv_tree.insert("", tk.END, iid=str(it["id"]), values=(
                it.get("code", ""), it["name"],
                stock_display, str(threshold),
                status_text
            ))
        
        # Color code the rows using tags
        self._inv_tree.tag_configure("untracked", foreground="#888888")
        self._inv_tree.tag_configure("out", foreground="#CC0000")
        self._inv_tree.tag_configure("low", foreground="#CC6600")
        self._inv_tree.tag_configure("ok", foreground="#006600")
        
        # Re-insert with tags for coloring
        for row in self._inv_tree.get_children():
            vals = self._inv_tree.item(row)["values"]
            status = vals[4]
            if "OUT" in str(status):
                tag = "out"
            elif "LOW" in str(status):
                tag = "low"
            elif "Not Tracked" in str(status):
                tag = "untracked"
            else:
                tag = "ok"
            self._inv_tree.item(row, tags=(tag,))

    def _selected_inv_item_id(self):
        """Get the selected inventory item id."""
        sel = self._inv_tree.selection()
        if not sel:
            return None, None
        item_id = int(sel[0])
        # Get name
        vals = self._inv_tree.item(sel[0])["values"]
        name = vals[1] if len(vals) > 1 else ""
        return item_id, name

    def _inv_add_stock(self):
        """Add stock to selected item."""
        item_id, name = self._selected_inv_item_id()
        if item_id is None:
            messagebox.showinfo("Select", "Select an item first.")
            return
        
        qty = simpledialog.askinteger("Add Stock",
                                       f"Add stock to: {name}\nEnter quantity to ADD:",
                                       parent=self.root, minvalue=1)
        if qty:
            db.adjust_stock(item_id, qty)
            self._refresh_inv_items()
            self._load_inventory_tab()

    def _inv_reduce_stock(self):
        """Reduce stock for selected item."""
        item_id, name = self._selected_inv_item_id()
        if item_id is None:
            messagebox.showinfo("Select", "Select an item first.")
            return
        
        qty = simpledialog.askinteger("Reduce Stock",
                                       f"Reduce stock for: {name}\nEnter quantity to REDUCE:",
                                       parent=self.root, minvalue=1)
        if qty:
            db.adjust_stock(item_id, -qty)
            self._refresh_inv_items()
            self._load_inventory_tab()

    def _inv_set_stock(self):
        """Set absolute stock quantity for selected item with a rich dialog."""
        item_id, name = self._selected_inv_item_id()
        if item_id is None:
            messagebox.showinfo("Select", "Select an item first.")
            return
        
        # Get current stock
        items = db.get_inventory()
        current_stock = -1
        current_threshold = 10
        for it in items:
            if it["id"] == item_id:
                current_stock = it["stock_quantity"]
                current_threshold = it.get("low_stock_threshold", 10)
                break

        win = tk.Toplevel(self.root)
        win.title(f"Set Stock: {name}")
        win.geometry("400x320")
        win.resizable(False, False)
        win.grab_set()
        win.configure(bg=C["bg"])
        win.transient(self.root)

        tk.Label(win, text=f"📦 {name}", font=FONT_BOLD, bg=C["bg"], fg=C["header"]).pack(pady=(10, 4))
        current_text = f"Current Stock: {current_stock}" if current_stock >= 0 else "Current Stock: Not tracked"
        tk.Label(win, text=current_text, font=FONT_NORMAL, bg=C["bg"], fg=C["text"]).pack(pady=4)

        qty_var = tk.StringVar(value=str(current_stock) if current_stock >= 0 else "50")
        v_untracked = tk.IntVar(value=1 if current_stock < 0 else 0)

        # Untracked checkbox
        chk_frm = tk.Frame(win, bg=C["bg"])
        chk_frm.pack(fill=tk.X, padx=16, pady=4)
        stock_widgets = []

        def toggle_track():
            if v_untracked.get():
                qty_var.set("-1")
                for w in stock_widgets:
                    w.config(state=tk.DISABLED)
            else:
                if qty_var.get() == "-1":
                    qty_var.set("50")
                for w in stock_widgets:
                    w.config(state=tk.NORMAL)

        tk.Checkbutton(chk_frm, text="Not tracked (unlimited)", variable=v_untracked,
                       bg=C["bg"], font=FONT_NORMAL, command=toggle_track).pack(anchor=tk.W)

        # Quantity input
        input_frm = tk.Frame(win, bg=C["bg"])
        input_frm.pack(fill=tk.X, padx=16, pady=4)
        tk.Label(input_frm, text="New Quantity:", bg=C["bg"], fg=C["text"], font=FONT_NORMAL).grid(row=0, column=0, sticky=tk.W)
        qty_entry = tk.Entry(input_frm, textvariable=qty_var, width=12, font=FONT_NORMAL)
        qty_entry.grid(row=0, column=1, padx=8)
        stock_widgets.append(qty_entry)

        # Quick preset buttons
        quick_frm = tk.Frame(win, bg=C["bg"])
        quick_frm.pack(fill=tk.X, padx=16, pady=6)
        tk.Label(quick_frm, text="Quick Set:", bg=C["bg"], fg=C["muted"], font=FONT_SMALL).pack(side=tk.LEFT)
        for val in [10, 25, 50, 100, 200]:
            b = tk.Button(quick_frm, text=str(val), font=FONT_SMALL,
                      bg="#E8EEF4", fg=C["text"], relief=tk.FLAT,
                      padx=8, pady=2, cursor="hand2",
                      command=lambda v=val: (qty_var.set(str(v)), v_untracked.set(0), toggle_track()))
            b.pack(side=tk.LEFT, padx=2)
            stock_widgets.append(b)

        # Quick add buttons
        add_frm = tk.Frame(win, bg=C["bg"])
        add_frm.pack(fill=tk.X, padx=16, pady=2)
        tk.Label(add_frm, text="Quick Add:", bg=C["bg"], fg=C["muted"], font=FONT_SMALL).pack(side=tk.LEFT)
        for delta in [5, 10, 25, 50]:
            b = tk.Button(add_frm, text=f"+{delta}", font=FONT_SMALL,
                      bg="#DFF5E3", fg="#2E7D32", relief=tk.FLAT,
                      padx=8, pady=2, cursor="hand2",
                      command=lambda d=delta: qty_var.set(str(max(0, int(qty_var.get() or 0)) + d)))
            b.pack(side=tk.LEFT, padx=2)
            stock_widgets.append(b)

        # Apply initial state
        toggle_track()

        def save():
            try:
                if v_untracked.get():
                    db.update_stock(item_id, -1)
                else:
                    q = int(qty_var.get())
                    if q < 0:
                        q = -1
                    db.update_stock(item_id, q)
            except ValueError:
                messagebox.showwarning("Invalid", "Enter a valid number.", parent=win)
                return
            win.destroy()
            self._refresh_inv_items()
            self._load_inventory_tab()

        btn_row = tk.Frame(win, bg=C["bg"])
        btn_row.pack(pady=10)
        tk.Button(btn_row, text="Save", font=FONT_BOLD,
                  bg=C["bill_btn"], fg="white", relief=tk.FLAT,
                  padx=20, pady=5, cursor="hand2", command=save).pack(side=tk.LEFT, padx=8)
        tk.Button(btn_row, text="Cancel", font=FONT_NORMAL,
                  bg="#CCCCCC", relief=tk.FLAT, padx=12, pady=5,
                  command=win.destroy).pack(side=tk.LEFT)
        win.bind("<Return>", lambda e: save())

    def _inv_set_threshold(self):
        """Set low stock threshold for selected item."""
        item_id, name = self._selected_inv_item_id()
        if item_id is None:
            messagebox.showinfo("Select", "Select an item first.")
            return
        
        # Get current threshold
        items = db.get_inventory()
        current_threshold = 10
        for it in items:
            if it["id"] == item_id:
                current_threshold = it["low_stock_threshold"]
                break
        
        threshold = simpledialog.askinteger("Set Threshold",
                                             f"Set low stock threshold for: {name}\nCurrent: {current_threshold}\nEnter new threshold:",
                                             parent=self.root, minvalue=0)
        if threshold is not None:
            db.set_low_stock_threshold(item_id, threshold)
            self._refresh_inv_items()
            self._load_inventory_tab()

    def _inv_init_item_stock(self):
        """Initialize stock for a single item (set quantity + threshold)."""
        item_id, name = self._selected_inv_item_id()
        if item_id is None:
            messagebox.showinfo("Select", "Select an item first.")
            return
        
        dlg = tk.Toplevel(self.root)
        dlg.title(f"Initialize Stock: {name}")
        dlg.geometry("350x200")
        dlg.resizable(False, False)
        dlg.grab_set()
        dlg.configure(bg=C["bg"])

        v_qty = tk.StringVar(value="50")
        v_threshold = tk.StringVar(value="10")

        tk.Label(dlg, text=f"Initialize Stock for: {name}",
                 font=FONT_BOLD, bg=C["bg"], fg=C["header"], pady=8).pack()

        frm = tk.Frame(dlg, bg=C["bg"]); frm.pack(padx=20)
        for label, var, width in [
                ("Initial Quantity", v_qty, 10),
                ("Low Stock Threshold", v_threshold, 10)]:
            row = tk.Frame(frm, bg=C["bg"]); row.pack(fill=tk.X, pady=4)
            tk.Label(row, text=label, width=20, anchor=tk.E,
                     bg=C["bg"], font=FONT_NORMAL).pack(side=tk.LEFT, padx=4)
            tk.Entry(row, textvariable=var, width=width,
                     font=FONT_NORMAL).pack(side=tk.LEFT)

        def save():
            try:
                qty = int(v_qty.get())
                threshold = int(v_threshold.get())
            except ValueError:
                messagebox.showwarning("Invalid", "Enter valid numbers.", parent=dlg)
                return
            db.init_stock_for_item(item_id, qty, threshold)
            dlg.destroy()
            self._refresh_inv_items()
            self._load_inventory_tab()

        btn_row = tk.Frame(dlg, bg=C["bg"]); btn_row.pack(pady=10)
        tk.Button(btn_row, text="Initialize", font=FONT_BOLD,
                  bg=C["bill_btn"], fg="white", relief=tk.FLAT,
                  padx=16, pady=4, cursor="hand2", command=save).pack(side=tk.LEFT, padx=6)
        tk.Button(btn_row, text="Cancel", font=FONT_NORMAL,
                  bg="#CCCCCC", relief=tk.FLAT, padx=12, pady=4,
                  command=dlg.destroy).pack(side=tk.LEFT)

    def _inv_init_section_stock(self):
        """Initialize stock for all untracked items in the selected section."""
        sel = self._inv_sec_lb.curselection()
        if not sel:
            messagebox.showinfo("Select", "Select a section first.")
            return
        idx = sel[0]
        if idx >= len(self._inv_sec_ids):
            return
        sec_id = self._inv_sec_ids[idx]
        secs = db.get_sections_db()
        sec_name = secs[idx]["name"]
        
        if not messagebox.askyesno("Init Section Stock",
                                    f"Initialize stock for all untracked items in '{sec_name}'?\n\n"
                                    f"Default: 50 units, Threshold: 10"):
            return
        
        db.init_stock_for_section(sec_id, default_quantity=50, default_threshold=10)
        self._refresh_inv_items(sec_id)
        self._load_inventory_tab()

    # ─────────────────────────────────── AGGREGATORS TAB ─────────

    def _build_aggregators_tab(self, parent):
        top = tk.Frame(parent, bg="#5A1A8A", padx=8, pady=4)
        top.pack(fill=tk.X)
        tk.Label(top, text="Aggregator Integration (Swiggy / Zomato)", font=FONT_LARGE,
                 bg="#5A1A8A", fg="#FFDDFF").pack(side=tk.LEFT)
                 
        body = tk.Frame(parent, bg=C["bg"])
        body.pack(fill=tk.BOTH, expand=True, padx=16, pady=16)
        
        # Left Panel: Status & Simulation
        left = tk.Frame(body, bg=C["bg"], width=self.aggregators_left_width)
        left.pack(side=tk.LEFT, fill=tk.BOTH, padx=(0, 16))
        left.pack_propagate(False)
        
        # Status Card
        status_box = tk.LabelFrame(left, text="Integration Status", font=FONT_BOLD,
                                   bg=C["item_bg"], fg=C["text"], padx=12, pady=12)
        status_box.pack(fill=tk.X, pady=(0, 16))
        
        is_p = CFG.get("is_primary", True)
        status_text = "● Integration Server Active (Port 9990)" if is_p else "○ Disabled on Secondary POS Terminal"
        status_color = "green" if is_p else "gray"
        self._agg_status_lbl = tk.Label(status_box, text=status_text,
                                        font=FONT_NORMAL, bg=C["item_bg"], fg=status_color)
        self._agg_status_lbl.pack(anchor="w", pady=4)
        
        if is_p:
            tk.Label(status_box, text="Endpoints:\n- POST http://127.0.0.1:9990/orders/swiggy\n- POST http://127.0.0.1:9990/orders/zomato",
                     font=FONT_MONO, bg=C["item_bg"], fg=C["muted"], justify=tk.LEFT).pack(anchor="w", pady=4)
                 
        # Simulation Card (Only enable simulation if primary POS)
        sim_box = tk.LabelFrame(left, text="Simulator", font=FONT_BOLD,
                                bg=C["item_bg"], fg=C["text"], padx=12, pady=12)
        sim_box.pack(fill=tk.X)
        
        if is_p:
            tk.Label(sim_box, text="Click below to simulate incoming aggregator webhook requests:",
                     font=FONT_SMALL, bg=C["item_bg"], fg=C["muted"], wrap=350, justify=tk.LEFT).pack(anchor="w", pady=(0, 10))
                     
            tk.Button(sim_box, text="🛵 Simulate Swiggy Order", font=FONT_BOLD,
                      bg="#FF6B00", fg="white", relief=tk.FLAT, cursor="hand2", padx=10, pady=8,
                      command=lambda: self._simulate_aggregator_order("swiggy")
                      ).pack(fill=tk.X, pady=4)
                      
            tk.Button(sim_box, text="🍕 Simulate Zomato Order", font=FONT_BOLD,
                      bg="#CB202D", fg="white", relief=tk.FLAT, cursor="hand2", padx=10, pady=8,
                      command=lambda: self._simulate_aggregator_order("zomato")
                      ).pack(fill=tk.X, pady=4)
        else:
            tk.Label(sim_box, text="Order simulation is only available on the Primary POS Terminal.",
                     font=FONT_SMALL, bg=C["item_bg"], fg=C["muted"], wrap=350, justify=tk.LEFT).pack(anchor="w")
                  
        # Right Panel: Recent Aggregator Orders Table
        right = tk.Frame(body, bg=C["bg"])
        right.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        tk.Label(right, text="Recent Aggregator Orders", font=FONT_LARGE,
                 bg=C["bg"], fg=C["text"]).pack(anchor="w", pady=(0, 6))
                 
        cols = ("id", "platform", "customer", "items", "total")
        self._agg_tree = ttk.Treeview(right, columns=cols, show="headings", selectmode="browse", height=15)
        self._agg_tree.heading("id", text="Order ID")
        self._agg_tree.heading("platform", text="Platform")
        self._agg_tree.heading("customer", text="Customer")
        self._agg_tree.heading("items", text="Items Summary")
        self._agg_tree.heading("total", text="Total (₹)")
        
        self._agg_tree.column("id", width=100, anchor=tk.CENTER)
        self._agg_tree.column("platform", width=100, anchor=tk.CENTER)
        self._agg_tree.column("customer", width=150, anchor=tk.W)
        self._agg_tree.column("items", width=250, anchor=tk.W)
        self._agg_tree.column("total", width=100, anchor=tk.E)
        
        scr = ttk.Scrollbar(right, orient=tk.VERTICAL, command=self._agg_tree.yview)
        self._agg_tree.configure(yscrollcommand=scr.set)
        
        self._agg_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scr.pack(side=tk.RIGHT, fill=tk.Y)

    def _load_aggregators(self):
        for row in self._agg_tree.get_children():
            self._agg_tree.delete(row)
            
        bills = db.get_bills(limit=100)
        agg_bills = [b for b in bills if b['payment_mode'] in ('swiggy', 'zomato', 'online')]
        
        for b in agg_bills:
            items_summary = ", ".join(f"{it['item_name']} x{it['quantity']}" for it in b['items'])
            platform = b['payment_mode'].upper()
            
            order_id = f"#{b['bill_no']:04d}"
            notes = b.get('notes', '')
            if "Order #" in notes:
                try:
                    order_id = notes.split("Order #")[1].split(" ")[0]
                except Exception:
                    pass
                    
            self._agg_tree.insert("", tk.END, values=(
                order_id,
                platform,
                b['customer_name'].replace(f"[{platform}]", "").strip(),
                items_summary,
                f"{b['total']:.2f}"
            ))

    def _prompt_resolution_selection(self):
        """Prompt user to select standard or compact resolution profile on first launch."""
        dlg = tk.Toplevel(self.root)
        dlg.title("Select Screen Resolution Profile")
        dlg.geometry("450x260")
        dlg.resizable(False, False)
        dlg.grab_set()
        dlg.configure(bg=C["bg"])
        
        sw = dlg.winfo_screenwidth()
        sh = dlg.winfo_screenheight()
        dlg.geometry(f"450x260+{(sw-450)//2}+{(sh-260)//2}")
        
        tk.Label(dlg, text="Optimize UI Layout Profile",
                 font=("Segoe UI", 14, "bold"), bg=C["bg"], fg=C["header"], pady=12).pack()
                 
        tk.Label(dlg, text="Select the layout size that fits this screen resolution.\nThis setting can be changed anytime in Settings.",
                 font=FONT_NORMAL, bg=C["bg"], fg=C["text"], justify=tk.CENTER).pack(pady=(0, 15))
                 
        selection = tk.StringVar(value="auto")
        
        frm = tk.Frame(dlg, bg=C["bg"])
        frm.pack(pady=10)
        
        def select_mode(mode):
            selection.set(mode)
            CFG["ui_scale"] = mode
            CFG["ui_scale_chosen"] = True
            from config import save as save_config
            save_config(CFG)
            dlg.destroy()
            
        tk.Button(frm, text="🖥️ Standard Layout\n(1920x1080 or larger)", font=FONT_BOLD,
                  bg=C["header"], fg="white", relief=tk.FLAT, padx=12, pady=8, cursor="hand2",
                  command=lambda: select_mode("standard")).pack(side=tk.LEFT, padx=6)
                  
        tk.Button(frm, text="📱 Compact Layout\n(1024x768 / Tablets)", font=FONT_BOLD,
                  bg="#3A1800", fg="white", relief=tk.FLAT, padx=12, pady=8, cursor="hand2",
                  command=lambda: select_mode("compact")).pack(side=tk.LEFT, padx=6)
                  
        tk.Button(dlg, text="Use Auto-Detection (Recommended)", font=FONT_NORMAL,
                  bg="#CCCCCC", fg=C["text"], relief=tk.FLAT, padx=15, pady=4, cursor="hand2",
                  command=lambda: select_mode("auto")).pack(pady=10)
                  
        self.root.wait_window(dlg)

    def _toggle_customer_display(self):
        """Toggle the Customer Facing Display secondary window."""
        if hasattr(self, "customer_window") and self.customer_window and tk.Toplevel.winfo_exists(self.customer_window):
            self.customer_window.destroy()
            self.customer_window = None
            self._btn_cfd.config(bg="#5A1A8A", text="📺 Customer Display")
        else:
            self.customer_window = tk.Toplevel(self.root)
            self.customer_window.title("Mini Centrino Lite — Customer Display")
            self.customer_window.configure(bg="#1A0A00")
            self.customer_window.geometry("800x600")
            self.customer_window.minsize(600, 450)
            self.customer_window.protocol("WM_DELETE_WINDOW", self._on_customer_window_close)
            self._btn_cfd.config(bg="#AA2020", text="✕ Close Customer Display")
            self._build_customer_display_ui()
            self._update_customer_display()

    def _on_customer_window_close(self):
        if hasattr(self, "customer_window") and self.customer_window:
            try:
                self.customer_window.destroy()
            except Exception:
                pass
        self.customer_window = None
        self._btn_cfd.config(bg="#5A1A8A", text="📺 Customer Display")

    def _build_customer_display_ui(self):
        win = self.customer_window
        
        # Left Panel: Brand / Promo
        left_frm = tk.Frame(win, bg="#1A0A00", padx=20, pady=20)
        left_frm.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        tk.Label(left_frm, text=CFG.get("restaurant_name", "SUDHAMRIT FOOD JOINT"),
                 font=("Segoe UI", 20, "bold"), bg="#1A0A00", fg="#FFD700").pack(anchor=tk.W, pady=(20, 10))
        
        tk.Label(left_frm, text=CFG.get("tagline", "Pure Sattvik Vegetarian | No Onion | No Garlic"),
                 font=("Segoe UI", 12, "italic"), bg="#1A0A00", fg="#AAAA66",
                 wraplength=350, justify=tk.LEFT).pack(anchor=tk.W, pady=(0, 40))
                 
        promo_frm = tk.Frame(left_frm, bg="#2A1405", bd=1, relief=tk.SOLID, padx=15, pady=15)
        promo_frm.pack(fill=tk.X, pady=(20, 0))
        
        tk.Label(promo_frm, text="Welcome! 🙏", font=("Segoe UI", 16, "bold"),
                 bg="#2A1405", fg="#FFF").pack(anchor=tk.W)
        tk.Label(promo_frm, text="We serve 100% Sattvik vegetarian food prepared with pure ingredients.\nNo Onion. No Garlic.",
                 font=("Segoe UI", 10), bg="#2A1405", fg="#DDBBAA",
                 wraplength=320, justify=tk.LEFT).pack(anchor=tk.W, pady=(10, 0))

        # Right Panel: Order Summary
        right_frm = tk.Frame(win, bg="#FFF8F2", width=380, padx=15, pady=15)
        right_frm.pack(side=tk.RIGHT, fill=tk.Y)
        right_frm.pack_propagate(False)
        
        tk.Label(right_frm, text="Current Order", font=("Segoe UI", 14, "bold"),
                 bg="#FFF8F2", fg="#6B2E00").pack(anchor=tk.W, pady=(0, 10))
                 
        self.cfd_cart_canvas = tk.Canvas(right_frm, bg="#FFF8F2", highlightthickness=0)
        self.cfd_cart_frame = tk.Frame(self.cfd_cart_canvas, bg="#FFF8F2")
        self.cfd_cart_scr = ttk.Scrollbar(right_frm, orient=tk.VERTICAL, command=self.cfd_cart_canvas.yview)
        
        self.cfd_cart_canvas.configure(yscrollcommand=self.cfd_cart_scr.set)
        self.cfd_cart_scr.pack(side=tk.RIGHT, fill=tk.Y)
        self.cfd_cart_canvas.pack(side=tk.TOP, fill=tk.BOTH, expand=True)
        
        self.cfd_cart_canvas_win = self.cfd_cart_canvas.create_window((0,0), window=self.cfd_cart_frame, anchor=tk.NW)
        
        self.cfd_cart_frame.bind("<Configure>", lambda e: self.cfd_cart_canvas.configure(scrollregion=self.cfd_cart_canvas.bbox("all")))
        self.cfd_cart_canvas.bind("<Configure>", lambda e: self.cfd_cart_canvas.itemconfig(self.cfd_cart_canvas_win, width=e.width))

        tot_frm = tk.Frame(right_frm, bg="#FFF8F2", bd=0)
        tot_frm.pack(side=tk.BOTTOM, fill=tk.X, pady=(10, 0))
        
        self.cfd_lbl_sub = tk.Label(tot_frm, text="Subtotal: ₹0.00", font=("Segoe UI", 10), bg="#FFF8F2", fg="#555", anchor=tk.E)
        self.cfd_lbl_sub.pack(fill=tk.X, pady=1)
        self.cfd_lbl_disc = tk.Label(tot_frm, text="Discount: -₹0.00", font=("Segoe UI", 10), bg="#FFF8F2", fg="#A33", anchor=tk.E)
        self.cfd_lbl_disc.pack(fill=tk.X, pady=1)
        self.cfd_lbl_gst = tk.Label(tot_frm, text="GST: ₹0.00", font=("Segoe UI", 10), bg="#FFF8F2", fg="#555", anchor=tk.E)
        self.cfd_lbl_gst.pack(fill=tk.X, pady=1)
        self.cfd_lbl_delivery = tk.Label(tot_frm, text="Delivery Charges: ₹0.00", font=("Segoe UI", 10), bg="#FFF8F2", fg="#555", anchor=tk.E)
        self.cfd_lbl_delivery.pack(fill=tk.X, pady=1)
        self.cfd_lbl_total = tk.Label(tot_frm, text="Total: ₹0.00", font=("Segoe UI", 16, "bold"), bg="#FFF8F2", fg="#6B2E00", anchor=tk.E)
        self.cfd_lbl_total.pack(fill=tk.X, pady=(5, 5))

    def _update_customer_display(self):
        if not hasattr(self, "customer_window") or not self.customer_window or not tk.Toplevel.winfo_exists(self.customer_window):
            return
            
        for w in self.cfd_cart_frame.winfo_children():
            w.destroy()
            
        if not self.cart:
            tk.Label(self.cfd_cart_frame, text="Ready to serve you! 🙏", font=("Segoe UI", 11, "italic"),
                     bg="#FFF8F2", fg="#888", pady=40).pack(fill=tk.X)
        else:
            for item in self.cart:
                row = tk.Frame(self.cfd_cart_frame, bg="#FFF8F2", pady=4)
                row.pack(fill=tk.X)
                
                tk.Label(row, text=f"{item['name'][:30]} x {item['qty']}", font=("Segoe UI", 10, "bold"),
                         bg="#FFF8F2", fg="#2C1500", anchor=tk.W).pack(side=tk.LEFT, fill=tk.X, expand=True)
                         
                tk.Label(row, text=f"₹{item['total']:.2f}", font=("Segoe UI", 10),
                         bg="#FFF8F2", fg="#2C1500", anchor=tk.E).pack(side=tk.RIGHT)

        sub = sum(c['total'] for c in self.cart)
        
        try:
            disc_pct = float(self.discount_pct.get() or "0")
        except ValueError:
            disc_pct = 0.0
            
        try:
            disc_flat = float(self.discount_flat.get() or "0")
        except ValueError:
            disc_flat = 0.0
            
        try:
            del_chg = float(self.delivery_charges.get() or "0")
        except ValueError:
            del_chg = 0.0
            
        discount_amount = round(sub * (disc_pct / 100.0) + disc_flat, 2)
        discount_amount = min(discount_amount, sub)
        taxable_value = max(0.0, sub - discount_amount)
        
        gst_rate = CFG.get("gst_rate", 5)
        gst = round(taxable_value * gst_rate / 100, 2)
        total = round(taxable_value + gst + del_chg, 2)
        
        self.cfd_lbl_sub.config(text=f"Subtotal: ₹{sub:.2f}")
        pct_lbl = f" ({disc_pct}%)" if disc_pct > 0 else ""
        self.cfd_lbl_disc.config(text=f"Discount{pct_lbl}: -₹{discount_amount:.2f}")
        self.cfd_lbl_gst.config(text=f"GST ({gst_rate}%): ₹{gst:.2f}")
        self.cfd_lbl_delivery.config(text=f"Delivery Charges: ₹{del_chg:.2f}")
        self.cfd_lbl_total.config(text=f"TOTAL TO PAY: ₹{total:.2f}")

# ═══════════════════════════════════════════════════════════════
#  Pine Labs Payment Dialog
#  Modal window shown while the customer pays on the EDC terminal.
# ═══════════════════════════════════════════════════════════════

class PineLabsPaymentDialog:
    """
    Blocking modal dialog that:
      1. Launches an AsyncSale in a background thread.
      2. Shows animated "Waiting for customer…" feedback.
      3. On completion sets self.result / self.error and closes.

    Usage:
        dlg = PineLabsPaymentDialog(root, amount=210.00, invoice_ref="MCL001")
        if dlg.result and dlg.result["approved"]:
            ...
    """

    # Colours for this dark payment UI
    _BG    = "#0D0D1A"
    _CARD  = "#141428"
    _GOLD  = "#FFD700"
    _GREEN = "#00DD88"
    _RED   = "#FF4455"
    _TEXT  = "#E0E0FF"
    _MUTED = "#666688"

    def __init__(self, parent: tk.Tk, amount: float, invoice_ref: str):
        self.result = None
        self.error  = None
        self._async : pl_edc.AsyncSale | None = None
        self._cancelled = False

        # Build dialog
        self._dlg = tk.Toplevel(parent)
        self._dlg.title("Pine Labs — Payment")
        self._dlg.geometry("440x360")
        self._dlg.resizable(False, False)
        self._dlg.configure(bg=self._BG)
        self._dlg.grab_set()
        self._dlg.protocol("WM_DELETE_WINDOW", self._cancel)

        self._build(amount, invoice_ref)
        self._start_payment(amount, invoice_ref)

        # Wait until dialog closes (blocking)
        parent.wait_window(self._dlg)

    def _build(self, amount: float, invoice_ref: str):
        dlg = self._dlg
        bg  = self._BG

        tk.Label(dlg, text="PINE LABS  EDC", font=("Segoe UI", 11, "bold"),
                 bg=bg, fg=self._GOLD).pack(pady=(14, 2))
        tk.Label(dlg, text="Present card or scan QR on the terminal",
                 font=("Segoe UI", 9), bg=bg, fg=self._MUTED).pack()

        # Amount display
        amt_frame = tk.Frame(dlg, bg=self._CARD, pady=18)
        amt_frame.pack(fill=tk.X, padx=30, pady=10)
        tk.Label(amt_frame, text="AMOUNT TO PAY",
                 font=("Segoe UI", 9), bg=self._CARD, fg=self._MUTED).pack()
        tk.Label(amt_frame, text=f"₹ {amount:,.2f}",
                 font=("Segoe UI", 28, "bold"),
                 bg=self._CARD, fg=self._GOLD).pack()
        tk.Label(amt_frame, text=f"Ref: {invoice_ref}",
                 font=("Courier New", 8), bg=self._CARD, fg=self._MUTED).pack()

        # Status label
        self._status_var = tk.StringVar(value="Connecting to terminal…")
        self._status_lbl = tk.Label(dlg, textvariable=self._status_var,
                                     font=("Segoe UI", 11), bg=bg, fg=self._TEXT,
                                     wraplength=380, justify=tk.CENTER)
        self._status_lbl.pack(pady=6)

        # Spinner dots
        self._spinner_var = tk.StringVar(value="")
        tk.Label(dlg, textvariable=self._spinner_var,
                 font=("Courier New", 14), bg=bg, fg=self._GOLD).pack()

        # Result icon (hidden until done)
        self._result_lbl = tk.Label(dlg, text="", font=("Segoe UI", 32),
                                     bg=bg)
        self._result_lbl.pack(pady=4)

        # Cancel button
        self._cancel_btn = tk.Button(dlg, text="Cancel",
                                      font=FONT_NORMAL, bg="#2A2A44",
                                      fg=self._MUTED, relief=tk.FLAT,
                                      padx=20, pady=6, cursor="hand2",
                                      command=self._cancel)
        self._cancel_btn.pack(pady=6)

        self._spin_step = 0
        self._spinning  = True
        self._spin()

    def _spin(self):
        if not self._spinning:
            return
        frames = ["●○○○", "○●○○", "○○●○", "○○○●", "○○●○", "○●○○"]
        self._spinner_var.set(frames[self._spin_step % len(frames)])
        self._spin_step += 1
        self._dlg.after(200, self._spin)

    def _start_payment(self, amount: float, invoice_ref: str):
        self._async = pl_edc.AsyncSale(
            amount_rupees = amount,
            invoice_no    = invoice_ref,
            store_id      = str(CFG.get("pl_store_id", "")),
            terminal_sn   = str(CFG.get("pl_terminal_sn", "")),
            ip            = str(CFG.get("pl_edc_ip", "")),
            port          = int(CFG.get("pl_edc_port", 4002)),
            timeout       = int(CFG.get("pl_timeout", 120)),
        )
        self._async.start()
        self._status_var.set("Waiting for customer…\nAsk the customer to tap / swipe / insert card or scan QR on the EDC terminal.")
        self._poll()

    def _poll(self):
        """Check async result every 300 ms."""
        if self._cancelled:
            return
        if self._async and self._async.is_done:
            result, err = self._async.get_result()
            self._spinning = False
            self._spinner_var.set("")
            self._cancel_btn.config(state=tk.DISABLED)
            if err:
                self.error = err
                self._show_result(False, "Payment Failed", err[:120])
            elif result:
                self.result = result
                if result["approved"]:
                    self._show_result(
                        True,
                        "Payment Approved ✓",
                        f"{result.get('card_scheme','Card')}  ••••  "
                        f"{result.get('masked_card','')[-4:] if result.get('masked_card') else ''}\n"
                        f"Approval: {result.get('approval_code','')}"
                    )
                else:
                    self._show_result(
                        False,
                        "Payment Declined",
                        result.get("message", "Transaction declined")
                    )
        else:
            self._dlg.after(300, self._poll)

    def _show_result(self, approved: bool, title: str, detail: str):
        color = self._GREEN if approved else self._RED
        icon  = "✔" if approved else "✘"
        self._status_var.set(title)
        self._status_lbl.config(fg=color)
        self._result_lbl.config(text=icon, fg=color)
        # Auto-close after 2 s on approval; keep open on decline so user reads it
        delay = 2000 if approved else 4000
        self._dlg.after(delay, self._dlg.destroy)

    def _cancel(self):
        self._cancelled = True
        self._spinning  = False
        # Note: we cannot forcibly abort the TCP connection, but
        # the background thread will time out naturally.
        # We just close the dialog and let the thread finish silently.
        self.result = None
        self.error  = None
        try:
            self._dlg.destroy()
        except Exception:
            pass


class CheckoutAssistanceDialog:
    """
    Onscreen assistance to determine change and manage split/part payments.
    """
    def __init__(self, parent, total_amount, terminal_ip, pl_enabled, default_mode, on_complete, customer_name="", notes=""):
        self.parent = parent
        self.total_amount = total_amount
        self.terminal_ip = terminal_ip
        self.pl_enabled = pl_enabled
        self.on_complete = on_complete
        self.customer_name = customer_name
        self.notes = notes

        # Track active input field for numeric keypad
        self.active_entry = None
        self.selected_mode = default_mode  # cash, card, upi, other, split

        # Form variables
        self.cash_received_var = tk.StringVar(value=f"{total_amount:.2f}")
        self.card_split_var = tk.StringVar(value="0")
        self.upi_split_var = tk.StringVar(value="0")
        self.other_split_var = tk.StringVar(value="0")

        # Create window
        self.dlg = tk.Toplevel(parent)
        self.dlg.title(t("Checkout Assistance", "Checkout Assistance"))
        self.dlg.geometry("780x580")
        self.dlg.configure(bg=C["bg"])
        self.dlg.resizable(False, False)
        self.dlg.grab_set()
        self.dlg.transient(parent)
        
        # Center the modal window on the parent window
        try:
            self.dlg.update_idletasks()
            pw = parent.winfo_width()
            ph = parent.winfo_height()
            px = parent.winfo_x()
            py = parent.winfo_y()
            w = 780
            h = 580
            x = px + (pw - w) // 2
            y = py + (ph - h) // 2
            self.dlg.geometry(f"{w}x{h}+{x}+{y}")
        except Exception:
            pass

        # Build UI layout
        self._build_ui()

        # Variable traces for dynamic calculations and split auto-fill
        self._updating_splits = False
        self.cash_received_var.trace_add("write", lambda *args: self._on_var_changed("cash"))
        self.card_split_var.trace_add("write", lambda *args: self._on_var_changed("card"))
        self.upi_split_var.trace_add("write", lambda *args: self._on_var_changed("upi"))
        self.other_split_var.trace_add("write", lambda *args: self._on_var_changed("other"))


        # Select initial mode and set initial focus/values
        self._select_mode(self.selected_mode)

        # Do initial calculations
        self._update_calculations()

        # Wait on this dialog (blocking)
        parent.wait_window(self.dlg)

    def _build_ui(self):
        # 1. Header Frame
        hdr_frame = tk.Frame(self.dlg, bg=C["header"], pady=12)
        hdr_frame.pack(fill=tk.X)
        
        tk.Label(
            hdr_frame, 
            text=t("Checkout Assistance", "Checkout Assistance").upper(), 
            font=("Segoe UI", 14, "bold"), 
            bg=C["header"], 
            fg=C["header_fg"]
        ).pack(side=tk.LEFT, padx=16)
        
        # Display Total Bill Amount
        tk.Label(
            hdr_frame, 
            text=f"{t('Total', 'Total')}: ₹{self.total_amount:.2f}", 
            font=("Segoe UI", 16, "bold"), 
            bg=C["header"], 
            fg="#FFD9A8"
        ).pack(side=tk.RIGHT, padx=16)
        
        # Info strip (Customer Name & Notes)
        if self.customer_name or self.notes:
            info_frm = tk.Frame(self.dlg, bg="#2A2A2A", pady=6)
            info_frm.pack(fill=tk.X)
            
            info_parts = []
            if self.customer_name:
                info_parts.append(f"{t('Customer', 'Customer')}: {self.customer_name}")
            if self.notes:
                info_parts.append(f"{t('Customer Note:', 'Customer Note:')} {self.notes}")
                
            info_text = "   |   ".join(info_parts)
            tk.Label(
                info_frm, 
                text=info_text, 
                font=("Segoe UI", 10, "bold"), 
                bg="#2A2A2A", 
                fg="#FFCC33",
                wraplength=760,
                justify=tk.LEFT
            ).pack(anchor=tk.W, padx=16)
        
        # 2. Main Work Area (Columns)
        main_work = tk.Frame(self.dlg, bg=C["bg"])
        main_work.pack(fill=tk.BOTH, expand=True, padx=12, pady=12)
        
        # LEFT COLUMN: Mode Selector
        self.left_col = tk.Frame(main_work, bg=C["bg"], width=160)
        self.left_col.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 6))
        self.left_col.pack_propagate(False)
        
        # MIDDLE COLUMN: Inputs & Dynamic Calculator
        self.mid_col = tk.Frame(main_work, bg=C["bg"], width=360)
        self.mid_col.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=6)
        self.mid_col.pack_propagate(False)
        
        # RIGHT COLUMN: Numeric Keypad
        self.right_col = tk.Frame(main_work, bg=C["bg"], width=230)
        self.right_col.pack(side=tk.LEFT, fill=tk.Y, padx=(6, 0))
        self.right_col.pack_propagate(False)
        
        # 3. Mode Selection Buttons
        self.mode_btns = {}
        modes = [
            ("cash", t("Cash", "Cash")),
            ("card", t("Card", "Card")),
            ("upi", t("UPI", "UPI")),
            ("other", t("Other", "Other")),
            ("split", t("Split Payment", "Split"))
        ]
        
        for m_id, m_lbl in modes:
            btn = tk.Button(
                self.left_col, 
                text=m_lbl, 
                font=("Segoe UI", 11, "bold"), 
                relief=tk.FLAT, 
                pady=12, 
                cursor="hand2"
            )
            btn.config(command=lambda m=m_id: self._select_mode(m))
            btn.pack(fill=tk.X, pady=3)
            self.mode_btns[m_id] = btn
            
        # 4. Populate Middle Dynamic Panels
        # Cash Panel
        self.cash_panel = tk.Frame(self.mid_col, bg=C["bg"])
        
        tk.Label(
            self.cash_panel, 
            text=t("Cash Received", "Cash Received"), 
            font=("Segoe UI", 11, "bold"), 
            bg=C["bg"], 
            fg=C["text"]
        ).pack(anchor=tk.W, pady=(8, 2))
        
        self.cash_received_entry = tk.Entry(
            self.cash_panel, 
            textvariable=self.cash_received_var, 
            font=("Segoe UI", 16, "bold"), 
            justify=tk.RIGHT, 
            bg="white", 
            relief=tk.SOLID, 
            bd=1,
            highlightthickness=1,
            highlightbackground=C["border"]
        )
        self.cash_received_entry.pack(fill=tk.X, ipady=4, pady=(0, 10))
        self.cash_received_entry.bind("<FocusIn>", lambda e: self._set_active_entry(self.cash_received_entry))
        self.cash_received_entry.bind("<Button-1>", lambda e: self._set_active_entry(self.cash_received_entry))
        
        # Quick Cash helper buttons
        qc_lbl = tk.Label(
            self.cash_panel, 
            text=t("Quick Cash", "Quick Cash").upper(), 
            font=("Segoe UI", 9, "bold"), 
            bg=C["bg"], 
            fg=C["muted"]
        )
        qc_lbl.pack(anchor=tk.W, pady=(4, 2))
        
        self.qc_grid_frame = tk.Frame(self.cash_panel, bg=C["bg"])
        self.qc_grid_frame.pack(fill=tk.X, pady=(0, 12))
        self._build_quick_cash_buttons()
        
        # Dynamic Change Display Frame
        self.change_box = tk.Frame(self.cash_panel, relief=tk.SOLID, bd=1, pady=16)
        self.change_box.pack(fill=tk.X, pady=10)
        
        self.change_title_lbl = tk.Label(
            self.change_box, 
            text=t("Change to Return", "Change to Return"), 
            font=("Segoe UI", 10, "bold")
        )
        self.change_title_lbl.pack()
        
        self.change_val_lbl = tk.Label(
            self.change_box, 
            text="₹0.00", 
            font=("Segoe UI", 24, "bold")
        )
        self.change_val_lbl.pack()
        
        # Split Panel
        self.split_panel = tk.Frame(self.mid_col, bg=C["bg"])
        
        # Inputs for splits
        split_fields = [
            ("card", t("Card Split", "Card Split"), self.card_split_var),
            ("upi", t("UPI Split", "UPI Split"), self.upi_split_var),
            ("other", t("Other Split", "Other Split"), self.other_split_var),
            ("cash", t("Cash Received", "Cash Received"), self.cash_received_var)
        ]
        
        self.split_entries = {}
        for s_id, s_lbl, s_var in split_fields:
            lbl_frm = tk.Frame(self.split_panel, bg=C["bg"])
            lbl_frm.pack(fill=tk.X, pady=(4, 0))
            
            tk.Label(
                lbl_frm, 
                text=s_lbl, 
                font=("Segoe UI", 9, "bold"), 
                bg=C["bg"], 
                fg=C["text"]
            ).pack(side=tk.LEFT)
            
            entry = tk.Entry(
                self.split_panel, 
                textvariable=s_var, 
                font=("Segoe UI", 12, "bold"), 
                justify=tk.RIGHT, 
                bg="white", 
                relief=tk.SOLID, 
                bd=1,
                highlightthickness=1,
                highlightbackground=C["border"]
            )
            entry.pack(fill=tk.X, ipady=3, pady=(0, 6))
            entry.bind("<FocusIn>", lambda e, ent=entry: self._set_active_entry(ent))
            entry.bind("<Button-1>", lambda e, ent=entry: self._set_active_entry(ent))
            self.split_entries[s_id] = entry
            
        self.cash_received_entry_split = self.split_entries["cash"]
        self.card_split_entry = self.split_entries["card"]
        self.upi_split_entry = self.split_entries["upi"]
        self.other_split_entry = self.split_entries["other"]
        
        # Split Calculations Display Box
        self.split_calc_box = tk.Frame(self.split_panel, relief=tk.SOLID, bd=1, pady=10, bg="#FFF8F0")
        self.split_calc_box.pack(fill=tk.X, pady=8)
        
        self.split_total_lbl = tk.Label(
            self.split_calc_box, 
            text="Total Entered: ₹0.00", 
            font=("Segoe UI", 10, "bold"), 
            bg="#FFF8F0", 
            fg=C["text"]
        )
        self.split_total_lbl.pack()
        
        self.split_status_lbl = tk.Label(
            self.split_calc_box, 
            text="Remaining: ₹0.00", 
            font=("Segoe UI", 13, "bold"), 
            bg="#FFF8F0"
        )
        self.split_status_lbl.pack()
        
        # Generic Electronic Modes Panel
        self.generic_panel = tk.Frame(self.mid_col, bg=C["bg"])
        self.generic_lbl = tk.Label(
            self.generic_panel, 
            text="", 
            font=("Segoe UI", 12), 
            bg=C["bg"], 
            fg=C["text"], 
            justify=tk.CENTER, 
            wraplength=320
        )
        self.generic_lbl.pack(pady=40, fill=tk.BOTH, expand=True)
        
        # 5. Populate Keypad Column
        tk.Label(
            self.right_col, 
            text=t("Keypad", "Keypad").upper(), 
            font=("Segoe UI", 9, "bold"), 
            bg=C["bg"], 
            fg=C["muted"]
        ).pack(anchor=tk.W, pady=(8, 2))
        
        keypad_grid = tk.Frame(self.right_col, bg=C["bg"])
        keypad_grid.pack(fill=tk.BOTH, expand=True)
        
        # Define Keypad Buttons Layout
        keys = [
            ("7", 0, 0), ("8", 0, 1), ("9", 0, 2),
            ("4", 1, 0), ("5", 1, 1), ("6", 1, 2),
            ("1", 2, 0), ("2", 2, 1), ("3", 2, 2),
            ("0", 3, 0), (".", 3, 1), ("⌫", 3, 2)
        ]
        
        for k_val, r, c in keys:
            keypad_grid.rowconfigure(r, weight=1)
            keypad_grid.columnconfigure(c, weight=1)
            
            cmd_val = "backspace" if k_val == "⌫" else k_val
            btn = tk.Button(
                keypad_grid, 
                text=k_val, 
                font=("Segoe UI", 14, "bold"), 
                relief=tk.FLAT,
                bg="#EEDDCC", 
                fg=C["text"], 
                cursor="hand2"
            )
            btn.config(command=lambda cv=cmd_val: self._keypad_press(cv))
            btn.grid(row=r, column=c, sticky="nsew", padx=2, pady=2)
            
        keypad_grid.rowconfigure(4, weight=1)
        btn_clr = tk.Button(
            keypad_grid, 
            text=t("Clear", "Clear"), 
            font=("Segoe UI", 11, "bold"), 
            relief=tk.FLAT,
            bg="#D9C8AA", 
            fg=C["text"], 
            cursor="hand2"
        )
        btn_clr.config(command=lambda: self._keypad_press("clear"))
        btn_clr.grid(row=4, column=0, columnspan=3, sticky="nsew", padx=2, pady=2)
        
        # 6. Bottom Action Frame (Cancel / Complete)
        bottom_action = tk.Frame(self.dlg, bg=C["bg"], pady=12, padx=16)
        bottom_action.pack(fill=tk.X, side=tk.BOTTOM)
        
        self.cancel_btn = tk.Button(
            bottom_action, 
            text=t("Cancel", "Cancel"), 
            font=("Segoe UI", 11, "bold"), 
            relief=tk.FLAT,
            bg=C["red"], 
            fg="white", 
            padx=24, 
            pady=8, 
            cursor="hand2", 
            command=self.dlg.destroy
        )
        self.cancel_btn.pack(side=tk.LEFT)
        
        self.complete_btn = tk.Button(
            bottom_action, 
            text=t("Complete Payment", "Complete Payment"), 
            font=("Segoe UI", 11, "bold"), 
            relief=tk.FLAT,
            bg=C["bill_btn"], 
            fg="white", 
            padx=24, 
            pady=8, 
            cursor="hand2", 
            command=self._complete_payment
        )
        self.complete_btn.pack(side=tk.RIGHT)

    def _build_quick_cash_buttons(self):
        # Clear existing buttons
        for w in self.qc_grid_frame.winfo_children():
            w.destroy()
            
        import math
        total = self.total_amount
        quick_vals = []
        
        # Exact Change
        quick_vals.append((t("Exact Change", "Exact"), total))
        
        # Next 10 (if not already a multiple of 10)
        n10 = math.ceil(total / 10.0) * 10.0
        if n10 != total:
            quick_vals.append((f"₹{int(n10)}", n10))
            
        # Next 50 (if not already a multiple of 50)
        n50 = math.ceil(total / 50.0) * 50.0
        if n50 != total and n50 != n10:
            quick_vals.append((f"₹{int(n50)}", n50))
            
        # Next 100
        n100 = math.ceil(total / 100.0) * 100.0
        if n100 != total and n100 != n50:
            quick_vals.append((f"₹{int(n100)}", n100))
            
        # Standard large notes if applicable
        if total < 500:
            quick_vals.append(("₹500", 500.0))
        if total < 2000:
            quick_vals.append(("₹2000", 2000.0))
            
        for i, (lbl, val) in enumerate(quick_vals):
            r, c = divmod(i, 3)
            self.qc_grid_frame.rowconfigure(r, weight=1)
            self.qc_grid_frame.columnconfigure(c, weight=1)
            
            btn = tk.Button(
                self.qc_grid_frame, 
                text=lbl, 
                font=("Segoe UI", 9, "bold"), 
                bg="#EEDDCC", 
                fg=C["text"], 
                relief=tk.FLAT, 
                pady=6, 
                cursor="hand2"
            )
            btn.config(command=lambda v=val: self._set_cash_received(v))
            btn.grid(row=r, column=c, padx=2, pady=2, sticky="ew")

    def _set_cash_received(self, value):
        self.cash_received_var.set(f"{value:.2f}")
        if self.selected_mode == "split":
            self.cash_received_entry_split.focus_set()
            self._set_active_entry(self.cash_received_entry_split)
        else:
            self.cash_received_entry.focus_set()
            self._set_active_entry(self.cash_received_entry)
        self._update_calculations()

    def _select_mode(self, mode):
        self.selected_mode = mode
        
        # Highlight active mode button
        for m_id, btn in self.mode_btns.items():
            if m_id == mode:
                btn.config(bg=C["accent"], fg="white")
            else:
                btn.config(bg="#FFE4CC", fg=C["text"])
                
        # Unpack all dynamic panels
        self.cash_panel.pack_forget()
        self.split_panel.pack_forget()
        self.generic_panel.pack_forget()
        
        # Reset variables for Split Mode to prevent carrying over large Cash Mode numbers
        if mode == "split":
            self._updating_splits = True
            try:
                self.cash_received_var.set("0")
                self.card_split_var.set("0")
                self.upi_split_var.set("0")
                self.other_split_var.set("0")
            finally:
                self._updating_splits = False
            
            # Default split: full total in cash
            self._updating_splits = True
            try:
                self.cash_received_var.set(f"{self.total_amount:.2f}")
            finally:
                self._updating_splits = False
        elif mode == "cash":
            self.cash_received_var.set(f"{self.total_amount:.2f}")

        
        # Show mode-specific panel
        if mode == "cash":
            self.cash_panel.pack(fill=tk.BOTH, expand=True)
            self.cash_received_entry.focus_set()
            self._set_active_entry(self.cash_received_entry)
        elif mode == "split":
            self.split_panel.pack(fill=tk.BOTH, expand=True)
            self.cash_received_entry_split.focus_set()
            self._set_active_entry(self.cash_received_entry_split)
        else:
            self.generic_panel.pack(fill=tk.BOTH, expand=True)
            if mode in ("card", "upi") and self.pl_enabled:
                msg = f"Payment will be processed via PINE LABS EDC Terminal for ₹{self.total_amount:.2f}.\n\nPress 'Complete Payment' to trigger the EDC Terminal."
            else:
                msg = f"Payment will be processed via {mode.upper()} for ₹{self.total_amount:.2f}.\n\nPress 'Complete Payment' to finalize."
            self.generic_lbl.config(text=t(msg, msg))
            self.active_entry = None
            
        self._update_calculations()

    def _set_active_entry(self, entry_widget):
        self.active_entry = entry_widget
        for entry in [self.cash_received_entry, self.card_split_entry, self.upi_split_entry, self.other_split_entry]:
            if entry:
                if entry == entry_widget:
                    entry.config(bg="#FFFDF0", highlightbackground=C["accent"], highlightcolor=C["accent"], highlightthickness=2)
                else:
                    entry.config(bg="white", highlightthickness=1, highlightbackground=C["border"], highlightcolor=C["accent"])

    def _keypad_press(self, char):
        if not self.active_entry:
            return
        
        try:
            if self.active_entry.select_present():
                self.active_entry.delete(tk.SEL_FIRST, tk.SEL_LAST)
        except Exception:
            pass
            
        if char == "backspace":
            pos = self.active_entry.index(tk.INSERT)
            if pos > 0:
                self.active_entry.delete(pos - 1, pos)
        elif char == "clear":
            self.active_entry.delete(0, tk.END)
            self.active_entry.insert(0, "0")
        else:
            val = self.active_entry.get()
            if char == "." and "." in val:
                return
            if val == "0" and char != ".":
                self.active_entry.delete(0, tk.END)
                
            self.active_entry.insert(tk.INSERT, char)
            
        self._update_calculations()

    def _on_var_changed(self, source):
        if self._updating_splits:
            return
            
        if self.selected_mode != "split":
            self._update_calculations()
            return
            
        def get_val(var):
            try:
                txt = var.get().strip()
                if not txt:
                    return 0.0
                return float(txt)
            except ValueError:
                return 0.0
                
        total = self.total_amount
        
        self._updating_splits = True
        try:
            if source == "cash":
                cash = get_val(self.cash_received_var)
                card = get_val(self.card_split_var)
                other = get_val(self.other_split_var)
                remaining = max(0.0, total - cash - card - other)
                val_str = f"{remaining:g}" if remaining == int(remaining) else f"{remaining:.2f}"
                self.upi_split_var.set(val_str)
            elif source == "upi":
                upi = get_val(self.upi_split_var)
                card = get_val(self.card_split_var)
                other = get_val(self.other_split_var)
                remaining = max(0.0, total - upi - card - other)
                val_str = f"{remaining:g}" if remaining == int(remaining) else f"{remaining:.2f}"
                self.cash_received_var.set(val_str)
            elif source == "card":
                card = get_val(self.card_split_var)
                upi = get_val(self.upi_split_var)
                other = get_val(self.other_split_var)
                remaining = max(0.0, total - card - upi - other)
                val_str = f"{remaining:g}" if remaining == int(remaining) else f"{remaining:.2f}"
                self.cash_received_var.set(val_str)
            elif source == "other":
                other = get_val(self.other_split_var)
                card = get_val(self.card_split_var)
                upi = get_val(self.upi_split_var)
                remaining = max(0.0, total - other - card - upi)
                val_str = f"{remaining:g}" if remaining == int(remaining) else f"{remaining:.2f}"
                self.cash_received_var.set(val_str)
        finally:
            self._updating_splits = False
            
        self._update_calculations()

    def _update_calculations(self):

        def get_val(var):
            try:
                txt = var.get().strip()
                if not txt:
                    return 0.0
                return float(txt)
            except ValueError:
                return 0.0
                
        mode = self.selected_mode
        total = self.total_amount
        
        if mode == "cash":
            cash_received = get_val(self.cash_received_var)
            if cash_received >= total:
                change = cash_received - total
                self.change_box.config(bg="#EEFFEE", highlightbackground=C["green"], highlightcolor=C["green"])
                self.change_title_lbl.config(text=t("Change to Return", "Change to Return"), bg="#EEFFEE", fg=C["green"])
                self.change_val_lbl.config(text=f"₹{change:.2f}", bg="#EEFFEE", fg=C["green"])
                self.complete_btn.config(state=tk.NORMAL)
            else:
                due = total - cash_received
                self.change_box.config(bg="#FFEFEF", highlightbackground=C["red"], highlightcolor=C["red"])
                self.change_title_lbl.config(text=t("Balance Due", "Balance Due"), bg="#FFEFEF", fg=C["red"])
                self.change_val_lbl.config(text=f"₹{due:.2f}", bg="#FFEFEF", fg=C["red"])
                self.complete_btn.config(state=tk.DISABLED)
                
        elif mode == "split":
            cash_received = get_val(self.cash_received_var)
            card_split = get_val(self.card_split_var)
            upi_split = get_val(self.upi_split_var)
            other_split = get_val(self.other_split_var)
            
            total_entered = cash_received + card_split + upi_split + other_split
            self.split_total_lbl.config(text=f"Total Entered: ₹{total_entered:.2f}")
            
            elec_total = card_split + upi_split + other_split
            
            if elec_total > total:
                self.split_calc_box.config(bg="#FFEFEF")
                self.split_total_lbl.config(bg="#FFEFEF")
                self.split_status_lbl.config(
                    text=f"Elec. Split exceeds total by ₹{elec_total - total:.2f}", 
                    bg="#FFEFEF", 
                    fg=C["red"]
                )
                self.complete_btn.config(state=tk.DISABLED)
            elif total_entered >= total:
                change = total_entered - total
                self.split_calc_box.config(bg="#EEFFEE")
                self.split_total_lbl.config(bg="#EEFFEE")
                if change > 0.0:
                    self.split_status_lbl.config(
                        text=f"{t('Change to Return', 'Change')}: ₹{change:.2f}", 
                        bg="#EEFFEE", 
                        fg=C["green"]
                    )
                else:
                    self.split_status_lbl.config(
                        text=t("Fully Paid ✓", "Fully Paid ✓"), 
                        bg="#EEFFEE", 
                        fg=C["green"]
                    )
                self.complete_btn.config(state=tk.NORMAL)
            else:
                due = total - total_entered
                self.split_calc_box.config(bg="#FFF8F0")
                self.split_total_lbl.config(bg="#FFF8F0")
                self.split_status_lbl.config(
                    text=f"{t('Remaining Balance', 'Remaining')}: ₹{due:.2f}", 
                    bg="#FFF8F0", 
                    fg=C["muted"]
                )
                self.complete_btn.config(state=tk.DISABLED)
        else:
            self.complete_btn.config(state=tk.NORMAL)

    def _complete_payment(self):
        mode = self.selected_mode
        total = self.total_amount
        
        def safe_float(var):
            try:
                return float(var.get() or 0.0)
            except ValueError:
                return 0.0
                
        cash_received = safe_float(self.cash_received_var)
        card_split = safe_float(self.card_split_var)
        upi_split = safe_float(self.upi_split_var)
        other_split = safe_float(self.other_split_var)
        
        splits = {
            "split_cash": 0.0,
            "split_card": 0.0,
            "split_upi": 0.0,
            "split_other": 0.0
        }
        
        if mode == "cash":
            if cash_received < total:
                messagebox.showerror("Error", t("Cash received is less than total.", "Cash received is less than total."))
                return
            splits["split_cash"] = total
            payment_mode = "cash"
        elif mode in ("card", "upi", "other"):
            splits[f"split_{mode}"] = total
            payment_mode = mode
        elif mode == "split":
            total_splits = card_split + upi_split + other_split + cash_received
            if total_splits < total:
                messagebox.showerror("Error", t("Total splits must equal or exceed total bill.", "Total splits must equal or exceed total bill."))
                return
            if card_split + upi_split + other_split > total:
                messagebox.showerror("Error", t("Electronic splits (Card, UPI, Other) cannot exceed total bill.", "Electronic splits (Card, UPI, Other) cannot exceed total bill."))
                return
                
            change = max(0.0, total_splits - total)
            splits["split_cash"] = max(0.0, cash_received - change)
            splits["split_card"] = card_split
            splits["split_upi"] = upi_split
            splits["split_other"] = other_split
            payment_mode = "split"
            
        meta_enrich = {}
        
        pl_enabled = self.pl_enabled
        if pl_enabled:
            pl_payments = []
            if mode == "card":
                pl_payments.append(("card", total))
            elif mode == "upi":
                pl_payments.append(("upi", total))
            elif mode == "split":
                if card_split > 0.0:
                    pl_payments.append(("card", card_split))
                if upi_split > 0.0:
                    pl_payments.append(("upi", upi_split))
                    
            for pl_type, pl_amount in pl_payments:
                preview_no = f"BILL{db._next.__doc__ and ''}{db.today().replace('/','')}"
                invoice_ref = f"MCL{db.today().replace('/','')}-{preview_no[-6:]}"
                
                dlg = PineLabsPaymentDialog(
                    self.dlg,
                    amount=pl_amount,
                    invoice_ref=invoice_ref
                )
                
                result, err = dlg.result, dlg.error
                if err:
                    messagebox.showerror("Payment failed", f"EDC Payment failed for {pl_type.upper()} split of ₹{pl_amount:.2f}:\n{err}")
                    return
                    
                if not (result and result.get("approved")):
                    msg = result.get("message", "Transaction declined") if result else "Transaction cancelled"
                    messagebox.showwarning("Payment declined", f"{pl_type.upper()} split transaction declined/cancelled:\n{msg}")
                    return
                    
                meta_enrich.update({
                    'pl_txn_id':        (meta_enrich.get('pl_txn_id', '') + " " + result.get("txn_id", "")).strip(),
                    'pl_approval_code': (meta_enrich.get('pl_approval_code', '') + " " + result.get("approval_code", "")).strip(),
                    'pl_card_scheme':   result.get("card_scheme", ""),
                    'pl_masked_card':   result.get("masked_card", ""),
                    'pl_invoice_no':    (meta_enrich.get('pl_invoice_no', '') + " " + result.get("pl_invoice_no", "")).strip(),
                    'pl_batch_no':      result.get("batch_no", ""),
                })
                
        self.dlg.destroy()
        self.on_complete(payment_mode, splits, meta_enrich)


import calendar
import datetime

class CalendarPopup(tk.Toplevel):
    """
    Custom lightweight high-contrast popup calendar using standard Tkinter.
    """
    def __init__(self, parent, initial_date_str, on_select):
        super().__init__(parent)
        self.on_select = on_select
        self.title(t("Select Date", "Select Date"))
        self.geometry("300x300")
        self.configure(bg="#222")
        self.resizable(False, False)
        self.grab_set()
        
        # Center on parent
        try:
            self.update_idletasks()
            pw = parent.winfo_width()
            ph = parent.winfo_height()
            px = parent.winfo_x()
            py = parent.winfo_y()
            w, h = 300, 300
            x = px + (pw - w) // 2
            y = py + (ph - h) // 2
            self.geometry(f"{w}x{h}+{x}+{y}")
        except Exception:
            pass

        try:
            d, m, y = map(int, initial_date_str.split("/"))
            self.current_date = datetime.date(y, m, d)
        except Exception:
            self.current_date = datetime.date.today()
            
        self.year = self.current_date.year
        self.month = self.current_date.month
        self.selected_day = self.current_date.day
        
        self.hdr = tk.Frame(self, bg="#333", pady=6)
        self.hdr.pack(fill=tk.X)
        
        tk.Button(self.hdr, text="◀", font=("Segoe UI", 11, "bold"), bg="#444", fg="white",
                  relief=tk.FLAT, padx=8, cursor="hand2", command=self._prev_month).pack(side=tk.LEFT, padx=6)
                  
        self.title_lbl = tk.Label(self.hdr, text="", font=("Segoe UI", 12, "bold"), bg="#333", fg="#FFCC33")
        self.title_lbl.pack(side=tk.LEFT, expand=True)
        
        tk.Button(self.hdr, text="▶", font=("Segoe UI", 11, "bold"), bg="#444", fg="white",
                  relief=tk.FLAT, padx=8, cursor="hand2", command=self._next_month).pack(side=tk.RIGHT, padx=6)
                  
        self.days_frame = tk.Frame(self, bg="#222", pady=6)
        self.days_frame.pack(fill=tk.BOTH, expand=True, padx=6, pady=4)
        
        self._render()

    def _render(self):
        for w in self.days_frame.winfo_children():
            w.destroy()
            
        month_names = ["", "January", "February", "March", "April", "May", "June", 
                       "July", "August", "September", "October", "November", "December"]
        self.title_lbl.config(text=f"{t(month_names[self.month], month_names[self.month])} {self.year}")
        
        weekdays = ["Mo", "Tu", "We", "Th", "Fr", "Sa", "Su"]
        for col, wd in enumerate(weekdays):
            tk.Label(self.days_frame, text=t(wd, wd), font=("Segoe UI", 10, "bold"), bg="#222", fg="#888").grid(row=0, column=col, pady=4)
            
        cal = calendar.monthcalendar(self.year, self.month)
        for r_idx, week in enumerate(cal):
            for c_idx, day in enumerate(week):
                if day == 0:
                    tk.Label(self.days_frame, text="", bg="#222").grid(row=r_idx+1, column=c_idx, sticky="nsew")
                else:
                    is_selected = (day == self.selected_day and self.month == self.current_date.month and self.year == self.current_date.year)
                    bg_color = "#FF9900" if is_selected else "#333"
                    fg_color = "black" if is_selected else "white"
                    
                    btn = tk.Button(
                        self.days_frame, 
                        text=str(day), 
                        font=("Segoe UI", 10),
                        bg=bg_color, 
                        fg=fg_color, 
                        relief=tk.FLAT,
                        borderwidth=1,
                        cursor="hand2",
                        command=lambda d=day: self._select_day(d)
                    )
                    btn.grid(row=r_idx+1, column=c_idx, padx=1, pady=1, sticky="nsew")
                    
        for col in range(7):
            self.days_frame.columnconfigure(col, weight=1)
        for row in range(1, 7):
            self.days_frame.rowconfigure(row, weight=1)

    def _prev_month(self):
        if self.month == 1:
            self.month = 12
            self.year -= 1
        else:
            self.month -= 1
        self._render()

    def _next_month(self):
        if self.month == 12:
            self.month = 1
            self.year += 1
        else:
            self.month += 1
        self._render()

    def _select_day(self, day):
        selected_date = datetime.date(self.year, self.month, day)
        date_str = selected_date.strftime("%d/%m/%Y")
        self.on_select(date_str)
        self.destroy()

