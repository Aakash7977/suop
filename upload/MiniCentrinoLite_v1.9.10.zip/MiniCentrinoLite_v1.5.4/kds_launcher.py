"""
Mini Centrino Lite v1.2 — KDS Standalone Launcher
This file is the entry point for MiniCentrinoLite_KDS.exe

v1.2.1: If setup has not been completed yet (setup_done=False),
        route to the setup wizard first so the user can configure
        hub_ip and other essentials.
"""
import sys
from config import CFG

sys.argv.append("--kds")

# v1.2.1: Check if setup is needed before launching KDS directly.
# This fixes the issue where KDS would open without any setup window
# on first run, leaving the user unable to configure hub_ip.
if not CFG.get("setup_done", False):
    from main import launch_setup
    launch_setup()
else:
    from main import launch_kds
    launch_kds()
