"""
Mini Centrino Lite v1.2 — POS Client (POS → Hub connector)

Every POS terminal runs this client alongside its UI. It:
  - Connects to the hub on startup
  - Auto-reconnects every 4 seconds on disconnect
  - Sends every KOT / bill / status / menu update to the hub
  - Receives broadcasts from the hub (other POS's events, menu updates)
  - Calls registered callbacks so the POS UI can refresh in real time

Protocol: newline-delimited JSON over TCP (same as v1.1 KDS protocol).
"""
import socket, threading, json, time, logging
from typing import Optional, Callable

log = logging.getLogger("mcl.pos_client")


class POSClient:
    """
    Client used by every POS terminal to talk to the hub.
    Usage:
        client = POSClient(host="192.168.1.10", port=9999, terminal_id=2)
        client.on_kot_new      = lambda kot: ...       # received from another POS
        client.on_bill_new     = lambda bill: ...
        client.on_status_update= lambda kot_no, status: ...
        client.on_menu_update  = lambda action, payload: ...
        client.on_menu_snapshot= lambda menu: ...
        client.on_connect      = lambda: ...
        client.on_disconnect   = lambda: ...
        client.start()
        # Later:
        client.send_kot(kot_dict)
        client.send_bill(bill_dict)
        client.send_status_update(kot_no, "preparing")
        client.send_menu_update("price_change", {"item_id": 42, "new_price": 150})
        client.request_sync()
    """

    def __init__(self, host: str, port: int = 9999, terminal_id: int = 1, terminal_name: str = "POS-1"):
        self.host = host
        self.port = int(port)
        self.terminal_id = terminal_id
        self.terminal_name = terminal_name

        self._conn: Optional[socket.socket] = None
        self._running = False
        self.connected = False

        # Callbacks (called from background thread — caller must use root.after for GUI updates)
        self.on_connect:        Optional[Callable[[], None]] = None
        self.on_disconnect:     Optional[Callable[[], None]] = None
        self.on_kot_new:        Optional[Callable[[dict], None]] = None
        self.on_bill_new:       Optional[Callable[[dict], None]] = None
        self.on_status_update:  Optional[Callable[[int, str], None]] = None
        self.on_menu_update:    Optional[Callable[[str, dict], None]] = None
        self.on_menu_snapshot:  Optional[Callable[[dict], None]] = None
        self.on_initial_state:  Optional[Callable[[dict], None]] = None
        self.on_held_recalled:  Optional[Callable[[int], None]] = None

    # ─────────────────────────────────── Lifecycle ───────────────

    def start(self):
        self._running = True
        threading.Thread(target=self._loop, daemon=True, name="pos-client").start()

    def stop(self):
        self._running = False
        if self._conn:
            try:
                self._conn.close()
            except Exception:
                pass

    # ─────────────────────────────────── Internal loop ───────────

    def _loop(self):
        while self._running:
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(5.0)
                sock.connect((self.host, self.port))
                sock.settimeout(None)
                self._conn = sock
                self.connected = True
                # Send POS connect handshake
                self._send_raw({"type": "pos_connect",
                                "terminal_id": self.terminal_id,
                                "terminal_name": self.terminal_name})
                if self.on_connect:
                    try:
                        self.on_connect()
                    except Exception as e:
                        log.warning("on_connect callback error: %s", e)
                log.info("POS-%s connected to hub %s:%s", self.terminal_id, self.host, self.port)
                self._recv(sock)
            except Exception as e:
                log.debug("POS connect error: %s", e)
            finally:
                self.connected = False
                if self.on_disconnect:
                    try:
                        self.on_disconnect()
                    except Exception as e:
                        log.warning("on_disconnect callback error: %s", e)
                try:
                    if self._conn:
                        self._conn.close()
                except Exception:
                    pass
                self._conn = None
            if self._running:
                time.sleep(4)  # reconnect every 4 seconds

    def _recv(self, sock: socket.socket):
        buf = ""
        while self._running:
            chunk = sock.recv(8192)
            if not chunk:
                break
            buf += chunk.decode("utf-8", errors="replace")
            while "\n" in buf:
                line, buf = buf.split("\n", 1)
                line = line.strip()
                if line:
                    try:
                        msg = json.loads(line)
                        self._dispatch(msg)
                    except Exception as e:
                        log.warning("Bad message from hub: %s | %s", e, line[:120])

    def _dispatch(self, msg: dict):
        """Route an incoming hub message to the right callback."""
        mtype = msg.get("type", "")
        try:
            if mtype == "kot_new" and self.on_kot_new:
                self.on_kot_new(msg.get("kot", {}))
            elif mtype == "bill_new" and self.on_bill_new:
                self.on_bill_new(msg.get("bill", {}))
            elif mtype == "status_update" and self.on_status_update:
                self.on_status_update(msg.get("kot_no"), msg.get("status"))
            elif mtype == "menu_update" and self.on_menu_update:
                self.on_menu_update(msg.get("action"), msg.get("payload", {}))
            elif mtype == "menu_snapshot" and self.on_menu_snapshot:
                self.on_menu_snapshot(msg.get("menu", {}))
            elif mtype == "initial_state" and self.on_initial_state:
                self.on_initial_state(msg)
            elif mtype == "held_recalled" and self.on_held_recalled:
                self.on_held_recalled(msg.get("held_id"))
            elif mtype == "pong":
                pass  # heartbeat response
            else:
                log.debug("Unhandled hub message: %s", mtype)
        except Exception as e:
            log.error("Callback error for %s: %s", mtype, e)

    # ─────────────────────────────────── Outbound helpers ────────

    def _send_raw(self, msg: dict):
        if self._conn and self.connected:
            try:
                self._conn.sendall((json.dumps(msg) + "\n").encode("utf-8"))
                return True
            except Exception as e:
                log.warning("POS send error: %s", e)
        return False

    def send_kot(self, kot: dict):
        """Tell the hub about a new KOT raised on this POS."""
        return self._send_raw({"type": "kot_new", "kot": kot})

    def send_bill(self, bill: dict):
        """Tell the hub about a new bill generated on this POS."""
        return self._send_raw({"type": "bill_new", "bill": bill})

    def send_status_update(self, kot_no: int, status: str):
        """Tell the hub that a KOT's status changed (e.g. POS recalled a KOT)."""
        return self._send_raw({"type": "status_update", "kot_no": kot_no, "status": status})

    def send_held_recall(self, held_id: int):
        """Tell the hub that this POS recalled a held bill (so others can hide it)."""
        return self._send_raw({"type": "held_recall", "held_id": held_id})

    def send_menu_update(self, action: str, payload: dict):
        """Tell the hub about a menu edit (price change, add/delete item, etc.).
        Hub will broadcast to all other POS and KDS."""
        return self._send_raw({"type": "menu_update", "action": action, "payload": payload})

    def request_sync(self):
        """Ask the hub for a full menu + state snapshot (used on POS startup)."""
        return self._send_raw({"type": "sync_request"})

    def ping(self):
        """Heartbeat. Returns True if sent successfully."""
        return self._send_raw({"type": "ping", "ts": time.time()})
