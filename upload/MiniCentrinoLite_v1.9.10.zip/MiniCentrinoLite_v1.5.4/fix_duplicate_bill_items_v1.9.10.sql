-- ============================================================
-- Mini Centrino Lite v1.9.10 — DUPLICATE BILL_ITEMS CLEANUP
-- ============================================================
-- ROOT CAUSE: The v1.9.7 backfill routine queried bill_items to
-- check which bill_nos already had items. But Supabase's REST API
-- returns max 1000 rows per request, so when there were >1000
-- bill_items, some bill_nos were missed → re-inserted → duplicates.
--
-- SYMPTOMS:
--   - Daily Product Sales Matrix shows inflated quantities
--   - Matrix total (₹37,155) ≠ Dashboard revenue (₹6,765)
--   - Same item appears 2-4 times for the same bill
--
-- FIX:
--   1. Delete duplicate rows (keep only one per bill_no + item_name)
--   2. Add a UNIQUE constraint to prevent future duplicates
-- ============================================================

-- ────────────────────────────────────────────────────────────
-- 1. Delete duplicates: keep only the FIRST row per (outlet_id, bill_no, item_name)
-- ────────────────────────────────────────────────────────────
-- Strategy: use rowid (ctid in Postgres) to keep the smallest id per group.
DELETE FROM public.bill_items
WHERE id IN (
    SELECT id FROM (
        SELECT
            id,
            ROW_NUMBER() OVER (
                PARTITION BY outlet_id, bill_no, item_name
                ORDER BY id ASC
            ) AS rn
        FROM public.bill_items
    ) t
    WHERE rn > 1
);

-- ────────────────────────────────────────────────────────────
-- 2. Add UNIQUE constraint to prevent future duplicates
-- ────────────────────────────────────────────────────────────
-- This ensures (outlet_id, bill_no, item_name) is always unique.
-- If the backfill tries to insert a duplicate, Postgres will reject it
-- instead of silently creating a copy.
ALTER TABLE public.bill_items
    DROP CONSTRAINT IF EXISTS uq_bill_items_outlet_billno_itemname;

ALTER TABLE public.bill_items
    ADD CONSTRAINT uq_bill_items_outlet_billno_itemname
    UNIQUE (outlet_id, bill_no, item_name);

-- ────────────────────────────────────────────────────────────
-- 3. Verify: check for remaining duplicates (should be 0)
-- ────────────────────────────────────────────────────────────
SELECT
    'duplicate pairs remaining' AS check_name,
    COUNT(*) AS count
FROM (
    SELECT outlet_id, bill_no, item_name, COUNT(*) AS cnt
    FROM public.bill_items
    GROUP BY outlet_id, bill_no, item_name
    HAVING COUNT(*) > 1
) dups;

-- Expected: count = 0

-- ────────────────────────────────────────────────────────────
-- 4. Verify: total bill_items count after cleanup
-- ────────────────────────────────────────────────────────────
SELECT
    'total bill_items after cleanup' AS check_name,
    COUNT(*) AS count
FROM public.bill_items;

-- ────────────────────────────────────────────────────────────
-- 5. Verify: Wada Pav total qty for today (should be much less than 484)
-- ────────────────────────────────────────────────────────────
SELECT
    'Wada Pav total qty today' AS check_name,
    SUM(quantity) AS total_qty,
    SUM(amount) AS total_amount
FROM public.bill_items bi
JOIN public.bills b ON bi.bill_id = b.id
WHERE bi.item_name = 'Wada Pav'
  AND b.bill_date = '04/07/2026'
  AND b.pl_voided = false;
