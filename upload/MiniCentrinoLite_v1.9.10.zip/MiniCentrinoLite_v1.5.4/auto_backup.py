"""
Mini Centrino Lite v1.5.0 — Automatic SQLite Backup Module
Sudhamrit Food Joint | Sri Ma Trust

Provides:
  - do_backup_now()           : one-shot backup using SQLite online backup API
  - AutoBackupWorker          : background thread that backs up periodically
  - _resolve_backup_folder()  : picks backup folder from CFG or default
  - _cleanup_old_backups()    : deletes backups older than N days

Backups are written to ~/MiniCentrinoLite_Backups/ by default, or to the
folder configured in CFG["auto_backup_folder"].

The SQLite online backup API (sqlite3.Connection.backup()) is used so that
the destination is a consistent snapshot even when the source DB is in WAL
mode and is being actively written to by the POS at the same time. This is
the same mechanism used by `sqlite3 .backup` and is crash-safe.
"""
import os
import shutil
import threading
import time
import datetime
import logging
import glob

from config import CFG
import database as db

log = logging.getLogger("mcl.auto_backup")

# Filename pattern for backups on disk. The timestamp portion is filled in
# by do_backup_now() using the format below.
BACKUP_FILENAME_FMT = "backup_{ts}.db"
BACKUP_TIMESTAMP_FMT = "%Y-%m-%d_%H%M%S"

# Default backup folder when CFG["auto_backup_folder"] is empty.
DEFAULT_BACKUP_FOLDER_NAME = "MiniCentrinoLite_Backups"

# Initial delay (seconds) before the first backup runs after AutoBackupWorker
# is started. Per the v1.5.0 spec.
INITIAL_BACKUP_DELAY_SECONDS = 60.0

# How long to wait between checks of the stop flag inside the worker's sleep
# loop. Kept small so stop() is responsive even when the next backup is hours
# away.
STOP_POLL_INTERVAL_SECONDS = 5.0


# ─────────────────────────────────────────────────────────────────────
# Folder resolution & cleanup
# ─────────────────────────────────────────────────────────────────────

def _resolve_backup_folder() -> str:
    """
    Return the absolute path to the backup folder, creating it if it does
    not exist.

    Resolution order:
      1. CFG["auto_backup_folder"] (if non-empty after stripping)
      2. ~/MiniCentrinoLite_Backups/
    """
    folder = (CFG.get("auto_backup_folder") or "").strip()
    if not folder:
        folder = os.path.join(os.path.expanduser("~"), DEFAULT_BACKUP_FOLDER_NAME)
    folder = os.path.abspath(folder)
    try:
        os.makedirs(folder, exist_ok=True)
    except Exception as e:
        log.error("Could not create backup folder %s: %s", folder, e)
    return folder


def _cleanup_old_backups(folder: str, keep_days: int) -> int:
    """
    Delete backup_*.db files in `folder` whose modification time is older
    than `keep_days` days.

    Returns the number of files actually deleted. Errors on individual files
    are logged but do not abort the cleanup pass.
    """
    if not folder or not os.path.isdir(folder):
        return 0
    try:
        keep_days = int(keep_days)
    except (TypeError, ValueError):
        return 0
    if keep_days <= 0:
        # 0 or negative = keep everything (safety default)
        return 0

    cutoff = time.time() - (keep_days * 86400.0)
    pattern = os.path.join(folder, "backup_*.db")
    deleted = 0
    for path in glob.glob(pattern):
        try:
            mtime = os.path.getmtime(path)
            if mtime < cutoff:
                os.remove(path)
                deleted += 1
                log.info(
                    "Removed old backup: %s (mtime=%s)",
                    os.path.basename(path),
                    datetime.datetime.fromtimestamp(mtime).isoformat(timespec="seconds"),
                )
        except Exception as e:
            log.warning("Could not remove %s: %s", path, e)
    return deleted


# ─────────────────────────────────────────────────────────────────────
# One-shot backup
# ─────────────────────────────────────────────────────────────────────

def do_backup_now() -> dict:
    """
    Perform a single backup of the SQLite DB located at `db.DB_PATH` using
    SQLite's online backup API.

    The destination file is named `backup_YYYY-MM-DD_HHMMSS.db` and is
    written to the folder returned by `_resolve_backup_folder()`. A
    `.tmp` suffix is used while the backup is in progress and the file is
    atomically renamed on success, so a crashed backup never leaves a
    half-written file that looks like a valid backup.

    After a successful backup, `_cleanup_old_backups()` is called to prune
    files older than `CFG["auto_backup_keep_days"]` days.

    Returns a dict describing the result:
        {
          "ok":        bool,           # True on success
          "path":      str,            # absolute path to the backup file
          "size":      int,            # file size in bytes (0 on failure)
          "error":     str | None,     # error message (None on success)
          "timestamp": str,            # ISO 8601 timestamp of the attempt
          "duration_ms": int,          # wall-clock duration of the backup
        }
    """
    # Import sqlite3 lazily so this module can be imported in environments
    # where sqlite3 isn't yet needed (e.g. setup wizard) without forcing it.
    import sqlite3

    src_path = str(db.DB_PATH)
    ts_label = datetime.datetime.now().strftime(BACKUP_TIMESTAMP_FMT)
    folder = _resolve_backup_folder()
    backup_name = BACKUP_FILENAME_FMT.format(ts=ts_label)
    backup_path = os.path.join(folder, backup_name)
    tmp_path = backup_path + ".tmp"

    started = time.monotonic()
    result = {
        "ok": False,
        "path": backup_path,
        "size": 0,
        "error": None,
        "timestamp": datetime.datetime.now().isoformat(timespec="seconds"),
        "duration_ms": 0,
    }

    if not src_path or not os.path.exists(src_path):
        result["error"] = f"Source DB not found: {src_path}"
        log.error(result["error"])
        return result

    try:
        # Open a fresh source connection for the backup. We deliberately do
        # NOT reuse db.get_conn() because that connection is shared with the
        # rest of the POS app and the backup API requires its own connection
        # to coordinate page-level locking with the source.
        src = sqlite3.connect(src_path, timeout=15)
        dst = sqlite3.connect(tmp_path)
        try:
            # src.backup(dst) performs an online page-by-page copy. Safe to
            # call while other connections are reading/writing the source.
            src.backup(dst)
        finally:
            try:
                dst.close()
            except Exception:
                pass
            try:
                src.close()
            except Exception:
                pass

        # Atomic rename on success
        os.replace(tmp_path, backup_path)

        result["ok"] = True
        result["size"] = os.path.getsize(backup_path)
        result["duration_ms"] = int((time.monotonic() - started) * 1000)
        log.info(
            "Backup complete: %s (%d bytes, %d ms)",
            backup_name, result["size"], result["duration_ms"],
        )

        # Prune old backups. Failure here is non-fatal — the backup itself
        # already succeeded.
        try:
            keep_days = int(CFG.get("auto_backup_keep_days", 30) or 30)
            n = _cleanup_old_backups(folder, keep_days)
            if n:
                log.info(
                    "Cleaned up %d old backup(s) older than %d day(s).", n, keep_days
                )
        except Exception as e:
            log.warning("Old-backup cleanup failed (non-fatal): %s", e)

    except Exception as e:
        result["error"] = str(e)
        result["duration_ms"] = int((time.monotonic() - started) * 1000)
        log.exception("Backup failed: %s", e)
        # Clean up the partial temp file so we never mistake it for a real
        # backup on the next run.
        try:
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
        except Exception:
            pass

    return result


# ─────────────────────────────────────────────────────────────────────
# AutoBackupWorker — background periodic backup
# ─────────────────────────────────────────────────────────────────────

class AutoBackupWorker:
    """
    Background thread that performs periodic SQLite backups.

    Lifecycle:
      - start()  spawns a daemon thread (idempotent — safe to call twice)
      - The first backup runs INITIAL_BACKUP_DELAY_SECONDS (60s) after
        start(), giving the POS time to settle on launch
      - Subsequent backups run every CFG["auto_backup_interval_hours"]
        hours (default 24h)
      - After each backup, files older than CFG["auto_backup_keep_days"]
        are pruned
      - stop() signals the thread to exit and joins it (default 5s timeout)

    The worker is fault-tolerant: any exception during a backup is logged
    and the loop continues. The thread is a daemon so it never blocks
    process exit.
    """

    def __init__(self):
        self._thread: threading.Thread | None = None
        self._stop_event = threading.Event()
        self._last_backup: dict | None = None
        self._lock = threading.Lock()

    # ── Public API ────────────────────────────────────────────────

    def start(self):
        """Start the worker thread (no-op if already running)."""
        if self._thread is not None and self._thread.is_alive():
            log.warning("AutoBackupWorker is already running; start() ignored.")
            return
        if not bool(CFG.get("auto_backup_enabled", True)):
            log.info(
                "Auto-backup is disabled in config (auto_backup_enabled=False); "
                "worker not started."
            )
            return
        self._stop_event.clear()
        self._thread = threading.Thread(
            target=self._run,
            name="mcl-autobackup",
            daemon=True,
        )
        self._thread.start()
        log.info("AutoBackupWorker started.")

    def stop(self, timeout: float = 5.0):
        """Signal the worker thread to stop and wait for it to exit."""
        self._stop_event.set()
        if self._thread is not None and self._thread.is_alive():
            self._thread.join(timeout=timeout)
        self._thread = None
        log.info("AutoBackupWorker stopped.")

    def last_backup_info(self) -> dict | None:
        """
        Return a copy of the result dict from the last backup performed by
        this worker, or None if no backup has been performed yet.

        The dict has the same shape as the one returned by do_backup_now().
        """
        with self._lock:
            return dict(self._last_backup) if self._last_backup else None

    # ── Internal helpers ──────────────────────────────────────────

    def _interval_seconds(self) -> float:
        """Return the configured backup interval in seconds (min 1h)."""
        try:
            hours = float(CFG.get("auto_backup_interval_hours", 24) or 24)
        except (TypeError, ValueError):
            hours = 24.0
        # Clamp to a sane minimum so a misconfigured value doesn't hammer
        # the disk.
        return max(1.0, hours) * 3600.0

    def _record_last(self, result: dict):
        with self._lock:
            self._last_backup = dict(result)

    # ── Thread main loop ──────────────────────────────────────────

    def _run(self):
        log.info(
            "AutoBackupWorker loop started. First backup in %d second(s); "
            "interval = %.1f hour(s).",
            int(INITIAL_BACKUP_DELAY_SECONDS),
            self._interval_seconds() / 3600.0,
        )

        # Initial delay before the very first backup. We use Event.wait()
        # so stop() is responsive during this period too.
        if self._stop_event.wait(INITIAL_BACKUP_DELAY_SECONDS):
            log.info("AutoBackupWorker received stop signal during initial delay.")
            return

        while not self._stop_event.is_set():
            try:
                result = do_backup_now()
                self._record_last(result)
            except Exception as e:
                # do_backup_now() already catches and records its own errors,
                # but we guard here too so a rogue exception never kills the
                # thread.
                log.exception("Unexpected error in backup loop: %s", e)
                self._record_last({
                    "ok": False,
                    "path": "",
                    "size": 0,
                    "error": str(e),
                    "timestamp": datetime.datetime.now().isoformat(timespec="seconds"),
                    "duration_ms": 0,
                })

            # Sleep until next interval, but wake up periodically so stop()
            # is responsive.
            interval = self._interval_seconds()
            slept = 0.0
            while slept < interval:
                step = min(STOP_POLL_INTERVAL_SECONDS, interval - slept)
                if self._stop_event.wait(step):
                    return
                slept += step

        log.info("AutoBackupWorker loop exited.")
