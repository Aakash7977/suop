"""
Mini Centrino Lite v1.2 - Configuration
Sudhamrit Food Joint | Sri Ma Trust

v1.2 changes:
  - Multi-POS hub architecture (hub_ip, hub_port, mode="hub")
  - Single price menu (no dine-in/parcel split)
  - Packaging checkbox at checkout (packaging_required)
  - PIN-protected menu editing (menu_pin)
  - Menu sync across all POS via hub
"""
import os, json
from pathlib import Path

APP_NAME      = "Mini Centrino Lite"
APP_VERSION   = "1.5.6"
APP_TAGLINE   = "Transition ERP for Outlet Operations"
BUILD_FOR     = "SUDHAMRIT FOOD JOINT"

# Data directory: %APPDATA%/MiniCentrinoLite on Windows, ~/.mcl on Linux
if os.name == 'nt':
    BASE_DIR = Path(os.environ.get('APPDATA', '.')) / 'MiniCentrinoLite'
else:
    BASE_DIR = Path.home() / '.mini_centrino_lite'

DB_PATH     = BASE_DIR / 'data.db'
CONFIG_PATH = BASE_DIR / 'settings.json'
LOG_PATH    = BASE_DIR / 'app.log'

DEFAULTS = {
    # Restaurant info
    "restaurant_name":    "SUDHAMRIT FOOD JOINT",
    "restaurant_address": "Thane, Maharashtra",
    "restaurant_phone":   "",
    "gstin":              "",
    "fssai_no":           "",
    "tagline":            "Pure Sattvik Vegetarian | No Onion | No Garlic",

    # ── v1.2 Hub architecture ──────────────────────────────────────
    # mode controls what this instance runs as:
    #   "terminal"  → POS billing terminal (client of hub)
    #   "kds"       → Kitchen display (client of hub)
    #   "hub"       → Hub service (TCP server + DB owner)
    #   "setup"     → Show first-run setup wizard
    "mode":               "terminal",

    # Hub TCP server settings (used when mode == "hub")
    "hub_host":           "0.0.0.0",      # bind address for hub
    "hub_port":           9999,           # TCP port

    # Hub client settings (used when mode in ("terminal", "kds"))
    "hub_ip":             "192.168.1.10", # LAN IP of hub machine
    "hub_port_client":    9999,           # must match hub_port above

    # Legacy: kept for backward compat with v1.1 KDS-only direct connection.
    # Used only as fallback if hub is unreachable.
    "server_host":        "0.0.0.0",
    "server_port":        9999,
    "kds_terminal_ip":    "192.168.1.1",
    "kds_terminal_port":  9999,
    "kds_station_id":     "KDS-01",

    # POS identity
    "terminal_id":        1,              # unique per POS (1, 2, 3 ...)
    "terminal_name":      "POS-1",        # human-friendly name shown in UI
    "is_primary":         False,          # v1.2: always False for POS clients.
                                          #       Hub owns the DB.

    # ── Menu editing ───────────────────────────────────────────────
    "menu_pin":           "1234",         # PIN required to edit menu (change in Settings)
    "menu_pin_enabled":   True,           # set False to disable PIN prompt

    # ── v1.2 Packaging checkbox ────────────────────────────────────
    # When cashier checks "Packaging required" at checkout:
    #   - KOT card shows PACK badge on KDS
    #   - Bill prints "Packaging: Yes"
    #   - Optional packaging charge auto-added
    "packaging_charge_mode":   "none",    # "none" | "fixed" | "per_item"
    "packaging_charge_amount": 0.0,       # in rupees (used when mode != "none")

    # ── Printing ───────────────────────────────────────────────────
    "printer_name":       "",              # Empty = system default
    "print_copies_bill":  1,
    "print_copies_kot":   1,
    "thermal_chars":      42,              # Chars per line on 80mm
    "print_on_hold":      False,

    # ── Tax ────────────────────────────────────────────────────────
    "gst_rate":           5.0,            # Total GST % (2.5 CGST + 2.5 SGST)

    # ── Pine Labs EDC ──────────────────────────────────────────────
    "pl_enabled":         False,
    "pl_edc_ip":          "192.168.1.100",
    "pl_edc_port":        4002,
    "pl_store_id":        "",
    "pl_terminal_sn":     "",
    "pl_timeout":         120,

    # ── UI ─────────────────────────────────────────────────────────
    "theme":              "amber",
    "ui_scale":           "auto",
    "ui_scale_chosen":    False,
    "language":           "en",            # "en" | "hi" | "mr"

    # ── First-run setup flag (v1.2.1) ──────────────────────────────
    # False until the user completes the --setup wizard at least once.
    # KDS and POS will auto-route to setup if this is False.
    "setup_done":         False,

    # ── Auto-backup (v1.3.3) ──────────────────────────────────────
    "auto_backup_enabled":      True,
    "auto_backup_folder":       "",
    "auto_backup_interval_hours": 24,
    "auto_backup_keep_days":    30,

    # ── Cloud Sync / Supabase (v1.4.0+) ───────────────────────────
    "cloud_sync_enabled":          False,
    "supabase_url":                "",
    "supabase_anon_key":           "",
    "supabase_outlet_id":          "",
    "cloud_sync_push_interval":    60,
    "cloud_sync_pull_interval":    30,

    # ── Coupons ────────────────────────────────────────────────────
    "coupons": [
        {"code": "WELCOME10", "type": "percentage", "value": 10.0},
        {"code": "STAFF15",    "type": "percentage", "value": 15.0},
        {"code": "FESTIVE20",  "type": "percentage", "value": 20.0},
        {"code": "SPECIAL25",  "type": "percentage", "value": 25.0},
        {"code": "FLAT50",     "type": "flat",       "value": 50.0},
        {"code": "FLAT100",    "type": "flat",       "value": 100.0}
    ],
}

def load():
    BASE_DIR.mkdir(parents=True, exist_ok=True)
    if CONFIG_PATH.exists():
        try:
            with open(CONFIG_PATH, encoding='utf-8') as f:
                saved = json.load(f)
            return {**DEFAULTS, **saved}
        except Exception:
            pass
    return DEFAULTS.copy()

def save(cfg):
    BASE_DIR.mkdir(parents=True, exist_ok=True)
    with open(CONFIG_PATH, 'w', encoding='utf-8') as f:
        json.dump(cfg, f, indent=2)

CFG = load()
if CFG.get("db_path"):
    DB_PATH = Path(CFG["db_path"])

# Note: Supabase + auto-backup settings are added at the end of DEFAULTS dict
# See the full config in v1.4.x for reference. For v1.5.0, these are added
# inline below by the setup script.

# v1.5.0 — Supabase + Auto-backup settings appended
# These are merged into DEFAULTS at runtime via the load() function below
