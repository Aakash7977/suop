@echo off
title Mini Centrino Lite - POS Billing Terminal
cd /d "%~dp0"
echo Starting POS Billing Terminal...
start "" pythonw main.py
exit
