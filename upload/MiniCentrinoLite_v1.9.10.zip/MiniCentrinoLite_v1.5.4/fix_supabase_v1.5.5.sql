-- ============================================================
-- Mini Centrino Lite v1.5.5 — SUPABASE FIX SQL
-- Run this in Supabase SQL Editor to fix all 4 sync errors
-- ============================================================

-- FIX 1: bills.bill_no is INTEGER but bill numbers are 26+ billion
-- Change to BIGINT (supports up to 9.2 quintillion)
ALTER TABLE public.bills ALTER COLUMN bill_no TYPE BIGINT;

-- FIX 2: kots table is missing 'items' JSONB column
-- (cloud_sync pushes items as a JSON array directly into this column)
ALTER TABLE public.kots ADD COLUMN IF NOT EXISTS items JSONB DEFAULT '[]'::jsonb;

-- FIX 3: sync_menu_updates is missing 'status' column
-- (cloud_sync updates status to 'applied' or 'error')
ALTER TABLE public.sync_menu_updates ADD COLUMN IF NOT EXISTS status TEXT DEFAULT '';

-- FIX 4: Also add 'error_message' column to sync_menu_updates if missing
ALTER TABLE public.sync_menu_updates ADD COLUMN IF NOT EXISTS error_message TEXT DEFAULT '';

-- FIX 5: Also add 'status' and 'error_message' columns to sync_orders if missing
ALTER TABLE public.sync_orders ADD COLUMN IF NOT EXISTS status TEXT DEFAULT 'pending';
ALTER TABLE public.sync_orders ADD COLUMN IF NOT EXISTS error_message TEXT DEFAULT '';
ALTER TABLE public.sync_orders ADD COLUMN IF NOT EXISTS processed_at TIMESTAMPTZ;
ALTER TABLE public.sync_orders ADD COLUMN IF NOT EXISTS kot_no INTEGER;
ALTER TABLE public.sync_orders ADD COLUMN IF NOT EXISTS total_amount NUMERIC(10,2) DEFAULT 0;
ALTER TABLE public.sync_orders ADD COLUMN IF NOT EXISTS customer_phone TEXT DEFAULT '';
ALTER TABLE public.sync_orders ADD COLUMN IF NOT EXISTS customer_address TEXT DEFAULT '';

-- FIX 6: Make sure bill_items table has all required columns
ALTER TABLE public.bill_items ADD COLUMN IF NOT EXISTS item_type TEXT DEFAULT 'standard';
ALTER TABLE public.bill_items ADD COLUMN IF NOT EXISTS notes TEXT DEFAULT '';
ALTER TABLE public.bill_items ADD COLUMN IF NOT EXISTS packaging_type TEXT DEFAULT '';

-- VERIFY — run this after to check everything is fixed
SELECT
    'bills.bill_no type' AS check_name,
    data_type
FROM information_schema.columns
WHERE table_name = 'bills' AND column_name = 'bill_no'
UNION ALL
SELECT
    'kots.items exists' AS check_name,
    data_type
FROM information_schema.columns
WHERE table_name = 'kots' AND column_name = 'items'
UNION ALL
SELECT
    'sync_menu_updates.status exists' AS check_name,
    data_type
FROM information_schema.columns
WHERE table_name = 'sync_menu_updates' AND column_name = 'status'
UNION ALL
SELECT
    'sync_orders.status exists' AS check_name,
    data_type
FROM information_schema.columns
WHERE table_name = 'sync_orders' AND column_name = 'status';
