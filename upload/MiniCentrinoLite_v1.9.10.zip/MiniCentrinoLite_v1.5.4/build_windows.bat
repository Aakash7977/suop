@echo off
REM ─────────────────────────────────────────────────────────────
REM  Mini Centrino Lite v1.2 — Windows Build Script
REM  Requirements: Python 3.10+  (https://python.org)
REM  Run from the folder containing main.py
REM
REM  Output (3 separate .exe builds):
REM    dist\MiniCentrinoLite\MiniCentrinoLite.exe            → POS terminal
REM    dist\MiniCentrinoLite_KDS\MiniCentrinoLite_KDS.exe    → Kitchen display
REM    dist\MiniCentrinoLite_Hub\MiniCentrinoLite_Hub.exe    → Hub service + admin UI
REM
REM  Deployment:
REM    1. Hub machine (dedicated mini-PC or POS-1):
REM       - Copy dist\MiniCentrinoLite_Hub\ folder
REM       - Open Windows Firewall: allow inbound TCP 9999
REM       - Run MiniCentrinoLite_Hub.exe
REM
REM    2. Each POS machine:
REM       - Copy dist\MiniCentrinoLite\ folder
REM       - Run --setup, set Hub IP to hub machine's LAN IP
REM       - Run MiniCentrinoLite.exe
REM
REM    3. Each KDS machine:
REM       - Copy dist\MiniCentrinoLite_KDS\ folder
REM       - Run --setup, set Hub IP to hub machine's LAN IP
REM       - Run MiniCentrinoLite_KDS.exe
REM ─────────────────────────────────────────────────────────────

setlocal

echo [1/5] Installing build dependencies...
pip install pyinstaller pywin32 pillow supabase --quiet
if errorlevel 1 ( echo ERROR: pip failed. Is Python in PATH? & pause & exit /b 1 )

REM Build icon if assets\icon.ico doesn't exist yet
IF NOT EXIST "assets\icon.ico" (
    echo [2/5] Generating app icon...
    python generate_icon.py
) ELSE (
    echo [2/5] Icon already exists, skipping generation.
)

REM ── Shared PyInstaller flags ──────────────────────────────────
set BASE_FLAGS=--noconfirm --onedir --windowed ^
  --hidden-import "tkinter" ^
  --hidden-import "tkinter.ttk" ^
  --hidden-import "tkinter.messagebox" ^
  --hidden-import "sqlite3" ^
  --hidden-import "win32print" ^
  --hidden-import "win32api"

REM Optional icon
set ICON_FLAG=
IF EXIST "assets\icon.ico" set ICON_FLAG=--icon "assets\icon.ico" --add-data "assets;assets"

echo.
echo [3/5] Building Hub (MiniCentrinoLite_Hub.exe)...
pyinstaller %BASE_FLAGS% %ICON_FLAG% --name "MiniCentrinoLite_Hub" --hidden-import "hub_admin" --hidden-import "auto_backup" --hidden-import "cloud_sync" --hidden-import "supabase" --collect-all "supabase" --collect-all "httpx" --collect-all "httpcore" --collect-all "anyio" --collect-all "pydantic" hub.py
if errorlevel 1 ( echo ERROR: Hub build failed. & pause & exit /b 1 )

echo.
echo [4/5] Building Main Terminal (MiniCentrinoLite.exe)...
pyinstaller %BASE_FLAGS% %ICON_FLAG% --name "MiniCentrinoLite" --hidden-import "pos_client" main.py
if errorlevel 1 ( echo ERROR: Terminal build failed. & pause & exit /b 1 )

echo.
echo [5/5] Building KDS (MiniCentrinoLite_KDS.exe)...
pyinstaller %BASE_FLAGS% %ICON_FLAG% --name "MiniCentrinoLite_KDS" kds_launcher.py
if errorlevel 1 ( echo ERROR: KDS build failed. & pause & exit /b 1 )

echo.
echo ─────────────────────────────────────────────────────────────
echo  BUILD COMPLETE
echo.
echo  Hub      : dist\MiniCentrinoLite_Hub\MiniCentrinoLite_Hub.exe
echo  Terminal : dist\MiniCentrinoLite\MiniCentrinoLite.exe
echo  KDS      : dist\MiniCentrinoLite_KDS\MiniCentrinoLite_KDS.exe
echo.
echo  DEPLOYMENT:
echo  1. Hub machine (dedicated mini-PC or POS-1):
echo     - Copy dist\MiniCentrinoLite_Hub\ folder
echo     - Open Windows Firewall: allow inbound TCP 9999
echo     - Run MiniCentrinoLite_Hub.exe
echo
echo  2. Each POS machine:
echo     - Copy dist\MiniCentrinoLite\ folder
echo     - Run --setup, set Hub IP to hub machine's LAN IP
echo     - Run MiniCentrinoLite.exe
echo
echo  3. Each KDS machine:
echo     - Copy dist\MiniCentrinoLite_KDS\ folder
echo     - Run --setup, set Hub IP to hub machine's LAN IP
echo     - Run MiniCentrinoLite_KDS.exe
echo ─────────────────────────────────────────────────────────────
endlocal
pause
