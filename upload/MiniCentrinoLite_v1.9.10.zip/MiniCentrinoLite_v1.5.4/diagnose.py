"""
Mini Centrino Lite v1.2 — Pre-Deploy Diagnostic Script

Run this on EACH POS and KDS machine BEFORE going live to verify:
  1. Can reach the hub machine on TCP port 9999
  2. Can reach each KDS machine (if applicable)
  3. Local config is correct (hub IP, terminal ID, mode, etc.)
  4. Local DB is reachable and migrations ran
  5. Local menu has expected number of items
  6. (Optional) Pine Labs EDC reachable if enabled

Usage:
  python diagnose.py                    # uses hub_ip from config
  python diagnose.py --hub 192.168.1.10 # override hub IP
  python diagnose.py --port 9999        # override port
  python diagnose.py --edc 192.168.1.100 --edc-port 4002  # also test Pine Labs

Exit codes:
  0 = all checks passed
  1 = one or more checks failed
  2 = script error (couldn't even run)
"""
import sys, os, socket, json, time, sqlite3, traceback

# Add this script's directory to path so we can import config
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
if SCRIPT_DIR not in sys.path:
    sys.path.insert(0, SCRIPT_DIR)

# ANSI colors (works on Windows 10+ and Linux)
class C:
    GREEN  = '\033[92m'
    YELLOW = '\033[93m'
    RED    = '\033[91m'
    CYAN   = '\033[96m'
    BOLD   = '\033[1m'
    END    = '\033[0m'
    # Windows fallback
    if sys.platform == 'win32':
        try:
            import colorama
            colorama.init()
        except ImportError:
            GREEN = YELLOW = RED = CYAN = BOLD = END = ''

def ok(msg):
    print(f"  {C.GREEN}[OK]{C.END}    {msg}")
def warn(msg):
    print(f"  {C.YELLOW}[WARN]{C.END}  {msg}")
def fail(msg):
    print(f"  {C.RED}[FAIL]{C.END}  {msg}")
def info(msg):
    print(f"  {C.CYAN}[INFO]{C.END}  {msg}")
def header(msg):
    print(f"\n{C.BOLD}=== {msg} ==={C.END}")

# ─────────────────────────────────────────────────────────────

def check_tcp(host, port, timeout=3.0) -> bool:
    """Try to open a TCP connection to host:port. Returns True on success."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(timeout)
        s.connect((host, int(port)))
        s.close()
        return True
    except Exception:
        return False

def get_local_ip() -> str:
    """Get this machine's primary LAN IP."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"

# ─────────────────────────────────────────────────────────────

def main():
    # Parse args
    hub_ip_override = None
    hub_port_override = None
    edc_ip = None
    edc_port = 4002

    args = sys.argv[1:]
    i = 0
    while i < len(args):
        if args[i] == "--hub" and i + 1 < len(args):
            hub_ip_override = args[i + 1]; i += 2
        elif args[i] == "--port" and i + 1 < len(args):
            hub_port_override = int(args[i + 1]); i += 2
        elif args[i] == "--edc" and i + 1 < len(args):
            edc_ip = args[i + 1]; i += 2
        elif args[i] == "--edc-port" and i + 1 < len(args):
            edc_port = int(args[i + 1]); i += 2
        elif args[i] in ("-h", "--help"):
            print(__doc__)
            return 0
        else:
            i += 1

    # Load config
    try:
        from config import CFG, DB_PATH, APP_VERSION
    except Exception as e:
        print(f"{C.RED}ERROR: Cannot import config: {e}{C.END}")
        print("Make sure you're running this from the Mini Centrino Lite v1.2 folder.")
        return 2

    hub_ip = hub_ip_override or CFG.get("hub_ip", "")
    hub_port = hub_port_override or int(CFG.get("hub_port_client", CFG.get("hub_port", 9999)))

    print(f"\n{C.BOLD}╔════════════════════════════════════════════════════════════╗{C.END}")
    print(f"{C.BOLD}║   Mini Centrino Lite v{APP_VERSION} — Pre-Deploy Diagnostic       ║{C.END}")
    print(f"{C.BOLD}╚════════════════════════════════════════════════════════════╝{C.END}")

    failures = 0
    warnings = 0

    # ── Section 1: Local environment ─────────────────────────
    header("1. Local Environment")

    local_ip = get_local_ip()
    info(f"This machine's LAN IP: {local_ip}")

    mode = CFG.get("mode", "terminal")
    ok(f"Mode: {mode}")

    if mode == "hub":
        warn("This machine IS the hub. Hub-reachability check will be skipped.")
    elif mode not in ("terminal", "kds", "hub"):
        fail(f"Unknown mode: {mode}")
        failures += 1

    term_id = CFG.get("terminal_id", 1)
    term_name = CFG.get("terminal_name", f"POS-{term_id}")
    if mode == "terminal":
        ok(f"Terminal ID: {term_id}  ({term_name})")
        if term_id < 1 or term_id > 99:
            fail(f"Terminal ID out of range (1-99): {term_id}")
            failures += 1
    elif mode == "kds":
        station = CFG.get("kds_station_id", "KDS-?")
        ok(f"KDS Station ID: {station}")

    # ── Section 2: Hub reachability ──────────────────────────
    header("2. Hub Reachability")

    if mode == "hub":
        info("Skipping hub reachability (this machine IS the hub).")
    elif not hub_ip:
        fail("hub_ip is not set in config. Run --setup or set it in Settings.")
        failures += 1
    elif hub_ip == "0.0.0.0":
        warn(f"hub_ip is '{hub_ip}' (placeholder). Set the real hub machine's LAN IP.")
        warnings += 1
    else:
        info(f"Testing TCP connection to hub at {hub_ip}:{hub_port}...")
        if check_tcp(hub_ip, hub_port, timeout=3.0):
            ok(f"Hub reachable at {hub_ip}:{hub_port}")
            # Try a quick protocol handshake
            try:
                s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                s.settimeout(5.0)
                s.connect((hub_ip, hub_port))
                handshake = {"type": "kds_connect" if mode == "kds" else "pos_connect",
                             "terminal_id": term_id,
                             "terminal_name": term_name}
                if mode == "kds":
                    handshake["station_id"] = CFG.get("kds_station_id", "KDS-?")
                s.sendall((json.dumps(handshake) + "\n").encode("utf-8"))
                # Wait briefly for a response (hub should send menu_snapshot / initial_state)
                s.settimeout(2.0)
                try:
                    data = s.recv(8192)
                    if data:
                        msg_text = data.decode("utf-8", errors="replace").strip().split("\n")[0]
                        try:
                            msg = json.loads(msg_text)
                            ok(f"Hub responded with message type: {msg.get('type', '?')}")
                            if msg.get("type") == "menu_snapshot":
                                items = msg.get("menu", {}).get("items", [])
                                ok(f"Hub sent menu snapshot: {len(items)} items")
                            elif msg.get("type") == "initial_state":
                                kots = msg.get("kots", [])
                                bills = msg.get("bills", [])
                                ok(f"Hub sent initial state: {len(kots)} KOTs, {len(bills)} bills today")
                        except json.JSONDecodeError:
                            warn(f"Hub sent non-JSON response: {msg_text[:80]}")
                            warnings += 1
                    else:
                        warn("Hub accepted connection but sent no data within 2s")
                        warnings += 1
                except socket.timeout:
                    warn("Hub accepted connection but did not respond within 2s (may still be OK)")
                    warnings += 1
                s.close()
            except Exception as e:
                warn(f"Hub TCP connect OK but handshake failed: {e}")
                warnings += 1
        else:
            fail(f"Cannot reach hub at {hub_ip}:{hub_port}")
            print(f"         {C.YELLOW}Possible causes:{C.END}")
            print(f"         - Hub machine is not running MiniCentrinoLite_Hub.exe")
            print(f"         - Hub IP is wrong (expected: actual hub machine's LAN IP)")
            print(f"         - Windows Firewall on hub machine is blocking inbound TCP {hub_port}")
            print(f"         - Both machines are not on the same LAN/Wi-Fi")
            print(f"         {C.YELLOW}How to fix:{C.END}")
            print(f"         1. Verify hub machine is powered on and Hub service is running")
            print(f"         2. On hub machine: ping {local_ip} (your IP) to confirm LAN connectivity")
            print(f"         3. On hub machine: open Windows Firewall → Inbound Rules →")
            print(f"            Add rule → Port → TCP → specific local port {hub_port} → Allow")
            print(f"         4. Verify hub_ip in your config: {hub_ip}")
            failures += 1

    # ── Section 3: Local database ────────────────────────────
    header("3. Local Database")

    if not os.path.exists(str(DB_PATH)):
        if mode == "hub":
            info(f"DB file not yet created at {DB_PATH} (will be created on first hub start)")
        else:
            warn(f"DB file not yet created at {DB_PATH}")
            warn("This is normal on a fresh POS install. Will be created on first hub connection.")
            warnings += 1
    else:
        ok(f"DB exists at: {DB_PATH}")
        try:
            conn = sqlite3.connect(str(DB_PATH))
            conn.row_factory = sqlite3.Row

            # Check menu_items count
            count = conn.execute("SELECT COUNT(*) FROM menu_items").fetchone()[0]
            if count == 0:
                if mode == "hub":
                    warn("menu_items is empty — Hub will seed on first start")
                    warnings += 1
                else:
                    info("menu_items is empty — POS will receive menu from hub on connect")
            else:
                ok(f"menu_items: {count} items")

            # Check v1.2 schema: price column
            cols = [r[1] for r in conn.execute("PRAGMA table_info(menu_items)").fetchall()]
            if "price" in cols:
                ok("v1.2 schema: 'price' column present in menu_items")
            else:
                fail("v1.2 schema: 'price' column MISSING in menu_items")
                fail("  → Run hub once to trigger v1.2 migration")
                failures += 1

            # Check v1.2 schema: packaging_required
            cols = [r[1] for r in conn.execute("PRAGMA table_info(bills)").fetchall()]
            if "packaging_required" in cols:
                ok("v1.2 schema: 'packaging_required' column present in bills")
            else:
                fail("v1.2 schema: 'packaging_required' column MISSING in bills")
                failures += 1

            # Check hub_sync_log exists
            tabs = [r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()]
            if "hub_sync_log" in tabs:
                ok("v1.2 schema: 'hub_sync_log' table exists")
            else:
                fail("v1.2 schema: 'hub_sync_log' table MISSING")
                failures += 1

            conn.close()
        except Exception as e:
            fail(f"Cannot open DB: {e}")
            failures += 1

    # ── Section 4: Local config sanity ───────────────────────
    header("4. Local Config Sanity")

    rest_name = CFG.get("restaurant_name", "")
    if rest_name:
        ok(f"Restaurant name: {rest_name}")
    else:
        warn("restaurant_name is empty")
        warnings += 1

    menu_pin = CFG.get("menu_pin", "1234")
    if menu_pin == "1234":
        warn("Menu PIN is still the default '1234' — change it in Hub Admin → Settings")
        warnings += 1
    else:
        ok(f"Menu PIN is set (not default)")

    if mode == "terminal":
        pkg_mode = CFG.get("packaging_charge_mode", "none")
        pkg_amt = CFG.get("packaging_charge_amount", 0.0)
        if pkg_mode == "none":
            ok(f"Packaging charge mode: none (default — no charge)")
        else:
            ok(f"Packaging charge mode: {pkg_mode}, amount: Rs.{pkg_amt}")

    # ── Section 5: Pine Labs EDC (optional) ──────────────────
    if CFG.get("pl_enabled", False) or edc_ip:
        header("5. Pine Labs EDC")
        pl_ip = edc_ip or CFG.get("pl_edc_ip", "")
        pl_port = edc_port or int(CFG.get("pl_edc_port", 4002))
        if not pl_ip:
            warn("Pine Labs enabled but pl_edc_ip is empty")
            warnings += 1
        else:
            info(f"Testing TCP to EDC at {pl_ip}:{pl_port}...")
            if check_tcp(pl_ip, pl_port, timeout=2.0):
                ok(f"EDC reachable at {pl_ip}:{pl_port}")
            else:
                warn(f"EDC not reachable at {pl_ip}:{pl_port}")
                warn("Make sure the EDC terminal is powered on and on the same LAN")
                warnings += 1

    # ── Section 6: Printer (optional) ────────────────────────
    header("6. Printer")
    printer_name = CFG.get("printer_name", "")
    if printer_name:
        info(f"Configured printer: {printer_name}")
        if sys.platform == "win32":
            try:
                import win32print
                printers = [p[2] for p in win32print.EnumPrinters(
                    win32print.PRINTER_ENUM_LOCAL | win32print.PRINTER_ENUM_CONNECTIONS)]
                if printer_name in printers:
                    ok(f"Printer '{printer_name}' found in Windows")
                else:
                    fail(f"Printer '{printer_name}' NOT FOUND in Windows installed printers")
                    print(f"         Available printers:")
                    for p in printers:
                        print(f"           - {p}")
                    failures += 1
            except ImportError:
                warn("pywin32 not installed — cannot verify printer")
                warnings += 1
        else:
            info("Skipping printer check on non-Windows OS")
    else:
        info("No printer_name set — Windows default printer will be used")

    # ── Summary ──────────────────────────────────────────────
    header("SUMMARY")
    if failures == 0 and warnings == 0:
        print(f"  {C.GREEN}{C.BOLD}ALL CHECKS PASSED — ready to go live!{C.END}")
        result = 0
    elif failures == 0:
        print(f"  {C.YELLOW}{C.BOLD}PASSED with {warnings} warning(s){C.END}")
        print(f"  You can proceed, but review the warnings above.")
        result = 0
    else:
        print(f"  {C.RED}{C.BOLD}FAILED: {failures} error(s), {warnings} warning(s){C.END}")
        print(f"  {C.RED}Fix the errors above before going live.{C.END}")
        result = 1

    print()
    return result

if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        print("\nAborted.")
        sys.exit(2)
    except Exception as e:
        print(f"\n{C.RED}SCRIPT ERROR: {e}{C.END}")
        traceback.print_exc()
        sys.exit(2)
