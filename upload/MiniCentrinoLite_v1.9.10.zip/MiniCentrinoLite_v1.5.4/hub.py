"""
Mini Centrino Lite v1.2 — Hub Service

The Hub is the central coordinator for a multi-POS outlet:
  - Owns the SQLite database (single source of truth)
  - Runs a TCP server on port 9999 (configurable)
  - Accepts connections from POS terminals and KDS screens
  - Broadcasts every event (KOT, bill, status, menu update) to all clients
  - Provides an admin UI (see hub_admin.py) for menu / reports / settings

Deployment:
  Option A (recommended): Run on a dedicated mini-PC plugged into the LAN switch.
  Option B: Run on POS-1 (alongside the POS terminal) — see README.

Launch:
  python hub.py
  python hub.py --headless          # no admin UI, just the service
  python hub.py --port 9999         # override port
"""
import sys, os, socket, threading, json, time, logging
from typing import Optional

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
log = logging.getLogger("mcl.hub")

from config import CFG, save as save_config
import database as db
from network import HubServer
from auto_backup import AutoBackupWorker
from cloud_sync import CloudSyncWorker


APP_NAME    = "Mini Centrino Lite Hub"
APP_VERSION = "1.5.4"
BUILD_FOR   = "Sudhamrit Food Joint | Sri Ma Trust"


class HubService:
    """
    Top-level orchestrator for the hub.
    Owns:
      - The TCP server (HubServer)
      - The database (via database.py)
      - Auto-backup worker (v1.3.3)
      - Cloud sync worker (v1.4.0 — Supabase)
      - Optional admin UI (launched separately)
    """

    def __init__(self, host: str = None, port: int = None):
        self.host = host or CFG.get("hub_host", "0.0.0.0")
        self.port = int(port or CFG.get("hub_port", 9999))
        self.server = None
        self._running = False
        self.backup_worker = None
        self.cloud_worker = None

        # Initialize DB schema
        log.info("Initializing database...")
        db.init_db()
        log.info("Database ready at %s", db.DB_PATH)

        # Callback wiring: when hub receives a message from any client, dispatch it
        self._on_message = self._dispatch_client_message

    # ─────────────────────────────────── Lifecycle ───────────────

    def start(self):
        self._running = True
        self.server = HubServer(host=self.host, port=self.port)
        self.server.on_message = self._on_message
        self.server.start()
        # v1.3.3: Start auto-backup worker
        try:
            self.backup_worker = AutoBackupWorker()
            self.backup_worker.start()
        except Exception as e:
            log.error("Failed to start auto-backup worker: %s", e)
        # v1.4.0: Start cloud sync worker (if enabled)
        if CFG.get("cloud_sync_enabled", False):
            try:
                self.cloud_worker = CloudSyncWorker(hub_service=self)
                if self.cloud_worker.start():
                    log.info("Cloud sync worker started")
                else:
                    log.warning("Cloud sync worker failed to start")
                    self.cloud_worker = None
            except Exception as e:
                log.error("Failed to start cloud sync worker: %s", e)
                self.cloud_worker = None
        log.info("=" * 60)
        log.info("  %s v%s", APP_NAME, APP_VERSION)
        log.info("  Built for: %s", BUILD_FOR)
        log.info("  Listening on %s:%s", self.host, self.port)
        log.info("  Database : %s", db.DB_PATH)
        log.info("  Auto-backup: %s", "ENABLED" if CFG.get("auto_backup_enabled") else "DISABLED")
        log.info("  Cloud sync: %s", "ENABLED" if CFG.get("cloud_sync_enabled") else "DISABLED")
        if CFG.get("cloud_sync_enabled"):
            log.info("  Supabase URL: %s", CFG.get("supabase_url"))
            log.info("  Outlet ID: %s", CFG.get("supabase_outlet_id"))
        log.info("=" * 60)
        log.info("Hub is ready. POS and KDS clients can now connect.")

    def stop(self):
        self._running = False
        if self.cloud_worker:
            try: self.cloud_worker.stop()
            except: pass
        if self.backup_worker:
            try: self.backup_worker.stop()
            except: pass
        if self.server:
            self.server.stop()
        log.info("Hub stopped.")

    # ─────────────────────────────────── Message dispatch ────────

    def _dispatch_client_message(self, msg: dict, conn: socket.socket):
        """
        Called whenever a POS or KDS sends a JSON message to the hub.
        We process it, persist to DB, then broadcast to all OTHER clients.
        """
        mtype = msg.get("type", "")
        try:
            if mtype == "pos_connect":
                self._handle_pos_connect(msg, conn)
            elif mtype == "kds_connect":
                self._handle_kds_connect(msg, conn)
            elif mtype == "sync_request":
                self._handle_sync_request(msg, conn)
            elif mtype == "kot_new":
                self._handle_kot_new(msg, conn)
            elif mtype == "bill_new":
                self._handle_bill_new(msg, conn)
            elif mtype == "status_update":
                self._handle_status_update(msg, conn)
            elif mtype == "kot_status":
                # v1.1 KDS clients send "kot_status" instead of "status_update"
                self._handle_status_update(msg, conn)
            elif mtype == "request_active_kots":
                # v1.1 KDS clients request active KOTs on connect — send them
                self.server.send_to(conn, {
                    "type": "initial_state",
                    "kots": db.get_all_kots_today(),
                })
            elif mtype == "held_recall":
                self._handle_held_recall(msg, conn)
            elif mtype == "menu_update":
                self._handle_menu_update(msg, conn)
            elif mtype == "ping":
                self.server.send_to(conn, {"type": "pong", "ts": time.time()})
            else:
                log.debug("Unknown message type from client: %s", mtype)
        except Exception as e:
            log.error("Error dispatching %s: %s", mtype, e)

    # ─────────────────────────────────── Handlers ────────────────

    def _handle_pos_connect(self, msg, conn):
        term_id = msg.get("terminal_id", 0)
        term_name = msg.get("terminal_name", f"POS-{term_id}")
        log.info("POS connected: T%s (%s)", term_id, term_name)
        # Send current menu snapshot
        snapshot = db.get_menu_snapshot()
        self.server.send_to(conn, {"type": "menu_snapshot", "menu": snapshot})
        # Send today's KOTs and bills (live state)
        self.server.send_to(conn, {
            "type": "initial_state",
            "kots": db.get_all_kots_today(),
            "bills": db.get_all_bills_today(),
        })

    def _handle_kds_connect(self, msg, conn):
        station_id = msg.get("station_id", "KDS-?")
        log.info("KDS connected: %s", station_id)
        # Send today's KOTs (so KDS shows current state)
        self.server.send_to(conn, {
            "type": "initial_state",
            "kots": db.get_all_kots_today(),
        })

    def _handle_sync_request(self, msg, conn):
        snapshot = db.get_menu_snapshot()
        self.server.send_to(conn, {"type": "menu_snapshot", "menu": snapshot})
        self.server.send_to(conn, {
            "type": "initial_state",
            "kots": db.get_all_kots_today(),
            "bills": db.get_all_bills_today(),
        })

    def _handle_kot_new(self, msg, conn):
        """A POS raised a KOT. Save to DB, broadcast to all KDS + other POS."""
        kot = msg.get("kot", {})
        # Use save_kot_sync which handles insert/update by kot_no
        db.save_kot_sync(kot)
        # Broadcast to everyone (including other POS for live KOT monitor)
        self.server.broadcast({"type": "kot_new", "kot": kot}, exclude=conn)
        log.info("KOT #%s broadcast (term=%s, items=%d)",
                 kot.get("kot_no"), kot.get("terminal_id"), len(kot.get("items", [])))

    def _handle_bill_new(self, msg, conn):
        """A POS generated a bill. Save to DB, broadcast to other POS for live Bills tab."""
        bill = msg.get("bill", {})
        db.save_bill_sync(bill)
        self.server.broadcast({"type": "bill_new", "bill": bill}, exclude=conn)
        log.info("Bill #%s broadcast (term=%s, total=Rs.%s)",
                 bill.get("bill_no"), bill.get("terminal_id"), bill.get("total", 0))

    def _handle_status_update(self, msg, conn):
        """KDS or POS updated KOT status. Persist + broadcast."""
        kot_no = msg.get("kot_no")
        new_status = msg.get("status")
        if kot_no and new_status:
            with db._lock:
                conn_db = db.get_conn()
                conn_db.execute("UPDATE kots SET status=?, updated_at=CURRENT_TIMESTAMP WHERE kot_no=?",
                                (new_status, kot_no))
                conn_db.commit()
                conn_db.close()
            self.server.broadcast({"type": "status_update", "kot_no": kot_no, "status": new_status}, exclude=conn)
            log.info("KOT #%s → %s", kot_no, new_status)

    def _handle_held_recall(self, msg, conn):
        """A POS recalled a held bill. Broadcast so other POS can hide it from their list."""
        held_id = msg.get("held_id")
        if held_id:
            self.server.broadcast({"type": "held_recalled", "held_id": held_id}, exclude=conn)

    def _handle_menu_update(self, msg, conn):
        """A POS edited the menu. Apply to DB, broadcast to all OTHER clients."""
        action = msg.get("action")
        payload = msg.get("payload", {})
        db.apply_menu_update(action, payload)
        # Broadcast to everyone EXCEPT the sender (sender already updated locally)
        self.server.broadcast({"type": "menu_update", "action": action, "payload": payload}, exclude=conn)
        log.info("Menu update broadcast: %s", action)


# ─────────────────────────────────────────────────────────────
#  Entry points
# ─────────────────────────────────────────────────────────────

def launch_hub(headless: bool = False, port: int = None):
    """
    Start the hub service. If not headless, also open the admin UI.
    """
    service = HubService(port=port)
    service.start()

    if not headless:
        # Launch admin UI in main thread (blocks)
        try:
            from hub_admin import HubAdminApp
            import tkinter as tk
            root = tk.Tk()
            root.title(f"{APP_NAME} v{APP_VERSION}")
            app = HubAdminApp(root, service)
            root.protocol("WM_DELETE_WINDOW", lambda: (_on_close(root, service)))
            root.mainloop()
        except Exception as e:
            log.error("Admin UI failed: %s. Running headless.", e)
            # Fall through to headless mode
            _run_headless_loop(service)
    else:
        _run_headless_loop(service)


def _run_headless_loop(service: HubService):
    """Block main thread until KeyboardInterrupt."""
    try:
        log.info("Hub running headless. Press Ctrl+C to stop.")
        while service._running:
            time.sleep(1)
    except KeyboardInterrupt:
        log.info("Shutdown requested.")
    finally:
        service.stop()


def _on_close(root, service: HubService):
    import tkinter.messagebox as mb
    if mb.askyesno("Exit", "Stop the Hub service? All POS and KDS clients will lose connection."):
        service.stop()
        root.destroy()


if __name__ == "__main__":
    headless = "--headless" in sys.argv
    port = None
    if "--port" in sys.argv:
        try:
            port = int(sys.argv[sys.argv.index("--port") + 1])
        except (ValueError, IndexError):
            pass
    launch_hub(headless=headless, port=port)
