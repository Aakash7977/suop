@echo off
title Mini Centrino Lite - HUB SERVICE (v1.2)
cd /d "%~dp0"
echo ============================================
echo  Mini Centrino Lite v1.2 - Hub Service
echo ============================================
echo.
echo Starting Hub service...
echo.
echo On this machine, the Hub:
echo   - Owns the central database
echo   - Listens on TCP port 9999
echo   - Receives all POS / KDS connections
echo   - Provides admin UI for menu, reports, settings
echo.
start "" pythonw main.py --hub
exit
