with open('terminal.py', 'r', encoding='utf-8') as f:
    lines = f.readlines()

for i, line in enumerate(lines):
    if 'self.customer' in line:
        safe_line = line.encode('ascii', errors='replace').decode('ascii').strip()
        print(f"{i+1}: {safe_line}")
