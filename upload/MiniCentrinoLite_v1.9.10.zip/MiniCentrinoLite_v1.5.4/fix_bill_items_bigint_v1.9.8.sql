-- ============================================================
-- Mini Centrino Lite v1.9.8 — BILL_ITEMS BILL_NO BIGINT FIX
-- ============================================================
-- ROOT CAUSE: bill_items.bill_no was created as INTEGER, but bill
-- numbers are 13 digits (e.g. 260704010081) which exceeds the
-- INTEGER max of 2,147,483,647 (10 digits).
--
-- This is why bill_items table is EMPTY (0 rows) even though the
-- Hub's cloud_sync is trying to push items. Every insert fails with:
--   "value 260704010081 is out of range for type integer"
--
-- The same bug was fixed for bills.bill_no in v1.5.5 (fix_supabase_v1.5.5.sql)
-- but bill_items.bill_no was missed.
--
-- SYMPTOMS:
--   - Bill detail page (/bills/[id]) shows 0 items
--   - Daily Product Sales Matrix shows no data
--   - Reports page "Item-wise Sales" table is empty
--   - cloud_sync.py logs show "bill_items insert failed for a chunk"
--
-- FIX: Change bill_items.bill_no from INTEGER to BIGINT.
-- After running this, the Hub's backfill routine (v1.9.7+) will
-- successfully push bill_items for all existing bills.
-- ============================================================

-- ────────────────────────────────────────────────────────────
-- 1. Change bill_items.bill_no to BIGINT
-- ────────────────────────────────────────────────────────────
ALTER TABLE public.bill_items ALTER COLUMN bill_no TYPE BIGINT;

-- ────────────────────────────────────────────────────────────
-- 2. Verify the fix worked
-- ────────────────────────────────────────────────────────────
SELECT
    'bill_items.bill_no type' AS check_name,
    data_type
FROM information_schema.columns
WHERE table_name = 'bill_items' AND column_name = 'bill_no';

-- Expected: data_type = 'bigint'

-- ────────────────────────────────────────────────────────────
-- 3. Test: try fetching bill_items by a 13-digit bill_no
-- ────────────────────────────────────────────────────────────
-- This should return an empty array [] (not an error) after the fix.
-- Run this in the SQL editor:
--   SELECT * FROM public.bill_items WHERE bill_no = 260704010081 LIMIT 1;

-- ────────────────────────────────────────────────────────────
-- 4. After running this fix:
-- ────────────────────────────────────────────────────────────
--    a. Restart the Hub (python main.py --hub)
--    b. The Hub's cloud_sync will now successfully push bill_items
--    c. The backfill routine (v1.9.7+) will push items for existing
--       bills at 200 bills/cycle (~22 minutes for ~4,800 bills)
--    d. New bills will have their items pushed immediately
--    e. Refresh the webapp — bill detail pages + Daily Product Sales
--       Matrix will start showing data within a few sync cycles
-- ────────────────────────────────────────────────────────────
