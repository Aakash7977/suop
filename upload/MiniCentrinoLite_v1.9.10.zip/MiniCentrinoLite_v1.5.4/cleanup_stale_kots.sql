-- ============================================================
-- Mini Centrino Lite v1.9.3 — STALE KOT CLEANUP
-- ============================================================
-- Run this in Supabase SQL Editor to mark old KOTs as "served"
-- so they stop inflating the "Active KOTs" count on the dashboard.
--
-- The dashboard now only counts today's active KOTs, but old KOTs
-- from prior days that were never marked "served" will still show
-- up in the KOT Monitor page. This SQL cleans them up.
-- ============================================================

-- Mark ALL KOTs that are NOT today as "served"
-- (they were never explicitly served, but they're old and stale)
UPDATE public.kots
SET status = 'served',
    updated_at = NOW()
WHERE status IN ('pending', 'preparing', 'ready')
  AND kot_date <> to_char(NOW() AT TIME ZONE 'Asia/Kolkata', 'DD/MM/YYYY');

-- Verify: count of active KOTs after cleanup
SELECT
    'Active KOTs after cleanup' AS check_name,
    COUNT(*) AS count
FROM public.kots
WHERE status IN ('pending', 'preparing', 'ready');

-- Expected: should be 0 (or only today's active KOTs if any were created today)

-- Show today's KOTs (if any)
SELECT
    kot_no,
    kot_date,
    kot_time,
    status,
    terminal_id,
    customer_name
FROM public.kots
WHERE kot_date = to_char(NOW() AT TIME ZONE 'Asia/Kolkata', 'DD/MM/YYYY')
ORDER BY kot_no DESC
LIMIT 10;
