-- ============================================================
-- Mini Centrino Lite v1.6.0 — SUPABASE REALTIME SETUP
-- ============================================================
-- Run this ONCE in the Supabase SQL Editor (Dashboard → SQL → New Query)
-- to enable real-time change notifications for the tables that the
-- Next.js HQ webapp subscribes to.
--
-- After running, the webapp's `useRealtime()` hook will receive
-- INSERT / UPDATE / DELETE events on these tables within ~200ms.
-- Until this is run, the webapp falls back to slow polling (60s
-- for bills/held-bills, 30s for KOT monitor, 30s for dashboard).
-- ============================================================

-- Add the 5 tables used by the webapp's Realtime subscriptions.
-- `IF NOT EXISTS` is implicit — ALTER PUBLICATION is idempotent for
-- already-member tables (it'll just say "relation is already member").
ALTER PUBLICATION supabase_realtime ADD TABLE public.bills;
ALTER PUBLICATION supabase_realtime ADD TABLE public.kots;
ALTER PUBLICATION supabase_realtime ADD TABLE public.held_bills;
ALTER PUBLICATION supabase_realtime ADD TABLE public.sync_orders;
ALTER PUBLICATION supabase_realtime ADD TABLE public.outlets;

-- Optional: also add bill_items + menu_items so future features can
-- subscribe to line-item changes (e.g. live stock-out alerts).
ALTER PUBLICATION supabase_realtime ADD TABLE public.bill_items;
ALTER PUBLICATION supabase_realtime ADD TABLE public.menu_items;
ALTER PUBLICATION supabase_realtime ADD TABLE public.menu_sections;
ALTER PUBLICATION supabase_realtime ADD TABLE public.packaging_types;

-- ── VERIFY ──────────────────────────────────────────────────
-- Run this SELECT after to confirm all 9 tables are in the publication.
SELECT
    schemaname AS schema,
    tablename  AS table
FROM pg_publication_tables
WHERE pubname = 'supabase_realtime'
ORDER BY tablename;

-- Expected output (9 rows):
--  public | bill_items
--  public | bills
--  public | held_bills
--  public | kots
--  public | menu_items
--  public | menu_sections
--  public | outlets
--  public | packaging_types
--  public | sync_orders
