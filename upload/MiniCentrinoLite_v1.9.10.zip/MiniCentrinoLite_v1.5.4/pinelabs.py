"""
Mini Centrino Lite — Pine Labs EDC Integration
Protocol : Pine Labs Plutus Smart  –  XML over TCP socket
Terminal  : Connect EDC machine to same LAN; configure static IP on EDC.
Port      : 4002 (default Plutus port; override in Settings if needed).

Flow:
  POS sends XML sale request  →  EDC shows amount on screen
  Customer taps / inserts / swipes card or pays via UPI QR on EDC screen
  EDC returns XML response    →  POS reads RESPONSECODE
  "00" = approved;  anything else = declined / error

Reference: Pine Labs Plutus Smart Integration Guide (contact your Pine Labs
           relationship manager for the latest version).
"""

import socket
import threading
import xml.etree.ElementTree as ET
import logging
from typing import Optional

log = logging.getLogger("mcl.pinelabs")

# ── Operation type codes ────────────────────────────────────────
OP_SALE     = "1"
OP_VOID     = "4"   # Cancel / void last approved txn on same terminal
OP_REFUND   = "2"   # Credit / refund (requires original txn data)
OP_GET_LAST = "5"   # Query last transaction status

# ── Response codes ──────────────────────────────────────────────
RC_APPROVED = "00"

# ── Default connection parameters ───────────────────────────────
DEFAULT_PORT    = 4002
DEFAULT_TIMEOUT = 120    # seconds – customer has this long to tap/swipe


class EDCError(Exception):
    """Raised when the EDC connection or transaction fails."""
    pass


# ─────────────────────────────────────────────────────────────────
#  XML builder
# ─────────────────────────────────────────────────────────────────

def _build_xml(fields: dict) -> bytes:
    """Serialize a dict of tag→value pairs to an XML byte string."""
    root = ET.Element("TRANSACTION")
    for tag, value in fields.items():
        ET.SubElement(root, tag).text = str(value) if value is not None else ""
    # Pine Labs expects UTF-8 XML declaration
    return ET.tostring(root, encoding="utf-8", xml_declaration=True)


def _parse_xml(data: bytes) -> dict:
    """Parse the XML response into a plain dict."""
    try:
        root = ET.fromstring(data)
        return {child.tag: (child.text or "").strip() for child in root}
    except ET.ParseError as e:
        raise EDCError(f"Bad XML from terminal: {e}\nRaw: {data[:200]}")


# ─────────────────────────────────────────────────────────────────
#  Low-level socket I/O
# ─────────────────────────────────────────────────────────────────

def _send_receive(ip: str, port: int, payload: bytes,
                  timeout: int = DEFAULT_TIMEOUT) -> bytes:
    """
    Open TCP connection, send XML payload, read response until socket closes.
    Pine Labs terminals close the connection after sending the response.
    """
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(timeout)
    try:
        log.debug("Connecting to EDC %s:%s", ip, port)
        sock.connect((ip, int(port)))
        sock.sendall(payload)
        log.debug("Request sent (%d bytes); waiting for response…", len(payload))

        # Read until terminal closes connection
        chunks = []
        while True:
            chunk = sock.recv(4096)
            if not chunk:
                break
            chunks.append(chunk)

        response = b"".join(chunks)
        log.debug("Response received (%d bytes)", len(response))
        if not response:
            raise EDCError("Empty response from terminal – is it powered on?")
        return response

    except socket.timeout:
        raise EDCError(
            "Timeout – the terminal did not respond within "
            f"{timeout} seconds.\n"
            "Check that the customer has completed the transaction "
            "and the terminal is reachable on the network."
        )
    except ConnectionRefusedError:
        raise EDCError(
            f"Connection refused ({ip}:{port}).\n"
            "Ensure the Pine Labs terminal is powered on, connected "
            "to the same LAN, and its IP/port settings are correct."
        )
    except OSError as e:
        raise EDCError(f"Network error: {e}")
    finally:
        try:
            sock.close()
        except Exception:
            pass


# ─────────────────────────────────────────────────────────────────
#  High-level transaction helpers
# ─────────────────────────────────────────────────────────────────

def sale(amount_rupees: float, invoice_no: str,
         store_id: str, terminal_sn: str,
         ip: str, port: int = DEFAULT_PORT,
         timeout: int = DEFAULT_TIMEOUT) -> dict:
    """
    Initiate a card / UPI sale on the Pine Labs EDC terminal.

    Parameters
    ----------
    amount_rupees  : Bill total in rupees (will be converted to paise).
    invoice_no     : Unique reference (e.g. "BILL0001") – shown on slip.
    store_id       : MERCHANTSTOREID from Pine Labs provisioning.
    terminal_sn    : MERCHANTTERMINALSERIALNUMBER from Pine Labs provisioning.
    ip             : LAN IP address of the EDC terminal.
    port           : TCP port (default 4002).
    timeout        : Seconds to wait for customer to complete payment.

    Returns
    -------
    dict with keys:
        approved       : bool
        response_code  : str  ("00" = approved)
        approval_code  : str
        txn_id         : str
        card_scheme    : str  ("VISA", "MASTERCARD", "RUPAY", …)
        masked_card    : str  ("XXXXXXXXXXXX1234")
        approved_amount: int  (paise)
        batch_no       : str
        pl_invoice_no  : str  (Pine Labs invoice number, for void)
        message        : str  (human-readable status)
        raw            : dict (full parsed XML response)

    Raises
    ------
    EDCError on network / protocol failure.
    """
    amount_paise = int(round(amount_rupees * 100))
    payload = _build_xml({
        "MERCHANTSTOREID":             store_id,
        "MERCHANTTERMINALSERIALNUMBER": terminal_sn,
        "OPERATIONTYPE":               OP_SALE,
        "AMOUNT":                      amount_paise,
        "ORIGINALINVOICENUMBER":       invoice_no,
        "COMMUNICATIONFORMAT":         "XML",
        "RESPONSECODEFORMAT":          "Y",
    })

    log.info("Pine Labs SALE  invoice=%s  amount=₹%.2f  terminal=%s",
             invoice_no, amount_rupees, ip)
    raw_response = _send_receive(ip, port, payload, timeout)
    resp = _parse_xml(raw_response)
    log.info("Pine Labs response: %s", resp)

    rc       = resp.get("RESPONSECODE", "")
    approved = (rc == RC_APPROVED)

    result = {
        "approved":        approved,
        "response_code":   rc,
        "approval_code":   resp.get("APPROVALNUMBER", ""),
        "txn_id":          resp.get("TRANSACTIONID", ""),
        "card_scheme":     resp.get("CARDSCHEMENAME") or resp.get("CARDSCHEME", ""),
        "masked_card":     resp.get("MASKEDCARDNUMBER", ""),
        "approved_amount": int(resp.get("APPROVEDAMOUNT", 0) or 0),
        "batch_no":        resp.get("BATCHNUMBER", ""),
        "pl_invoice_no":   resp.get("INVOICENUMBER", ""),
        "message":         "Approved" if approved else _decline_message(rc),
        "raw":             resp,
    }
    return result


def void(original_invoice_no: str, pl_invoice_no: str,
         batch_no: str, amount_rupees: float,
         store_id: str, terminal_sn: str,
         ip: str, port: int = DEFAULT_PORT,
         timeout: int = 60) -> dict:
    """
    Void / cancel the last approved transaction on the terminal.
    Must be called on the same day before batch settlement.

    Returns same structure as sale().
    """
    amount_paise = int(round(amount_rupees * 100))
    payload = _build_xml({
        "MERCHANTSTOREID":             store_id,
        "MERCHANTTERMINALSERIALNUMBER": terminal_sn,
        "OPERATIONTYPE":               OP_VOID,
        "AMOUNT":                      amount_paise,
        "ORIGINALINVOICENUMBER":       original_invoice_no,
        "BATCHNUMBER":                 batch_no,
        "INVOICENUMBER":               pl_invoice_no,
        "COMMUNICATIONFORMAT":         "XML",
        "RESPONSECODEFORMAT":          "Y",
    })

    log.info("Pine Labs VOID  orig_invoice=%s  batch=%s  terminal=%s",
             original_invoice_no, batch_no, ip)
    raw_response = _send_receive(ip, port, payload, timeout)
    resp = _parse_xml(raw_response)
    log.info("Pine Labs VOID response: %s", resp)

    rc = resp.get("RESPONSECODE", "")
    approved = (rc == RC_APPROVED)
    return {
        "approved":        approved,
        "response_code":   rc,
        "approval_code":   resp.get("APPROVALNUMBER", ""),
        "txn_id":          resp.get("TRANSACTIONID", ""),
        "message":         "Void successful" if approved else _decline_message(rc),
        "raw":             resp,
    }


def test_connection(ip: str, port: int = DEFAULT_PORT, timeout: int = 5) -> tuple[bool, str]:
    """
    Quick connectivity check – just TCP handshake, no transaction.
    Returns (success: bool, message: str).
    """
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(timeout)
        s.connect((ip, int(port)))
        s.close()
        return True, f"Connected to Pine Labs EDC at {ip}:{port}"
    except socket.timeout:
        return False, f"Timeout – no response from {ip}:{port} in {timeout}s"
    except ConnectionRefusedError:
        return False, f"Connection refused at {ip}:{port} – terminal offline?"
    except OSError as e:
        return False, f"Network error: {e}"


def _decline_message(rc: str) -> str:
    """Map common Pine Labs response codes to human-readable messages."""
    codes = {
        "01": "Refer to card issuer",
        "05": "Do not honour – card declined",
        "12": "Invalid transaction",
        "14": "Invalid card number",
        "51": "Insufficient funds",
        "54": "Expired card",
        "55": "Incorrect PIN",
        "57": "Transaction not permitted",
        "61": "Exceeds withdrawal limit",
        "91": "Card issuer unavailable – try again",
        "96": "System malfunction",
        "Z3": "Transaction cancelled by customer",
        "":   "No response code – terminal may have timed out",
    }
    return codes.get(rc, f"Declined (code {rc})")


# ─────────────────────────────────────────────────────────────────
#  Async wrapper – runs transaction in background thread
# ─────────────────────────────────────────────────────────────────

class AsyncSale:
    """
    Run a Pine Labs sale in a background thread.
    GUI calls start(), then polls is_done / get_result().
    """

    def __init__(self, amount_rupees: float, invoice_no: str,
                 store_id: str, terminal_sn: str,
                 ip: str, port: int, timeout: int):
        self._args   = (amount_rupees, invoice_no, store_id, terminal_sn, ip, port, timeout)
        self._result : Optional[dict] = None
        self._error  : Optional[str]  = None
        self._done   = threading.Event()
        self._thread : Optional[threading.Thread] = None

    def start(self):
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def _run(self):
        try:
            self._result = sale(*self._args)
        except EDCError as e:
            self._error = str(e)
        except Exception as e:
            self._error = f"Unexpected error: {e}"
        finally:
            self._done.set()

    @property
    def is_done(self) -> bool:
        return self._done.is_set()

    def get_result(self) -> tuple[Optional[dict], Optional[str]]:
        """Returns (result, error_message). One will be None."""
        return self._result, self._error
