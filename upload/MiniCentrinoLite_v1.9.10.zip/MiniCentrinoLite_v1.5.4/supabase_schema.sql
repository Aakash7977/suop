-- ============================================================
-- Mini Centrino Lite v1.5.0 — Supabase Schema
-- Restaurant POS Cloud Sync Schema
-- Sudhamrit Food Joint | Sri Ma Trust
-- ============================================================
--
-- This schema is the cloud-side companion to the local SQLite DB owned
-- by the POS hub. The hub pushes bills / KOTs / menu / packaging here,
-- and the Next.js web dashboard reads from these tables.
--
-- Tables (14 total, all carrying outlet_id for multi-outlet separation):
--   1.  outlets              — one row per physical restaurant location
--   2.  web_users            — login accounts for the web dashboard
--   3.  menu_sections        — POS menu sections (mirrored from local)
--   4.  menu_items           — POS menu items (mirrored from local)
--   5.  bills                — finalised bills pushed from POS hub
--   6.  bill_items           — line items per bill (for analytics)
--   7.  kots                 — Kitchen Order Tickets pushed from POS hub
--   8.  kot_items            — line items per KOT (for analytics)
--   9.  held_bills           — bills on hold (parked orders)
--   10. packaging_types      — packaging options (mirrored from local)
--   11. product_packaging    — item → packaging mapping
--   12. sync_menu_updates    — outbound: web → POS hub (menu edits)
--   13. sync_orders          — inbound: web → POS hub → KDS (new orders)
--   14. sync_audit_log       — diagnostic log of all sync activity
--
-- RLS POLICY:
--   RLS is DISABLED on all tables. This is intentional — the POS hub
--   connects with the anon key over a LAN and RLS causes permission
--   errors in that scenario. If you ever expose the web app publicly,
--   enable RLS and add proper policies based on auth.uid(). The
--   companion file disable_rls.sql performs the actual DISABLE statements
--   (kept separate so it can be re-run safely after any schema change).
--
--   RLS disabled for LAN-only deployment. Enable if making web app public.
--
-- NOTE ON auth SCHEMA:
--   We do NOT create any functions in the `auth` schema. All helper
--   functions live in `public`. Web login verification is done by the
--   Next.js app using bcrypt against web_users.password_hash — there
--   are no Supabase-Auth triggers here.
-- ============================================================

-- ─────────────────────────────────────────────────────────────
-- Extensions
-- ─────────────────────────────────────────────────────────────
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- ─────────────────────────────────────────────────────────────
-- 1. outlets
-- ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.outlets (
    id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    code          TEXT UNIQUE NOT NULL,
    name          TEXT NOT NULL,
    address       TEXT DEFAULT '',
    city          TEXT DEFAULT '',
    phone         TEXT DEFAULT '',
    gstin         TEXT DEFAULT '',
    tagline       TEXT DEFAULT '',
    is_active     BOOLEAN DEFAULT TRUE,
    hub_version   TEXT DEFAULT '',
    last_seen_at  TIMESTAMPTZ,
    created_at    TIMESTAMPTZ DEFAULT NOW(),
    updated_at    TIMESTAMPTZ DEFAULT NOW()
);
COMMENT ON TABLE public.outlets IS
    'One row per restaurant outlet. The POS hub sends a heartbeat to update last_seen_at.';

-- ─────────────────────────────────────────────────────────────
-- 2. web_users — logins for the Next.js web dashboard
-- ─────────────────────────────────────────────────────────────
-- password_hash is a bcrypt hash produced by pgcrypto's crypt()
-- function. To verify a password at login:
--     crypt(input_password, password_hash) = password_hash
CREATE TABLE IF NOT EXISTS public.web_users (
    id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    outlet_id     UUID REFERENCES public.outlets(id) ON DELETE CASCADE,
    email         TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    full_name     TEXT DEFAULT '',
    role          TEXT DEFAULT 'staff',   -- 'owner' | 'manager' | 'staff'
    is_active     BOOLEAN DEFAULT TRUE,
    last_login_at TIMESTAMPTZ,
    created_at    TIMESTAMPTZ DEFAULT NOW(),
    updated_at    TIMESTAMPTZ DEFAULT NOW()
);
COMMENT ON TABLE public.web_users IS
    'Web dashboard logins. password_hash is bcrypt via pgcrypto crypt().';

-- ─────────────────────────────────────────────────────────────
-- 3. menu_sections
-- ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.menu_sections (
    id         UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    outlet_id  UUID NOT NULL REFERENCES public.outlets(id) ON DELETE CASCADE,
    local_id   INTEGER NOT NULL,            -- matches menu_sections.id on the hub
    name       TEXT NOT NULL,
    sort_order INTEGER DEFAULT 0,
    is_active  BOOLEAN DEFAULT TRUE,
    synced_at  TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE (outlet_id, local_id)
);

-- ─────────────────────────────────────────────────────────────
-- 4. menu_items
-- ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.menu_items (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    outlet_id           UUID NOT NULL REFERENCES public.outlets(id) ON DELETE CASCADE,
    local_id            INTEGER NOT NULL,            -- matches menu_items.id on the hub
    section_local_id    INTEGER NOT NULL,            -- matches menu_sections.id (local) on the hub
    name                TEXT NOT NULL,
    code                TEXT DEFAULT '',
    price               NUMERIC(10,2) DEFAULT 0,
    is_active           BOOLEAN DEFAULT TRUE,
    sort_order          INTEGER DEFAULT 0,
    stock_quantity       INTEGER DEFAULT -1,         -- -1 = not tracked
    low_stock_threshold  INTEGER DEFAULT 10,
    synced_at           TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE (outlet_id, local_id)
);

-- ─────────────────────────────────────────────────────────────
-- 5. bills — finalised bills pushed from POS hub
-- ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.bills (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    outlet_id           UUID NOT NULL REFERENCES public.outlets(id) ON DELETE CASCADE,
    bill_no             INTEGER NOT NULL,
    bill_date           TEXT NOT NULL,               -- "DD/MM/YYYY" as stored locally
    bill_time           TEXT NOT NULL,               -- "HH:MM" as stored locally
    table_no            TEXT DEFAULT '',
    customer_name       TEXT DEFAULT '',
    order_source        TEXT DEFAULT 'walkin',       -- walkin | swiggy | zomato | ...
    subtotal            NUMERIC(10,2) DEFAULT 0,
    cgst                NUMERIC(10,2) DEFAULT 0,
    sgst                NUMERIC(10,2) DEFAULT 0,
    discount_amount     NUMERIC(10,2) DEFAULT 0,
    delivery_charges    NUMERIC(10,2) DEFAULT 0,
    packaging_charge    NUMERIC(10,2) DEFAULT 0,
    total               NUMERIC(10,2) DEFAULT 0,
    packaging_required  BOOLEAN DEFAULT FALSE,
    payment_mode        TEXT DEFAULT 'cash',
    pl_voided           BOOLEAN DEFAULT FALSE,       -- TRUE = Pine Labs voided sale
    terminal_id         INTEGER DEFAULT 1,
    synced_at           TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE (outlet_id, bill_no)
);
COMMENT ON TABLE public.bills IS
    'Finalised bills pushed from POS hub. pl_voided=TRUE marks Pine Labs voided sales.';

-- ─────────────────────────────────────────────────────────────
-- 6. bill_items — line items per bill (for analytics / item sales)
-- ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.bill_items (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    outlet_id       UUID NOT NULL REFERENCES public.outlets(id) ON DELETE CASCADE,
    bill_id         UUID NOT NULL REFERENCES public.bills(id) ON DELETE CASCADE,
    bill_no         INTEGER NOT NULL,
    item_name       TEXT NOT NULL,
    section         TEXT DEFAULT '',
    unit_price      NUMERIC(10,2) DEFAULT 0,
    quantity        INTEGER DEFAULT 1,
    amount          NUMERIC(10,2) DEFAULT 0,
    item_type       TEXT DEFAULT 'dine-in',
    notes           TEXT DEFAULT '',
    packaging_type  TEXT DEFAULT ''
);

-- ─────────────────────────────────────────────────────────────
-- 7. kots — Kitchen Order Tickets pushed from POS hub
-- ─────────────────────────────────────────────────────────────
-- `items` is stored as JSONB for compactness and easy broadcasting to
-- the KDS via Supabase Realtime. kot_items (table 8) is the normalized
-- version kept for SQL-level analytics.
CREATE TABLE IF NOT EXISTS public.kots (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    outlet_id           UUID NOT NULL REFERENCES public.outlets(id) ON DELETE CASCADE,
    kot_no              INTEGER NOT NULL,
    kot_date            TEXT NOT NULL,
    kot_time            TEXT NOT NULL,
    table_no            TEXT DEFAULT '',
    customer_name       TEXT DEFAULT '',
    order_source        TEXT DEFAULT 'walkin',
    status              TEXT DEFAULT 'pending',      -- pending | preparing | ready | served | cancelled
    packaging_required  BOOLEAN DEFAULT FALSE,
    terminal_id         INTEGER DEFAULT 1,
    items               JSONB DEFAULT '[]'::jsonb,
    synced_at           TIMESTAMPTZ DEFAULT NOW(),
    updated_at          TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE (outlet_id, kot_no)
);
COMMENT ON TABLE public.kots IS
    'KOTs pushed from POS hub. Status is updated by KDS via the hub and re-pushed.';

-- ─────────────────────────────────────────────────────────────
-- 8. kot_items — normalized KOT line items (for analytics)
-- ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.kot_items (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    outlet_id       UUID NOT NULL REFERENCES public.outlets(id) ON DELETE CASCADE,
    kot_id          UUID NOT NULL REFERENCES public.kots(id) ON DELETE CASCADE,
    kot_no          INTEGER NOT NULL,
    item_name       TEXT NOT NULL,
    quantity        INTEGER DEFAULT 1,
    item_type       TEXT DEFAULT 'dine-in',
    notes           TEXT DEFAULT '',
    packaging_type  TEXT DEFAULT ''
);

-- ─────────────────────────────────────────────────────────────
-- 9. held_bills — bills on hold (parked orders)
-- ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.held_bills (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    outlet_id           UUID NOT NULL REFERENCES public.outlets(id) ON DELETE CASCADE,
    local_id            INTEGER NOT NULL,            -- matches held_bills.id on the hub
    date                TEXT NOT NULL,
    time                TEXT NOT NULL,
    table_no            TEXT DEFAULT '',
    customer_name       TEXT DEFAULT '',
    order_type          TEXT DEFAULT 'dine-in',
    subtotal            NUMERIC(10,2) DEFAULT 0,
    cgst                NUMERIC(10,2) DEFAULT 0,
    sgst                NUMERIC(10,2) DEFAULT 0,
    total               NUMERIC(10,2) DEFAULT 0,
    payment_mode        TEXT DEFAULT 'cash',
    notes               TEXT DEFAULT '',
    terminal_id         INTEGER DEFAULT 1,
    packaging_required  BOOLEAN DEFAULT FALSE,
    items               JSONB DEFAULT '[]'::jsonb,
    synced_at           TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE (outlet_id, local_id)
);

-- ─────────────────────────────────────────────────────────────
-- 10. packaging_types
-- ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.packaging_types (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    outlet_id           UUID NOT NULL REFERENCES public.outlets(id) ON DELETE CASCADE,
    local_id            INTEGER NOT NULL,            -- matches packaging_types.id on the hub
    name                TEXT NOT NULL,
    code                TEXT DEFAULT '',
    description         TEXT DEFAULT '',
    charge              NUMERIC(10,2) DEFAULT 0,
    is_active           BOOLEAN DEFAULT TRUE,
    stock_quantity       INTEGER DEFAULT -1,         -- -1 = not tracked
    low_stock_threshold  INTEGER DEFAULT 10,
    synced_at           TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE (outlet_id, local_id)
);

-- ─────────────────────────────────────────────────────────────
-- 11. product_packaging — mapping items to packaging types
-- ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.product_packaging (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    outlet_id           UUID NOT NULL REFERENCES public.outlets(id) ON DELETE CASCADE,
    item_local_id       INTEGER NOT NULL,            -- matches menu_items.id (local)
    packaging_local_id  INTEGER NOT NULL,            -- matches packaging_types.id (local)
    is_default          BOOLEAN DEFAULT FALSE,
    synced_at           TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE (outlet_id, item_local_id, packaging_local_id)
);

-- ─────────────────────────────────────────────────────────────
-- 12. sync_menu_updates — outbound: web dashboard → POS hub
-- ─────────────────────────────────────────────────────────────
-- Rows here are pulled by the hub's CloudSyncWorker (every 30s by
-- default). After applying, the hub sets applied_at and the row no
-- longer matches the "applied_at IS NULL" filter.
CREATE TABLE IF NOT EXISTS public.sync_menu_updates (
    id          BIGSERIAL PRIMARY KEY,
    outlet_id   UUID NOT NULL REFERENCES public.outlets(id) ON DELETE CASCADE,
    action      TEXT NOT NULL,           -- price_change | add_item | delete_item | toggle_active
                                         -- | add_section | update_section | delete_section
    payload     JSONB NOT NULL DEFAULT '{}'::jsonb,
    status      TEXT DEFAULT 'pending',  -- pending | applied | error
    applied_at  TIMESTAMPTZ,
    created_at  TIMESTAMPTZ DEFAULT NOW(),
    created_by  TEXT DEFAULT 'web'
);

-- ─────────────────────────────────────────────────────────────
-- 13. sync_orders — inbound: web app → POS hub → KDS
-- ─────────────────────────────────────────────────────────────
-- Online orders created on the web dashboard land here. The hub's
-- CloudSyncWorker picks them up, creates a local KOT, broadcasts to KDS,
-- and marks the row as 'processed' with the local kot_no filled in.
CREATE TABLE IF NOT EXISTS public.sync_orders (
    id                    BIGSERIAL PRIMARY KEY,
    outlet_id             UUID NOT NULL REFERENCES public.outlets(id) ON DELETE CASCADE,
    items                 JSONB NOT NULL DEFAULT '[]'::jsonb,
    customer_name         TEXT DEFAULT '',
    customer_phone        TEXT DEFAULT '',
    customer_address      TEXT DEFAULT '',
    order_source          TEXT DEFAULT 'walkin',     -- walkin | swiggy | zomato | web | ...
    order_type            TEXT DEFAULT 'dine-in',    -- dine-in | parcel
    packaging_required    BOOLEAN DEFAULT FALSE,
    table_no              TEXT DEFAULT '',
    notes                 TEXT DEFAULT '',
    aggregator_order_id   TEXT DEFAULT '',
    total_amount          NUMERIC(10,2) DEFAULT 0,
    status                TEXT DEFAULT 'pending',    -- pending | processing | processed | error
    kot_no                INTEGER,                   -- filled by hub when KOT is created
    processed_at          TIMESTAMPTZ,
    error_message         TEXT DEFAULT '',
    created_at            TIMESTAMPTZ DEFAULT NOW()
);

-- ─────────────────────────────────────────────────────────────
-- 14. sync_audit_log — diagnostic log of all sync activity
-- ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.sync_audit_log (
    id           BIGSERIAL PRIMARY KEY,
    outlet_id    UUID REFERENCES public.outlets(id) ON DELETE SET NULL,
    direction    TEXT NOT NULL,           -- 'push' | 'pull' | 'heartbeat'
    entity       TEXT NOT NULL,           -- 'bills' | 'kots' | 'menu' | 'orders' | ...
    record_count INTEGER DEFAULT 0,
    status       TEXT DEFAULT 'ok',       -- 'ok' | 'error'
    error        TEXT DEFAULT '',
    created_at   TIMESTAMPTZ DEFAULT NOW()
);


-- ============================================================
-- Indexes
-- (In addition to the UNIQUE constraints defined above, which
-- already create indexes on those column combos.)
-- ============================================================
CREATE INDEX IF NOT EXISTS idx_bills_outlet_date      ON public.bills          (outlet_id, bill_date);
CREATE INDEX IF NOT EXISTS idx_bills_outlet_no        ON public.bills          (outlet_id, bill_no);
CREATE INDEX IF NOT EXISTS idx_bills_voided           ON public.bills          (pl_voided);
CREATE INDEX IF NOT EXISTS idx_bill_items_outlet_no   ON public.bill_items     (outlet_id, bill_no);
CREATE INDEX IF NOT EXISTS idx_bill_items_bill        ON public.bill_items     (bill_id);
CREATE INDEX IF NOT EXISTS idx_bill_items_item        ON public.bill_items     (outlet_id, item_name);
CREATE INDEX IF NOT EXISTS idx_kots_outlet_no         ON public.kots           (outlet_id, kot_no);
CREATE INDEX IF NOT EXISTS idx_kots_outlet_status     ON public.kots           (outlet_id, status);
CREATE INDEX IF NOT EXISTS idx_kots_outlet_date       ON public.kots           (outlet_id, kot_date);
CREATE INDEX IF NOT EXISTS idx_kot_items_outlet_no    ON public.kot_items      (outlet_id, kot_no);
CREATE INDEX IF NOT EXISTS idx_kot_items_kot          ON public.kot_items      (kot_id);
CREATE INDEX IF NOT EXISTS idx_menu_sections_outlet   ON public.menu_sections  (outlet_id);
CREATE INDEX IF NOT EXISTS idx_menu_items_outlet      ON public.menu_items     (outlet_id);
CREATE INDEX IF NOT EXISTS idx_menu_items_section     ON public.menu_items     (outlet_id, section_local_id);
CREATE INDEX IF NOT EXISTS idx_menu_items_code        ON public.menu_items     (outlet_id, code);
CREATE INDEX IF NOT EXISTS idx_held_bills_outlet      ON public.held_bills     (outlet_id);
CREATE INDEX IF NOT EXISTS idx_packaging_outlet       ON public.packaging_types (outlet_id);
CREATE INDEX IF NOT EXISTS idx_product_packaging_outlet ON public.product_packaging (outlet_id);
CREATE INDEX IF NOT EXISTS idx_web_users_outlet       ON public.web_users      (outlet_id);
CREATE INDEX IF NOT EXISTS idx_web_users_email        ON public.web_users      (email);
CREATE INDEX IF NOT EXISTS idx_outlets_code           ON public.outlets        (code);
CREATE INDEX IF NOT EXISTS idx_outlets_active         ON public.outlets        (is_active);

-- Partial indexes for the hot sync paths. These keep the pending-rows
-- lookup fast even when the audit-style tables grow large.
CREATE INDEX IF NOT EXISTS idx_sync_menu_updates_outlet_pending
    ON public.sync_menu_updates (outlet_id, created_at)
    WHERE applied_at IS NULL;

CREATE INDEX IF NOT EXISTS idx_sync_orders_outlet_status
    ON public.sync_orders (outlet_id, created_at)
    WHERE status = 'pending';

CREATE INDEX IF NOT EXISTS idx_sync_audit_outlet_created
    ON public.sync_audit_log (outlet_id, created_at DESC);


-- ============================================================
-- RLS — DISABLED
-- ============================================================
-- RLS disabled for LAN-only deployment. Enable if making web app public.
--
-- We intentionally do NOT add ENABLE ROW LEVEL SECURITY or any POLICY
-- statements here. The POS hub connects with the anon key over a LAN
-- and RLS causes permission errors in that scenario.
--
-- If you ever expose the web app publicly, run:
--   ALTER TABLE public.<table> ENABLE ROW LEVEL SECURITY;
--   CREATE POLICY <policy_name> ON public.<table>
--     FOR SELECT USING (true);   -- or auth.uid()-based check
--
-- The companion file disable_rls.sql performs the inverse operation
-- (DISABLE ROW LEVEL SECURITY on all 14 tables) and can be re-run any
-- time after a schema change to force RLS off again.


-- ============================================================
-- Triggers — auto-update updated_at on UPDATE
-- ============================================================
-- A single reusable trigger function in public schema (NOT auth schema).
CREATE OR REPLACE FUNCTION public.update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_outlets_updated_at ON public.outlets;
CREATE TRIGGER trg_outlets_updated_at
    BEFORE UPDATE ON public.outlets
    FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();

DROP TRIGGER IF EXISTS trg_web_users_updated_at ON public.web_users;
CREATE TRIGGER trg_web_users_updated_at
    BEFORE UPDATE ON public.web_users
    FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();

DROP TRIGGER IF EXISTS trg_kots_updated_at ON public.kots;
CREATE TRIGGER trg_kots_updated_at
    BEFORE UPDATE ON public.kots
    FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();


-- ============================================================
-- Views
-- ============================================================

-- v_daily_revenue — total sales per outlet per day (excludes voided bills)
CREATE OR REPLACE VIEW public.v_daily_revenue AS
SELECT
    outlet_id,
    bill_date AS revenue_date,
    COUNT(*)  AS bill_count,
    SUM(subtotal)         AS subtotal,
    SUM(cgst)             AS cgst,
    SUM(sgst)             AS sgst,
    SUM(discount_amount)  AS discount,
    SUM(delivery_charges) AS delivery,
    SUM(packaging_charge) AS packaging,
    SUM(total)            AS total,
    SUM(CASE WHEN payment_mode = 'cash'   THEN total ELSE 0 END) AS cash_total,
    SUM(CASE WHEN payment_mode <> 'cash'  THEN total ELSE 0 END) AS non_cash_total
FROM public.bills
WHERE pl_voided = FALSE
GROUP BY outlet_id, bill_date;

-- v_item_sales — per-item sales rolled up from bill_items
CREATE OR REPLACE VIEW public.v_item_sales AS
SELECT
    bi.outlet_id,
    b.bill_date,
    bi.item_name,
    bi.section,
    SUM(bi.quantity) AS qty_sold,
    SUM(bi.amount)   AS revenue
FROM public.bill_items bi
JOIN public.bills b ON bi.bill_id = b.id
WHERE b.pl_voided = FALSE
GROUP BY bi.outlet_id, b.bill_date, bi.item_name, bi.section;

-- v_active_kots — KOTs not yet served (for KDS dashboards)
CREATE OR REPLACE VIEW public.v_active_kots AS
SELECT
    outlet_id,
    kot_no,
    kot_date,
    kot_time,
    table_no,
    customer_name,
    order_source,
    status,
    packaging_required,
    terminal_id,
    items,
    updated_at
FROM public.kots
WHERE status IN ('pending', 'preparing', 'ready')
ORDER BY kot_date DESC, kot_no DESC;

-- v_outlet_summary — one row per outlet with latest activity counts
CREATE OR REPLACE VIEW public.v_outlet_summary AS
SELECT
    o.id             AS outlet_id,
    o.code,
    o.name,
    o.city,
    o.is_active,
    o.last_seen_at,
    (SELECT COUNT(*) FROM public.bills       b WHERE b.outlet_id = o.id) AS total_bills,
    (SELECT COUNT(*) FROM public.kots        k WHERE k.outlet_id = o.id) AS total_kots,
    (SELECT COUNT(*) FROM public.menu_items  m WHERE m.outlet_id = o.id AND m.is_active = TRUE) AS active_menu_items,
    (SELECT COUNT(*) FROM public.sync_orders s WHERE s.outlet_id = o.id AND s.status = 'pending') AS pending_orders
FROM public.outlets o;


-- ============================================================
-- Helper functions (public schema — NOT auth schema)
-- ============================================================
-- These mirror the SQLite-side daily_report() and get_item_sales_report()
-- functions in database.py so the web dashboard can show the same numbers.

-- get_daily_report(p_outlet_id UUID, p_date TEXT)
--   Returns one row matching the structure of db.daily_report(date)
--   on the POS hub. p_date is in 'DD/MM/YYYY' format (same as stored
--   locally on the hub).
CREATE OR REPLACE FUNCTION public.get_daily_report(
    p_outlet_id UUID,
    p_date      TEXT
) RETURNS TABLE (
    outlet_id     UUID,
    report_date   TEXT,
    bill_count    BIGINT,
    voided_count  BIGINT,
    subtotal      NUMERIC,
    cgst          NUMERIC,
    sgst          NUMERIC,
    total         NUMERIC,
    cash_total    NUMERIC,
    non_cash_total NUMERIC
) AS $$
    SELECT
        p_outlet_id,
        p_date,
        COUNT(*) FILTER (WHERE pl_voided = FALSE) AS bill_count,
        COUNT(*) FILTER (WHERE pl_voided = TRUE)  AS voided_count,
        COALESCE(SUM(subtotal) FILTER (WHERE pl_voided = FALSE), 0)::NUMERIC,
        COALESCE(SUM(cgst)     FILTER (WHERE pl_voided = FALSE), 0)::NUMERIC,
        COALESCE(SUM(sgst)     FILTER (WHERE pl_voided = FALSE), 0)::NUMERIC,
        COALESCE(SUM(total)    FILTER (WHERE pl_voided = FALSE), 0)::NUMERIC,
        COALESCE(SUM(total)    FILTER (WHERE pl_voided = FALSE AND payment_mode = 'cash'),  0)::NUMERIC,
        COALESCE(SUM(total)    FILTER (WHERE pl_voided = FALSE AND payment_mode <> 'cash'), 0)::NUMERIC
    FROM public.bills
    WHERE outlet_id = p_outlet_id
      AND bill_date = p_date
$$ LANGUAGE sql STABLE;

-- get_item_sales(p_outlet_id UUID, p_date TEXT)
--   Returns per-item sales for a given outlet + date.
CREATE OR REPLACE FUNCTION public.get_item_sales(
    p_outlet_id UUID,
    p_date      TEXT
) RETURNS TABLE (
    outlet_id  UUID,
    item_name  TEXT,
    section    TEXT,
    qty_sold   BIGINT,
    revenue    NUMERIC
) AS $$
    SELECT
        bi.outlet_id,
        bi.item_name,
        bi.section,
        SUM(bi.quantity)::BIGINT AS qty_sold,
        COALESCE(SUM(bi.amount), 0)::NUMERIC AS revenue
    FROM public.bill_items bi
    JOIN public.bills b ON bi.bill_id = b.id
    WHERE bi.outlet_id = p_outlet_id
      AND b.bill_date  = p_date
      AND b.pl_voided  = FALSE
    GROUP BY bi.outlet_id, bi.item_name, bi.section
    ORDER BY revenue DESC
$$ LANGUAGE sql STABLE;


-- ============================================================
-- Default data
-- ============================================================

-- Default outlet: THANE / Sudhamrit Food Joint
-- We use a fixed UUID so re-running this script is idempotent and so the
-- POS hub can be pre-configured with this same outlet_id.
INSERT INTO public.outlets (id, code, name, address, city, phone, tagline, is_active, hub_version)
VALUES (
    '00000000-0000-0000-0000-000000000001',
    'THANE',
    'Sudhamrit Food Joint',
    'Thane, Maharashtra',
    'Thane',
    '',
    'Pure Sattvik Vegetarian | No Onion | No Garlic',
    TRUE,
    '1.5.0'
)
ON CONFLICT (code) DO UPDATE SET
    name        = EXCLUDED.name,
    address     = EXCLUDED.address,
    city        = EXCLUDED.city,
    tagline     = EXCLUDED.tagline,
    hub_version = EXCLUDED.hub_version;

-- Default owner: admin@sudhamrit.com / admin123
-- password_hash is generated at INSERT time by pgcrypto's crypt() with
-- bcrypt (work factor 10 via gen_salt('bf')). To verify at login:
--     SELECT id FROM web_users
--     WHERE email = 'admin@sudhamrit.com'
--       AND password_hash = crypt($user_input, password_hash);
INSERT INTO public.web_users (outlet_id, email, password_hash, full_name, role, is_active)
VALUES (
    '00000000-0000-0000-0000-000000000001',
    'admin@sudhamrit.com',
    crypt('admin123', gen_salt('bf')),
    'Outlet Owner',
    'owner',
    TRUE
)
ON CONFLICT (email) DO NOTHING;


-- ============================================================
-- Realtime publication
-- ============================================================
-- Supabase ships with a default publication named 'supabase_realtime'.
-- Add our hot tables to it so the web app can subscribe to live changes
-- (new bills, KOT status updates, new online orders, menu edits).
DO $$
BEGIN
    BEGIN ALTER PUBLICATION supabase_realtime ADD TABLE public.bills;             EXCEPTION WHEN OTHERS THEN NULL; END;
    BEGIN ALTER PUBLICATION supabase_realtime ADD TABLE public.kots;              EXCEPTION WHEN OTHERS THEN NULL; END;
    BEGIN ALTER PUBLICATION supabase_realtime ADD TABLE public.sync_orders;       EXCEPTION WHEN OTHERS THEN NULL; END;
    BEGIN ALTER PUBLICATION supabase_realtime ADD TABLE public.sync_menu_updates; EXCEPTION WHEN OTHERS THEN NULL; END;
END $$;


-- ============================================================
-- End of schema
-- ============================================================
