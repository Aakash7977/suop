"use client";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { cn } from "@/lib/utils";
import { useAuth } from "@/lib/auth";
import { usePermissions } from "@/lib/permissions";
import { useEffect, useState } from "react";

// v1.8.0: sidebar is now permission-driven (not hardcoded PERMISSIONS).
// Uses the usePermissions() hook to fetch role_permissions from Supabase
// and filters nav items via canAccessNav(href) → can(module, "view").
// Owner bypasses all checks (handled in permissions.ts).
const ALL_NAV = [
  { href: "/", label: "Dashboard", icon: "📊", module: "dashboard" },
  { href: "/kot-monitor", label: "Live KOTs", icon: "🍳", module: "kots" },
  { href: "/bills", label: "Bills", icon: "🧾", module: "bills" },
  { href: "/menu", label: "Menu", icon: "📋", module: "menu" },
  { href: "/reports", label: "Reports", icon: "📈", module: "reports" },
  { href: "/outlets", label: "Outlets", icon: "🏪", module: "outlets" },
  { href: "/packaging", label: "Packaging", icon: "📦", module: "packaging" },
  { href: "/users", label: "Users", icon: "👥", module: "users" },
  { href: "/settings", label: "Settings", icon: "⚙️", module: "settings" },
];

const ROLE_LABELS: Record<string, string> = {
  owner: "Owner",
  manager: "Manager",
  cashier: "Cashier",
  viewer: "Viewer",
};

const ROLE_BADGE_COLORS: Record<string, string> = {
  owner: "bg-purple-50 text-purple-600",
  manager: "bg-blue-50 text-blue-600",
  cashier: "bg-green-50 text-green-600",
  viewer: "bg-gray-100 text-gray-500",
};

export default function Sidebar({ onNavigate }: { onNavigate?: () => void }) {
  const pathname = usePathname();
  const router = useRouter();
  const { profile, signOut } = useAuth();
  const { canAccessNav, loading: permLoading } = usePermissions(profile?.role);
  const [signingOut, setSigningOut] = useState(false);

  // Filter nav items by the user's permissions.
  // Owner always sees everything (canAccessNav returns true for owner).
  // For other roles, canAccessNav checks the role_permissions table.
  const nav = ALL_NAV.filter(item => canAccessNav(item.href));

  function handleSignOut() {
    setSigningOut(true);
    signOut();  // clears localStorage mcl_user
    onNavigate?.();  // close mobile drawer if open
    router.replace("/login");
  }

  // v1.9.0: when a nav link is clicked on mobile, close the drawer.
  // On desktop this is a no-op (onNavigate is undefined).
  function handleNavClick() {
    onNavigate?.();
  }

  // Keyboard shortcut: Ctrl+L to sign out (handy for kiosk-style POS setups).
  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "l") {
        e.preventDefault();
        handleSignOut();
      }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <aside className="w-64 bg-white border-r border-gray-200 fixed left-0 top-0 bottom-0 flex flex-col z-30">
      {/* Brand header */}
      <div className="p-5 border-b border-gray-100">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-primary-500 rounded-xl flex items-center justify-center text-white text-xl shadow-lg shadow-primary-500/30">
            🍽️
          </div>
          <div>
            <div className="font-bold text-gray-800 leading-tight">Mini Centrino</div>
            <div className="text-xs text-gray-400">HQ Dashboard v1.8</div>
          </div>
        </div>
      </div>

      {/* Nav items (permission-filtered) */}
      <nav className="flex-1 py-3 overflow-y-auto">
        {permLoading ? (
          <div className="px-5 py-4 text-xs text-gray-400">Loading permissions...</div>
        ) : nav.length === 0 ? (
          <div className="px-5 py-4 text-xs text-gray-400">No pages available for your role.</div>
        ) : (
          nav.map((item) => {
            const active = item.href === "/" ? pathname === "/" : pathname.startsWith(item.href);
            return (
              <Link key={item.href} href={item.href} onClick={handleNavClick}
                className={cn("flex items-center gap-3 px-5 py-2.5 text-sm font-medium transition-colors",
                  active ? "bg-primary-50 text-primary-600" : "text-gray-500 hover:bg-gray-50 hover:text-gray-800")}>
                <span className="text-lg">{item.icon}</span>
                <span>{item.label}</span>
                {active && <span className="ml-auto w-1.5 h-1.5 bg-primary-500 rounded-full"></span>}
              </Link>
            );
          })
        )}
      </nav>

      {/* Real user info + sign-out button */}
      <div className="p-4 border-t border-gray-100">
        <div className="flex items-center gap-3 mb-3">
          <div className={cn(
            "w-9 h-9 rounded-full flex items-center justify-center text-white text-sm font-bold shadow-md",
            "bg-gradient-to-br from-primary-400 to-primary-600"
          )}>
            {(profile?.full_name || profile?.email || "?").charAt(0).toUpperCase()}
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-sm font-medium text-gray-700 truncate">
              {profile?.full_name || "User"}
            </div>
            <div className="text-xs text-gray-400 truncate">{profile?.email}</div>
          </div>
        </div>
        <div className="flex items-center justify-between">
          {profile && (
            <span className={cn(
              "text-xs px-2 py-0.5 rounded-full font-medium uppercase tracking-wide",
              ROLE_BADGE_COLORS[profile.role] || "bg-gray-100 text-gray-500"
            )}>
              {ROLE_LABELS[profile.role] || profile.role}
            </span>
          )}
          <button
            onClick={handleSignOut}
            disabled={signingOut}
            title="Sign out (Ctrl+L)"
            className="text-xs text-gray-400 hover:text-red-500 font-medium flex items-center gap-1 disabled:opacity-50"
          >
            <span>{signingOut ? "..." : "⏻"}</span>
            <span>{signingOut ? "Signing out" : "Logout"}</span>
          </button>
        </div>
      </div>
    </aside>
  );
}
