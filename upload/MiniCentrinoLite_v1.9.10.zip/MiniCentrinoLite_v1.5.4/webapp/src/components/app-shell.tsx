"use client";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import Sidebar from "./sidebar";

// v1.9.0 NEW: mobile-responsive shell.
// v1.9.6 FIX: previous version rendered the mobile top bar with `lg:hidden`
// but on desktop screens near the lg breakpoint (1024px) it could still
// occupy layout space due to sticky positioning + body scroll lock
// interacting badly. Now we conditionally render based on a runtime
// viewport-width check so the mobile header is NEVER in the DOM on desktop.
//
// - Desktop (lg+, ≥1024px): sidebar fixed left, main content has ml-64,
//   NO mobile top bar rendered at all.
// - Mobile (<1024px): sidebar hidden by default, hamburger top bar visible,
//   drawer slides in when hamburger clicked.
export function AppShell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const isLoginRoute = pathname === "/login";

  // Track viewport width so we can conditionally render the mobile header.
  // Only the HEADER needs this — Tailwind's `lg:hidden` handles the drawer
  // wrapper, but `position: sticky` headers can leave blank space even when
  // hidden via CSS, so we remove them from the DOM entirely on desktop.
  const [isDesktop, setIsDesktop] = useState(true);

  useEffect(() => {
    if (typeof window === "undefined") return;
    const mql = window.matchMedia("(min-width: 1024px)");
    const update = () => setIsDesktop(mql.matches);
    update();
    mql.addEventListener("change", update);
    return () => mql.removeEventListener("change", update);
  }, []);

  // Mobile sidebar drawer state
  const [drawerOpen, setDrawerOpen] = useState(false);

  // Close drawer whenever the route changes (so clicking a nav link closes it)
  useEffect(() => {
    setDrawerOpen(false);
  }, [pathname]);

  // Lock body scroll when drawer is open (so the page doesn't scroll behind)
  useEffect(() => {
    if (typeof document === "undefined") return;
    if (drawerOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }
    return () => { document.body.style.overflow = ""; };
  }, [drawerOpen]);

  if (isLoginRoute) {
    return <>{children}</>;
  }

  return (
    <>
      {/* Desktop sidebar (lg+) — always visible, fixed left */}
      <div className="hidden lg:block">
        <Sidebar />
      </div>

      {/* Mobile drawer sidebar (<lg) — slides in when drawerOpen.
          Hidden via Tailwind lg:hidden AND not even in the DOM on desktop
          thanks to the isDesktop check on the parent. */}
      {!isDesktop && (
        <div
          className={`fixed inset-0 z-50 transition-opacity duration-300 ${
            drawerOpen ? "opacity-100 pointer-events-auto" : "opacity-0 pointer-events-none"
          }`}
        >
          {/* Overlay backdrop — click anywhere to close */}
          <div
            className="absolute inset-0 bg-black/50"
            onClick={() => setDrawerOpen(false)}
          />
          {/* Sidebar drawer — slides in from left */}
          <div
            className={`absolute left-0 top-0 bottom-0 w-64 transform transition-transform duration-300 ${
              drawerOpen ? "translate-x-0" : "-translate-x-full"
            }`}
          >
            <Sidebar onNavigate={() => setDrawerOpen(false)} />
          </div>
        </div>
      )}

      {/* Mobile top bar with hamburger — only rendered on mobile (<1024px).
          v1.9.6 FIX: removed `lg:hidden` and replaced with runtime isDesktop
          check so the sticky header is NEVER in the DOM on desktop. Previously
          the sticky element left a blank space at the top of desktop pages. */}
      {!isDesktop && (
        <header className="sticky top-0 z-40 bg-white border-b border-gray-200 px-4 py-3 flex items-center justify-between shadow-sm">
          <button
            onClick={() => setDrawerOpen(true)}
            className="p-2 -ml-2 rounded-lg hover:bg-gray-100"
            aria-label="Open menu"
          >
            <svg className="w-6 h-6 text-gray-700" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
            </svg>
          </button>
          <div className="flex items-center gap-2">
            <span className="text-lg">🍽️</span>
            <span className="font-bold text-gray-800 text-sm">Mini Centrino HQ</span>
          </div>
          {/* Spacer to balance the hamburger */}
          <div className="w-9" />
        </header>
      )}

      {/* Main content area — ml-64 on desktop, full width on mobile */}
      <main className="lg:ml-64 min-h-screen bg-gray-50">{children}</main>
    </>
  );
}
