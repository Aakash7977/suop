"use client";
import { useEffect, useState } from "react";
import { supabase } from "./supabase";
import type { Role } from "./supabase";

// v1.8.0 REWRITE: matches the user's existing login implementation.
// - Permissions live in a `role_permissions` table in Supabase (not hardcoded).
// - usePermissions() hook fetches them on every page load (no stale cache).
// - can(module, action) does the runtime check.
// - Owner role bypasses all checks (always returns true).
//
// Table schema (see supabase_simple_auth_setup.sql):
//   role_permissions(role, module, action, allowed)
//
// Module names map to nav routes via NAV_MODULE_MAP below.

// ── Nav route → module name mapping ──────────────────────────
// The sidebar uses this to filter which nav items to show.
// A nav item is visible iff can(module, "view") returns true.
export const NAV_MODULE_MAP: Record<string, string> = {
  "/":            "dashboard",
  "/kot-monitor": "kots",
  "/bills":       "bills",
  "/menu":        "menu",
  "/reports":     "reports",
  "/outlets":     "outlets",
  "/packaging":   "packaging",
  "/users":       "users",
  "/settings":    "settings",
};

// ── Action type ──────────────────────────────────────────────
export type PermissionAction = "view" | "create" | "edit" | "delete";

// ── Permissions row from Supabase ────────────────────────────
interface PermissionRow {
  role: string;
  module: string;
  action: string;
  allowed: boolean;
}

// ── usePermissions hook ──────────────────────────────────────
// Fetches role_permissions from Supabase for the user's role.
// Re-fetches on every page load (no caching) so permission changes
// in the DB are picked up immediately.
//
// Returns:
//   permissions: Map<"module:action", boolean> for fast lookup
//   loading:     true during fetch
//   can:         (module, action) => boolean — the runtime check
export function usePermissions(role: Role | null | undefined) {
  const [permissions, setPermissions] = useState<Map<string, boolean>>(new Map());
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;

    async function fetchPermissions() {
      if (!role) {
        setPermissions(new Map());
        setLoading(false);
        return;
      }
      // Owner bypasses everything — no need to fetch.
      if (role === "owner") {
        setLoading(false);
        return;
      }
      try {
        const { data, error } = await supabase
          .from("role_permissions")
          .select("role, module, action, allowed")
          .eq("role", role);
        if (error) {
          console.error("[permissions] fetch error:", error.message);
          setPermissions(new Map());
        } else if (data) {
          const map = new Map<string, boolean>();
          for (const row of data as PermissionRow[]) {
            map.set(`${row.module}:${row.action}`, !!row.allowed);
          }
          if (!cancelled) setPermissions(map);
        }
      } catch (e) {
        console.error("[permissions] unexpected error:", e);
      } finally {
        if (!cancelled) setLoading(false);
      }
    }

    fetchPermissions();
    return () => { cancelled = true; };
  }, [role]);

  // ── can(module, action) ────────────────────────────────────
  // Owner always returns true (bypass).
  // Otherwise, look up `module:action` in the permissions map.
  // Default to false if not found (deny by default — safer).
  function can(module: string, action: PermissionAction): boolean {
    if (role === "owner") return true;
    if (!role) return false;
    return permissions.get(`${module}:${action}`) === true;
  }

  // ── canAccessNav(href) ─────────────────────────────────────
  // Convenience for sidebar: maps a route to its module name and
  // checks can(module, "view").
  function canAccessNav(href: string): boolean {
    const mod = NAV_MODULE_MAP[href];
    if (!mod) return false;
    return can(mod, "view");
  }

  return { permissions, loading, can, canAccessNav };
}
