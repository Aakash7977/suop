"use client";
import React, { createContext, useContext, useEffect, useState, useCallback } from "react";
import { useRouter, usePathname } from "next/navigation";
import { supabase, type Profile, type Role } from "./supabase";

// v1.8.0 REWRITE: matches the user's existing login implementation.
// - NO Supabase Auth — direct query to web_users table.
// - Plaintext password stored as `plain:password` in password_hash column.
// - Session lives in localStorage under the `mcl_user` key (NOT a Supabase JWT).
// - last_login_at is updated on every successful login.
// - Owner role bypasses all permission checks (handled in permissions.ts).
//
// This is "simple but functional for LAN" — the user's words. It's not
// suitable for a public internet deployment without additional network-level
// protection (VPN, IP allowlist, etc.).

const STORAGE_KEY = "mcl_user";

// ── Stored session shape ─────────────────────────────────────
interface StoredSession {
  id: string;            // web_users.id
  email: string;
  full_name: string;
  role: Role;
  outlet_id: string | null;
  logged_in_at: number;  // epoch ms — when the session was stored
}

// ── Auth context shape ───────────────────────────────────────
interface AuthContextValue {
  profile: Profile | null;
  loading: boolean;       // true during initial localStorage check
  error: string | null;
  signIn: (email: string, password: string) => Promise<{ ok: boolean; error?: string }>;
  signOut: () => void;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

// ── Helper: read session from localStorage ───────────────────
function readSession(): StoredSession | null {
  if (typeof window === "undefined") return null; // SSR safety
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as StoredSession;
    // Sanity check the shape
    if (!parsed.email || !parsed.role || !parsed.id) return null;
    return parsed;
  } catch {
    return null;
  }
}

// ── Helper: write/remove session ─────────────────────────────
function writeSession(s: StoredSession) {
  if (typeof window === "undefined") return;
  localStorage.setItem(STORAGE_KEY, JSON.stringify(s));
}
function clearSession() {
  if (typeof window === "undefined") return;
  localStorage.removeItem(STORAGE_KEY);
}

// ── Provider ─────────────────────────────────────────────────
export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // On mount: check localStorage for existing session.
  useEffect(() => {
    const stored = readSession();
    if (stored) {
      setProfile({
        id: stored.id,
        email: stored.email,
        full_name: stored.full_name,
        role: stored.role,
        outlet_id: stored.outlet_id,
        is_active: true,  // we already checked is_active at sign-in time
      });
    }
    setLoading(false);

    // v1.8.0: also listen for cross-tab logout (storage event).
    // If another tab signs out, this tab should pick it up.
    function onStorage(e: StorageEvent) {
      if (e.key === STORAGE_KEY && !e.newValue) {
        setProfile(null);
      }
    }
    window.addEventListener("storage", onStorage);
    return () => window.removeEventListener("storage", onStorage);
  }, []);

  // ── signIn ────────────────────────────────────────────────
  // Queries web_users table directly. Checks `plain:` prefix on password_hash.
  // On success, stores the profile in localStorage and updates last_login_at.
  const signIn = useCallback(async (email: string, password: string) => {
    setError(null);
    const cleanEmail = email.trim().toLowerCase();
    if (!cleanEmail || !password) {
      return { ok: false, error: "Email and password are required" };
    }

    // Query web_users by email (case-insensitive via ilike).
    const { data, error: queryError } = await supabase
      .from("web_users")
      .select("*")
      .ilike("email", cleanEmail)
      .maybeSingle();

    if (queryError) {
      const msg = `Database error: ${queryError.message}`;
      setError(msg);
      return { ok: false, error: msg };
    }

    if (!data) {
      const msg = "No account found with that email";
      setError(msg);
      return { ok: false, error: msg };
    }

    if (!data.is_active) {
      const msg = "Your account has been disabled. Contact an administrator.";
      setError(msg);
      return { ok: false, error: msg };
    }

    // Password check: stored as `plain:password`. Strip prefix and compare.
    const storedHash = String(data.password_hash || "");
    if (!storedHash.startsWith("plain:")) {
      const msg = "Account password format is invalid. Contact an administrator.";
      setError(msg);
      return { ok: false, error: msg };
    }
    const storedPassword = storedHash.slice("plain:".length);
    if (storedPassword !== password) {
      const msg = "Incorrect password";
      setError(msg);
      return { ok: false, error: msg };
    }

    // ── Success ─────────────────────────────────────────────
    // Build the profile + store in localStorage.
    const profileData: Profile = {
      id: data.id,
      email: data.email,
      full_name: data.full_name || "",
      role: (data.role as Role) || "viewer",
      outlet_id: data.outlet_id,
      is_active: true,
    };
    const sessionData: StoredSession = {
      id: data.id,
      email: data.email,
      full_name: profileData.full_name,
      role: profileData.role,
      outlet_id: profileData.outlet_id,
      logged_in_at: Date.now(),
    };
    writeSession(sessionData);
    setProfile(profileData);

    // Fire-and-forget: update last_login_at in Supabase.
    // Don't block the UI on this — if it fails, login still succeeded.
    supabase
      .from("web_users")
      .update({ last_login_at: new Date().toISOString() })
      .eq("id", data.id)
      .then(({ error: updErr }) => {
        if (updErr) console.warn("[auth] failed to update last_login_at:", updErr.message);
      });

    return { ok: true };
  }, []);

  // ── signOut ───────────────────────────────────────────────
  const signOut = useCallback(() => {
    clearSession();
    setProfile(null);
    setError(null);
  }, []);

  const value: AuthContextValue = { profile, loading, error, signIn, signOut };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

// ── Hook ─────────────────────────────────────────────────────
export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used inside an <AuthProvider>");
  return ctx;
}

// ── AuthWrapper (route guard) ────────────────────────────────
// Wraps every page. Behavior:
//   1. While loading localStorage → spinner.
//   2. /login → render children (no auth required).
//   3. Not logged in → redirect to /login?next=<current>.
//   4. Logged in → render children.
//
// NOTE: route-level permission checks (can the user view this page?) are
// handled separately in the sidebar (nav filtering) and on each page
// (button hiding via can(module, action)). AuthWrapper only checks
// "is there a session at all".
export function AuthWrapper({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const pathname = usePathname();
  const { profile, loading } = useAuth();

  // /login is the only public route — never guard it.
  if (pathname === "/login") return <>{children}</>;

  // Initial session load — show spinner so we don't flash /login on refresh.
  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="spinner w-10 h-10 border-4 border-primary-500 border-t-transparent rounded-full"></div>
      </div>
    );
  }

  // No session in localStorage → go to login.
  if (!profile) {
    if (typeof window !== "undefined") {
      router.replace(`/login?next=${encodeURIComponent(pathname)}`);
    }
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="spinner w-10 h-10 border-4 border-primary-500 border-t-transparent rounded-full"></div>
      </div>
    );
  }

  return <>{children}</>;
}
