"use client";
import { useEffect, useRef } from "react";
import { supabase } from "./supabase";

interface UseRealtimeOptions {
  /** Table name in the `public` schema, e.g. "bills", "kots". */
  table: string;
  /**
   * Optional filter in Supabase Realtime syntax: `column=operator.value`
   * e.g. `outlet_id=eq.abc-123`. Omit to subscribe to all rows.
   */
  filter?: string;
  /** Called on any INSERT / UPDATE / DELETE event. Use this to trigger a refetch. */
  onChange: () => void;
  /** Set to false to disable. Default true. */
  enabled?: boolean;
}

/**
 * Subscribe to Supabase Realtime changes on a single table.
 * Calls `onChange` whenever an INSERT, UPDATE, or DELETE event fires.
 *
 * ⚠️ IMPORTANT — Realtime must be enabled on the table in Supabase.
 * Run `supabase_realtime_setup.sql` once in the Supabase SQL Editor:
 *
 *     ALTER PUBLICATION supabase_realtime ADD TABLE public.bills;
 *     ALTER PUBLICATION supabase_realtime ADD TABLE public.kots;
 *     ALTER PUBLICATION supabase_realtime ADD TABLE public.held_bills;
 *     ALTER PUBLICATION supabase_realtime ADD TABLE public.sync_orders;
 *     ALTER PUBLICATION supabase_realtime ADD TABLE public.outlets;
 *
 * If Realtime is NOT enabled on the table, the subscription silently does
 * nothing — callers should keep a slow polling fallback (e.g. every 60s).
 *
 * @example
 * useRealtime({
 *   table: "bills",
 *   filter: `outlet_id=eq.${selOutlet}`,
 *   onChange: () => load(),
 * });
 */
export function useRealtime({ table, filter, onChange, enabled = true }: UseRealtimeOptions) {
  // Keep onChange in a ref so we don't resubscribe when the callback identity changes
  // (this matters because `load` from useCallback changes whenever its deps change).
  const cbRef = useRef(onChange);
  cbRef.current = onChange;

  useEffect(() => {
    if (!enabled) return;

    // Each subscription needs a unique channel name — otherwise multiple
    // pages or filter switches can collide. The random suffix prevents that.
    const channelName = `rt-${table}-${filter || "all"}-${Math.random().toString(36).slice(2, 8)}`;

    // Build the postgres_changes filter object. `filter` is optional — when
    // omitted, all rows on the table are subscribed.
    const eventFilter: Record<string, unknown> = {
      event: "*",
      schema: "public",
      table,
    };
    if (filter) eventFilter.filter = filter;

    const channel = supabase
      .channel(channelName)
      .on("postgres_changes", eventFilter as any, () => {
        // Defer to next macrotask so we don't block the Realtime callback queue.
        // Also batches rapid-fire changes (e.g. multiple inserts in 0ms).
        setTimeout(() => cbRef.current(), 0);
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
    // We deliberately only resubscribe when table/filter/enabled changes —
    // onChange is captured via ref so identity changes don't trigger resubscribe.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [table, filter, enabled]);
}
