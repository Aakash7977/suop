import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

// v1.5.9 FIX: `ClassValue` was not imported — caused `Cannot find name 'ClassValue'` TS error.
export function cn(...inputs: ClassValue[]) { return twMerge(clsx(inputs)); }
export function formatCurrency(n: number) { return `₹${(n || 0).toFixed(2)}`; }
export function timeAgo(iso: string | null): string {
  if (!iso) return "Never";
  const d = new Date(iso); const now = new Date();
  const diff = Math.floor((now.getTime() - d.getTime()) / 1000);
  if (diff < 60) return `${diff}s ago`;
  if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
  if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
  return `${Math.floor(diff / 86400)}d ago`;
}
