"use client";
import { createClient } from "@supabase/supabase-js";

const url = process.env.NEXT_PUBLIC_SUPABASE_URL || "";
const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || "";

// v1.8.0: persistSession=false — we use localStorage + plain:password auth,
// NOT Supabase Auth. The anon key is enough because RLS is disabled on the
// tables the webapp reads (web_users, outlets, role_permissions, etc.).
export const supabase = createClient(url, key, {
  auth: { persistSession: false },
});

export interface Outlet {
  id: string; code: string; name: string; address: string; city: string;
  phone: string; gstin: string; tagline: string; is_active: boolean;
  hub_version: string; last_seen_at: string | null;
}
export interface Kot {
  id: string; outlet_id: string; kot_no: number; kot_date: string;
  kot_time: string; table_no: string; customer_name: string;
  order_source: string; status: string; packaging_required: boolean;
  terminal_id: number; items: Array<{ name: string; qty: number; notes: string }>;
}
export interface MenuSection {
  id: string; outlet_id: string; local_id: number; name: string;
  sort_order: number; is_active: boolean;
}
export interface MenuItem {
  id: string; outlet_id: string; local_id: number; section_local_id: number;
  name: string; code: string; price: number; is_active: boolean;
  stock_quantity: number; low_stock_threshold: number;
}
export interface SyncOrder {
  id: number; outlet_id: string;
  items: Array<{ name: string; qty: number; price?: number; notes?: string }>;
  customer_name: string; customer_phone: string; customer_address: string;
  order_source: string; order_type: string; packaging_required: boolean;
  table_no: string; notes: string; status: string; created_at: string;
  kot_no: number | null; total_amount: number; processed_at: string | null;
  error_message: string;
}

// v1.5.9 FIX: previously imported by packaging/page.tsx but missing here
// — caused TypeScript strict-mode compile failure on `next build`.
export interface PackagingType {
  id: string; outlet_id: string; local_id: number;
  name: string; code: string; description: string;
  charge: number; is_active: boolean;
  stock_quantity: number; low_stock_threshold: number;
  synced_at: string;
}

// v1.5.9 FIX: previously imported by users/page.tsx but missing here.
// Role union matches the values used in the Add-User form + sidebar badges.
// v1.7.0: added must_change_password field for first-login flow.
export interface WebUser {
  id: string; outlet_id: string | null;
  email: string; password_hash: string; full_name: string;
  role: "owner" | "manager" | "cashier" | "viewer" | "staff";
  is_active: boolean;
  must_change_password: boolean;
  last_login_at: string | null;
  created_at: string; updated_at: string;
}

// v1.5.9 NEW: used by the new /bills/[id] detail page.
export interface BillItem {
  id: string; outlet_id: string; bill_id: string; bill_no: number;
  item_name: string; section: string;
  unit_price: number; quantity: number; amount: number;
  item_type: string; notes: string; packaging_type: string;
}

// v1.5.9 EXPANDED: Bill now includes all columns the detail page needs.
export interface Bill {
  id: string; outlet_id: string; bill_no: number;
  bill_date: string; bill_time: string;
  table_no: string; customer_name: string;
  order_source: string;
  subtotal: number; cgst: number; sgst: number;
  discount_amount: number; delivery_charges: number;
  packaging_charge: number; total: number;
  packaging_required: boolean; payment_mode: string;
  pl_voided: boolean; terminal_id: number;
  synced_at: string;
}

// v1.7.0 NEW: Profile = auth.users row joined with web_users row.
// `auth.users` has email + id; `web_users` has role + outlet_id + full_name.
// We merge them in the AuthProvider after sign-in.
export type Role = "owner" | "manager" | "cashier" | "viewer";

export interface Profile {
  id: string;            // auth.users.id
  email: string;         // auth.users.email
  full_name: string;     // web_users.full_name
  role: Role;            // web_users.role
  outlet_id: string | null; // web_users.outlet_id (null = all outlets for owner)
  is_active: boolean;    // web_users.is_active
}
