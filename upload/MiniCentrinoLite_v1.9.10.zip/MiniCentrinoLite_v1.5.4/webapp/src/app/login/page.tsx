"use client";
import { useState, useEffect, Suspense } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { useAuth } from "@/lib/auth";

// v1.8.0 REWRITE: matches the user's existing login implementation.
// - Dark mode toggle (top-right corner) — persists to localStorage
// - Language toggle (top-right corner) — en | hi | mr
// - Email + Password form
// - On submit: calls useAuth().signIn() which queries web_users directly

// v1.8.0 FIX: useSearchParams() must be wrapped in a Suspense boundary
// for Next.js 14 static prerendering.
export default function LoginPage() {
  return (
    <Suspense fallback={
      <div className="min-h-screen flex items-center justify-center">
        <div className="spinner w-10 h-10 border-4 border-primary-500 border-t-transparent rounded-full"></div>
      </div>
    }>
      <LoginForm />
    </Suspense>
  );
}

// ── i18n strings (subset of POS app's locales.py) ────────────
const STRINGS: Record<string, Record<string, string>> = {
  en: {
    title: "Mini Centrino HQ",
    subtitle: "Multi-Outlet Restaurant Dashboard",
    heading: "Sign in",
    subheading: "Enter your credentials to continue",
    email: "Email",
    emailPlaceholder: "you@sudhamrit.com",
    password: "Password",
    passwordPlaceholder: "••••••••",
    submit: "Sign In →",
    submitting: "Signing in...",
    sessionNote: "Your session stays active until you sign out.",
    forgotNote: "Forgot your password? Contact your administrator.",
    footer: "Mini Centrino HQ v1.8 · Sudhamrit Food Joint",
  },
  hi: {
    title: "मिनी सेंट्रिनो HQ",
    subtitle: "मल्टी-आउटलेट रेस्टोरेंट डैशबोर्ड",
    heading: "साइन इन",
    subheading: "जारी रखने के लिए अपनी प्रवेश-जानकारी दर्ज करें",
    email: "ईमेल",
    emailPlaceholder: "you@sudhamrit.com",
    password: "पासवर्ड",
    passwordPlaceholder: "••••••••",
    submit: "साइन इन →",
    submitting: "साइन इन हो रहा है...",
    sessionNote: "आपका सत्र तब तक सक्रिय रहता है जब तक आप साइन आउट न करें।",
    forgotNote: "पासवर्ड भूल गए? अपने व्यवस्थापक से संपर्क करें।",
    footer: "मिनी सेंट्रिनो HQ v1.8 · सुधामृत फूड जॉइंट",
  },
  mr: {
    title: "मिनी सेंट्रिनो HQ",
    subtitle: "मल्टी-आउटलेट रेस्टॉरंट डॅशबोर्ड",
    heading: "साइन इन",
    subheading: "सुरू ठेवण्यासाठी तुमची क्रेडेन्शियल्स एंटर करा",
    email: "ईमेल",
    emailPlaceholder: "you@sudhamrit.com",
    password: "पासवर्ड",
    passwordPlaceholder: "••••••••",
    submit: "साइन इन →",
    submitting: "साइन इन होत आहे...",
    sessionNote: "तुम्ही साइन आउट करेपर्यंत तुमचा सत्र सक्रिय राहील.",
    forgotNote: "पासवर्ड विसरलात? तुमच्या व्यवस्थापकाशी संपर्क साधा.",
    footer: "मिनी सेंट्रिनो HQ v1.8 · सुधामृत फूड जॉइंट",
  },
};

function LoginForm() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { signIn, profile } = useAuth();

  // ── Theme + language state (persisted to localStorage) ────
  const [dark, setDark] = useState(false);
  const [lang, setLang] = useState<"en" | "hi" | "mr">("en");

  useEffect(() => {
    // Load persisted preferences
    const savedDark = localStorage.getItem("mcl_dark") === "true";
    const savedLang = (localStorage.getItem("mcl_lang") as "en" | "hi" | "mr") || "en";
    setDark(savedDark);
    setLang(savedLang);
  }, []);

  function toggleDark() {
    const next = !dark;
    setDark(next);
    localStorage.setItem("mcl_dark", String(next));
  }

  function cycleLang() {
    const order: Array<"en" | "hi" | "mr"> = ["en", "hi", "mr"];
    const idx = order.indexOf(lang);
    const next = order[(idx + 1) % order.length];
    setLang(next);
    localStorage.setItem("mcl_lang", next);
  }

  // If already logged in, redirect away from /login.
  useEffect(() => {
    if (profile) {
      const next = searchParams.get("next") || "/";
      router.replace(next);
    }
  }, [profile, router, searchParams]);

  // ── Form state ────────────────────────────────────────────
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const t = STRINGS[lang];

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!email || !password) return;
    setSubmitting(true);
    setError(null);
    const result = await signIn(email, password);
    setSubmitting(false);
    if (!result.ok) {
      setError(result.error || "Sign in failed");
      return;
    }
    // On success, the useEffect above will fire (profile updates) and redirect.
    const next = searchParams.get("next") || "/";
    router.replace(next);
  }

  // ── Theme-aware classes ───────────────────────────────────
  const bgClass = dark
    ? "bg-gradient-to-br from-gray-900 via-gray-800 to-purple-900"
    : "bg-gradient-to-br from-primary-50 via-white to-purple-50";
  const cardClass = dark ? "bg-gray-800 border border-gray-700" : "bg-white";
  const headingClass = dark ? "text-white" : "text-gray-800";
  const subheadingClass = dark ? "text-gray-300" : "text-gray-700";
  const subtleClass = dark ? "text-gray-400" : "text-gray-500";
  const microClass = dark ? "text-gray-500" : "text-gray-400";
  const inputClass = dark
    ? "bg-gray-900 border-gray-700 text-white placeholder-gray-500 focus:ring-primary-500"
    : "bg-white border-gray-200 text-gray-800 placeholder-gray-400 focus:ring-primary-400";
  const errorClass = dark
    ? "bg-red-900/40 border-red-700 text-red-300"
    : "bg-red-50 border-red-200 text-red-600";
  const toggleBtnClass = dark
    ? "bg-gray-700 hover:bg-gray-600 text-gray-200"
    : "bg-white hover:bg-gray-100 text-gray-600 border border-gray-200";

  return (
    <div className={`min-h-screen ${bgClass} flex items-center justify-center p-6 transition-colors`}>
      <div className="w-full max-w-md">
        {/* Top-right toggles (fixed position so they're always accessible) */}
        <div className="fixed top-4 right-4 flex items-center gap-2 z-50">
          <button
            onClick={cycleLang}
            className={`${toggleBtnClass} px-3 py-1.5 rounded-lg text-xs font-semibold uppercase shadow-sm transition-colors`}
            title="Toggle language"
          >
            {lang === "en" ? "EN" : lang === "hi" ? "हिं" : "मरा"}
          </button>
          <button
            onClick={toggleDark}
            className={`${toggleBtnClass} w-9 h-9 rounded-lg text-sm shadow-sm transition-colors flex items-center justify-center`}
            title="Toggle dark mode"
          >
            {dark ? "☀️" : "🌙"}
          </button>
        </div>

        {/* Logo / Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-primary-500 rounded-2xl shadow-lg shadow-primary-500/30 mb-4">
            <span className="text-3xl">🍽️</span>
          </div>
          <h1 className={`text-2xl font-bold ${headingClass}`}>{t.title}</h1>
          <p className={`${subtleClass} text-sm mt-1`}>{t.subtitle}</p>
        </div>

        {/* Login card */}
        <div className={`${cardClass} rounded-2xl shadow-card p-8`}>
          <h2 className={`text-lg font-semibold ${headingClass} mb-1`}>{t.heading}</h2>
          <p className={`${microClass} text-sm mb-6`}>{t.subheading}</p>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className={`block text-xs font-medium ${microClass} uppercase tracking-wide mb-1.5`}>{t.email}</label>
              <input
                type="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder={t.emailPlaceholder}
                required
                autoFocus
                className={`w-full border ${inputClass} rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:border-transparent`}
              />
            </div>
            <div>
              <label className={`block text-xs font-medium ${microClass} uppercase tracking-wide mb-1.5`}>{t.password}</label>
              <input
                type="password"
                value={password}
                onChange={e => setPassword(e.target.value)}
                placeholder={t.passwordPlaceholder}
                required
                className={`w-full border ${inputClass} rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:border-transparent`}
              />
            </div>

            {error && (
              <div className={`${errorClass} border rounded-lg px-3 py-2 text-sm flex items-start gap-2`}>
                <span>⚠️</span>
                <span>{error}</span>
              </div>
            )}

            <button
              type="submit"
              disabled={submitting || !email || !password}
              className="w-full bg-primary-500 hover:bg-primary-600 text-white py-2.5 rounded-xl text-sm font-semibold shadow-md disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              {submitting ? t.submitting : t.submit}
            </button>
          </form>

          {/* Help text */}
          <div className={`mt-6 pt-4 border-t ${dark ? "border-gray-700" : "border-gray-100"} text-xs ${microClass} space-y-1`}>
            <div>🔒 {t.sessionNote}</div>
            <div>{t.forgotNote}</div>
          </div>
        </div>

        <p className={`text-center text-xs ${microClass} mt-6`}>{t.footer}</p>
      </div>
    </div>
  );
}
