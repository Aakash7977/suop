"use client";
import { useEffect, useState, useCallback } from "react";
import { useRouter } from "next/navigation";
import { supabase, type Outlet } from "@/lib/supabase";
import { formatCurrency, timeAgo } from "@/lib/utils";
import { useRealtime } from "@/lib/realtime";
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Tooltip, CartesianGrid } from "recharts";

// v1.6.1: removed pending_orders field — /orders page deleted, dashboard no longer shows it.
interface Summary { outlet_id: string; code: string; name: string; is_active: boolean; last_seen_at: string | null; bills_today: number; revenue_today: number; active_kots: number; }

function todayStr() { const d = new Date(); return `${String(d.getDate()).padStart(2,"0")}/${String(d.getMonth()+1).padStart(2,"0")}/${d.getFullYear()}`; }
function dateStr(daysAgo: number) { const d = new Date(); d.setDate(d.getDate() - daysAgo); return `${String(d.getDate()).padStart(2,"0")}/${String(d.getMonth()+1).padStart(2,"0")}/${d.getFullYear()}`; }

export default function Dashboard() {
  const router = useRouter();
  const [outlets, setOutlets] = useState<Summary[]>([]);
  const [recentBills, setRecentBills] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [chartData, setChartData] = useState<any[]>([]);
  const [selDate, setSelDate] = useState("today"); // today | yesterday | 7days | all | custom
  const [customDate, setCustomDate] = useState("");

  const load = useCallback(async () => {
    try {
      const { data: outletData } = await supabase.from("outlets").select("*").eq("is_active", true).order("name");
      const allOutlets = outletData || [];
      const allOutletIds = allOutlets.map(o => o.id);

      // Determine which dates to query
      let datesToQuery: string[] = [];
      if (selDate === "today") datesToQuery = [todayStr()];
      else if (selDate === "yesterday") datesToQuery = [dateStr(1)];
      else if (selDate === "7days") { for (let i = 0; i < 7; i++) datesToQuery.push(dateStr(i)); }
      else if (selDate === "custom" && customDate) datesToQuery = [customDate];
      // "all" = no date filter

      // For each outlet, fetch bills for selected date range
      // v1.6.1: removed sync_orders count query (was for Pending Orders card).
      // v1.9.3 FIX: Active KOTs now filtered to today only — was counting stale
      // KOTs from prior days that were never marked "served", inflating the count.
      const summaries: Summary[] = [];
      const todayDateStr = todayStr();
      for (const o of allOutlets) {
        let billsQuery = supabase.from("bills").select("total,pl_voided,bill_date").eq("outlet_id", o.id);
        if (datesToQuery.length > 0) billsQuery = billsQuery.in("bill_date", datesToQuery);
        const { data: dayBills } = await billsQuery;
        const activeBills = (dayBills || []).filter(b => !b.pl_voided);
        const revenue = activeBills.reduce((s, b) => s + (b.total || 0), 0);
        // v1.9.3: filter KOTs by today's date so old stale KOTs don't inflate the count
        const { count: kotCount } = await supabase.from("kots").select("*", { count: "exact", head: true }).eq("outlet_id", o.id).eq("kot_date", todayDateStr).in("status", ["pending", "preparing", "ready"]);
        summaries.push({ outlet_id: o.id, code: o.code, name: o.name, is_active: o.is_active, last_seen_at: o.last_seen_at, bills_today: activeBills.length, revenue_today: revenue, active_kots: kotCount || 0 });
      }
      setOutlets(summaries);

      // Recent bills
      // v1.5.9 FIX: order by synced_at desc, not bill_no desc.
      // bill_no resets per outlet, so cross-outlet ranking by bill_no is wrong.
      let bills: any[] = [];
      if (allOutletIds.length > 0) {
        let q = supabase.from("bills").select("id,bill_no,bill_date,customer_name,total,payment_mode,packaging_required,order_source,terminal_id,outlet_id,synced_at").in("outlet_id", allOutletIds).order("synced_at", { ascending: false }).limit(10);
        if (datesToQuery.length > 0) q = q.in("bill_date", datesToQuery);
        const { data } = await q;
        bills = data || [];
      }
      setRecentBills(bills);

      // Chart: last 7 days revenue (always, regardless of filter)
      const days: any[] = [];
      for (let i = 6; i >= 0; i--) { const ds = dateStr(i); days.push({ date: ds, label: new Date(Date.now() - i * 86400000).toLocaleDateString("en", { weekday: "short" }), revenue: 0, bills: 0 }); }
      if (allOutletIds.length > 0) {
        const { data: weekBills } = await supabase.from("bills").select("bill_date,total,pl_voided").in("outlet_id", allOutletIds).in("bill_date", days.map(d => d.date));
        if (weekBills) { for (const b of weekBills) { if (b.pl_voided) continue; const day = days.find(d => d.date === b.bill_date); if (day) { day.revenue += b.total || 0; day.bills += 1; } } }
      }
      setChartData(days);
    } catch (e) { console.error(e); }
    setLoading(false);
  }, [selDate, customDate]);

  useEffect(() => { load(); const i = setInterval(load, 30000); return () => clearInterval(i); }, [load]);

  // v1.6.0 NEW: Supabase Realtime subscriptions for instant updates.
  // When Realtime is enabled (see supabase_realtime_setup.sql), changes
  // appear within ~200ms instead of waiting for the 30s poll.
  // We pass `load` directly — the hook internally refs it so identity
  // changes don't cause resubscribe churn.
  //
  // v1.6.1: removed sync_orders subscription — /orders page deleted.
  useRealtime({ table: "bills", onChange: load });
  useRealtime({ table: "kots", onChange: load });
  useRealtime({ table: "outlets", onChange: load });

  const totalRev = outlets.reduce((s, o) => s + (o.revenue_today || 0), 0);
  const totalBills = outlets.reduce((s, o) => s + (o.bills_today || 0), 0);
  const totalKots = outlets.reduce((s, o) => s + (o.active_kots || 0), 0);
  // v1.6.1 NEW: Average Order Value = revenue / bills (guarded against div/0).
  const aov = totalBills > 0 ? totalRev / totalBills : 0;
  const outletName = (id: string) => outlets.find(o => o.outlet_id === id)?.name || "—";

  const dateLabel = selDate === "today" ? "Today" : selDate === "yesterday" ? "Yesterday" : selDate === "7days" ? "Last 7 Days" : selDate === "all" ? "All Time" : customDate || "Custom";

  if (loading) return <div className="flex items-center justify-center h-screen"><div className="spinner w-10 h-10 border-4 border-primary-500 border-t-transparent rounded-full"></div></div>;

  return (
    <div className="p-4 sm:p-6 lg:p-8">
      <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
        <div><h1 className="text-xl sm:text-2xl font-bold text-gray-800">Sales Overview</h1><p className="text-gray-500 text-xs sm:text-sm mt-0.5">Auto-refreshes every 30s — showing: <span className="font-medium text-primary-600">{dateLabel}</span></p></div>
        {/* Date filter */}
        <div className="flex items-center gap-2 flex-wrap">
          <select value={selDate} onChange={e => setSelDate(e.target.value)} className="border border-gray-200 rounded-xl px-3 py-2 bg-white text-sm shadow-sm">
            <option value="today">Today</option>
            <option value="yesterday">Yesterday</option>
            <option value="7days">Last 7 Days</option>
            <option value="all">All Time</option>
            <option value="custom">Custom Date</option>
          </select>
          {selDate === "custom" && <input type="text" value={customDate} onChange={e => setCustomDate(e.target.value)} placeholder="DD/MM/YYYY" className="border border-gray-200 rounded-xl px-3 py-2 text-sm w-32" />}
        </div>
      </div>

      {/* v1.9.0: responsive grid — 1 col mobile, 2 col tablet, 4 col desktop */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-5 mb-6">
        {/* v1.6.1: dashboard is now 4 cards — Revenue / Bills / AOV / Active KOTs.
            Pending Orders card removed (orders page deleted). */}
        <MetricCard label={`Revenue (${dateLabel})`} value={formatCurrency(totalRev)} sub="View all bills →" icon="💰" bg="bg-primary-500" text="text-white" onClick={() => router.push("/bills")} />
        <MetricCard label={`Bills (${dateLabel})`} value={totalBills.toString()} sub="View all bills →" icon="🧾" bg="bg-white" text="text-gray-800" border onClick={() => router.push("/bills")} />
        {/* v1.6.1 NEW: Average Order Value = total revenue ÷ total bills. */}
        <MetricCard label="Avg Order Value" value={formatCurrency(aov)} sub="Revenue ÷ Bills" icon="📊" bg="bg-white" text="text-gray-800" border />
        <MetricCard label="Active KOTs" value={totalKots.toString()} sub="Open KOT monitor →" icon="🍳" bg="bg-white" text="text-gray-800" border onClick={() => router.push("/kot-monitor")} />
      </div>

      {/* v1.9.0: stack on mobile, 3-col on desktop */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 sm:gap-5 mb-6">
        <div className="lg:col-span-2 bg-white rounded-2xl shadow-card p-4 sm:p-6">
          <h3 className="font-semibold text-gray-700 mb-4">Revenue — Last 7 Days</h3>
          {/* v1.9.5 FIX: increased chart height + added margin to XAxis so day labels (Mon, Tue...) are not cut off at the bottom */}
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={chartData} margin={{ top: 10, right: 10, left: 0, bottom: 20 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#F3F4F6" />
              <XAxis dataKey="label" tick={{ fontSize: 12, fill: "#9CA3AF" }} axisLine={false} tickLine={false} dy={10} />
              <YAxis tick={{ fontSize: 12, fill: "#9CA3AF" }} axisLine={false} tickLine={false} tickFormatter={(v) => `₹${v/1000}k`} />
              <Tooltip formatter={(v: number) => formatCurrency(v)} contentStyle={{ borderRadius: 12, border: "none", boxShadow: "0 4px 12px rgb(0 0 0 / 0.1)" }} />
              <Bar dataKey="revenue" fill="#6366F1" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
        <div className="bg-white rounded-2xl shadow-card p-4 sm:p-6">
          <h3 className="font-semibold text-gray-700 mb-4">Outlets Status</h3>
          <div className="space-y-3">{outlets.map(o => (
            <div key={o.outlet_id} className="flex items-center justify-between py-2 border-b border-gray-50 last:border-0">
              <div><div className="font-medium text-sm text-gray-700">{o.name}</div><div className="text-xs text-gray-400">{timeAgo(o.last_seen_at)}</div></div>
              <div className="text-right"><div className="font-bold text-sm text-gray-800">{formatCurrency(o.revenue_today || 0)}</div><div className="text-xs text-gray-400">{o.bills_today || 0} bills | {o.active_kots || 0} KOTs</div></div>
              <span className={`w-2 h-2 rounded-full ${o.is_active ? "bg-green-400 pulse-dot" : "bg-gray-300"}`}></span>
            </div>
          ))}{outlets.length === 0 && <div className="text-gray-400 text-sm text-center py-4">No outlets found</div>}</div>
        </div>
      </div>

      {/* v1.9.0: table wraps in overflow-x-auto on mobile */}
      <div className="bg-white rounded-2xl shadow-card p-4 sm:p-6">
        <h3 className="font-semibold text-gray-700 mb-4">Recent Bills ({dateLabel})</h3>
        <div className="overflow-x-auto -mx-4 sm:mx-0 px-4 sm:px-0">
          <table className="w-full min-w-[700px]">
            <thead><tr className="border-b border-gray-100">
              <th className="text-left py-2 text-xs font-medium text-gray-400 uppercase">Bill #</th>
              <th className="text-left py-2 text-xs font-medium text-gray-400 uppercase">Date</th>
              <th className="text-left py-2 text-xs font-medium text-gray-400 uppercase">Customer</th>
              <th className="text-left py-2 text-xs font-medium text-gray-400 uppercase">Outlet</th>
              <th className="text-left py-2 text-xs font-medium text-gray-400 uppercase">Source</th>
              <th className="text-left py-2 text-xs font-medium text-gray-400 uppercase">Payment</th>
              <th className="text-right py-2 text-xs font-medium text-gray-400 uppercase">Total</th>
              <th className="text-center py-2 text-xs font-medium text-gray-400 uppercase">POS</th>
            </tr></thead>
            <tbody>
              {recentBills.map((b, i) => (
                <tr key={b.id || i} className="border-b border-gray-50 hover:bg-gray-50 cursor-pointer" onClick={() => router.push(`/bills/${b.id}`)}>
                  <td className="py-2.5 text-sm font-medium text-primary-600">#{b.bill_no}</td>
                  <td className="py-2.5 text-sm text-gray-500">{b.bill_date}</td>
                  <td className="py-2.5 text-sm text-gray-700">{b.customer_name || "—"}</td>
                  <td className="py-2.5 text-sm text-gray-500">{outletName(b.outlet_id)}</td>
                  <td className="py-2.5">{b.order_source && b.order_source !== "walkin" ? <span className="text-xs px-2 py-0.5 rounded-full bg-purple-50 text-purple-600 capitalize">{b.order_source}</span> : <span className="text-xs text-gray-400">Walk-in</span>}</td>
                  <td className="py-2.5 text-sm text-gray-500 capitalize">{b.payment_mode}</td>
                  <td className="py-2.5 text-sm font-bold text-gray-800 text-right">{formatCurrency(b.total)}</td>
                  <td className="py-2.5 text-center text-sm text-gray-400">T{b.terminal_id}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {recentBills.length === 0 && <div className="text-center py-8 text-gray-400 text-sm">No bills for selected period.</div>}
      </div>
    </div>
  );
}

function MetricCard({ label, value, sub, icon, bg, text, border, onClick }: { label: string; value: string; sub: string; icon: string; bg: string; text: string; border?: boolean; onClick?: () => void }) {
  // v1.5.9: if onClick is provided, render as a button with hover lift + arrow hint.
  // v1.9.3 FIX: responsive text sizes — text-2xl was too big on mobile 2-col grid,
  // causing the value (e.g. "₹152.00") to overlap with the label above it.
  // Now uses text-lg on mobile, text-2xl on desktop. Label truncates if too long.
  const cls = `${bg} ${border ? "border border-gray-200" : ""} rounded-2xl shadow-card p-3 sm:p-5 transition-all ${onClick ? "hover:shadow-card-hover hover:-translate-y-0.5 cursor-pointer text-left w-full" : ""}`;
  const inner = (<>
    <div className="flex items-center justify-between mb-2 sm:mb-3 gap-1">
      <span className={`text-[10px] sm:text-xs font-medium ${text === "text-white" ? "text-primary-100" : "text-gray-400"} uppercase tracking-wide truncate`}>{label}</span>
      <span className="text-lg sm:text-2xl flex-shrink-0">{icon}</span>
    </div>
    <div className={`text-lg sm:text-2xl font-bold ${text} truncate`}>{value}</div>
    <div className={`text-[10px] sm:text-xs mt-1 flex items-center gap-1 ${text === "text-white" ? "text-primary-100" : "text-gray-400"} truncate`}>{sub}{onClick && <span className="opacity-70 flex-shrink-0">→</span>}</div>
  </>);
  return onClick ? <button type="button" onClick={onClick} className={cls}>{inner}</button> : <div className={cls}>{inner}</div>;
}
