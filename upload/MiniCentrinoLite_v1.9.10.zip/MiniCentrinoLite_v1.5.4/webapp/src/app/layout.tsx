import type { Metadata } from "next";
import "./globals.css";
import Sidebar from "@/components/sidebar";
import { AuthProvider, AuthWrapper } from "@/lib/auth";
import { AppShell } from "@/components/app-shell";

export const metadata: Metadata = {
  title: "Mini Centrino HQ — Multi-Outlet Dashboard",
  description: "Central management for Sudhamrit Food Joint outlets",
};

// v1.8.0: Layout now wraps every page in <AuthProvider> (for useAuth) and
// <AuthWrapper> (route guard — redirects to /login if no mcl_user in localStorage).
//
// The <AppShell> client component decides whether to render the sidebar:
//   - /login → no sidebar, full-bleed
//   - everything else → sidebar + main shifted by ml-64
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <AuthProvider>
          <AuthWrapper>
            <AppShell>{children}</AppShell>
          </AuthWrapper>
        </AuthProvider>
      </body>
    </html>
  );
}
