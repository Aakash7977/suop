"use client";
import { useAuth } from "@/lib/auth";

export default function SettingsPage() {
  const { profile } = useAuth();

  return (
    <div className="p-8 max-w-3xl">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-800">⚙️ Settings</h1>
        <p className="text-gray-500 text-sm mt-0.5">Configuration reference</p>
      </div>

      <div className="bg-white rounded-2xl shadow-card p-6 space-y-6">
        {/* Current user info */}
        <div>
          <h2 className="font-semibold text-gray-700 mb-2">Your Account</h2>
          {profile ? (
            <div className="bg-primary-50 border border-primary-100 rounded-lg p-4 text-sm">
              <div><span className="text-gray-500">Name:</span> <span className="font-medium text-gray-800">{profile.full_name || "—"}</span></div>
              <div><span className="text-gray-500">Email:</span> <span className="font-mono text-gray-800">{profile.email}</span></div>
              <div><span className="text-gray-500">Role:</span> <span className="font-medium text-purple-600 uppercase">{profile.role}</span></div>
              <div><span className="text-gray-500">Outlet:</span> <span className="font-medium text-gray-800">{profile.outlet_id ? "Specific outlet" : "All outlets"}</span></div>
            </div>
          ) : (
            <p className="text-sm text-gray-400">Not signed in.</p>
          )}
        </div>

        <div className="border-t pt-4">
          <h2 className="font-semibold text-gray-700 mb-2">Supabase Config</h2>
          <div className="bg-gray-900 text-green-400 rounded-lg p-4 text-sm font-mono">
            NEXT_PUBLIC_SUPABASE_URL=https://xxxxx.supabase.co<br />
            NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGciOi...
          </div>
          <p className="text-xs text-gray-400 mt-2">Set in webapp/.env.local — restart after changing.</p>
        </div>

        <div className="border-t pt-4">
          <h2 className="font-semibold text-gray-700 mb-2">Hub Cloud Sync</h2>
          <p className="text-sm text-gray-500 mb-2">Edit settings.json in %APPDATA%\MiniCentrinoLite\:</p>
          <div className="bg-gray-900 text-green-400 rounded-lg p-4 text-sm font-mono">
            "cloud_sync_enabled": true,<br />
            "supabase_url": "https://xxxxx.supabase.co",<br />
            "supabase_anon_key": "eyJhbGciOi...",<br />
            "supabase_outlet_id": "UUID-from-outlets-table"
          </div>
        </div>

        {/* v1.8.0: simpler auth setup instructions */}
        <div className="border-t pt-4">
          <h2 className="font-semibold text-gray-700 mb-2">🔐 Login System (v1.8.0)</h2>
          <p className="text-sm text-gray-500 mb-2">
            The webapp uses simple localStorage-based auth. To set up your first admin user:
          </p>
          <ol className="text-sm text-gray-600 list-decimal list-inside space-y-1 mb-3">
            <li>Run <code className="bg-gray-100 px-1.5 py-0.5 rounded text-xs">supabase_simple_auth_setup.sql</code> in Supabase SQL Editor</li>
            <li>This creates the <code className="bg-gray-100 px-1.5 py-0.5 rounded text-xs">role_permissions</code> table + a default admin user</li>
            <li>Sign in with <code className="bg-gray-100 px-1.5 py-0.5 rounded text-xs">admin@sudhamrit.com</code> / <code className="bg-gray-100 px-1.5 py-0.5 rounded text-xs">admin123</code></li>
            <li>Change the password immediately via the Users page → Reset Password</li>
          </ol>
          <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 text-xs text-amber-800">
            <strong>⚠️ Security note:</strong> Passwords are stored as plaintext (<code>plain:password</code>) in the
            <code>web_users.password_hash</code> column. This is intentional for LAN-only deployments. Do NOT expose
            this webapp to the public internet without additional network-level protection (VPN, IP allowlist, reverse proxy with auth).
          </div>
        </div>

        <div className="border-t pt-4">
          <h2 className="font-semibold text-gray-700 mb-2">📱 Realtime (optional)</h2>
          <p className="text-sm text-gray-500">
            Run <code className="bg-gray-100 px-1.5 py-0.5 rounded text-xs">supabase_realtime_setup.sql</code> in Supabase SQL Editor to enable live updates
            (instant bill/KOT refresh instead of polling).
          </p>
        </div>
      </div>
    </div>
  );
}
