"use client";
import { useEffect, useState } from "react";
import { supabase, type Outlet } from "@/lib/supabase";
import { timeAgo } from "@/lib/utils";

export default function OutletsPage() {
  const [outlets, setOutlets] = useState<Outlet[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [code, setCode] = useState(""); const [name, setName] = useState(""); const [city, setCity] = useState(""); const [phone, setPhone] = useState(""); const [gstin, setGstin] = useState("");

  const load = async () => { const { data } = await supabase.from("outlets").select("*").order("name"); setOutlets(data || []); };
  useEffect(() => { load(); }, []);

  async function add() {
    if (!code || !name) { alert("Code and Name required"); return; }
    const { error } = await supabase.from("outlets").insert({ code: code.toUpperCase(), name, city, phone, gstin, is_active: true });
    if (error) { alert(error.message); return; }
    alert("✓ Outlet added!"); setShowForm(false); setCode(""); setName(""); setCity(""); setPhone(""); setGstin(""); load();
  }

  return (
    <div className="p-4 sm:p-6 lg:p-8">
      <div className="flex items-center justify-between mb-6">
        <div><h1 className="text-2xl font-bold text-gray-800">Outlets</h1><p className="text-gray-500 text-sm mt-0.5">Manage all restaurant outlets</p></div>
        <button onClick={() => setShowForm(!showForm)} className="bg-primary-500 hover:bg-primary-600 text-white px-4 py-2.5 rounded-xl text-sm font-medium shadow-sm">{showForm ? "✕ Cancel" : "+ Add Outlet"}</button>
      </div>
      {showForm && (
        <div className="bg-white rounded-2xl shadow-card p-5 mb-5">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {/* v1.5.9 FIX: explicit tuple type so TS doesn't widen `l` to `string | Dispatch<SetStateAction<string>>`. */}
            {([
              ["Code", code, setCode],
              ["Name", name, setName],
              ["City", city, setCity],
              ["Phone", phone, setPhone],
              ["GSTIN", gstin, setGstin],
            ] as Array<[string, string, (v: string) => void]>).map(([l, v, set]) => (
              <div key={l}><label className="block text-xs text-gray-400 mb-1">{l}</label><input type="text" value={v} onChange={e => set(e.target.value)} className="border border-gray-200 rounded-lg px-3 py-2 w-full text-sm" /></div>
            ))}
          </div>
          <button onClick={add} className="mt-3 bg-green-500 text-white px-5 py-2 rounded-lg text-sm font-medium">✓ Save</button>
        </div>
      )}
      <div className="bg-white rounded-2xl shadow-card overflow-hidden">
        <div className="overflow-x-auto">
        <table className="w-full min-w-[800px]">
          <thead className="bg-gray-50"><tr>{["Name", "Code", "City", "GSTIN", "Status", "Last Seen", "Hub"].map(h => <th key={h} className="text-left px-5 py-3 text-xs font-medium text-gray-400 uppercase">{h}</th>)}</tr></thead>
          <tbody>{outlets.map(o => <tr key={o.id} className="border-b border-gray-50 hover:bg-gray-50"><td className="px-5 py-3 text-sm font-medium text-gray-700">{o.name}</td><td className="px-5 py-3"><code className="bg-gray-100 px-2 py-0.5 rounded text-xs">{o.code}</code></td><td className="px-5 py-3 text-sm text-gray-500">{o.city || "—"}</td><td className="px-5 py-3 text-sm text-gray-400">{o.gstin || "—"}</td><td className="px-5 py-3"><span className={`text-xs px-2 py-0.5 rounded-full ${o.is_active ? "bg-green-50 text-green-600" : "bg-gray-100 text-gray-400"}`}>{o.is_active ? "● Active" : "○ Inactive"}</span></td><td className="px-5 py-3 text-sm text-gray-400">{timeAgo(o.last_seen_at)}</td><td className="px-5 py-3 text-sm text-gray-400">{o.hub_version || "—"}</td></tr>)}</tbody>
        </table>
        </div>
      </div>
    </div>
  );
}
