"use client";
import { useEffect, useState, useCallback } from "react";
import { supabase, type Outlet, type MenuSection, type MenuItem, type SyncOrder } from "@/lib/supabase";
import { formatCurrency, timeAgo } from "@/lib/utils";

interface CartItem { name: string; qty: number; price: number; notes: string; }

export default function OrdersPage() {
  // Outlet + menu state
  const [outlets, setOutlets] = useState<Outlet[]>([]);
  const [selOutlet, setSelOutlet] = useState("");
  const [sections, setSections] = useState<MenuSection[]>([]);
  const [items, setItems] = useState<MenuItem[]>([]);
  const [activeSection, setActiveSection] = useState<number | null>(null);
  const [search, setSearch] = useState("");

  // Cart state
  const [cart, setCart] = useState<CartItem[]>([]);

  // Order details (same as POS)
  const [customerName, setCustomerName] = useState("");
  const [customerPhone, setCustomerPhone] = useState("");
  const [tableNo, setTableNo] = useState("");
  const [orderSource, setOrderSource] = useState("walkin");
  const [packagingRequired, setPackagingRequired] = useState(false);
  const [notes, setNotes] = useState("");

  // Discount + charges (same as POS)
  const [discountPct, setDiscountPct] = useState("0");
  const [discountFlat, setDiscountFlat] = useState("0");
  const [deliveryCharges, setDeliveryCharges] = useState("0");

  // Payment (same as POS)
  const [paymentMode, setPaymentMode] = useState("cash");

  // Recent orders
  const [orders, setOrders] = useState<SyncOrder[]>([]);
  const [saving, setSaving] = useState(false);

  // ── Load outlets ──────────────────────────────────────
  useEffect(() => {
    (async () => {
      const { data } = await supabase.from("outlets").select("*").eq("is_active", true).order("name");
      setOutlets(data || []);
      if (data && data[0]) setSelOutlet(data[0].id);
    })();
  }, []);

  // ── Load menu when outlet changes ─────────────────────
  const loadMenu = useCallback(async () => {
    if (!selOutlet) return;
    const { data: secs } = await supabase.from("menu_sections").select("*").eq("outlet_id", selOutlet).eq("is_active", true).order("sort_order");
    setSections(secs || []);
    const { data: its } = await supabase.from("menu_items").select("*").eq("outlet_id", selOutlet).eq("is_active", true).order("sort_order");
    setItems(its || []);
    if (secs && secs[0]) setActiveSection(secs[0].local_id);
  }, [selOutlet]);

  useEffect(() => { loadMenu(); }, [loadMenu]);

  // ── Load recent orders ────────────────────────────────
  const loadOrders = useCallback(async () => {
    if (!selOutlet) return;
    const { data } = await supabase.from("sync_orders").select("*").eq("outlet_id", selOutlet).order("created_at", { ascending: false }).limit(15);
    setOrders(data || []);
  }, [selOutlet]);

  useEffect(() => { loadOrders(); }, [loadOrders]);

  // ── Cart operations ───────────────────────────────────
  function addToCart(item: MenuItem) {
    setCart(prev => {
      const ex = prev.find(c => c.name === item.name);
      if (ex) return prev.map(c => c.name === item.name ? { ...c, qty: c.qty + 1 } : c);
      return [...prev, { name: item.name, qty: 1, price: item.price, notes: "" }];
    });
  }

  function changeQty(name: string, delta: number) {
    setCart(prev => prev.map(c => c.name === name ? { ...c, qty: Math.max(0, c.qty + delta) } : c).filter(c => c.qty > 0));
  }

  function setQty(name: string, qty: number) {
    if (qty <= 0) { setCart(prev => prev.filter(c => c.name !== name)); return; }
    setCart(prev => prev.map(c => c.name === name ? { ...c, qty } : c));
  }

  function removeItem(name: string) {
    setCart(prev => prev.filter(c => c.name !== name));
  }

  function clearCart() {
    setCart([]); setCustomerName(""); setCustomerPhone(""); setTableNo(""); setNotes("");
    setDiscountPct("0"); setDiscountFlat("0"); setDeliveryCharges("0");
    setPackagingRequired(false); setPaymentMode("cash");
  }

  // ── Calculations (exact same as POS) ──────────────────
  const subtotal = cart.reduce((s, c) => s + c.price * c.qty, 0);
  const discPct = parseFloat(discountPct) || 0;
  const discFlat = parseFloat(discountFlat) || 0;
  const discountAmount = Math.min(subtotal, (subtotal * discPct / 100) + discFlat);
  const taxableValue = Math.max(0, subtotal - discountAmount);
  const gstRate = 5; // 5% GST (2.5 CGST + 2.5 SGST)
  const cgst = taxableValue * gstRate / 200;
  const sgst = taxableValue * gstRate / 200;
  const delChg = parseFloat(deliveryCharges) || 0;
  const total = taxableValue + cgst + sgst + delChg;

  // ── Submit order (push to Hub as sync_order) ──────────
  async function submitOrder() {
    if (cart.length === 0) { alert("Add items to cart first!"); return; }
    setSaving(true);
    // v1.5.9 FIX: previously the UI captured payment_mode, discount_pct,
    // discount_flat, delivery_charges but never sent them to sync_orders.
    // The sync_orders schema has no dedicated columns for these (they are
    // POS-side checkout concerns), so we pack them into the `items` JSONB
    // as a leading `_meta` object. The Hub's cloud_sync consumer iterates
    // `items` looking for `name`/`qty` — entries without `name` are skipped,
    // so this is safe and round-trip preserves the data for future use.
    const payload: Array<Record<string, unknown>> = [{
      _meta: true,
      payment_mode: paymentMode,
      discount_pct: discPct,
      discount_flat: discFlat,
      delivery_charges: delChg,
      subtotal,
      discount_amount: discountAmount,
      cgst,
      sgst,
      total,
    }];
    for (const c of cart) payload.push({ name: c.name, qty: c.qty, price: c.price, notes: c.notes });

    const { error } = await supabase.from("sync_orders").insert({
      outlet_id: selOutlet,
      items: payload,
      customer_name: customerName,
      customer_phone: customerPhone,
      // v1.5.9: derive order_type from packaging flag so Hub KOT shows
      // the correct PACK / PLATE badge.
      order_type: packagingRequired ? "parcel" : "dine-in",
      order_source: orderSource,
      packaging_required: packagingRequired,
      table_no: tableNo,
      notes: notes,
      status: "pending",
      total_amount: total,
    });
    setSaving(false);
    if (error) { alert("Error: " + error.message); return; }
    alert(`✓ Order pushed!\nTotal: ${formatCurrency(total)}\nKOT will appear on KDS within 30 seconds.`);
    clearCart();
    loadOrders();
  }

  // ── Filtered items ────────────────────────────────────
  const filteredItems = items.filter(i => !search || i.name.toLowerCase().includes(search.toLowerCase()) || (i.code || "").toLowerCase().includes(search.toLowerCase()));
  const sectionItems = activeSection ? filteredItems.filter(i => i.section_local_id === activeSection) : filteredItems;

  return (
    <div className="flex h-screen">
      {/* ════════════════════════════════════════════════ */}
      {/* LEFT: Menu area (60% width) — same as POS terminal */}
      {/* ════════════════════════════════════════════════ */}
      <div className="flex-1 p-5 overflow-hidden flex flex-col">
        {/* Top bar: outlet selector + search */}
        <div className="flex items-center gap-3 mb-4">
          <select value={selOutlet} onChange={e => setSelOutlet(e.target.value)} className="border border-gray-200 rounded-xl px-3 py-2 bg-white text-sm font-medium shadow-sm">
            {outlets.map(o => <option key={o.id} value={o.id}>{o.name}</option>)}
          </select>
          <input type="text" value={search} onChange={e => setSearch(e.target.value)} placeholder="🔍 Search items by name or code..." className="flex-1 border border-gray-200 rounded-xl px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary-400" />
        </div>

        {/* Section tabs — same as POS */}
        <div className="flex gap-2 mb-3 flex-wrap">
          {sections.map(s => (
            <button key={s.id} onClick={() => setActiveSection(s.local_id)}
              className={`px-4 py-2 rounded-xl text-sm font-medium transition-all ${activeSection === s.local_id ? "bg-primary-500 text-white shadow-md" : "bg-white text-gray-600 border border-gray-200 hover:bg-gray-50"}`}>
              {s.name}
            </button>
          ))}
        </div>

        {/* Items grid — same as POS */}
        <div className="flex-1 overflow-y-auto">
          <div className="grid grid-cols-4 gap-3 pb-4">
            {sectionItems.map(item => (
              <button key={item.id} onClick={() => addToCart(item)}
                className="bg-white border border-gray-200 rounded-xl p-3 text-left hover:border-primary-300 hover:shadow-card-hover transition-all active:scale-95">
                <div className="font-medium text-sm text-gray-700 truncate">{item.name}</div>
                {item.code && <div className="text-xs text-gray-400 font-mono">{item.code}</div>}
                <div className="font-bold text-primary-600 mt-1">{formatCurrency(item.price)}</div>
              </button>
            ))}
            {sectionItems.length === 0 && <div className="col-span-4 text-center py-12 text-gray-400">No items found.</div>}
          </div>
        </div>
      </div>

      {/* ════════════════════════════════════════════════ */}
      {/* RIGHT: Cart + order details (40% width) — same as POS */}
      {/* ════════════════════════════════════════════════ */}
      <div className="w-[480px] bg-white border-l border-gray-200 flex flex-col overflow-hidden">
        {/* Cart header */}
        <div className="p-4 border-b border-gray-100 flex items-center justify-between">
          <h2 className="font-bold text-gray-700 flex items-center gap-2">
            🛒 Cart
            {cart.length > 0 && <span className="text-xs bg-primary-100 text-primary-600 px-2 py-0.5 rounded-full">{cart.reduce((s,c)=>s+c.qty,0)} items</span>}
          </h2>
          {cart.length > 0 && <button onClick={clearCart} className="text-xs text-red-400 hover:text-red-600 font-medium">Clear All</button>}
        </div>

        {/* Cart items — scrollable */}
        <div className="flex-1 overflow-y-auto p-3">
          {cart.length === 0 ? (
            <div className="text-center py-12 text-gray-300">
              <div className="text-4xl mb-2">🛒</div>
              <div className="text-sm">Click items to add to cart</div>
            </div>
          ) : (
            <div className="space-y-2">
              {cart.map(c => (
                <div key={c.name} className="flex items-center gap-2 p-2 bg-gray-50 rounded-lg">
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium text-gray-700 truncate">{c.name}</div>
                    <div className="text-xs text-gray-400">{formatCurrency(c.price)} each</div>
                  </div>
                  <div className="flex items-center gap-1">
                    <button onClick={() => changeQty(c.name, -1)} className="w-7 h-7 rounded-lg bg-white border border-gray-200 text-gray-600 font-bold hover:bg-gray-100">−</button>
                    <input type="number" value={c.qty} onChange={e => setQty(c.name, parseInt(e.target.value) || 0)} className="w-10 text-center text-sm font-medium border border-gray-200 rounded-lg py-1" />
                    <button onClick={() => changeQty(c.name, 1)} className="w-7 h-7 rounded-lg bg-white border border-gray-200 text-gray-600 font-bold hover:bg-gray-100">+</button>
                  </div>
                  <div className="text-sm font-bold text-gray-700 w-16 text-right">{formatCurrency(c.price * c.qty)}</div>
                  <button onClick={() => removeItem(c.name)} className="text-red-300 hover:text-red-500 text-sm">✕</button>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Order details + totals — fixed at bottom */}
        <div className="border-t border-gray-100 p-4 space-y-3 max-h-[55%] overflow-y-auto">
          {/* Customer info */}
          <div className="grid grid-cols-2 gap-2">
            <input type="text" value={customerName} onChange={e => setCustomerName(e.target.value)} placeholder="Customer name" className="border border-gray-200 rounded-lg px-3 py-1.5 text-sm" />
            <input type="text" value={tableNo} onChange={e => setTableNo(e.target.value)} placeholder="Table no" className="border border-gray-200 rounded-lg px-3 py-1.5 text-sm" />
          </div>
          <input type="text" value={customerPhone} onChange={e => setCustomerPhone(e.target.value)} placeholder="Phone (optional)" className="w-full border border-gray-200 rounded-lg px-3 py-1.5 text-sm" />

          {/* Order source + packaging */}
          <div className="flex gap-2 items-center">
            <select value={orderSource} onChange={e => setOrderSource(e.target.value)} className="flex-1 border border-gray-200 rounded-lg px-3 py-1.5 text-sm bg-white">
              <option value="walkin">🚶 Walk-in</option>
              <option value="website">🌐 Website</option>
              <option value="phone">📞 Phone</option>
              <option value="swiggy">🟧 Swiggy</option>
              <option value="zomato">🟥 Zomato</option>
            </select>
            <label className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg cursor-pointer text-sm font-medium ${packagingRequired ? "bg-orange-50 text-orange-600 border border-orange-300" : "bg-gray-50 text-gray-400 border border-gray-200"}`}>
              <input type="checkbox" checked={packagingRequired} onChange={e => setPackagingRequired(e.target.checked)} className="hidden" />
              📦 Packaging
            </label>
          </div>

          {/* Discount + delivery */}
          <div className="grid grid-cols-3 gap-2">
            <div><label className="block text-xs text-gray-400 mb-0.5">Disc %</label><input type="number" value={discountPct} onChange={e => setDiscountPct(e.target.value)} className="w-full border border-gray-200 rounded-lg px-2 py-1.5 text-sm" /></div>
            <div><label className="block text-xs text-gray-400 mb-0.5">Disc ₹</label><input type="number" value={discountFlat} onChange={e => setDiscountFlat(e.target.value)} className="w-full border border-gray-200 rounded-lg px-2 py-1.5 text-sm" /></div>
            <div><label className="block text-xs text-gray-400 mb-0.5">Delivery ₹</label><input type="number" value={deliveryCharges} onChange={e => setDeliveryCharges(e.target.value)} className="w-full border border-gray-200 rounded-lg px-2 py-1.5 text-sm" /></div>
          </div>

          {/* Payment mode */}
          <div className="flex gap-1">
            {["cash", "card", "upi", "other"].map(m => (
              <button key={m} onClick={() => setPaymentMode(m)}
                className={`flex-1 py-1.5 rounded-lg text-xs font-medium capitalize ${paymentMode === m ? "bg-primary-500 text-white" : "bg-gray-50 text-gray-500 border border-gray-200"}`}>
                {m}
              </button>
            ))}
          </div>

          {/* Notes */}
          <input type="text" value={notes} onChange={e => setNotes(e.target.value)} placeholder="Notes to kitchen..." className="w-full border border-gray-200 rounded-lg px-3 py-1.5 text-sm" />

          {/* Totals — exact same as POS */}
          <div className="bg-gray-50 rounded-xl p-3 space-y-1 text-sm">
            <div className="flex justify-between text-gray-500"><span>Subtotal</span><span>{formatCurrency(subtotal)}</span></div>
            {discountAmount > 0 && <div className="flex justify-between text-red-500"><span>Discount</span><span>-{formatCurrency(discountAmount)}</span></div>}
            <div className="flex justify-between text-gray-500"><span>CGST @2.5%</span><span>{formatCurrency(cgst)}</span></div>
            <div className="flex justify-between text-gray-500"><span>SGST @2.5%</span><span>{formatCurrency(sgst)}</span></div>
            {delChg > 0 && <div className="flex justify-between text-gray-500"><span>Delivery</span><span>{formatCurrency(delChg)}</span></div>}
            <div className="flex justify-between font-bold text-lg text-gray-800 pt-1 border-t border-gray-200"><span>TOTAL</span><span className="text-primary-600">{formatCurrency(total)}</span></div>
          </div>

          {/* Push button */}
          <button onClick={submitOrder} disabled={saving || cart.length === 0}
            className="w-full bg-primary-500 hover:bg-primary-600 text-white py-3 rounded-xl font-bold text-sm shadow-md disabled:opacity-50 transition-colors">
            {saving ? "Pushing..." : `Push Order → ${formatCurrency(total)}`}
          </button>

          {/* Recent orders */}
          <div className="pt-2 border-t border-gray-50">
            <div className="text-xs font-medium text-gray-400 uppercase mb-1.5">Recent Orders</div>
            <div className="space-y-1 max-h-32 overflow-y-auto">
              {orders.map(o => (
                <div key={o.id} className="flex items-center justify-between text-xs py-1 border-b border-gray-50">
                  <div><span className="font-medium text-gray-600">#{o.id}</span> <span className="text-gray-400">{o.customer_name || "—"}</span></div>
                  <div className="flex items-center gap-2">
                    <span className="text-gray-400">{timeAgo(o.created_at)}</span>
                    <span className={`px-1.5 py-0.5 rounded text-xs ${o.status === "pending" ? "bg-yellow-50 text-yellow-600" : o.status === "processed" || o.status === "pushed" ? "bg-blue-50 text-blue-600" : o.status === "error" ? "bg-red-50 text-red-600" : "bg-green-50 text-green-600"}`}>{o.status}</span>
                  </div>
                </div>
              ))}
              {orders.length === 0 && <div className="text-gray-300 text-center py-3">No orders yet</div>}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
