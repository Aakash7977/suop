"use client";
import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { supabase, type Bill, type BillItem, type Outlet } from "@/lib/supabase";
import { formatCurrency } from "@/lib/utils";

const THERMAL_CHARS = 42; // matches Hub's 80mm thermal printer setting

export default function BillDetailPage() {
  const params = useParams<{ id: string }>();
  const router = useRouter();
  const [bill, setBill] = useState<Bill | null>(null);
  const [items, setItems] = useState<BillItem[]>([]);
  const [outlet, setOutlet] = useState<Outlet | null>(null);
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);

  useEffect(() => {
    if (!params?.id) return;
    (async () => {
      // Load the bill, its line items, and the outlet info in parallel
      const [billRes, itemsRes] = await Promise.all([
        supabase.from("bills").select("*").eq("id", params.id).single(),
        supabase.from("bill_items").select("*").eq("bill_id", params.id).order("item_name"),
      ]);
      if (billRes.error || !billRes.data) { setNotFound(true); setLoading(false); return; }
      setBill(billRes.data as Bill);
      setItems((itemsRes.data || []) as BillItem[]);
      if (billRes.data?.outlet_id) {
        const { data: o } = await supabase.from("outlets").select("*").eq("id", billRes.data.outlet_id).single();
        if (o) setOutlet(o as Outlet);
      }
      setLoading(false);
    })();
  }, [params?.id]);

  if (loading) return (
    <div className="flex items-center justify-center h-screen">
      <div className="spinner w-10 h-10 border-4 border-primary-500 border-t-transparent rounded-full"></div>
    </div>
  );

  if (notFound || !bill) return (
    <div className="p-8">
      <div className="bg-white rounded-2xl shadow-card p-10 text-center">
        <div className="text-5xl mb-3">🔍</div>
        <h1 className="text-xl font-bold text-gray-800 mb-1">Bill not found</h1>
        <p className="text-gray-500 text-sm mb-5">This bill may have been deleted, or the link is invalid.</p>
        <button onClick={() => router.push("/bills")} className="bg-primary-500 hover:bg-primary-600 text-white px-5 py-2 rounded-xl text-sm font-medium">← Back to Bills</button>
      </div>
    </div>
  );

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-5xl mx-auto">
      {/* Top bar: back + print */}
      <div className="flex items-center justify-between mb-5 print:hidden">
        <button onClick={() => router.push("/bills")} className="inline-flex items-center gap-2 text-sm font-medium text-gray-600 hover:text-gray-800">
          ← Back to Bills
        </button>
        <button onClick={() => window.print()} className="inline-flex items-center gap-1.5 bg-primary-500 hover:bg-primary-600 text-white px-4 py-2 rounded-xl text-sm font-medium shadow-sm">
          🖨 Print Bill
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6">
        {/* ════════════════════════════════════════════════ */}
        {/* LEFT: POS-style thermal receipt preview           */}
        {/* ════════════════════════════════════════════════ */}
        <div className="bg-white rounded-2xl shadow-card p-4 sm:p-6 print:shadow-none print:rounded-none print:p-0">
          <div className="text-center mb-3 print:hidden">
            <h2 className="font-semibold text-gray-700 text-sm uppercase tracking-wide">Receipt Preview</h2>
            <p className="text-xs text-gray-400">80mm thermal format</p>
          </div>

          <pre className="bg-gray-50 rounded-xl p-4 text-[11px] leading-relaxed text-gray-800 whitespace-pre-wrap font-mono overflow-x-auto print:bg-white print:p-0 print:text-[10px]">
{buildReceipt(outlet, bill, items)}
          </pre>
        </div>

        {/* ════════════════════════════════════════════════ */}
        {/* RIGHT: structured detail cards                    */}
        {/* ════════════════════════════════════════════════ */}
        <div className="space-y-5">
          {/* Header card */}
          <div className="bg-white rounded-2xl shadow-card p-6">
            <div className="flex items-start justify-between mb-3">
              <div>
                <div className="text-xs text-gray-400 uppercase tracking-wide mb-0.5">Bill Number</div>
                <div className="text-2xl font-bold text-gray-800">#{bill.bill_no}</div>
              </div>
              <div className="text-right">
                {bill.pl_voided ? (
                  <span className="inline-block text-xs px-3 py-1 rounded-full bg-red-50 text-red-500 font-medium">VOIDED</span>
                ) : (
                  <span className="inline-block text-xs px-3 py-1 rounded-full bg-green-50 text-green-600 font-medium">● SETTLED</span>
                )}
                <div className="text-xs text-gray-400 mt-1">Synced {new Date(bill.synced_at).toLocaleString()}</div>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4 pt-3 border-t border-gray-100">
              <div>
                <div className="text-xs text-gray-400 uppercase mb-0.5">Date</div>
                <div className="text-sm font-medium text-gray-700">{bill.bill_date}</div>
              </div>
              <div>
                <div className="text-xs text-gray-400 uppercase mb-0.5">Time</div>
                <div className="text-sm font-medium text-gray-700">{bill.bill_time}</div>
              </div>
              <div>
                <div className="text-xs text-gray-400 uppercase mb-0.5">Outlet</div>
                <div className="text-sm font-medium text-gray-700">{outlet?.name || "—"}</div>
              </div>
              <div>
                <div className="text-xs text-gray-400 uppercase mb-0.5">POS Terminal</div>
                <div className="text-sm font-medium text-gray-700">T{bill.terminal_id}</div>
              </div>
            </div>
          </div>

          {/* Order info */}
          <div className="bg-white rounded-2xl shadow-card p-6">
            <h3 className="text-sm font-semibold text-gray-700 uppercase tracking-wide mb-3">Order Details</h3>
            <div className="grid grid-cols-2 gap-y-3 gap-x-4 text-sm">
              <div><span className="text-gray-400">Customer</span><div className="font-medium text-gray-700">{bill.customer_name || "—"}</div></div>
              <div><span className="text-gray-400">Table</span><div className="font-medium text-gray-700">{bill.table_no || "—"}</div></div>
              <div><span className="text-gray-400">Source</span><div className="font-medium text-gray-700 capitalize">{bill.order_source}</div></div>
              <div><span className="text-gray-400">Packaging</span><div className="font-medium text-gray-700">{bill.packaging_required ? "📦 Yes (Pack)" : "🍽️ No (Plate)"}</div></div>
              <div><span className="text-gray-400">Payment Mode</span><div className="font-medium text-gray-700 capitalize">{bill.payment_mode}</div></div>
            </div>
          </div>

          {/* Items table */}
          <div className="bg-white rounded-2xl shadow-card overflow-hidden">
            <div className="px-4 sm:px-6 py-4 border-b border-gray-100">
              <h3 className="text-sm font-semibold text-gray-700 uppercase tracking-wide">Items ({items.length})</h3>
            </div>
            <div className="overflow-x-auto">
            <table className="w-full min-w-[400px]">
              <thead className="bg-gray-50">
                <tr>
                  <th className="text-left px-4 sm:px-6 py-2 text-xs font-medium text-gray-400 uppercase">Item</th>
                  <th className="text-right px-3 py-2 text-xs font-medium text-gray-400 uppercase">Qty</th>
                  <th className="text-right px-3 py-2 text-xs font-medium text-gray-400 uppercase">Price</th>
                  <th className="text-right px-4 sm:px-6 py-2 text-xs font-medium text-gray-400 uppercase">Amount</th>
                </tr>
              </thead>
              <tbody>
                {items.map(it => (
                  <tr key={it.id} className="border-b border-gray-50">
                    <td className="px-4 sm:px-6 py-2.5">
                      <div className="text-sm font-medium text-gray-700">{it.item_name}</div>
                      {it.section && <div className="text-xs text-gray-400">{it.section}</div>}
                      {it.notes && <div className="text-xs text-orange-500 italic mt-0.5">↳ {it.notes}</div>}
                      {it.packaging_type && <div className="text-xs text-purple-500 mt-0.5">📦 {it.packaging_type}</div>}
                    </td>
                    <td className="px-3 py-2.5 text-sm text-right text-gray-600">{it.quantity}</td>
                    <td className="px-3 py-2.5 text-sm text-right text-gray-600">{formatCurrency(it.unit_price)}</td>
                    <td className="px-4 sm:px-6 py-2.5 text-sm font-medium text-right text-gray-800">{formatCurrency(it.amount)}</td>
                  </tr>
                ))}
                {items.length === 0 && (
                  <tr><td colSpan={4} className="px-4 sm:px-6 py-6 text-center text-sm text-gray-400">No items recorded for this bill.</td></tr>
                )}
              </tbody>
            </table>
            </div>
          </div>

          {/* Totals */}
          <div className="bg-white rounded-2xl shadow-card p-6">
            <h3 className="text-sm font-semibold text-gray-700 uppercase tracking-wide mb-3">Bill Summary</h3>
            <div className="space-y-2 text-sm">
              <Row label="Subtotal" value={formatCurrency(bill.subtotal)} />
              {bill.discount_amount > 0 && <Row label="Discount" value={"-" + formatCurrency(bill.discount_amount)} valueClass="text-red-500" />}
              <Row label="CGST @2.5%" value={formatCurrency(bill.cgst)} />
              <Row label="SGST @2.5%" value={formatCurrency(bill.sgst)} />
              {bill.packaging_charge > 0 && <Row label="Packaging Charge" value={formatCurrency(bill.packaging_charge)} />}
              {bill.delivery_charges > 0 && <Row label="Delivery Charges" value={formatCurrency(bill.delivery_charges)} />}
              <div className="pt-2 mt-2 border-t border-gray-200 flex justify-between items-center">
                <span className="text-base font-bold text-gray-800">TOTAL</span>
                <span className="text-xl font-bold text-primary-600">{formatCurrency(bill.total)}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Print-only CSS: hide everything except the receipt preview */}
      <style jsx global>{`
        @media print {
          body * { visibility: hidden; }
          pre, pre * { visibility: visible; }
          pre { position: absolute; left: 0; top: 0; width: 80mm; padding: 2mm; font-size: 10px; }
        }
      `}</style>
    </div>
  );
}

// ── Thermal receipt layout helpers ───────────────────────────
function center(text: string): string {
  if (!text) return "";
  const pad = Math.max(0, Math.floor((THERMAL_CHARS - text.length) / 2));
  return " ".repeat(pad) + text;
}

function lineStr(l: string, r: string = ""): string {
  const space = Math.max(1, THERMAL_CHARS - l.length - r.length);
  return l + " ".repeat(space) + r;
}

function wrap(text: string, indent = 0): string[] {
  if (!text) return [];
  const words = text.split(" ");
  const lines: string[] = [];
  let cur = " ".repeat(indent);
  for (const w of words) {
    if ((cur + w).length > THERMAL_CHARS && cur.trim()) { lines.push(cur); cur = " ".repeat(indent) + w; }
    else cur += (cur.trim() ? " " : "") + w;
  }
  if (cur.trim()) lines.push(cur);
  return lines;
}

// v1.6.1 FIX: Build the entire receipt as ONE string joined by "\n".
// Previously each line was a separate JSX `{expr}` child of <pre>, but JSX
// collapses whitespace between expressions — so `Subtotal ₹277.00` and
// `CGST @2.5% ₹0.08` ended up on the same visual line, producing the
// overlapping mess the user reported. Centralising it here also makes the
// layout testable in isolation.
function buildReceipt(outlet: Outlet | null, bill: Bill, items: BillItem[]): string {
  const eq = "=".repeat(THERMAL_CHARS);
  const dash = "-".repeat(THERMAL_CHARS);
  const lines: string[] = [];

  // ── Header ─────────────────────────────────────────────
  lines.push(center(outlet?.name || "Mini Centrino Lite"));
  if (outlet?.address) lines.push(center(outlet.address));
  if (outlet?.city) lines.push(center(outlet.city));
  if (outlet?.phone) lines.push(center("Tel: " + outlet.phone));
  if (outlet?.gstin) lines.push(center("GSTIN: " + outlet.gstin));
  if (outlet?.tagline) lines.push(center(outlet.tagline));

  // ── Bill meta ──────────────────────────────────────────
  lines.push(eq);
  lines.push(lineStr("Bill No:", `#${bill.bill_no}`));
  lines.push(lineStr("Date:", bill.bill_date));
  lines.push(lineStr("Time:", bill.bill_time));
  lines.push(lineStr("Terminal:", `T${bill.terminal_id}`));
  if (bill.table_no) lines.push(lineStr("Table:", bill.table_no));
  if (bill.customer_name) lines.push(lineStr("Customer:", bill.customer_name));
  lines.push(lineStr("Source:", bill.order_source === "walkin" ? "Walk-in" : bill.order_source));
  lines.push(lineStr("Packaging:", bill.packaging_required ? "Yes (PACK)" : "No (PLATE)"));
  lines.push(lineStr("Payment:", bill.payment_mode.toUpperCase()));
  if (bill.pl_voided) lines.push(center("*** VOIDED ***"));

  // ── Items ──────────────────────────────────────────────
  lines.push(eq);
  lines.push(lineStr("ITEM", "AMT"));
  lines.push(dash);
  for (const it of items) {
    lines.push(lineStr(it.item_name, formatCurrency(it.amount)));
    if (it.quantity > 1) lines.push("  " + `${it.quantity} x ${formatCurrency(it.unit_price)}`);
    if (it.notes) for (const l of wrap("note: " + it.notes, 2)) lines.push(l);
  }

  // ── Totals ─────────────────────────────────────────────
  lines.push(dash);
  lines.push(lineStr("Subtotal", formatCurrency(bill.subtotal)));
  if (bill.discount_amount > 0) lines.push(lineStr("Discount", "-" + formatCurrency(bill.discount_amount)));
  lines.push(lineStr("CGST @2.5%", formatCurrency(bill.cgst)));
  lines.push(lineStr("SGST @2.5%", formatCurrency(bill.sgst)));
  if (bill.packaging_charge > 0) lines.push(lineStr("Packaging", formatCurrency(bill.packaging_charge)));
  if (bill.delivery_charges > 0) lines.push(lineStr("Delivery", formatCurrency(bill.delivery_charges)));
  lines.push(eq);
  lines.push(lineStr("TOTAL", formatCurrency(bill.total)));
  lines.push(eq);
  lines.push(center("*** Thank You! Visit Again ***"));

  return lines.join("\n");
}

// ── Small helper component ───────────────────────────────────
function Row({ label, value, valueClass = "text-gray-700" }: { label: string; value: string; valueClass?: string }) {
  return (
    <div className="flex justify-between">
      <span className="text-gray-500">{label}</span>
      <span className={`font-medium ${valueClass}`}>{value}</span>
    </div>
  );
}
