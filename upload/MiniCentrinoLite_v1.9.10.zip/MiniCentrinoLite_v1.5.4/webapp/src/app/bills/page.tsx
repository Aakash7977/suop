"use client";
import { useEffect, useState, useCallback } from "react";
import { useRouter } from "next/navigation";
import { supabase, type Outlet } from "@/lib/supabase";
import { formatCurrency } from "@/lib/utils";
import { useRealtime } from "@/lib/realtime";

function todayStr() { const d = new Date(); return `${String(d.getDate()).padStart(2,"0")}/${String(d.getMonth()+1).padStart(2,"0")}/${d.getFullYear()}`; }
function dateStr(daysAgo: number) { const d = new Date(); d.setDate(d.getDate() - daysAgo); return `${String(d.getDate()).padStart(2,"0")}/${String(d.getMonth()+1).padStart(2,"0")}/${d.getFullYear()}`; }

export default function BillsPage() {
  const router = useRouter();
  const [outlets, setOutlets] = useState<Outlet[]>([]);
  const [selOutlet, setSelOutlet] = useState("");
  const [bills, setBills] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [selDate, setSelDate] = useState("today");
  const [customDate, setCustomDate] = useState("");

  const load = useCallback(async () => {
    if (!selOutlet) return;
    // v1.5.9: include `id` so the View button can route to /bills/[id].
    let q = supabase.from("bills").select("*").eq("outlet_id", selOutlet);
    if (selDate === "today") q = q.eq("bill_date", todayStr());
    else if (selDate === "yesterday") q = q.eq("bill_date", dateStr(1));
    else if (selDate === "7days") { const dates: string[] = []; for (let i = 0; i < 7; i++) dates.push(dateStr(i)); q = q.in("bill_date", dates); }
    else if (selDate === "custom" && customDate) q = q.eq("bill_date", customDate);
    const { data } = await q.order("bill_no", { ascending: false }).limit(500);
    setBills(data || []);
    setLoading(false);
  }, [selOutlet, selDate, customDate]);

  useEffect(() => { (async () => { const { data } = await supabase.from("outlets").select("*").eq("is_active", true).order("name"); setOutlets(data || []); if (data && data[0]) setSelOutlet(data[0].id); })(); }, []);
  useEffect(() => { load(); }, [load]);
  // v1.6.0: kept the polling interval but slowed from 15s → 60s as a fallback
  // for when Realtime is not enabled. Realtime below triggers instant refetch.
  useEffect(() => { if (!selOutlet) return; const i = setInterval(load, 60000); return () => clearInterval(i); }, [selOutlet, load]);

  // v1.6.0 NEW: Supabase Realtime — instant refetch when bills change on this outlet.
  useRealtime({
    table: "bills",
    filter: selOutlet ? `outlet_id=eq.${selOutlet}` : undefined,
    onChange: load,
    enabled: !!selOutlet,
  });

  const filtered = bills.filter(b => {
    if (!search) return true;
    const s = search.toLowerCase();
    return String(b.bill_no).includes(s) || (b.customer_name || "").toLowerCase().includes(s) || (b.table_no || "").toLowerCase().includes(s) || (b.payment_mode || "").toLowerCase().includes(s);
  });
  const totalRev = filtered.filter(b => !b.pl_voided).reduce((s, b) => s + (b.total || 0), 0);
  const dateLabel = selDate === "today" ? "Today" : selDate === "yesterday" ? "Yesterday" : selDate === "7days" ? "Last 7 Days" : selDate === "all" ? "All Time" : customDate || "Custom";

  return (
    <div className="p-4 sm:p-6 lg:p-8">
      <div className="flex items-center justify-between mb-4 flex-wrap gap-3">
        <div><h1 className="text-xl sm:text-2xl font-bold text-gray-800">Bills</h1><p className="text-gray-500 text-xs sm:text-sm mt-0.5">Showing: {dateLabel} — auto-refresh 60s</p></div>
        <div className="flex gap-2 sm:gap-3 flex-wrap">
          <select value={selDate} onChange={e => setSelDate(e.target.value)} className="border border-gray-200 rounded-xl px-3 py-2 bg-white text-sm shadow-sm">
            <option value="today">Today</option><option value="yesterday">Yesterday</option><option value="7days">Last 7 Days</option><option value="all">All Time</option><option value="custom">Custom Date</option>
          </select>
          {selDate === "custom" && <input type="text" value={customDate} onChange={e => setCustomDate(e.target.value)} placeholder="DD/MM/YYYY" className="border border-gray-200 rounded-xl px-3 py-2 text-sm w-32" />}
          <select value={selOutlet} onChange={e => setSelOutlet(e.target.value)} className="border border-gray-200 rounded-xl px-3 py-2 bg-white text-sm shadow-sm">
            {outlets.map(o => <option key={o.id} value={o.id}>{o.name}</option>)}
          </select>
        </div>
      </div>
      <div className="flex items-center gap-3 mb-4 flex-wrap">
        <input type="text" value={search} onChange={e => setSearch(e.target.value)} placeholder="Search by bill no, customer..." className="border border-gray-200 rounded-xl px-3 py-2 flex-1 min-w-[200px] sm:w-80 text-sm" />
        <div className="text-sm text-gray-500">{filtered.length} bills | Revenue: <span className="font-bold text-green-600">{formatCurrency(totalRev)}</span></div>
      </div>
      {loading ? <div className="text-center py-16 text-gray-400">Loading bills...</div> : (
        <div className="bg-white rounded-2xl shadow-card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full min-w-[900px]">
              <thead className="bg-gray-50"><tr>{["Bill #", "Date", "Time", "Table", "Customer", "Pkg", "Source", "Payment", "Total", "POS", "Status", ""].map(h => <th key={h || "action"} className="text-left px-4 py-3 text-xs font-medium text-gray-400 uppercase">{h}</th>)}</tr></thead>
            <tbody>
              {filtered.map(b => (
                <tr key={b.id} className={`border-b border-gray-50 hover:bg-gray-50 ${b.pl_voided ? "opacity-40" : ""}`}>
                  <td className="px-4 py-2.5 text-sm font-medium text-gray-700">#{b.bill_no}</td>
                  <td className="px-4 py-2.5 text-sm text-gray-500">{b.bill_date}</td>
                  <td className="px-4 py-2.5 text-sm text-gray-500">{b.bill_time}</td>
                  <td className="px-4 py-2.5 text-sm text-gray-500">{b.table_no || "—"}</td>
                  <td className="px-4 py-2.5 text-sm text-gray-700">{b.customer_name || "—"}</td>
                  <td className="px-4 py-2.5 text-center text-sm">{b.packaging_required ? "📦" : "🍽️"}</td>
                  <td className="px-4 py-2.5">{b.order_source && b.order_source !== "walkin" ? <span className="text-xs px-2 py-0.5 rounded-full bg-purple-50 text-purple-600 capitalize">{b.order_source}</span> : <span className="text-xs text-gray-400">Walk-in</span>}</td>
                  <td className="px-4 py-2.5 text-sm text-gray-500 capitalize">{b.payment_mode}</td>
                  <td className="px-4 py-2.5 text-sm font-bold text-gray-800 text-right">{formatCurrency(b.total)}</td>
                  <td className="px-4 py-2.5 text-sm text-gray-400 text-center">T{b.terminal_id}</td>
                  <td className="px-4 py-2.5 text-center">{b.pl_voided ? <span className="text-xs px-2 py-0.5 rounded-full bg-red-50 text-red-500">VOID</span> : <span className="w-2 h-2 inline-block rounded-full bg-green-400"></span>}</td>
                  {/* v1.5.9 NEW: View Bill button → /bills/[id] detail page */}
                  <td className="px-4 py-2.5 text-right">
                    <button onClick={() => router.push(`/bills/${b.id}`)} className="inline-flex items-center gap-1 text-xs font-medium text-primary-600 hover:text-primary-700 bg-primary-50 hover:bg-primary-100 px-3 py-1.5 rounded-lg transition-colors">
                      <span>👁</span> View
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          </div>
          {filtered.length === 0 && <div className="text-center py-12 text-gray-400 text-sm">No bills found for selected period.</div>}
        </div>
      )}
    </div>
  );
}
