"use client";
import { useEffect, useState } from "react";
import { supabase, type WebUser, type Outlet, type Role } from "@/lib/supabase";
import { useAuth } from "@/lib/auth";
import { usePermissions } from "@/lib/permissions";

export default function UsersPage() {
  const { profile } = useAuth();
  const { can } = usePermissions(profile?.role);
  const [users, setUsers] = useState<WebUser[]>([]);
  const [outlets, setOutlets] = useState<Outlet[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  const [pass, setPass] = useState("");
  const [role, setRole] = useState<Role>("manager");
  const [oid, setOid] = useState("");
  const [saving, setSaving] = useState(false);
  const [feedback, setFeedback] = useState<{ type: "ok" | "err"; msg: string } | null>(null);

  const load = async () => {
    const [{ data: u }, { data: o }] = await Promise.all([
      supabase.from("web_users").select("*").order("created_at"),
      supabase.from("outlets").select("*").order("name"),
    ]);
    setUsers(u || []);
    setOutlets(o || []);
  };
  useEffect(() => { load(); }, []);

  // v1.8.0: button-level permission check (user's existing pattern).
  // The "Add User" button only renders if can("users", "create") is true.
  // Owner bypasses — can() returns true for owner regardless of role_permissions.
  const canCreate = can("users", "create");
  const canEdit = can("users", "edit");
  const canDelete = can("users", "delete");

  async function add() {
    if (!email || !pass || !name) { setFeedback({ type: "err", msg: "All fields required" }); return; }
    setSaving(true);
    setFeedback(null);

    // v1.8.0: reverted to plaintext password storage as per the user's
    // existing implementation. Password stored as `plain:password`.
    // This is intentional — "simple but functional for LAN" per user.
    const { error } = await supabase.from("web_users").insert({
      email: email.trim().toLowerCase(),
      full_name: name.trim(),
      password_hash: `plain:${pass}`,
      role,
      outlet_id: role === "owner" ? null : (oid || null),
      is_active: true,
    });

    setSaving(false);
    if (error) {
      setFeedback({ type: "err", msg: error.message });
      return;
    }
    setFeedback({ type: "ok", msg: `✓ User ${name} created with role ${role}. They can now sign in.` });
    setShowForm(false);
    setEmail(""); setName(""); setPass(""); setRole("manager"); setOid("");
    load();
  }

  async function toggleActive(u: WebUser) {
    if (!canEdit) return;
    const { error } = await supabase.from("web_users").update({ is_active: !u.is_active }).eq("id", u.id);
    if (error) { setFeedback({ type: "err", msg: error.message }); return; }
    load();
  }

  async function resetPassword(u: WebUser) {
    if (!canEdit) return;
    const newPass = prompt(`Enter new password for ${u.email}:`);
    if (!newPass) return;
    const { error } = await supabase.from("web_users").update({ password_hash: `plain:${newPass}` }).eq("id", u.id);
    if (error) { setFeedback({ type: "err", msg: error.message }); return; }
    setFeedback({ type: "ok", msg: `✓ Password updated for ${u.email}.` });
  }

  const oName = (id: string | null) => !id ? "All (Owner)" : outlets.find(o => o.id === id)?.name || "?";

  return (
    <div className="p-4 sm:p-6 lg:p-8">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">Users</h1>
          <p className="text-gray-500 text-sm mt-0.5">Web app access management</p>
        </div>
        {/* v1.8.0: button-level permission check — only show if can("users","create") */}
        {canCreate && (
          <button onClick={() => setShowForm(!showForm)} className="bg-primary-500 hover:bg-primary-600 text-white px-4 py-2.5 rounded-xl text-sm font-medium">
            {showForm ? "✕ Cancel" : "+ Add User"}
          </button>
        )}
      </div>

      {/* Info banner explaining the simple LAN auth model */}
      <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 mb-5 text-sm text-blue-800">
        <div className="font-semibold mb-1">ℹ️ How login works in v1.8</div>
        <p className="text-blue-700 text-xs leading-relaxed">
          Passwords are stored as <code className="bg-blue-100 px-1 rounded">plain:password</code> in the
          <code className="bg-blue-100 px-1 rounded">web_users.password_hash</code> column. On login, the
          webapp queries <code className="bg-blue-100 px-1 rounded">web_users</code> directly (no Supabase Auth).
          The session is stored in <code className="bg-blue-100 px-1 rounded">localStorage</code> under the
          <code className="bg-blue-100 px-1 rounded">mcl_user</code> key. This is intentional for LAN-only deployments —
          not suitable for public internet exposure without network-level protection.
        </p>
      </div>

      {feedback && (
        <div className={`rounded-xl p-4 mb-5 text-sm ${feedback.type === "ok" ? "bg-green-50 border border-green-200 text-green-800" : "bg-red-50 border border-red-200 text-red-700"}`}>
          {feedback.msg}
        </div>
      )}

      {showForm && canCreate && (
        <div className="bg-white rounded-2xl shadow-card p-5 mb-5">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs text-gray-400 mb-1">Full Name</label>
              <input type="text" value={name} onChange={e => setName(e.target.value)} className="border border-gray-200 rounded-lg px-3 py-2 w-full text-sm" />
            </div>
            <div>
              <label className="block text-xs text-gray-400 mb-1">Email</label>
              <input type="email" value={email} onChange={e => setEmail(e.target.value)} className="border border-gray-200 rounded-lg px-3 py-2 w-full text-sm" />
            </div>
            <div>
              <label className="block text-xs text-gray-400 mb-1">Password</label>
              <input type="text" value={pass} onChange={e => setPass(e.target.value)} placeholder="initial password" className="border border-gray-200 rounded-lg px-3 py-2 w-full text-sm" />
            </div>
            <div>
              <label className="block text-xs text-gray-400 mb-1">Role</label>
              <select value={role} onChange={e => setRole(e.target.value as Role)} className="border border-gray-200 rounded-lg px-3 py-2 w-full bg-white text-sm">
                <option value="owner">Owner</option>
                <option value="manager">Manager</option>
                <option value="cashier">Cashier</option>
                <option value="viewer">Viewer</option>
              </select>
            </div>
            {role !== "owner" && (
              <div>
                <label className="block text-xs text-gray-400 mb-1">Outlet</label>
                <select value={oid} onChange={e => setOid(e.target.value)} className="border border-gray-200 rounded-lg px-3 py-2 w-full bg-white text-sm">
                  <option value="">— Select —</option>
                  {outlets.map(o => <option key={o.id} value={o.id}>{o.name}</option>)}
                </select>
              </div>
            )}
          </div>
          <button onClick={add} disabled={saving} className="mt-3 bg-green-500 text-white px-5 py-2 rounded-lg text-sm font-medium disabled:opacity-50">
            {saving ? "Saving..." : "✓ Save"}
          </button>
        </div>
      )}

      <div className="bg-white rounded-2xl shadow-card overflow-hidden">
        <div className="overflow-x-auto">
        <table className="w-full min-w-[700px]">
          <thead className="bg-gray-50">
            <tr>{["Name", "Email", "Role", "Outlet", "Status", canEdit || canDelete ? "Actions" : ""].map(h => <th key={h || "actions"} className="text-left px-5 py-3 text-xs font-medium text-gray-400 uppercase">{h}</th>)}</tr>
          </thead>
          <tbody>
            {users.map(u => (
              <tr key={u.id} className="border-b border-gray-50 hover:bg-gray-50">
                <td className="px-5 py-3 text-sm font-medium text-gray-700">{u.full_name || "—"}</td>
                <td className="px-5 py-3 text-sm text-gray-500">{u.email}</td>
                <td className="px-5 py-3">
                  <span className={`text-xs px-2 py-0.5 rounded-full uppercase ${u.role === "owner" ? "bg-purple-50 text-purple-600" : u.role === "manager" ? "bg-blue-50 text-blue-600" : u.role === "cashier" ? "bg-green-50 text-green-600" : "bg-gray-100 text-gray-500"}`}>
                    {u.role}
                  </span>
                </td>
                <td className="px-5 py-3 text-sm text-gray-500">{oName(u.outlet_id)}</td>
                <td className="px-5 py-3">
                  <span className={`text-xs px-2 py-0.5 rounded-full ${u.is_active ? "bg-green-50 text-green-600" : "bg-red-50 text-red-500"}`}>
                    {u.is_active ? "● Active" : "○ Disabled"}
                  </span>
                </td>
                {(canEdit || canDelete) && (
                  <td className="px-5 py-3 text-sm">
                    <div className="flex gap-2">
                      {canEdit && (
                        <>
                          <button onClick={() => toggleActive(u)} className="text-xs text-orange-500 hover:underline">
                            {u.is_active ? "Disable" : "Enable"}
                          </button>
                          <button onClick={() => resetPassword(u)} className="text-xs text-blue-500 hover:underline">
                            Reset Password
                          </button>
                        </>
                      )}
                    </div>
                  </td>
                )}
              </tr>
            ))}
            {users.length === 0 && (
              <tr><td colSpan={6} className="px-5 py-8 text-center text-sm text-gray-400">No users yet. Click "Add User" to create the first one.</td></tr>
            )}
          </tbody>
        </table>
        </div>
      </div>

      {profile && (
        <div className="mt-6 text-xs text-gray-400">
          Signed in as: <span className="font-mono">{profile.email}</span> ({profile.role})
        </div>
      )}
    </div>
  );
}
