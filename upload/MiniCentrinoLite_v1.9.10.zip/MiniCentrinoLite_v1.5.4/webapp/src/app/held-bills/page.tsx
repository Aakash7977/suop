"use client";
import { useEffect, useState, useCallback } from "react";
import { supabase, type Outlet } from "@/lib/supabase";
import { formatCurrency } from "@/lib/utils";
import { useRealtime } from "@/lib/realtime";

export default function HeldBillsPage() {
  const [outlets, setOutlets] = useState<Outlet[]>([]);
  const [sel, setSel] = useState("");
  const [held, setHeld] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    if (!sel) return;
    const { data } = await supabase.from("held_bills").select("*").eq("outlet_id", sel).eq("recalled", false).order("created_at", { ascending: false }).limit(100);
    setHeld(data || []);
    setLoading(false);
  }, [sel]);

  useEffect(() => { (async () => { const { data } = await supabase.from("outlets").select("*").eq("is_active", true).order("name"); setOutlets(data || []); if (data && data[0]) setSel(data[0].id); })(); }, []);
  useEffect(() => { load(); }, [load]);
  // v1.6.0: polling slowed from 15s → 60s as fallback when Realtime is not enabled.
  useEffect(() => { if (!sel) return; const i = setInterval(load, 60000); return () => clearInterval(i); }, [sel, load]);

  // v1.6.0 NEW: Supabase Realtime — instant refetch when held_bills change.
  useRealtime({
    table: "held_bills",
    filter: sel ? `outlet_id=eq.${sel}` : undefined,
    onChange: load,
    enabled: !!sel,
  });

  return (
    <div className="p-8">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">⏸ Held Bills</h1>
          <p className="text-gray-500 text-sm mt-0.5">Drafts saved on POS — pay later</p>
        </div>
        <select value={sel} onChange={e => setSel(e.target.value)} className="border border-gray-200 rounded-xl px-4 py-2.5 bg-white text-sm shadow-sm">
          {outlets.map(o => <option key={o.id} value={o.id}>{o.name}</option>)}
        </select>
      </div>
      {loading ? <div className="text-center py-16 text-gray-400">Loading...</div> : held.length === 0 ? (
        <div className="text-center py-20 bg-white rounded-2xl shadow-card"><div className="text-5xl mb-3">⏸</div><div className="text-gray-500 text-lg">No held bills</div></div>
      ) : (
        <div className="bg-white rounded-2xl shadow-card overflow-hidden">
          <table className="w-full">
            <thead className="bg-gray-50"><tr>{["Hold #", "Date", "Time", "Table", "Customer", "Total", "POS"].map(h => <th key={h} className="text-left px-5 py-3 text-xs font-medium text-gray-400 uppercase">{h}</th>)}</tr></thead>
            <tbody>{held.map(h => <tr key={h.id} className="border-b border-gray-50 hover:bg-gray-50"><td className="px-5 py-3 text-sm font-medium text-gray-700">#H{String(h.local_id || 0).padStart(4, "0")}</td><td className="px-5 py-3 text-sm text-gray-500">{h.hold_date}</td><td className="px-5 py-3 text-sm text-gray-500">{h.hold_time}</td><td className="px-5 py-3 text-sm text-gray-500">{h.table_no || "—"}</td><td className="px-5 py-3 text-sm text-gray-700">{h.customer_name || "—"}</td><td className="px-5 py-3 text-sm font-bold text-gray-800">{formatCurrency(h.total || 0)}</td><td className="px-5 py-3 text-sm text-gray-400">T{h.terminal_id}</td></tr>)}</tbody>
          </table>
        </div>
      )}
    </div>
  );
}
