"use client";
import { useEffect, useState, useMemo } from "react";
import { supabase, type Outlet } from "@/lib/supabase";
import { formatCurrency } from "@/lib/utils";
import { downloadCSV, downloadReportPDF } from "@/lib/export";
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from "recharts";

// ── v1.9.7 NEW: helpers for Daily Product Sales Matrix ─────────
// Parse a "DD/MM/YYYY" string into a Date object (local midnight).
function parseDMY(s: string): Date | null {
  const m = s.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
  if (!m) return null;
  const d = new Date(parseInt(m[3]), parseInt(m[2]) - 1, parseInt(m[1]));
  return isNaN(d.getTime()) ? null : d;
}

// Format a Date as "DD/MM/YYYY".
function fmtDMY(d: Date): string {
  return `${String(d.getDate()).padStart(2, "0")}/${String(d.getMonth() + 1).padStart(2, "0")}/${d.getFullYear()}`;
}

// Return all dates between from and to (inclusive) as "DD/MM/YYYY" strings.
// Caps at 90 days to prevent excessive Supabase queries.
function datesBetween(from: string, to: string): string[] {
  const f = parseDMY(from);
  const t = parseDMY(to);
  if (!f || !t) return [];
  const out: string[] = [];
  const cur = new Date(f);
  let count = 0;
  while (cur <= t && count < 90) {
    out.push(fmtDMY(cur));
    cur.setDate(cur.getDate() + 1);
    count++;
  }
  return out;
}

// Short label for a date: "03 Jul" instead of "03/07/2026" (for matrix headers).
function shortDate(dmy: string): string {
  const d = parseDMY(dmy);
  if (!d) return dmy;
  return d.toLocaleDateString("en", { day: "2-digit", month: "short" });
}

// Day-of-week label for a date: "Mon", "Tue", etc.
function dayLabel(dmy: string): string {
  const d = parseDMY(dmy);
  if (!d) return "";
  return d.toLocaleDateString("en", { weekday: "short" });
}
// ────────────────────────────────────────────────────────────────

export default function ReportsPage() {
  const [outlets, setOutlets] = useState<Outlet[]>([]);
  const [sel, setSel] = useState("all");
  const [date, setDate] = useState(() => { const d = new Date(); return fmtDMY(d); });
  const [report, setReport] = useState<Record<string, number> | null>(null);
  const [items, setItems] = useState<Array<{ item_name: string; total_qty: number; total_amount: number }>>([]);
  const [loading, setLoading] = useState(false);
  const [pieData, setPieData] = useState<any[]>([]);

  // v1.9.7 NEW: Daily Product Sales Matrix state
  const [fromDate, setFromDate] = useState(() => { const d = new Date(); d.setDate(d.getDate() - 6); return fmtDMY(d); });
  const [toDate, setToDate] = useState(() => fmtDMY(new Date()));
  const [matrixLoading, setMatrixLoading] = useState(false);
  const [matrixSearch, setMatrixSearch] = useState("");
  // matrix: Map<item_name, Map<date_dmy, { qty, amount }>>
  const [matrix, setMatrix] = useState<Map<string, Map<string, { qty: number; amount: number }>>>(new Map());
  const [matrixDates, setMatrixDates] = useState<string[]>([]);
  const [matrixGenerated, setMatrixGenerated] = useState(false);

  useEffect(() => { (async () => { const { data } = await supabase.from("outlets").select("*").eq("is_active", true).order("name"); setOutlets(data || []); })(); }, []);

  async function generate() {
    setLoading(true);
    const ids = sel === "all" ? outlets.map(o => o.id) : [sel];
    const r: Record<string, number> = { bills: 0, voided: 0, gross_revenue: 0, gst_collected: 0, cash_sales: 0, card_sales: 0, parcel_sales: 0, dinein_sales: 0 };
    const allItems: Record<string, { item_name: string; total_qty: number; total_amount: number }> = {};
    for (const oid of ids) {
      const { data: bills } = await supabase.from("bills").select("*").eq("outlet_id", oid).eq("bill_date", date);
      if (!bills) continue;
      const active = bills.filter(b => !b.pl_voided);
      r.bills += active.length; r.voided += bills.length - active.length;
      r.gross_revenue += active.reduce((s,b) => s + (b.total || 0), 0);
      r.gst_collected += active.reduce((s,b) => s + (b.cgst || 0) + (b.sgst || 0), 0);
      r.cash_sales += active.filter(b => b.payment_mode === "cash").reduce((s,b) => s + (b.total || 0), 0);
      r.card_sales += active.filter(b => b.payment_mode !== "cash").reduce((s,b) => s + (b.total || 0), 0);
      r.parcel_sales += active.filter(b => b.packaging_required).reduce((s,b) => s + (b.total || 0), 0);
      r.dinein_sales += active.filter(b => !b.packaging_required).reduce((s,b) => s + (b.total || 0), 0);
      const billIds = active.map(b => b.id);
      if (billIds.length) { const { data: its } = await supabase.from("bill_items").select("item_name,quantity,amount").in("bill_id", billIds); if (its) for (const it of its) { if (!allItems[it.item_name]) allItems[it.item_name] = { item_name: it.item_name, total_qty: 0, total_amount: 0 }; allItems[it.item_name].total_qty += it.quantity || 0; allItems[it.item_name].total_amount += it.amount || 0; } }
    }
    setReport(r);
    setItems(Object.values(allItems).sort((a,b) => b.total_qty - a.total_qty));
    setPieData([{ name: "Cash", value: r.cash_sales, color: "#10B981" }, { name: "Card/UPI", value: r.card_sales, color: "#6366F1" }]);
    setLoading(false);
  }

  // v1.9.7 NEW: Generate the Daily Product Sales Matrix.
  // Fetches all bills in the date range, then fetches their bill_items,
  // then pivots into a Map<item_name, Map<date, {qty, amount}>>.
  async function generateMatrix() {
    setMatrixLoading(true);
    const ids = sel === "all" ? outlets.map(o => o.id) : [sel];
    const dates = datesBetween(fromDate, toDate);
    if (dates.length === 0) {
      alert("Invalid date range. Use DD/MM/YYYY format. Max 90 days.");
      setMatrixLoading(false);
      return;
    }
    setMatrixDates(dates);

    // Fetch all bills in the date range for all selected outlets.
    // We fetch bill_date, id, pl_voided — we only need id (for joining to bill_items)
    // and pl_voided (to exclude voided bills).
    const billIdsByDate: Map<string, string[]> = new Map(); // date → bill_ids
    for (const oid of ids) {
      const { data: bills } = await supabase
        .from("bills")
        .select("id,bill_date,pl_voided")
        .eq("outlet_id", oid)
        .in("bill_date", dates);
      if (!bills) continue;
      for (const b of bills) {
        if (b.pl_voided) continue; // exclude voided
        const arr = billIdsByDate.get(b.bill_date) || [];
        arr.push(b.id);
        billIdsByDate.set(b.bill_date, arr);
      }
    }

    // For each date, fetch bill_items for that date's bills.
    // We fetch item_name, quantity, amount.
    const newMatrix: Map<string, Map<string, { qty: number; amount: number }>> = new Map();
    // v1.9.7 FIX: use Array.from() to iterate Map — tsconfig targets es5 which
    // doesn't support for...of on Maps without downlevelIteration.
    for (const [dmy, billIds] of Array.from(billIdsByDate.entries())) {
      if (billIds.length === 0) continue;
      // Supabase .in() has a limit of ~300 items per request; chunk if needed.
      const chunkSize = 200;
      for (let i = 0; i < billIds.length; i += chunkSize) {
        const chunk = billIds.slice(i, i + chunkSize);
        const { data: its } = await supabase
          .from("bill_items")
          .select("item_name,quantity,amount")
          .in("bill_id", chunk);
        if (!its) continue;
        for (const it of its) {
          const itemName = it.item_name || "(unknown)";
          if (!newMatrix.has(itemName)) newMatrix.set(itemName, new Map());
          const dateMap = newMatrix.get(itemName)!;
          const cur = dateMap.get(dmy) || { qty: 0, amount: 0 };
          cur.qty += it.quantity || 0;
          cur.amount += it.amount || 0;
          dateMap.set(dmy, cur);
        }
      }
    }

    setMatrix(newMatrix);
    setMatrixGenerated(true);
    setMatrixLoading(false);
  }

  // v1.9.7 NEW: derived data for the matrix
  // Sort items by total qty desc (so bestsellers appear at top)
  const sortedItems = useMemo(() => {
    const arr: Array<{ name: string; totalQty: number; totalAmount: number }> = [];
    // v1.9.7 FIX: Array.from() for es5 target compatibility.
    for (const [name, dateMap] of Array.from(matrix.entries())) {
      let totalQty = 0, totalAmount = 0;
      for (const v of Array.from(dateMap.values())) { totalQty += v.qty; totalAmount += v.amount; }
      arr.push({ name, totalQty, totalAmount });
    }
    arr.sort((a, b) => b.totalQty - a.totalQty);
    return arr;
  }, [matrix]);

  // Filtered items (by search box)
  const filteredItems = useMemo(() => {
    if (!matrixSearch) return sortedItems;
    const s = matrixSearch.toLowerCase();
    return sortedItems.filter(it => it.name.toLowerCase().includes(s));
  }, [sortedItems, matrixSearch]);

  // Top 10 bestsellers (regardless of search filter)
  const top10 = useMemo(() => sortedItems.slice(0, 10), [sortedItems]);

  // Daily totals (qty + amount per date, for the bottom row)
  const dailyTotals = useMemo(() => {
    const totals: Map<string, { qty: number; amount: number }> = new Map();
    for (const dmy of matrixDates) totals.set(dmy, { qty: 0, amount: 0 });
    // v1.9.7 FIX: Array.from() for es5 target compatibility.
    for (const dateMap of Array.from(matrix.values())) {
      for (const [dmy, v] of Array.from(dateMap.entries())) {
        const t = totals.get(dmy);
        if (t) { t.qty += v.qty; t.amount += v.amount; }
      }
    }
    return totals;
  }, [matrix, matrixDates]);

  // Grand total
  const grandTotal = useMemo(() => {
    let qty = 0, amount = 0;
    for (const it of sortedItems) { qty += it.totalQty; amount += it.totalAmount; }
    return { qty, amount };
  }, [sortedItems]);

  // v1.9.7 NEW: export the matrix as CSV.
  // Format: Item | date1 | date2 | ... | Total Qty | Total Amount
  function exportMatrixCSV() {
    if (matrix.size === 0) return;
    const outletName = sel === "all" ? "All Outlets" : (outlets.find(o => o.id === sel)?.name || "Outlet");
    const rows: (string | number)[][] = [];
    rows.push(["Mini Centrino HQ — Daily Product Sales Matrix"]);
    rows.push([]);
    rows.push(["Outlet", outletName]);
    rows.push(["From", fromDate]);
    rows.push(["To", toDate]);
    rows.push(["Generated At", new Date().toLocaleString()]);
    rows.push([]);
    // Header row
    const header: (string | number)[] = ["Item"];
    for (const dmy of matrixDates) header.push(`${shortDate(dmy)} (${dayLabel(dmy)})`);
    header.push("Total Qty", "Total Amount");
    rows.push(header);
    // Item rows
    for (const it of sortedItems) {
      const row: (string | number)[] = [it.name];
      const dateMap = matrix.get(it.name)!;
      for (const dmy of matrixDates) {
        const v = dateMap.get(dmy);
        row.push(v ? v.qty : 0);
      }
      row.push(it.totalQty, `Rs. ${it.totalAmount.toFixed(2)}`);
      rows.push(row);
    }
    // Daily totals row
    const totalRow: (string | number)[] = ["DAILY TOTAL (qty)"];
    for (const dmy of matrixDates) totalRow.push(dailyTotals.get(dmy)?.qty || 0);
    totalRow.push(grandTotal.qty, "");
    rows.push(totalRow);
    const amtRow: (string | number)[] = ["DAILY TOTAL (amount)"];
    for (const dmy of matrixDates) amtRow.push(`Rs. ${(dailyTotals.get(dmy)?.amount || 0).toFixed(2)}`);
    amtRow.push("", `Rs. ${grandTotal.amount.toFixed(2)}`);
    rows.push(amtRow);
    downloadCSV(`daily_product_sales_${fromDate.replace(/\//g, "-")}_to_${toDate.replace(/\//g, "-")}_${outletName.replace(/\s+/g, "_")}.csv`, rows);
  }

  // v1.9.7 NEW: export the matrix as PDF.
  function exportMatrixPDF() {
    if (matrix.size === 0) return;
    const outletName = sel === "all" ? "All Outlets" : (outlets.find(o => o.id === sel)?.name || "Outlet");
    // Use the existing downloadReportPDF but reshape the matrix into a flat item list.
    // For PDF, we show: item | total qty | total amount (no per-day columns — too wide for A4).
    downloadReportPDF({
      outletName,
      date: `${fromDate} to ${toDate}`,
      generatedAt: new Date().toLocaleString(),
      summary: [
        { label: "Date Range", value: `${fromDate} → ${toDate}` },
        { label: "Unique Items", value: String(sortedItems.length) },
        { label: "Total Qty Sold", value: String(grandTotal.qty) },
        { label: "Total Revenue", value: formatCurrency(grandTotal.amount) },
      ],
      items: sortedItems.map(it => ({
        item_name: it.name,
        total_qty: it.totalQty,
        total_amount: it.totalAmount,
      })),
    });
  }

  // v1.6.0 NEW: export the current report as a CSV file.
  function exportCSV() {
    if (!report) return;
    const outletName = sel === "all" ? "All Outlets" : (outlets.find(o => o.id === sel)?.name || "Outlet");
    const rows: (string | number)[][] = [];
    rows.push(["Mini Centrino HQ — Sales Report"]);
    rows.push([]);
    rows.push(["Outlet", outletName]);
    rows.push(["Date", date]);
    rows.push(["Generated At", new Date().toLocaleString()]);
    rows.push([]);
    rows.push(["SUMMARY"]);
    rows.push(["Metric", "Value"]);
    rows.push(["Bills", report.bills]);
    rows.push(["Gross Revenue", `Rs. ${report.gross_revenue.toFixed(2)}`]);
    rows.push(["GST Collected", `Rs. ${report.gst_collected.toFixed(2)}`]);
    rows.push(["Voided Bills", report.voided]);
    rows.push(["Cash Sales", `Rs. ${report.cash_sales.toFixed(2)}`]);
    rows.push(["Card/UPI Sales", `Rs. ${report.card_sales.toFixed(2)}`]);
    rows.push(["Parcel Sales", `Rs. ${report.parcel_sales.toFixed(2)}`]);
    rows.push(["Dine-in Sales", `Rs. ${report.dinein_sales.toFixed(2)}`]);
    rows.push([]);
    rows.push(["ITEM-WISE SALES"]);
    rows.push(["Item", "Qty", "Amount"]);
    for (const it of items) rows.push([it.item_name, it.total_qty, `Rs. ${it.total_amount.toFixed(2)}`]);
    downloadCSV(`report_${date.replace(/\//g, "-")}_${outletName.replace(/\s+/g, "_")}.csv`, rows);
  }

  function exportPDF() {
    if (!report) return;
    const outletName = sel === "all" ? "All Outlets" : (outlets.find(o => o.id === sel)?.name || "Outlet");
    downloadReportPDF({
      outletName,
      date,
      generatedAt: new Date().toLocaleString(),
      summary: [
        { label: "Bills", value: String(report.bills) },
        { label: "Gross Revenue", value: formatCurrency(report.gross_revenue) },
        { label: "GST Collected", value: formatCurrency(report.gst_collected) },
        { label: "Voided Bills", value: String(report.voided) },
        { label: "Cash Sales", value: formatCurrency(report.cash_sales) },
        { label: "Card/UPI Sales", value: formatCurrency(report.card_sales) },
        { label: "Parcel Sales", value: formatCurrency(report.parcel_sales) },
        { label: "Dine-in Sales", value: formatCurrency(report.dinein_sales) },
      ],
      items,
    });
  }

  return (
    <div className="p-4 sm:p-6 lg:p-8">
      <div className="mb-6"><h1 className="text-xl sm:text-2xl font-bold text-gray-800">Reports</h1><p className="text-gray-500 text-xs sm:text-sm mt-0.5">Revenue breakdown + item-wise sales</p></div>
      <div className="bg-white rounded-2xl shadow-card p-4 mb-5 flex gap-3 items-end flex-wrap">
        <div><label className="block text-xs text-gray-400 mb-1">Outlet</label><select value={sel} onChange={e => setSel(e.target.value)} className="border border-gray-200 rounded-lg px-3 py-2 bg-white text-sm"><option value="all">All Outlets</option>{outlets.map(o => <option key={o.id} value={o.id}>{o.name}</option>)}</select></div>
        <div><label className="block text-xs text-gray-400 mb-1">Date (DD/MM/YYYY)</label><input type="text" value={date} onChange={e => setDate(e.target.value)} className="border border-gray-200 rounded-lg px-3 py-2 text-sm w-32" /></div>
        <button onClick={generate} disabled={loading} className="bg-primary-500 hover:bg-primary-600 text-white px-5 py-2 rounded-lg text-sm font-medium disabled:opacity-50">{loading ? "Generating..." : "Generate"}</button>
        {/* v1.6.0 NEW: CSV + PDF export buttons. Disabled until a report has been generated. */}
        <div className="flex gap-2 ml-auto">
          <button onClick={exportCSV} disabled={!report} className="inline-flex items-center gap-1.5 bg-green-50 hover:bg-green-100 text-green-700 px-3 sm:px-4 py-2 rounded-lg text-sm font-medium border border-green-200 disabled:opacity-40 disabled:cursor-not-allowed">
            <span>📄</span> CSV
          </button>
          <button onClick={exportPDF} disabled={!report} className="inline-flex items-center gap-1.5 bg-red-50 hover:bg-red-100 text-red-700 px-3 sm:px-4 py-2 rounded-lg text-sm font-medium border border-red-200 disabled:opacity-40 disabled:cursor-not-allowed">
            <span>📕</span> PDF
          </button>
        </div>
      </div>
      {report && (
        <>
          {/* v1.9.0: summary cards responsive (2 cols mobile, 4 cols desktop) */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 mb-5">
            {[["Bills", report.bills, "🧾"], ["Revenue", formatCurrency(report.gross_revenue), "💰"], ["GST", formatCurrency(report.gst_collected), "📋"], ["Voided", report.voided, "❌"]].map(([l, v, i]) => (
              <div key={l as string} className="bg-white rounded-2xl shadow-card p-4 sm:p-5">
                <div className="flex justify-between mb-2"><span className="text-xs text-gray-400 uppercase">{l}</span><span className="text-xl">{i}</span></div>
                <div className="text-lg sm:text-xl font-bold text-gray-800">{v}</div>
              </div>
            ))}
          </div>
          {/* v1.9.0: stack on mobile, 3 cols on desktop */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 sm:gap-5 mb-5">
            <div className="bg-white rounded-2xl shadow-card p-4 sm:p-6">
              <h3 className="font-semibold text-gray-700 mb-4">Payment Split</h3>
              <ResponsiveContainer width="100%" height={200}><PieChart><Pie data={pieData} dataKey="value" nameKey="name" innerRadius={50} outerRadius={80}>{pieData.map((e, i) => <Cell key={i} fill={e.color} />)}</Pie><Tooltip formatter={(v: number) => formatCurrency(v)} /><Legend /></PieChart></ResponsiveContainer>
            </div>
            <div className="lg:col-span-2 bg-white rounded-2xl shadow-card p-4 sm:p-6">
              <h3 className="font-semibold text-gray-700 mb-4">Item-wise Sales</h3>
              <div className="max-h-64 overflow-auto">
                <table className="w-full min-w-[400px]"><thead><tr className="border-b border-gray-100"><th className="text-left py-2 text-xs text-gray-400 uppercase">Item</th><th className="text-right py-2 text-xs text-gray-400 uppercase">Qty</th><th className="text-right py-2 text-xs text-gray-400 uppercase">Amount</th></tr></thead>
                <tbody>{items.map((it, i) => <tr key={i} className="border-b border-gray-50"><td className="py-2 text-sm text-gray-700">{it.item_name}</td><td className="py-2 text-sm text-right text-gray-500">{it.total_qty}</td><td className="py-2 text-sm text-right font-medium text-gray-800">{formatCurrency(it.total_amount)}</td></tr>)}</tbody>
                </table>
                {items.length === 0 && <div className="text-center py-8 text-gray-400 text-sm">No sales for this date.</div>}
              </div>
            </div>
          </div>
        </>
      )}

      {/* ════════════════════════════════════════════════════════════ */}
      {/* v1.9.7 NEW: Daily Product Sales Matrix                        */}
      {/* ════════════════════════════════════════════════════════════ */}
      <div className="mt-8 border-t-2 border-primary-100 pt-6">
        <div className="mb-4">
          <h2 className="text-lg sm:text-xl font-bold text-gray-800 flex items-center gap-2">
            <span>📈</span> Daily Product Sales Matrix
          </h2>
          <p className="text-gray-500 text-xs sm:text-sm mt-0.5">
            See how each product sells day-by-day over a date range (max 90 days). Spot weekday/weekend trends, bestsellers, and slow movers.
          </p>
        </div>

        {/* Date range picker + generate + export */}
        <div className="bg-white rounded-2xl shadow-card p-4 mb-5 flex gap-3 items-end flex-wrap">
          <div>
            <label className="block text-xs text-gray-400 mb-1">From (DD/MM/YYYY)</label>
            <input type="text" value={fromDate} onChange={e => setFromDate(e.target.value)} placeholder="DD/MM/YYYY" className="border border-gray-200 rounded-lg px-3 py-2 text-sm w-32" />
          </div>
          <div>
            <label className="block text-xs text-gray-400 mb-1">To (DD/MM/YYYY)</label>
            <input type="text" value={toDate} onChange={e => setToDate(e.target.value)} placeholder="DD/MM/YYYY" className="border border-gray-200 rounded-lg px-3 py-2 text-sm w-32" />
          </div>
          <div>
            <label className="block text-xs text-gray-400 mb-1">Outlet</label>
            <select value={sel} onChange={e => setSel(e.target.value)} className="border border-gray-200 rounded-lg px-3 py-2 bg-white text-sm">
              <option value="all">All Outlets</option>
              {outlets.map(o => <option key={o.id} value={o.id}>{o.name}</option>)}
            </select>
          </div>
          <button onClick={generateMatrix} disabled={matrixLoading} className="bg-primary-500 hover:bg-primary-600 text-white px-5 py-2 rounded-lg text-sm font-medium disabled:opacity-50">
            {matrixLoading ? "Generating..." : "Generate Matrix"}
          </button>
          <div className="flex gap-2 ml-auto">
            <button onClick={exportMatrixCSV} disabled={matrix.size === 0} className="inline-flex items-center gap-1.5 bg-green-50 hover:bg-green-100 text-green-700 px-3 sm:px-4 py-2 rounded-lg text-sm font-medium border border-green-200 disabled:opacity-40 disabled:cursor-not-allowed">
              <span>📄</span> CSV
            </button>
            <button onClick={exportMatrixPDF} disabled={matrix.size === 0} className="inline-flex items-center gap-1.5 bg-red-50 hover:bg-red-100 text-red-700 px-3 sm:px-4 py-2 rounded-lg text-sm font-medium border border-red-200 disabled:opacity-40 disabled:cursor-not-allowed">
              <span>📕</span> PDF
            </button>
          </div>
        </div>

        {/* Top 10 bestsellers card */}
        {matrixGenerated && top10.length > 0 && (
          <div className="bg-gradient-to-br from-primary-50 to-purple-50 rounded-2xl p-4 sm:p-5 mb-5 border border-primary-100">
            <h3 className="font-semibold text-gray-700 mb-3 flex items-center gap-2">
              <span>🏆</span> Top 10 Bestsellers ({fromDate} → {toDate})
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
              {top10.map((it, i) => (
                <div key={it.name} className="bg-white rounded-xl p-3 shadow-sm">
                  <div className="flex items-center gap-2 mb-1">
                    <span className={`text-xs font-bold ${i < 3 ? "text-yellow-500" : "text-gray-400"}`}>
                      {i === 0 ? "🥇" : i === 1 ? "🥈" : i === 2 ? "🥉" : `#${i + 1}`}
                    </span>
                    <span className="text-xs text-gray-500">{it.totalQty} sold</span>
                  </div>
                  <div className="text-sm font-medium text-gray-800 truncate" title={it.name}>{it.name}</div>
                  <div className="text-xs text-primary-600 font-bold mt-0.5">{formatCurrency(it.totalAmount)}</div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Search box + matrix table */}
        {matrixGenerated && (
          <>
            <div className="bg-white rounded-2xl shadow-card p-4 mb-4">
              <div className="flex items-center gap-3 flex-wrap">
                <input
                  type="text"
                  value={matrixSearch}
                  onChange={e => setMatrixSearch(e.target.value)}
                  placeholder="🔍 Search items by name..."
                  className="border border-gray-200 rounded-lg px-3 py-2 text-sm flex-1 min-w-[200px] max-w-xs"
                />
                <div className="text-sm text-gray-500 ml-auto">
                  {filteredItems.length} of {sortedItems.length} items | Total: <span className="font-bold text-gray-800">{grandTotal.qty} qty</span> | <span className="font-bold text-green-600">{formatCurrency(grandTotal.amount)}</span>
                </div>
              </div>
            </div>

            {/* Matrix table — horizontally scrollable on mobile */}
            {matrixDates.length > 0 && (
              <div className="bg-white rounded-2xl shadow-card overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-sm" style={{ minWidth: `${Math.max(600, 200 + matrixDates.length * 70)}px` }}>
                    <thead className="bg-gray-50 sticky top-0">
                      <tr>
                        <th className="text-left px-3 py-3 text-xs font-medium text-gray-400 uppercase sticky left-0 bg-gray-50 z-10">Item</th>
                        {matrixDates.map(dmy => (
                          <th key={dmy} className="text-center px-2 py-3 text-xs font-medium text-gray-400 uppercase">
                            <div>{shortDate(dmy)}</div>
                            <div className="text-[10px] normal-case text-gray-400">{dayLabel(dmy)}</div>
                          </th>
                        ))}
                        <th className="text-right px-3 py-3 text-xs font-bold text-gray-600 uppercase bg-primary-50">Total Qty</th>
                        <th className="text-right px-3 py-3 text-xs font-bold text-gray-600 uppercase bg-primary-50">Total ₹</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredItems.map(it => {
                        const dateMap = matrix.get(it.name)!;
                        return (
                          <tr key={it.name} className="border-b border-gray-50 hover:bg-gray-50">
                            <td className="px-3 py-2 text-sm text-gray-700 font-medium sticky left-0 bg-white z-10">{it.name}</td>
                            {matrixDates.map(dmy => {
                              const v = dateMap.get(dmy);
                              return (
                                <td key={dmy} className={`text-center px-2 py-2 text-sm ${v ? "text-gray-700" : "text-gray-300"}`}>
                                  {v ? v.qty : "—"}
                                </td>
                              );
                            })}
                            <td className="px-3 py-2 text-sm font-bold text-right text-primary-600 bg-primary-50/50">{it.totalQty}</td>
                            <td className="px-3 py-2 text-sm font-medium text-right text-gray-800 bg-primary-50/50">{formatCurrency(it.totalAmount)}</td>
                          </tr>
                        );
                      })}
                      {/* Daily totals row */}
                      <tr className="bg-gray-100 font-bold border-t-2 border-gray-200">
                        <td className="px-3 py-3 text-sm text-gray-700 sticky left-0 bg-gray-100 z-10">DAILY TOTAL (qty)</td>
                        {matrixDates.map(dmy => (
                          <td key={dmy} className="text-center px-2 py-3 text-sm text-gray-700">
                            {dailyTotals.get(dmy)?.qty || 0}
                          </td>
                        ))}
                        <td className="px-3 py-3 text-sm text-right text-primary-700 bg-primary-100">{grandTotal.qty}</td>
                        <td className="px-3 py-3 text-sm text-right text-green-700 bg-primary-100">{formatCurrency(grandTotal.amount)}</td>
                      </tr>
                      <tr className="bg-gray-50 font-medium border-t border-gray-200">
                        <td className="px-3 py-2 text-sm text-gray-600 sticky left-0 bg-gray-50 z-10">DAILY REVENUE</td>
                        {matrixDates.map(dmy => (
                          <td key={dmy} className="text-center px-2 py-2 text-xs text-gray-600">
                            {formatCurrency(dailyTotals.get(dmy)?.amount || 0).replace("₹", "₹")}
                          </td>
                        ))}
                        <td colSpan={2} className="text-center px-3 py-2 text-xs text-gray-400 italic">← See qty total column for grand total</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
                {filteredItems.length === 0 && (
                  <div className="text-center py-12 text-gray-400 text-sm">
                    {sortedItems.length === 0
                      ? "No sales data for this date range. Make sure the Hub is running and bill_items are being pushed to Supabase."
                      : "No items match your search."}
                  </div>
                )}
              </div>
            )}

            {/* Help text when no data */}
            {matrixGenerated && sortedItems.length === 0 && (
              <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 mt-4 text-sm text-amber-800">
                <div className="font-semibold mb-1">⚠️ No bill_items found in Supabase for this date range</div>
                <p className="text-amber-700 text-xs leading-relaxed">
                  The Hub's cloud_sync needs to push bill_items for your existing bills. Make sure you're running
                  the latest Hub code (v1.9.7+) which includes an automatic backfill routine — it will push
                  bill_items for up to 200 bills per sync cycle. With ~4,293 existing bills, it may take ~22
                  cycles (~22 minutes at 1 cycle/minute) to fully backfill. New bills will have their items
                  pushed immediately.
                </p>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
