"use client";
import { useEffect, useState } from "react";
import { supabase, type Outlet, type PackagingType } from "@/lib/supabase";

export default function PackagingPage() {
  const [outlets, setOutlets] = useState<Outlet[]>([]);
  const [sel, setSel] = useState("");
  const [pkgs, setPkgs] = useState<PackagingType[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => { (async () => { const { data } = await supabase.from("outlets").select("*").eq("is_active", true).order("name"); setOutlets(data || []); if (data && data[0]) setSel(data[0].id); })(); }, []);
  useEffect(() => { if (!sel) return; (async () => { const { data } = await supabase.from("packaging_types").select("*").eq("outlet_id", sel).order("name"); setPkgs(data || []); setLoading(false); })(); }, [sel]);

  return (
    <div className="p-4 sm:p-6 lg:p-8">
      <div className="flex items-center justify-between mb-6">
        <div><h1 className="text-2xl font-bold text-gray-800">📦 Packaging Inventory</h1><p className="text-gray-500 text-sm mt-0.5">Stock levels per outlet</p></div>
        <select value={sel} onChange={e => setSel(e.target.value)} className="border border-gray-200 rounded-xl px-4 py-2.5 bg-white text-sm shadow-sm">{outlets.map(o => <option key={o.id} value={o.id}>{o.name}</option>)}</select>
      </div>
      {loading ? <div className="text-center py-16 text-gray-400">Loading...</div> : (
        <div className="bg-white rounded-2xl shadow-card overflow-hidden">
          <div className="overflow-x-auto">
          <table className="w-full min-w-[700px]">
            <thead className="bg-gray-50"><tr>{["Name", "Code", "Description", "Charge", "Stock", "Status"].map(h => <th key={h} className="text-left px-5 py-3 text-xs font-medium text-gray-400 uppercase">{h}</th>)}</tr></thead>
            <tbody>{pkgs.map(p => <tr key={p.id} className="border-b border-gray-50 hover:bg-gray-50"><td className="px-5 py-3 text-sm font-medium text-gray-700">{p.name}</td><td className="px-5 py-3"><code className="bg-gray-100 px-2 py-0.5 rounded text-xs">{p.code}</code></td><td className="px-5 py-3 text-sm text-gray-400">{p.description || "—"}</td><td className="px-5 py-3 text-sm text-right">₹{p.charge}</td><td className="px-5 py-3 text-sm text-right">{p.stock_quantity < 0 ? "∞" : <span className={p.stock_quantity <= p.low_stock_threshold ? "text-red-500 font-bold" : ""}>{p.stock_quantity}</span>}</td><td className="px-5 py-3"><span className={`text-xs px-2 py-0.5 rounded-full ${p.is_active ? "bg-green-50 text-green-600" : "bg-gray-100 text-gray-400"}`}>{p.is_active ? "● Active" : "○ Inactive"}</span></td></tr>)}</tbody>
          </table>
          </div>
          {pkgs.length === 0 && <div className="text-center py-12 text-gray-400 text-sm">No packaging types. Add from Hub's Packaging tab.</div>}
        </div>
      )}
    </div>
  );
}
