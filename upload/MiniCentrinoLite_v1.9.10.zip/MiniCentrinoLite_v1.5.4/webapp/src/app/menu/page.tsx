"use client";
import { useEffect, useState, useCallback } from "react";
import { supabase, type Outlet, type MenuSection, type MenuItem } from "@/lib/supabase";
import { formatCurrency } from "@/lib/utils";

export default function MenuPage() {
  const [outlets, setOutlets] = useState<Outlet[]>([]);
  const [sel, setSel] = useState("");
  const [sections, setSections] = useState<MenuSection[]>([]);
  const [items, setItems] = useState<MenuItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState<MenuItem | null>(null);
  const [editPrice, setEditPrice] = useState("");
  const [showAddSec, setShowAddSec] = useState(false);
  const [newSec, setNewSec] = useState("");
  const [showAddItem, setShowAddItem] = useState<number | null>(null);
  const [newName, setNewName] = useState("");
  const [newPrice, setNewPrice] = useState("");

  const load = useCallback(async () => {
    if (!sel) return;
    const { data: s } = await supabase.from("menu_sections").select("*").eq("outlet_id", sel).order("sort_order");
    setSections(s || []);
    const { data: i } = await supabase.from("menu_items").select("*").eq("outlet_id", sel).order("sort_order");
    setItems(i || []);
    setLoading(false);
  }, [sel]);

  useEffect(() => { (async () => { const { data } = await supabase.from("outlets").select("*").eq("is_active", true).order("name"); setOutlets(data || []); if (data && data[0]) setSel(data[0].id); })(); }, []);
  useEffect(() => { load(); }, [load]);

  async function pushUpdate(item: MenuItem, updates: Record<string, unknown>) {
    const { error } = await supabase.from("sync_menu_updates").insert({ outlet_id: sel, action: "update_item", payload: { item_id: item.local_id, ...updates } });
    if (error) { alert("Failed: " + error.message); return; }
    alert("✓ Update queued! Hub applies within 30s.");
    setEditing(null); setTimeout(load, 2000);
  }

  async function addSection() {
    if (!newSec.trim()) return;
    const { error } = await supabase.from("sync_menu_updates").insert({ outlet_id: sel, action: "add_section", payload: { name: newSec.trim() } });
    if (error) { alert(error.message); return; }
    alert("✓ Section queued!"); setShowAddSec(false); setNewSec(""); setTimeout(load, 2000);
  }

  async function addItem(secLocalId: number) {
    if (!newName.trim() || !newPrice) return;
    const sec = sections.find(s => s.local_id === secLocalId);
    // v1.5.9 FIX: parseFloat instead of parseInt — preserves paise (e.g. ₹50.50)
    const { error } = await supabase.from("sync_menu_updates").insert({ outlet_id: sel, action: "add_item", payload: { section: sec?.name || "", name: newName.trim(), price: parseFloat(newPrice) } });
    if (error) { alert(error.message); return; }
    alert("✓ Item queued!"); setShowAddItem(null); setNewName(""); setNewPrice(""); setTimeout(load, 2000);
  }

  async function deleteItem(item: MenuItem) {
    if (!confirm(`Delete "${item.name}"?`)) return;
    const { error } = await supabase.from("sync_menu_updates").insert({ outlet_id: sel, action: "delete_item", payload: { item_id: item.local_id } });
    if (error) { alert(error.message); return; }
    alert("✓ Delete queued!"); setTimeout(load, 2000);
  }

  return (
    <div className="p-4 sm:p-6 lg:p-8">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">Menu Management</h1>
          <p className="text-gray-500 text-sm mt-0.5">Add / edit / delete — pushes to Hub within 30s</p>
        </div>
        <div className="flex gap-3">
          <select value={sel} onChange={e => setSel(e.target.value)} className="border border-gray-200 rounded-xl px-4 py-2.5 bg-white text-sm shadow-sm">
            {outlets.map(o => <option key={o.id} value={o.id}>{o.name}</option>)}
          </select>
          <button onClick={() => setShowAddSec(!showAddSec)} className="bg-primary-500 hover:bg-primary-600 text-white px-4 py-2.5 rounded-xl text-sm font-medium shadow-sm">{showAddSec ? "✕ Cancel" : "+ Add Section"}</button>
        </div>
      </div>

      {showAddSec && (
        <div className="bg-white rounded-2xl shadow-card p-5 mb-4 flex gap-3 items-end">
          <div className="flex-1"><label className="block text-xs text-gray-400 mb-1">Section Name</label><input type="text" value={newSec} onChange={e => setNewSec(e.target.value)} className="border border-gray-200 rounded-lg px-3 py-2 w-full text-sm" /></div>
          <button onClick={addSection} className="bg-green-500 text-white px-5 py-2 rounded-lg text-sm font-medium">✓ Add</button>
        </div>
      )}

      {loading ? <div className="text-center py-16 text-gray-400">Loading...</div> : (
        <div className="space-y-4">
          {sections.map(sec => {
            const si = items.filter(i => i.section_local_id === sec.local_id);
            if (si.length === 0 && !showAddItem) return null;
            return (
              <div key={sec.id} className="bg-white rounded-2xl shadow-card p-5">
                <div className="flex items-center justify-between mb-3 border-b border-gray-50 pb-2">
                  <h2 className="font-semibold text-gray-700">{sec.name} <span className="text-xs text-gray-400">({si.length})</span></h2>
                  <button onClick={() => setShowAddItem(showAddItem === sec.local_id ? null : sec.local_id)} className="text-xs text-primary-500 hover:underline font-medium">{showAddItem === sec.local_id ? "✕ Cancel" : "+ Add Item"}</button>
                </div>
                {showAddItem === sec.local_id && (
                  <div className="mb-3 bg-primary-50 rounded-lg p-3 flex gap-2 items-end">
                    <div className="flex-1"><input type="text" value={newName} onChange={e => setNewName(e.target.value)} placeholder="Item name" className="border rounded-lg px-2 py-1.5 text-sm w-full" /></div>
                    <div className="w-24"><input type="number" value={newPrice} onChange={e => setNewPrice(e.target.value)} placeholder="₹" className="border rounded-lg px-2 py-1.5 text-sm w-full" /></div>
                    <button onClick={() => addItem(sec.local_id)} className="bg-green-500 text-white px-3 py-1.5 rounded-lg text-sm">✓ Add</button>
                  </div>
                )}
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2">
                  {si.map(item => (
                    <div key={item.id} className={`border rounded-lg p-2.5 ${item.is_active ? "border-gray-200" : "border-gray-200 bg-gray-50 opacity-60"}`}>
                      {editing?.id === item.id ? (
                        <div className="space-y-1">
                          <input type="text" value={editing.name} onChange={e => setEditing({ ...editing, name: e.target.value })} className="border rounded px-2 py-1 text-xs w-full" />
                          <input type="number" value={editPrice} onChange={e => setEditPrice(e.target.value)} className="border rounded px-2 py-1 text-xs w-full" />
                          <div className="flex gap-1">
                            {/* v1.5.9 FIX: parseFloat instead of parseInt — preserves paise */}
                            <button onClick={() => pushUpdate(item, { name: editing.name, new_price: parseFloat(editPrice) })} className="bg-green-500 text-white px-2 py-0.5 rounded text-xs">✓</button>
                            <button onClick={() => setEditing(null)} className="bg-gray-300 px-2 py-0.5 rounded text-xs">✕</button>
                          </div>
                        </div>
                      ) : (
                        <div>
                          <div className="flex justify-between items-start">
                            <div className="flex-1 min-w-0"><div className="text-xs font-medium text-gray-700 truncate">{item.name}</div></div>
                            <div className="font-bold text-primary-600 text-xs ml-1">{formatCurrency(item.price)}</div>
                          </div>
                          <div className="flex gap-1.5 mt-1.5 pt-1.5 border-t border-gray-50">
                            <button onClick={() => { setEditing(item); setEditPrice(item.price.toString()); }} className="text-xs text-blue-500">✏️</button>
                            <button onClick={() => pushUpdate(item, { is_active: !item.is_active })} className="text-xs text-orange-500">{item.is_active ? "🚫" : "✅"}</button>
                            <button onClick={() => deleteItem(item)} className="text-xs text-red-500">🗑️</button>
                          </div>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
