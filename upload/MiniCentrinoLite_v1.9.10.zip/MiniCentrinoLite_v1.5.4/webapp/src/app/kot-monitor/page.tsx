"use client";
import { useEffect, useState, useCallback } from "react";
import { supabase, type Outlet } from "@/lib/supabase";
import { useRealtime } from "@/lib/realtime";

const statusStyle: Record<string, string> = {
  pending: "bg-red-50 border-red-400", preparing: "bg-yellow-50 border-yellow-400",
  ready: "bg-green-50 border-green-400", served: "bg-gray-50 border-gray-300",
};
const termColors: Record<number, string> = { 1: "#6366F1", 2: "#10B981", 3: "#8B5CF6", 4: "#3B82F6", 5: "#F59E0B", 6: "#EC4899" };

export default function KotMonitor() {
  const [outlets, setOutlets] = useState<Outlet[]>([]);
  const [sel, setSel] = useState("");
  const [kots, setKots] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    if (!sel) return;
    const { data } = await supabase.from("v_active_kots").select("*").eq("outlet_id", sel).order("kot_no");
    setKots(data || []);
    setLoading(false);
  }, [sel]);

  useEffect(() => {
    (async () => {
      const { data } = await supabase.from("outlets").select("*").eq("is_active", true).order("name");
      setOutlets(data || []);
      if (data && data[0]) setSel(data[0].id);
    })();
  }, []);

  useEffect(() => { load(); }, [load]);
  // v1.6.0: polling slowed from 5s → 30s as fallback. Realtime below fires
  // within ~200ms when the KOT list changes, so aggressive polling is no
  // longer needed. The 30s poll covers cases where Realtime isn't enabled.
  useEffect(() => { if (!sel) return; const i = setInterval(load, 30000); return () => clearInterval(i); }, [sel, load]);

  // v1.6.0 NEW: Supabase Realtime on the `kots` table.
  // The page reads from `v_active_kots` view but writes go to `kots` table.
  // Any INSERT / UPDATE / DELETE on `kots` triggers a refetch of the view.
  useRealtime({
    table: "kots",
    filter: sel ? `outlet_id=eq.${sel}` : undefined,
    onChange: load,
    enabled: !!sel,
  });

  // v1.5.1: Update KOT status directly in Supabase
  // The Hub's cloud_sync will pick up the status change on next push cycle
  // and broadcast to all LAN KDS screens
  async function updateStatus(kotNo: number, newStatus: string) {
    // Update in Supabase directly
    // v1.5.9 FIX: removed `.execute()` — awaiting the query builder already executes it,
    // and `.execute()` doesn't exist on the PATCH builder type signature.
    await supabase.from("kots").update({
      status: newStatus,
      updated_at: new Date().toISOString(),
    }).eq("outlet_id", sel).eq("kot_no", kotNo);
    // Refresh immediately
    load();
  }

  return (
    <div className="p-4 sm:p-6 lg:p-8">
      <div className="flex items-center justify-between mb-4 sm:mb-6 flex-wrap gap-3">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-gray-800">🍳 Live KOT Monitor</h1>
          <p className="text-gray-500 text-xs sm:text-sm mt-0.5">Auto-refreshes 30s + Realtime — click buttons to update status</p>
        </div>
        <select value={sel} onChange={e => setSel(e.target.value)} className="border border-gray-200 rounded-xl px-3 py-2 bg-white text-sm shadow-sm">
          {outlets.map(o => <option key={o.id} value={o.id}>{o.name}</option>)}
        </select>
      </div>

      {/* Status summary — v1.9.0: responsive (2 cols mobile, 4 cols desktop) */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-6">
        {[
          { label: "Pending", status: "pending", color: "bg-red-50 text-red-600" },
          { label: "Preparing", status: "preparing", color: "bg-yellow-50 text-yellow-600" },
          { label: "Ready", status: "ready", color: "bg-green-50 text-green-600" },
          { label: "Total Active", status: "", color: "bg-primary-50 text-primary-600" },
        ].map(s => (
          <div key={s.label} className={`${s.color} rounded-xl p-4`}>
            <div className="text-xs uppercase font-medium">{s.label}</div>
            <div className="text-2xl font-bold mt-1">
              {s.status ? kots.filter(k => k.status === s.status).length : kots.length}
            </div>
          </div>
        ))}
      </div>

      {loading ? <div className="text-center py-16 text-gray-400">Loading...</div> :
       kots.length === 0 ? (
        <div className="text-center py-20 bg-white rounded-2xl shadow-card">
          <div className="text-5xl mb-3">✅</div>
          <div className="text-gray-500 text-lg">No active KOTs — kitchen is all caught up!</div>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
          {kots.map(k => {
            const tc = termColors[k.terminal_id] || "#6B7280";
            return (
              <div key={`${k.outlet_id}-${k.kot_no}`} className={`bg-white rounded-2xl shadow-card p-4 border-l-4 ${statusStyle[k.status] || "border-gray-300"}`}>
                {/* ── Row 1: KOT # + status (clean separation, no overlap) ── */}
                <div className="flex items-center justify-between mb-3 gap-2">
                  <div className="font-bold text-gray-800 text-sm">KOT #{String(k.kot_no).padStart(4, "0")}</div>
                  <div className="text-[10px] font-bold uppercase tracking-wide text-gray-500 bg-gray-100 px-2 py-0.5 rounded-full whitespace-nowrap">{k.status}</div>
                </div>

                {/* ── Row 2: badges (POS, PACK, Source) — own row, clear wrap ── */}
                <div className="flex items-center gap-1.5 mb-2 flex-wrap">
                  <span className="text-[10px] font-bold text-white px-2 py-0.5 rounded" style={{ background: tc }}>POS-{k.terminal_id}</span>
                  {k.packaging_required && <span className="text-[10px] font-bold text-white bg-orange-500 px-2 py-0.5 rounded">📦 PACK</span>}
                  {k.order_source && k.order_source !== "walkin" && <span className="text-[10px] font-bold text-white bg-purple-500 px-2 py-0.5 rounded uppercase">{k.order_source}</span>}
                </div>

                {/* ── Row 3: time + table + customer (clear block, no overlap) ── */}
                <div className="text-xs text-gray-500 mb-1 flex items-center gap-2 flex-wrap">
                  <span>🕐 {k.kot_time}</span>
                  {!k.packaging_required && k.table_no && <span className="text-gray-400">• Table: {k.table_no}</span>}
                </div>
                {k.customer_name && <div className="text-xs text-gray-600 mb-2">👤 {k.customer_name}</div>}

                {/* ── Row 4: items list ── */}
                <div className="border-t border-gray-100 pt-2 space-y-1 mb-3">
                  {Array.isArray(k.items) && k.items.map((it: any, i: number) => (
                    <div key={i} className="flex justify-between text-xs gap-2">
                      <span className="text-gray-600 flex-1 truncate">{it.name}</span>
                      <span className="font-bold text-gray-700 whitespace-nowrap">×{it.qty}</span>
                    </div>
                  ))}
                </div>

                {/* ── Row 5: status control buttons ── */}
                <div className="flex gap-1.5">
                  {k.status === "pending" && (
                    <button onClick={() => updateStatus(k.kot_no, "preparing")} className="flex-1 bg-yellow-500 hover:bg-yellow-600 text-white py-2 rounded-lg text-xs font-bold">Start Preparing</button>
                  )}
                  {k.status === "preparing" && (
                    <button onClick={() => updateStatus(k.kot_no, "ready")} className="flex-1 bg-green-500 hover:bg-green-600 text-white py-2 rounded-lg text-xs font-bold">Mark READY</button>
                  )}
                  {k.status === "ready" && (
                    <button onClick={() => updateStatus(k.kot_no, "served")} className="flex-1 bg-gray-500 hover:bg-gray-600 text-white py-2 rounded-lg text-xs font-bold">Mark Served</button>
                  )}
                  {k.status === "served" && (
                    <span className="flex-1 text-center text-xs text-gray-400 py-2">✓ Served</span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
