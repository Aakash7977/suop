@echo off
title Mini Centrino Lite - KDS (Kitchen Display System)
cd /d "%~dp0"
echo Starting Kitchen Display System (KDS)...
start "" pythonw main.py --kds
exit
