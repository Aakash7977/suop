-- ============================================================
-- Mini Centrino Lite v1.5.0 — Disable Row Level Security
-- Companion to supabase_schema.sql
-- ============================================================
--
-- RLS disabled for LAN-only deployment. Enable if making web app public.
--
-- WHY:
--   The POS hub connects to Supabase with the anon key over a LAN.
--   Supabase's default RLS policies block anon-key access to tables
--   that don't have an explicit permissive policy, which causes
--   permission errors (HTTP 401 / "JWT subject is not a UUID") when
--   the hub tries to push bills / KOTs / menu updates.
--
--   Since this schema is designed for a LAN-only deployment where the
--   web app is reachable only inside the restaurant's network (or via
--   a VPN), RLS is unnecessary. We disable it on all 14 data tables
--   so the anon key can read/write freely.
--
-- WHEN TO ENABLE RLS:
--   If you ever expose the web dashboard to the public internet,
--   re-enable RLS and add auth.uid()-based policies. See the
--   "RLS — DISABLED" section of supabase_schema.sql for guidance.
--
-- RUN ORDER:
--   1. supabase_schema.sql   (creates tables, triggers, views, defaults)
--   2. disable_rls.sql       (this file — disables RLS on all tables)
--
--   This file is safe to re-run any time. ALTER TABLE ... DISABLE ROW
--   LEVEL SECURITY is idempotent.
-- ============================================================

-- 1. outlets
ALTER TABLE public.outlets            DISABLE ROW LEVEL SECURITY;

-- 2. web_users
ALTER TABLE public.web_users          DISABLE ROW LEVEL SECURITY;

-- 3. menu_sections
ALTER TABLE public.menu_sections      DISABLE ROW LEVEL SECURITY;

-- 4. menu_items
ALTER TABLE public.menu_items         DISABLE ROW LEVEL SECURITY;

-- 5. bills
ALTER TABLE public.bills              DISABLE ROW LEVEL SECURITY;

-- 6. bill_items
ALTER TABLE public.bill_items         DISABLE ROW LEVEL SECURITY;

-- 7. kots
ALTER TABLE public.kots               DISABLE ROW LEVEL SECURITY;

-- 8. kot_items
ALTER TABLE public.kot_items          DISABLE ROW LEVEL SECURITY;

-- 9. held_bills
ALTER TABLE public.held_bills         DISABLE ROW LEVEL SECURITY;

-- 10. packaging_types
ALTER TABLE public.packaging_types    DISABLE ROW LEVEL SECURITY;

-- 11. product_packaging
ALTER TABLE public.product_packaging  DISABLE ROW LEVEL SECURITY;

-- 12. sync_menu_updates
ALTER TABLE public.sync_menu_updates  DISABLE ROW LEVEL SECURITY;

-- 13. sync_orders
ALTER TABLE public.sync_orders        DISABLE ROW LEVEL SECURITY;

-- 14. sync_audit_log
ALTER TABLE public.sync_audit_log     DISABLE ROW LEVEL SECURITY;


-- ============================================================
-- Verification
-- ============================================================
-- Lists every table in the public schema along with its current RLS
-- status. After running this script, every row below should show
-- rowsecurity = false (i.e. RLS is OFF).
--
-- If any row shows rowsecurity = true, RLS is still enabled on that
-- table — re-run the corresponding ALTER TABLE statement above.
-- ============================================================
SELECT
    tablename,
    rowsecurity
FROM pg_tables
WHERE schemaname = 'public'
ORDER BY tablename;
