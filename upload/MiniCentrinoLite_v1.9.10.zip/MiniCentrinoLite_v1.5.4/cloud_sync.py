"""
Mini Centrino Lite v1.5.0 — Cloud Sync (Supabase) Module
Sudhamrit Food Joint | Sri Ma Trust

Bidirectional sync between the local SQLite DB (owned by the hub) and a
Supabase project. Designed for LAN-only deployments where the hub runs
inside the restaurant and pushes data up to Supabase for the Next.js
web dashboard to read.

────────────────────────────────────────────────────────────────────
PUSH CYCLE (every cloud_sync_push_interval seconds, default 60)
────────────────────────────────────────────────────────────────────
  - Push all local bills (NO timestamp filter — fetch all, batch-check
    which bill_no already exist in Supabase, insert only new ones)
  - Push all local KOTs (same pattern; ALSO update status of existing
    KOTs whose status has changed)
  - Push all held bills (upsert by outlet_id + local_id)
  - Push menu sections + items (full snapshot, upsert)
  - Push packaging types (upsert)
  - Send heartbeat (update outlets.last_seen_at)

  Why no timestamp filter?
    Earlier versions filtered local bills/KOTs by "created in the last
    push window" using datetime.now(). But datetime.now() returns local
    IST, while Supabase stores/compares timestamps in UTC. This caused
    bills created around the IST→UTC boundary to be silently skipped.
    The fix is to fetch ALL local records on every push and let
    Supabase's UNIQUE(outlet_id, bill_no) constraint dedupe. Cheap
    network-wise because we batch-check existence before inserting.

────────────────────────────────────────────────────────────────────
PULL CYCLE (every cloud_sync_pull_interval seconds, default 30)
────────────────────────────────────────────────────────────────────
  - sync_menu_updates WHERE applied_at IS NULL
        → apply via db.apply_menu_update()
        → broadcast fresh menu_snapshot to LAN clients via hub_service
        → mark applied_at = utcnow()
  - sync_orders WHERE status = 'pending'
        → create local KOT via db.save_kot_with_packaging()
        → broadcast kot_new to LAN KDS clients via hub_service
        → mark status='processed', kot_no=<local kot_no>,
          processed_at = utcnow()

────────────────────────────────────────────────────────────────────
TIMEZONE POLICY
────────────────────────────────────────────────────────────────────
  All timestamps written to Supabase use datetime.utcnow() — UTC, no
  tzinfo suffix. This is what Supabase/PostgREST expects and avoids the
  IST/UTC mismatch bug. NEVER use datetime.now() in this module.
"""
import os
import sys
import json
import time
import threading
import logging
import datetime
import sqlite3

from config import CFG
import database as db

log = logging.getLogger("mcl.cloud_sync")

# ── Optional Supabase dependency ────────────────────────────────────────
# supabase-py is imported with try/except so the rest of the POS still
# works on machines where it isn't installed (cloud sync is opt-in via
# CFG["cloud_sync_enabled"]).
try:
    from supabase import create_client
    from supabase.client import Client as SupabaseClient
    SUPABASE_AVAILABLE = True
except Exception as _e:  # pragma: no cover
    SupabaseClient = None
    create_client = None
    SUPABASE_AVAILABLE = False
    log.warning(
        "supabase-py is not installed — cloud sync will be disabled. (%s)", _e
    )


# ── Module-level constants ──────────────────────────────────────────────

# PostgREST limits IN(...) clauses to ~1000 items. We batch smaller to be
# safe across Supabase versions.
BATCH_SIZE = 200

# Upper bound on how many local rows we pull into memory per push cycle.
# A busy restaurant generates maybe a few hundred bills per day; 500k
# covers ~10 years of operation. If you exceed this, paginate.
MAX_LOCAL_ROWS = 500_000

# How long to sleep between stop-flag checks inside the run loop. Kept
# small so stop() is responsive.
RUN_LOOP_TICK_SECONDS = 2.0


def _utcnow_iso() -> str:
    """
    Return the current UTC time as an ISO 8601 string WITHOUT microseconds
    and WITHOUT a timezone suffix. Example: '2025-01-15T09:30:00'.

    This is the format Supabase expects for TIMESTAMPTZ columns when
    using the anon-key REST API.
    """
    return datetime.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%S")


# ─────────────────────────────────────────────────────────────────────
# CloudSyncWorker
# ─────────────────────────────────────────────────────────────────────

class CloudSyncWorker:
    """
    Background thread that pushes local SQLite data to Supabase and pulls
    remote menu/order changes back to local SQLite.

    Pass an instance of HubService (from hub.py) as the `hub_service`
    argument so that pulled orders can be broadcast to LAN KDS clients.

    If `hub_service` is None (or has no `.server` attribute), cloud sync
    still works — it just won't broadcast pulled events to LAN clients.
    This is useful for headless / testing setups.
    """

    def __init__(self, hub_service=None):
        self.hub_service = hub_service
        self._thread: threading.Thread | None = None
        self._stop_event = threading.Event()
        self._client = None  # SupabaseClient instance (set in start())
        self._outlet_id: str | None = None
        self._lock = threading.Lock()

        # Status dict — returned by get_status(). Updated under self._lock.
        self._status = {
            "enabled": False,
            "supabase_available": SUPABASE_AVAILABLE,
            "connected": False,
            "outlet_id": None,
            "last_push_at": None,
            "last_pull_at": None,
            "last_heartbeat_at": None,
            "last_error": None,
            # Counters since last start()
            "pushed_bills": 0,
            "pushed_kots": 0,
            "pushed_held_bills": 0,
            "pushed_menu_items": 0,
            "pushed_packaging": 0,
            "pulled_menu_updates": 0,
            "pulled_orders": 0,
        }

    # ── Public API ────────────────────────────────────────────────

    def start(self):
        """
        Start the worker thread. Returns True if started successfully,
        False otherwise.

        Refuses to start if cloud sync is disabled in config, if
        supabase-py isn't installed, or if the Supabase URL/key/outlet_id
        aren't configured.
        """
        if not bool(CFG.get("cloud_sync_enabled", False)):
            log.info("Cloud sync is disabled in config; worker not started.")
            return False
        if not SUPABASE_AVAILABLE:
            log.error("Cannot start CloudSyncWorker: supabase-py not installed.")
            return False

        url = (CFG.get("supabase_url") or "").strip()
        key = (CFG.get("supabase_anon_key") or "").strip()
        if not url or not key:
            log.error(
                "Cannot start CloudSyncWorker: supabase_url / supabase_anon_key "
                "not configured."
            )
            return False

        outlet_id = (CFG.get("supabase_outlet_id") or "").strip()
        if not outlet_id:
            log.error(
                "Cannot start CloudSyncWorker: supabase_outlet_id not configured."
            )
            return False

        try:
            self._client = create_client(url, key)
        except Exception as e:
            log.exception("Failed to create Supabase client: %s", e)
            self._set(last_error=str(e))
            return False

        self._outlet_id = outlet_id

        if self._thread is not None and self._thread.is_alive():
            log.warning("CloudSyncWorker is already running; start() ignored.")
            return True

        self._stop_event.clear()
        self._thread = threading.Thread(
            target=self._run,
            name="mcl-cloudsync",
            daemon=True,
        )
        self._thread.start()
        self._set(enabled=True, outlet_id=outlet_id)
        log.info("CloudSyncWorker started (outlet=%s).", outlet_id)
        return True  # v1.5.8 FIX: Return True so hub.py knows it started

    def stop(self, timeout: float = 5.0):
        """Signal the worker thread to stop and wait for it to exit."""
        self._stop_event.set()
        if self._thread is not None and self._thread.is_alive():
            self._thread.join(timeout=timeout)
        self._thread = None
        self._set(enabled=False, connected=False)
        log.info("CloudSyncWorker stopped.")

    def get_status(self) -> dict:
        """Return a snapshot of the worker's current state (thread-safe copy)."""
        with self._lock:
            return dict(self._status)

    # ── Internal helpers ──────────────────────────────────────────

    def _set(self, **kwargs):
        with self._lock:
            self._status.update(kwargs)

    def _push_interval(self) -> float:
        try:
            v = float(CFG.get("cloud_sync_push_interval", 60) or 60)
        except (TypeError, ValueError):
            v = 60.0
        return max(5.0, v)

    def _pull_interval(self) -> float:
        try:
            v = float(CFG.get("cloud_sync_pull_interval", 30) or 30)
        except (TypeError, ValueError):
            v = 30.0
        return max(5.0, v)

    @staticmethod
    def _chunks(lst, n):
        """Yield successive n-sized chunks from lst."""
        for i in range(0, len(lst), n):
            yield lst[i:i + n]

    def _existing_ids(self, table: str, id_col: str, ids: list) -> set:
        """
        Return the set of `id_col` values already present in `table` for
        the current outlet. Used for batch existence checks before insert.
        """
        if not ids:
            return set()
        existing = set()
        for chunk in self._chunks(ids, BATCH_SIZE):
            try:
                resp = (
                    self._client.table(table)
                    .select(id_col)
                    .eq("outlet_id", self._outlet_id)
                    .in_(id_col, chunk)
                    .execute()
                )
                for row in (resp.data or []):
                    val = row.get(id_col)
                    if val is not None:
                        existing.add(val)
            except Exception as e:
                log.warning(
                    "Existence check on %s.%s failed for a chunk: %s", table, id_col, e
                )
        return existing

    def _broadcast_lan(self, msg: dict):
        """Broadcast a message to all LAN clients via hub_service, if available."""
        try:
            srv = getattr(self.hub_service, "server", None) if self.hub_service else None
            if srv is not None and hasattr(srv, "broadcast"):
                srv.broadcast(msg)
        except Exception as e:
            log.warning("LAN broadcast failed (non-fatal): %s", e)

    # ── PUSH CYCLE ────────────────────────────────────────────────

    def _push_bills(self) -> int:
        """
        Push all local bills to Supabase. Returns the number of newly
        inserted bills.

        IMPORTANT: We do NOT filter bills by date/timestamp. We fetch ALL
        local bills, batch-check which bill_no values already exist in
        Supabase for this outlet, and only insert the ones that don't.
        This fixes a timezone bug where date-string filtering was missing
        same-day bills due to IST/UTC mismatch.
        """
        try:
            all_bills = db.get_bills(limit=MAX_LOCAL_ROWS)
        except Exception as e:
            log.exception("db.get_bills() failed: %s", e)
            self._set(last_error=str(e))
            return 0

        if not all_bills:
            return 0

        bill_nos = [b["bill_no"] for b in all_bills if b.get("bill_no") is not None]
        existing = self._existing_ids("bills", "bill_no", bill_nos)

        to_insert = []
        for b in all_bills:
            if b.get("bill_no") in existing:
                continue
            to_insert.append({
                "outlet_id": self._outlet_id,
                "bill_no": int(b["bill_no"]),
                "bill_date": b.get("date", ""),
                "bill_time": b.get("time", ""),
                "table_no": b.get("table_no", "") or "",
                "customer_name": b.get("customer_name", "") or "",
                "order_source": b.get("order_source", "walkin") or "walkin",
                "subtotal": float(b.get("subtotal", 0) or 0),
                "cgst": float(b.get("cgst", 0) or 0),
                "sgst": float(b.get("sgst", 0) or 0),
                "discount_amount": float(b.get("discount_amount", 0) or 0),
                "delivery_charges": float(b.get("delivery_charges", 0) or 0),
                "packaging_charge": float(b.get("packaging_charge", 0) or 0),
                "total": float(b.get("total", 0) or 0),
                "packaging_required": bool(b.get("packaging_required", 0)),
                "payment_mode": b.get("payment_mode", "cash") or "cash",
                "pl_voided": bool(b.get("pl_voided", 0)),
                "terminal_id": int(b.get("terminal_id", 1) or 1),
                "synced_at": _utcnow_iso(),
            })

        if not to_insert:
            log.debug("Bills: nothing new to push (of %d local).", len(all_bills))
            return 0

        inserted = 0
        bill_items_to_insert = []
        for chunk in self._chunks(to_insert, BATCH_SIZE):
            try:
                resp = self._client.table("bills").insert(chunk).execute()
                # v1.6.6 FIX: Only count actual inserted rows from response
                if resp and resp.data:
                    inserted += len(resp.data)
                    for inserted_bill in resp.data:
                        bill_no = inserted_bill.get("bill_no")
                        bill_uuid = inserted_bill.get("id")
                        if not bill_uuid:
                            log.warning("Inserted bill has no UUID, skipping bill_items for bill_no=%s", bill_no)
                            continue
                        # Find the original local bill (with items) by bill_no
                        orig_bill = next((b for b in all_bills if b.get("bill_no") == bill_no), None)
                        if not orig_bill:
                            log.warning("Could not find local bill with bill_no=%s to get items", bill_no)
                            continue
                        local_items = orig_bill.get("items") or []
                        if not local_items:
                            log.warning("Local bill %s has no items in DB", bill_no)
                            continue
                        for it in local_items:
                            bill_items_to_insert.append({
                                "outlet_id": self._outlet_id,
                                "bill_id": bill_uuid,
                                "item_name": str(it.get("item_name") or it.get("name") or ""),
                                "section": str(it.get("section", "") or ""),
                                "unit_price": float(it.get("unit_price") or it.get("price") or 0),
                                "quantity": int(it.get("quantity") or it.get("qty") or 1),
                                "amount": float(it.get("amount", 0) or 0),
                                "item_type": str(it.get("item_type") or "standard"),
                                "notes": str(it.get("notes", "") or ""),
                                "packaging_type": str(it.get("packaging_type", "") or ""),
                            })
                else:
                    log.error("Bills insert returned no data. Resp: %s", str(resp)[:200] if resp else "None")
            except Exception as e:
                error_str = str(e)
                log.error("bills insert failed: %s", error_str[:300])
                self._set(last_error=error_str[:500])

        # Push bill_items in batches

        # Push bill_items in batches
        if bill_items_to_insert:
            for chunk in self._chunks(bill_items_to_insert, BATCH_SIZE):
                try:
                    self._client.table("bill_items").insert(chunk).execute()
                except Exception as e:
                    log.error("bill_items insert failed for a chunk: %s", e)

        log.info("Pushed %d new bill(s) + %d bill_items (of %d local).", inserted, len(bill_items_to_insert), len(all_bills))

        # v1.9.7 NEW: Backfill bill_items for existing bills that have no items in Supabase.
        # This fixes the historical gap where bills pushed before bill_items support
        # (or bills pushed when the items-push had a bug) have no line items in Supabase.
        # The new "Daily Product Sales" webapp report depends on bill_items being present.
        # Runs every push cycle, capped at 200 backfilled bills per cycle so it doesn't
        # block sync — over a few cycles all 4,293 bills will get their items.
        try:
            backfilled = self._backfill_bill_items(all_bills)
            if backfilled > 0:
                log.info("Backfilled bill_items for %d existing bill(s).", backfilled)
        except Exception as e:
            log.error("bill_items backfill failed: %s", e)

        return inserted

    def _backfill_bill_items(self, all_bills: list) -> int:
        """
        v1.9.7 NEW: For bills already in Supabase but missing their bill_items rows,
        fetch the items from local SQLite and push them. Capped at 200 bills per call
        so we don't hammer Supabase. Returns the number of bills backfilled.
        """
        if not all_bills:
            return 0

        # Build a lookup of local bills by bill_no → items, so we can quickly
        # find items for any bill_no that needs backfilling.
        local_by_bill_no = {}
        for b in all_bills:
            bn = b.get("bill_no")
            if bn is not None:
                local_by_bill_no[int(bn)] = b

        # v1.9.10 FIX: Find which bill_nos already have items in Supabase.
        # PREVIOUS BUG: queried ALL bill_items for the outlet in one request.
        # Supabase REST API returns max 1000 rows per request, so when there
        # were >1000 bill_items, some bill_nos were missed → re-inserted →
        # duplicates (some items appeared 2-4 times for the same bill).
        #
        # NEW APPROACH: only query the candidate bill_nos (from local bills)
        # using .in_() with chunked requests. This way we never exceed the
        # 1000-row limit and always get an accurate set.
        #
        # Build the full candidate list first (local bills that have items).
        local_candidates = []
        for b in all_bills:
            bn = b.get("bill_no")
            if bn is None:
                continue
            items = b.get("items") or []
            if not items:
                continue
            local_candidates.append((int(bn), b))

        if not local_candidates:
            return 0

        # Query Supabase for which of these bill_nos already have items.
        # Chunk into groups of 200 (Supabase .in_() has a ~300 item limit).
        candidate_bill_nos = [c[0] for c in local_candidates]
        existing_bill_nos_with_items = set()
        for chunk in self._chunks(candidate_bill_nos, 200):
            try:
                resp = self._client.table("bill_items") \
                    .select("bill_no") \
                    .eq("outlet_id", self._outlet_id) \
                    .in_("bill_no", chunk) \
                    .execute()
                if resp and resp.data:
                    for row in resp.data:
                        bn = row.get("bill_no")
                        if bn is not None:
                            existing_bill_nos_with_items.add(int(bn))
            except Exception as e:
                log.error("backfill: failed to query existing bill_items for chunk: %s", e)

        # v1.9.10: Also relies on the UNIQUE constraint (outlet_id, bill_no, item_name)
        # added by fix_duplicate_bill_items_v1.9.10.sql as a safety net — even if
        # this check misses a bill, the DB will reject the duplicate insert.
        # v1.9.10: Use local_candidates (already built above) instead of re-iterating.
        # Filter out bill_nos that already have items in Supabase.
        candidates = []
        for bn_int, b in local_candidates:
            if bn_int in existing_bill_nos_with_items:
                continue  # already has items — skip to prevent duplicates
            candidates.append((bn_int, b))
            if len(candidates) >= 200:
                break  # cap per cycle

        if not candidates:
            return 0

        # We need the Supabase bill UUID for each candidate. Fetch it from Supabase
        # by bill_no. Batch this in chunks of BATCH_SIZE.
        bill_nos_to_fetch = [c[0] for c in candidates]
        bill_no_to_uuid = {}
        for chunk in self._chunks(bill_nos_to_fetch, BATCH_SIZE):
            try:
                resp = self._client.table("bills") \
                    .select("id,bill_no") \
                    .eq("outlet_id", self._outlet_id) \
                    .in_("bill_no", chunk) \
                    .execute()
                if resp and resp.data:
                    for row in resp.data:
                        bill_no_to_uuid[int(row["bill_no"])] = row["id"]
            except Exception as e:
                log.error("backfill: failed to fetch bill UUIDs for chunk: %s", e)

        if not bill_no_to_uuid:
            return 0  # none of the candidates are in Supabase yet

        # Build bill_items payload for the candidates that have a UUID
        items_to_insert = []
        bills_backfilled = 0
        for bn_int, b in candidates:
            bill_uuid = bill_no_to_uuid.get(bn_int)
            if not bill_uuid:
                continue  # bill not in Supabase yet — skip, will be handled next cycle
            local_items = b.get("items") or []
            for it in local_items:
                items_to_insert.append({
                    "outlet_id": self._outlet_id,
                    "bill_id": bill_uuid,
                    "bill_no": bn_int,
                    "item_name": str(it.get("item_name") or it.get("name") or ""),
                    "section": str(it.get("section", "") or ""),
                    "unit_price": float(it.get("unit_price") or it.get("price") or 0),
                    "quantity": int(it.get("quantity") or it.get("qty") or 1),
                    "amount": float(it.get("amount", 0) or 0),
                    "item_type": str(it.get("item_type") or "standard"),
                    "notes": str(it.get("notes", "") or ""),
                    "packaging_type": str(it.get("packaging_type", "") or ""),
                })
            bills_backfilled += 1

        # Push in batches
        for chunk in self._chunks(items_to_insert, BATCH_SIZE):
            try:
                self._client.table("bill_items").insert(chunk).execute()
            except Exception as e:
                log.error("backfill: bill_items insert failed for a chunk: %s", e)

        return bills_backfilled

    def _push_kots(self) -> int:
        """
        Push all local KOTs to Supabase. Returns the number of KOTs
        inserted or updated.

        For KOTs that already exist in Supabase, we ALSO update their
        status if it has changed locally (e.g. KDS marked them as
        'preparing' / 'ready' / 'served').
        """
        try:
            all_kots = db.get_kots(limit=MAX_LOCAL_ROWS)
        except Exception as e:
            log.exception("db.get_kots() failed: %s", e)
            self._set(last_error=str(e))
            return 0

        if not all_kots:
            return 0

        kot_nos = [k["kot_no"] for k in all_kots if k.get("kot_no") is not None]

        # Fetch existing KOTs with their current status so we can detect
        # changes (and avoid re-inserting existing ones).
        existing_status = {}
        for chunk in self._chunks(kot_nos, BATCH_SIZE):
            try:
                resp = (
                    self._client.table("kots")
                    .select("kot_no,status")
                    .eq("outlet_id", self._outlet_id)
                    .in_("kot_no", chunk)
                    .execute()
                )
                for row in (resp.data or []):
                    existing_status[row.get("kot_no")] = row.get("status")
            except Exception as e:
                log.warning("kots existence check failed for a chunk: %s", e)

        to_insert = []
        to_update = []  # list of (kot_no, new_status)
        for k in all_kots:
            kot_no = k.get("kot_no")
            if kot_no is None:
                continue
            local_status = k.get("status", "pending") or "pending"
            if kot_no in existing_status:
                # Existing — update status if it has changed
                if existing_status[kot_no] != local_status:
                    to_update.append((kot_no, local_status))
            else:
                # New — insert with items
                items_payload = []
                for it in k.get("items", []):
                    items_payload.append({
                        "name": it.get("item_name") or it.get("name", ""),
                        "qty": int(it.get("quantity") or it.get("qty") or 1),
                        "notes": it.get("notes", "") or "",
                        "item_type": it.get("item_type") or it.get("type", "dine-in"),
                        "packaging_type": it.get("packaging_type", "") or "",
                    })
                to_insert.append({
                    "outlet_id": self._outlet_id,
                    "kot_no": int(kot_no),
                    "kot_date": k.get("date", ""),
                    "kot_time": k.get("time", ""),
                    "table_no": k.get("table_no", "") or "",
                    "customer_name": k.get("customer_name", "") or "",
                    "order_source": k.get("order_source", "walkin") or "walkin",
                    "status": local_status,
                    "packaging_required": bool(k.get("packaging_required", 0)),
                    "terminal_id": int(k.get("terminal_id", 1) or 1),
                    "items": items_payload,
                    "synced_at": _utcnow_iso(),
                })

        inserted = 0
        for chunk in self._chunks(to_insert, BATCH_SIZE):
            try:
                self._client.table("kots").insert(chunk).execute()
                inserted += len(chunk)
            except Exception as e:
                log.error("kots insert failed for a chunk: %s", e)
                self._set(last_error=str(e))

        updated = 0
        for kot_no, status in to_update:
            try:
                self._client.table("kots").update({
                    "status": status,
                    "updated_at": _utcnow_iso(),
                }).eq("outlet_id", self._outlet_id).eq("kot_no", kot_no).execute()
                updated += 1
            except Exception as e:
                log.warning("kots status update failed for kot_no=%s: %s", kot_no, e)

        log.info(
            "Pushed %d new KOT(s), updated %d status(es) (of %d local).",
            inserted, updated, len(all_kots),
        )
        return inserted + updated

    def _push_held_bills(self) -> int:
        """Upsert all local held bills to Supabase by (outlet_id, local_id)."""
        try:
            held = db.get_held_bills()
        except Exception as e:
            log.exception("db.get_held_bills() failed: %s", e)
            self._set(last_error=str(e))
            return 0
        if not held:
            return 0

        payload = []
        for h in held:
            payload.append({
                "outlet_id": self._outlet_id,
                "local_id": int(h.get("id", 0)),
                "date": h.get("date", ""),
                "time": h.get("time", ""),
                "table_no": h.get("table_no", "") or "",
                "customer_name": h.get("customer_name", "") or "",
                "order_type": h.get("order_type", "dine-in") or "dine-in",
                "subtotal": float(h.get("subtotal", 0) or 0),
                "cgst": float(h.get("cgst", 0) or 0),
                "sgst": float(h.get("sgst", 0) or 0),
                "total": float(h.get("total", 0) or 0),
                "payment_mode": h.get("payment_mode", "cash") or "cash",
                "notes": h.get("notes", "") or "",
                "terminal_id": int(h.get("terminal_id", 1) or 1),
                "packaging_required": bool(h.get("packaging_required", 0)),
                "items": [
                    {
                        "name": it.get("item_name", ""),
                        "qty": int(it.get("quantity", 0) or 0),
                        "unit_price": float(it.get("unit_price", 0) or 0),
                        "section": it.get("section", "") or "",
                        "item_type": it.get("item_type", "dine-in") or "dine-in",
                        "notes": it.get("notes", "") or "",
                        "packaging_type": it.get("packaging_type", "") or "",
                    }
                    for it in h.get("items", [])
                ],
                "synced_at": _utcnow_iso(),
            })

        inserted = 0
        for chunk in self._chunks(payload, BATCH_SIZE):
            try:
                # Upsert keyed on (outlet_id, local_id) — requires a UNIQUE
                # constraint on those columns in Supabase (defined in
                # supabase_schema.sql).
                self._client.table("held_bills").upsert(
                    chunk, on_conflict="outlet_id,local_id"
                ).execute()
                inserted += len(chunk)
            except Exception as e:
                log.error("held_bills upsert failed for a chunk: %s", e)
                self._set(last_error=str(e))
        log.info("Pushed %d held bill(s).", inserted)
        return inserted

    def _push_menu(self) -> int:
        """
        Push the full menu snapshot (sections + items) to Supabase as an
        upsert. Returns the number of menu items pushed.
        """
        try:
            snap = db.get_menu_snapshot()
        except Exception as e:
            log.exception("db.get_menu_snapshot() failed: %s", e)
            self._set(last_error=str(e))
            return 0

        sections = snap.get("sections", []) or []
        items = snap.get("items", []) or []

        # Upsert sections (key: outlet_id + local_id)
        sec_payload = [
            {
                "outlet_id": self._outlet_id,
                "local_id": int(s["id"]),
                "name": s.get("name", "") or "",
                "sort_order": int(s.get("sort_order", 0) or 0),
                "is_active": bool(s.get("is_active", 1)),
            }
            for s in sections
        ]
        for chunk in self._chunks(sec_payload, BATCH_SIZE):
            try:
                self._client.table("menu_sections").upsert(
                    chunk, on_conflict="outlet_id,local_id"
                ).execute()
            except Exception as e:
                log.error("menu_sections upsert failed for a chunk: %s", e)
                self._set(last_error=str(e))

        # Upsert items (key: outlet_id + local_id)
        item_payload = [
            {
                "outlet_id": self._outlet_id,
                "local_id": int(it["id"]),
                "section_local_id": int(it.get("section_id", 0) or 0),
                "name": it.get("name", "") or "",
                "code": it.get("code", "") or "",
                "price": int(it.get("price", 0) or 0),
                "is_active": bool(it.get("is_active", 1)),
                "sort_order": int(it.get("sort_order", 0) or 0),
            }
            for it in items
        ]
        for chunk in self._chunks(item_payload, BATCH_SIZE):
            try:
                self._client.table("menu_items").upsert(
                    chunk, on_conflict="outlet_id,local_id"
                ).execute()
            except Exception as e:
                log.error("menu_items upsert failed for a chunk: %s", e)
                self._set(last_error=str(e))

        log.info(
            "Pushed %d section(s), %d item(s).", len(sec_payload), len(item_payload)
        )
        return len(item_payload)

    def _push_packaging(self) -> int:
        """Upsert all local packaging types to Supabase by (outlet_id, local_id)."""
        try:
            types = db.get_packaging_types()
        except Exception as e:
            log.exception("db.get_packaging_types() failed: %s", e)
            self._set(last_error=str(e))
            return 0
        if not types:
            return 0

        payload = []
        for p in types:
            payload.append({
                "outlet_id": self._outlet_id,
                "local_id": int(p.get("id", 0)),
                "name": p.get("name", "") or "",
                "code": p.get("code", "") or "",
                "description": p.get("description", "") or "",
                "charge": float(p.get("charge", 0) or 0),
                "is_active": bool(p.get("is_active", 1)),
            })
        for chunk in self._chunks(payload, BATCH_SIZE):
            try:
                self._client.table("packaging_types").upsert(
                    chunk, on_conflict="outlet_id,local_id"
                ).execute()
            except Exception as e:
                log.error("packaging_types upsert failed for a chunk: %s", e)
                self._set(last_error=str(e))
        log.info("Pushed %d packaging type(s).", len(payload))
        return len(payload)

    def _send_heartbeat(self):
        """Update outlets.last_seen_at = utcnow() for our outlet."""
        try:
            self._client.table("outlets").update({
                "last_seen_at": _utcnow_iso(),
            }).eq("id", self._outlet_id).execute()
            self._set(last_heartbeat_at=_utcnow_iso(), connected=True)
            log.debug("Heartbeat sent.")
        except Exception as e:
            log.warning("Heartbeat failed: %s", e)
            self._set(connected=False, last_error=str(e))

    def _do_push_cycle(self):
        """Run one full push cycle: bills, kots, held_bills, menu, packaging, heartbeat."""
        try:
            n_bills = self._push_bills()
            n_kots = self._push_kots()
            n_held = self._push_held_bills()
            n_menu = self._push_menu()
            n_pkg = self._push_packaging()
            self._send_heartbeat()
            self._set(
                last_push_at=_utcnow_iso(),
                pushed_bills=n_bills,
                pushed_kots=n_kots,
                pushed_held_bills=n_held,
                pushed_menu_items=n_menu,
                pushed_packaging=n_pkg,
            )
        except Exception as e:
            log.exception("Push cycle error: %s", e)
            self._set(last_error=str(e))

    # ── PULL CYCLE ────────────────────────────────────────────────

    def _pull_menu_updates(self) -> int:
        """
        Pull unapplied sync_menu_updates rows, apply each via
        db.apply_menu_update(), mark it applied_at = utcnow(), and
        broadcast the fresh menu_snapshot to LAN clients.
        """
        try:
            resp = (
                self._client.table("sync_menu_updates")
                .select("*")
                .eq("outlet_id", self._outlet_id)
                .is_("applied_at", "null")
                .order("created_at")
                .limit(100)
                .execute()
            )
        except Exception as e:
            log.error("Pull sync_menu_updates failed: %s", e)
            self._set(last_error=str(e))
            return 0

        rows = resp.data or []
        applied = 0
        for row in rows:
            row_id = row.get("id")
            try:
                action = row.get("action", "") or ""
                payload = row.get("payload", {}) or {}
                if isinstance(payload, str):
                    try:
                        payload = json.loads(payload)
                    except Exception:
                        payload = {}
                db.apply_menu_update(action, payload)
                # Mark applied (this is what makes the row "disappear" from
                # the next pull — applied_at IS NULL filter).
                # v1.5.7: Only update applied_at — don't touch 'status' column
                # (it may not exist in older schema versions)
                self._client.table("sync_menu_updates").update({
                    "applied_at": _utcnow_iso(),
                }).eq("id", row_id).execute()
                applied += 1
            except Exception as e:
                log.error("Failed to apply menu update id=%s: %s", row_id, e)
                # v1.5.7: Mark as applied even on error, so we don't loop forever
                try:
                    self._client.table("sync_menu_updates").update({
                        "applied_at": _utcnow_iso(),
                    }).eq("id", row_id).execute()
                except Exception:
                    pass

        if applied:
            log.info("Applied %d remote menu update(s).", applied)
            # Broadcast the fresh menu to LAN POS/KDS clients.
            try:
                snap = db.get_menu_snapshot()
                self._broadcast_lan({"type": "menu_snapshot", "menu": snap})
            except Exception as e:
                log.warning("Menu broadcast to LAN failed: %s", e)
        return applied

    def _pull_orders(self) -> int:
        """
        Pull pending sync_orders rows, create a local KOT for each via
        db.save_kot_with_packaging(), broadcast kot_new to LAN KDS
        clients, and mark the order as processed.

        v1.5.2 FIX: Mark order as 'processing' BEFORE creating KOT, so if
        the pull cycle runs again before we finish, the order won't be
        re-pulled. Then mark as 'processed' after KOT is created.
        """
        try:
            resp = (
                self._client.table("sync_orders")
                .select("*")
                .eq("outlet_id", self._outlet_id)
                .eq("status", "pending")
                .order("created_at")
                .limit(20)
                .execute()
            )
        except Exception as e:
            log.error("Pull sync_orders failed: %s", e)
            self._set(last_error=str(e))
            return 0

        rows = resp.data or []
        processed = 0
        for row in rows:
            row_id = row.get("id")
            try:
                # v1.5.2: IMMEDIATELY mark as 'processing' so the next pull
                # cycle doesn't pick up the same order again.
                self._client.table("sync_orders").update({
                    "status": "processing",
                }).eq("id", row_id).execute()

                # Idempotency: if a previous run already created the KOT,
                # just mark the order processed.
                if row.get("kot_no") is not None:
                    self._client.table("sync_orders").update({
                        "status": "processed",
                        "processed_at": _utcnow_iso(),
                    }).eq("id", row_id).execute()
                    processed += 1
                    continue

                items_raw = row.get("items", []) or []
                if isinstance(items_raw, str):
                    try:
                        items_raw = json.loads(items_raw)
                    except Exception:
                        items_raw = []
                items = []
                for it in items_raw:
                    items.append({
                        "name": it.get("name", "") or "",
                        "qty": int(it.get("qty", 1) or 1),
                        "notes": it.get("notes", "") or "",
                        "type": "standard",  # v1.5.2: always standard type
                        "packaging_type": "",
                    })

                # v1.5.2 FIX: Don't force order_type to 'parcel'. Use 'standard'.
                # If table_no is set, it's a dine-in order — KDS will show table number.
                # If packaging_required is true, KDS shows PACK badge.
                meta = {
                    "order_type": "standard",
                    "order_source": row.get("order_source", "walkin") or "walkin",
                    "table_no": row.get("table_no", "") or "",
                    "customer_name": row.get("customer_name", "") or "",
                    "notes": row.get("notes", "") or "",
                    "packaging_required": 1 if row.get("packaging_required") else 0,
                    "aggregator_order_id": row.get("aggregator_order_id", "") or "",
                }

                kot = db.save_kot_with_packaging(meta, items)
                kot_no = kot.get("kot_no")

                # Mark the remote order as processed (with our local kot_no
                # so the web app can link them).
                self._client.table("sync_orders").update({
                    "status": "processed",
                    "kot_no": int(kot_no) if kot_no is not None else None,
                    "processed_at": _utcnow_iso(),
                }).eq("id", row_id).execute()

                # Broadcast the new KOT to LAN KDS clients.
                try:
                    full_kot = db.get_kot_by_no(kot_no) if kot_no is not None else None
                    self._broadcast_lan({
                        "type": "kot_new",
                        "kot": full_kot or kot,
                    })
                except Exception as e:
                    log.warning("Broadcast of pulled order failed: %s", e)

                processed += 1
            except Exception as e:
                log.error("Failed to process sync_order id=%s: %s", row_id, e)
                # Mark as error so we don't loop on a bad row.
                try:
                    self._client.table("sync_orders").update({
                        "status": "error",
                        "error_message": str(e)[:500],
                    }).eq("id", row_id).execute()
                except Exception:
                    pass

        if processed:
            log.info("Processed %d remote order(s) into local KOTs.", processed)
        return processed

    def _do_pull_cycle(self):
        """Run one full pull cycle: menu updates + orders."""
        try:
            n_menu = self._pull_menu_updates()
            n_orders = self._pull_orders()
            self._set(
                last_pull_at=_utcnow_iso(),
                pulled_menu_updates=n_menu,
                pulled_orders=n_orders,
            )
        except Exception as e:
            log.exception("Pull cycle error: %s", e)
            self._set(last_error=str(e))

    # ── Thread main loop ──────────────────────────────────────────

    def _run(self):
        log.info(
            "CloudSyncWorker loop started (push every %ds, pull every %ds).",
            int(self._push_interval()), int(self._pull_interval()),
        )
        last_push = 0.0
        last_pull = 0.0
        # Run an immediate push+pull on startup so the dashboard sees data
        # without having to wait for the first interval.
        while not self._stop_event.is_set():
            now = time.monotonic()
            if now - last_push >= self._push_interval():
                self._do_push_cycle()
                last_push = time.monotonic()
            if now - last_pull >= self._pull_interval():
                self._do_pull_cycle()
                last_pull = time.monotonic()
            # Sleep in small increments so stop() is responsive.
            if self._stop_event.wait(RUN_LOOP_TICK_SECONDS):
                break
        log.info("CloudSyncWorker loop exited.")


# ─────────────────────────────────────────────────────────────────────
# Module-level convenience: a singleton worker for the hub to use.
# ─────────────────────────────────────────────────────────────────────
# The hub typically does:
#     from cloud_sync import CloudSyncWorker
#     cloud = CloudSyncWorker(hub_service=self)
#     cloud.start()
# ...and on shutdown:
#     cloud.stop()
# We don't auto-instantiate at import time because that would require the
# hub to exist first. The hub owns the lifecycle.
