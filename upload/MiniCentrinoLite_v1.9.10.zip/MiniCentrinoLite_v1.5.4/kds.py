"""
Mini Centrino Lite — Kitchen Display System (KDS)
Connects to the main terminal over LAN.
Shows live KOTs, status buttons, and can print KOTs at the kitchen printer.
"""
import tkinter as tk
from tkinter import ttk, messagebox
import datetime, threading
from config import CFG
from network import KDSClient
import printer as pr
from locales import t

# ── KDS colour theme (high-contrast for kitchen monitor)
KC = {
    "bg":          "#111111",
    "header":      "#1A1A1A",
    "header_fg":   "#FFD700",
    "card_pending":  "#3A0000",
    "card_prepare":  "#3A2A00",
    "card_ready":    "#003A00",
    "card_served":   "#1A1A2A",
    "border_pending":  "#CC3300",
    "border_prepare":  "#CC9900",
    "border_ready":    "#00AA00",
    "border_served":   "#444466",
    "text":          "#FFFFFF",
    "muted":         "#AAAAAA",
    "item_text":     "#FFEECC",
    "timer_warn":    "#FF4444",
    "timer_ok":      "#AAFFAA",
}

KFONT_TITLE  = ("Segoe UI", 11, "bold")
KFONT_NORMAL = ("Segoe UI", 10)
KFONT_ITEM   = ("Segoe UI", 12, "bold")
KFONT_QTY    = ("Segoe UI", 16, "bold")
KFONT_SMALL  = ("Segoe UI", 9)
KFONT_LARGE  = ("Segoe UI", 14, "bold")
KFONT_MONO   = ("Courier New", 9)

# v1.3: Source badge colors and labels (Swiggy / Zomato / walk-in)
SOURCE_BADGES = {
    "swiggy":  {"label": "SWIGGY",   "bg": "#FC8019", "fg": "#FFFFFF"},  # Swiggy orange
    "zomato":  {"label": "ZOMATO",   "bg": "#E23744", "fg": "#FFFFFF"},  # Zomato red
    "zepto":   {"label": "ZEPTO",    "bg": "#8246EC", "fg": "#FFFFFF"},  # Zepto purple
    "blinkit": {"label": "BLINKIT",  "bg": "#FFD600", "fg": "#1A1A1A"},  # Blinkit yellow
    "walkin":  {"label": None,        "bg": None,     "fg": None},        # No badge for walk-in
    None:      {"label": None,        "bg": None,     "fg": None},
    "":        {"label": None,        "bg": None,     "fg": None},
}

# v1.3: Packaging badge — bright orange box with white text
PACKAGING_BADGE_BG = "#FF6600"
PACKAGING_BADGE_FG = "#FFFFFF"


class KDSApp:
    def __init__(self, root: tk.Tk):
        self.root = root
        
        # Parse CLI station ID
        import sys
        self.station_id = CFG.get('kds_station_id','KDS-01')
        if "--station" in sys.argv:
            try:
                idx = sys.argv.index("--station")
                self.station_id = sys.argv[idx + 1]
            except Exception:
                pass

        self.root.title(f"Mini Centrino Lite — KDS  |  {self.station_id}")
        import sys
        if sys.platform == "win32":
            self.root.state('zoomed')
        else:
            self.root.geometry("1280x750")
        self.root.minsize(800, 500)
        self.root.configure(bg=KC["bg"])

        self._kots: dict[int, dict] = {}   # kot_no -> kot dict
        self._lock = threading.Lock()

        self._build_ui()
        self._start_client()
        self._tick()


    # ──────────────────────────────────── UI ───────────────

    def _select_language(self, lang_code):
        CFG["language"] = lang_code
        from config import save as save_config
        save_config(CFG)
        self._build_ui()
        self._render_cards()

    def _build_ui(self):
        if hasattr(self, "main_container") and self.main_container:
            try:
                self.main_container.destroy()
            except Exception:
                pass
        self.main_container = tk.Frame(self.root, bg=KC["bg"])
        self.main_container.pack(fill=tk.BOTH, expand=True)

        # Header
        hdr = tk.Frame(self.main_container, bg=KC["header"], height=52)
        hdr.pack(side=tk.TOP, fill=tk.X)
        hdr.pack_propagate(False)

        tk.Label(hdr, text=t("KITCHEN DISPLAY SYSTEM", "KITCHEN DISPLAY SYSTEM"),
                 font=("Segoe UI", 15, "bold"),
                 bg=KC["header"], fg=KC["header_fg"]).pack(side=tk.LEFT, padx=12)
        tk.Label(hdr, text=f"│  {self.station_id}",
                 font=KFONT_NORMAL, bg=KC["header"], fg="#CCCCCC").pack(side=tk.LEFT)
        tk.Label(hdr, text=f"│  {CFG.get('restaurant_name','')}",
                 font=KFONT_NORMAL, bg=KC["header"], fg="#CCCCCC").pack(side=tk.LEFT)

        self._conn_lbl = tk.Label(hdr, text=t("Connecting…", "○  Connecting…"),
                                   font=KFONT_NORMAL, bg=KC["header"], fg="#FFAA44")
        self._conn_lbl.pack(side=tk.RIGHT, padx=12)

        # Language buttons
        lang_frm = tk.Frame(hdr, bg=KC["header"])
        lang_frm.pack(side=tk.RIGHT, padx=8)
        self._lang_btns = {}
        curr_lang = CFG.get("language", "en")
        for lang_code, lang_lbl in [("en", "EN"), ("hi", "हिंदी"), ("mr", "मराठी")]:
            is_active = (lang_code == curr_lang)
            btn_bg = "#FFD700" if is_active else "#333333"
            btn_fg = "black" if is_active else "white"
            btn = tk.Button(lang_frm, text=lang_lbl, font=KFONT_SMALL, relief=tk.FLAT,
                            bg=btn_bg, fg=btn_fg, cursor="hand2", padx=6, pady=2)
            btn.pack(side=tk.LEFT, padx=2)
            btn.config(command=lambda c=lang_code: self._select_language(c))
            self._lang_btns[lang_code] = btn

        self._clock_lbl = tk.Label(hdr, text="",
                                    font=KFONT_NORMAL, bg=KC["header"], fg="#CCCCCC")
        self._clock_lbl.pack(side=tk.RIGHT, padx=8)

        # Status counts bar
        self._stat_bar = tk.Frame(self.main_container, bg="#1A1A1A", pady=4)
        self._stat_bar.pack(side=tk.TOP, fill=tk.X)
        self._stat_pending   = self._stat_pill(self._stat_bar, t("Pending", "Pending"),   "0", KC["border_pending"])
        self._stat_preparing = self._stat_pill(self._stat_bar, t("Preparing", "Preparing"), "0", KC["border_prepare"])
        self._stat_ready     = self._stat_pill(self._stat_bar, t("Ready", "Ready"),     "0", KC["border_ready"])
        self._stat_served    = self._stat_pill(self._stat_bar, t("Served", "Served"),    "0", KC["border_served"])

        # Controls strip
        ctrl = tk.Frame(self.main_container, bg="#1A1A1A", pady=2)
        ctrl.pack(side=tk.TOP, fill=tk.X, padx=8)
        for label, cmd in [(t("Show All", "Show All"),     lambda: self._set_filter("all")),
                            (t("Pending Only", "Pending Only"), lambda: self._set_filter("pending")),
                            (t("Active", "Active"),       lambda: self._set_filter("active")),
                            (t("Ready", "Ready"),        lambda: self._set_filter("ready"))]:
            tk.Button(ctrl, text=label, font=KFONT_NORMAL, bg="#333333", fg="#DDDDDD",
                      relief=tk.FLAT, padx=16, pady=8, cursor="hand2",
                      command=cmd).pack(side=tk.LEFT, padx=4, pady=4)

        self._filter = "active"  # pending + preparing by default

        # KOT card scroll area
        container = tk.Frame(self.main_container, bg=KC["bg"])
        container.pack(fill=tk.BOTH, expand=True)

        self._canvas = tk.Canvas(container, bg=KC["bg"], highlightthickness=0)
        self._canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        vscr = tk.Scrollbar(container, orient=tk.VERTICAL, command=self._canvas.yview)
        vscr.pack(side=tk.RIGHT, fill=tk.Y)
        self._canvas.configure(yscrollcommand=vscr.set)

        self._card_area = tk.Frame(self._canvas, bg=KC["bg"])
        self._cwin = self._canvas.create_window((0, 0), window=self._card_area, anchor=tk.NW)
        self._card_area.bind("<Configure>",
            lambda e: self._canvas.configure(scrollregion=self._canvas.bbox("all")))
        self._canvas.bind("<Configure>",
            lambda e: self._canvas.itemconfig(self._cwin, width=e.width))
        self._canvas.bind_all("<MouseWheel>",
            lambda e: self._canvas.yview_scroll(-1*(e.delta//120), "units"))

    def _stat_pill(self, parent, label, value, color):
        f = tk.Frame(parent, bg="#1A1A1A", padx=12)
        f.pack(side=tk.LEFT)
        lbl = tk.Label(f, text=f"{label}: {value}",
                       font=KFONT_TITLE, bg="#1A1A1A", fg=color)
        lbl.pack()
        return lbl

    def _set_filter(self, f):
        self._filter = f
        self._render_cards()

    # ──────────────────────────────────── NETWORK ──────────

    def _start_client(self):
        # v1.2.1: Connect to HUB (not v1.1 terminal) using hub_ip / hub_port_client.
        # Falls back to legacy kds_terminal_ip for backward compat with v1.1 setups.
        host = CFG.get("hub_ip", "") or CFG.get("kds_terminal_ip", "127.0.0.1")
        port = int(CFG.get("hub_port_client", CFG.get("hub_port", CFG.get("kds_terminal_port", 9999))))
        self._client = KDSClient(host, port)
        self._client.on_message    = self._on_message
        self._client.on_connect    = self._on_connect
        self._client.on_disconnect = self._on_disconnect
        self._client.start()

    def _on_connect(self):
        self.root.after(0, lambda: self._conn_lbl.config(
            text="●  Connected", fg="#44FF44"))
        # v1.1 protocol: Ask terminal/primary for active KOTs.
        # v1.2 hub auto-sends initial_state on connect, so this is harmless if no response.
        self._client.send({"type": "request_active_kots"})

    def _on_disconnect(self):
        self.root.after(0, lambda: self._conn_lbl.config(
            text="○  Disconnected — retrying…", fg="#FF4444"))

    def _on_message(self, msg: dict):
        mtype = msg.get("type")
        # v1.2 protocol: hub sends "kot_new" (newer naming)
        if mtype == "kot_new":
            kot = msg.get("kot", {})
            kot_no = kot.get("kot_no")
            if kot_no:
                with self._lock:
                    kot["_arrived"] = datetime.datetime.now()
                    self._kots[kot_no] = kot
                self.root.after(0, self._render_cards)

        # v1.1 protocol: terminal sends "new_kot" (older naming, kept for backward compat)
        elif mtype == "new_kot":
            kot = msg.get("kot", {})
            kot_no = kot.get("kot_no")
            if kot_no:
                with self._lock:
                    kot["_arrived"] = datetime.datetime.now()
                    self._kots[kot_no] = kot
                self.root.after(0, self._render_cards)

        # v1.2 protocol: hub broadcasts "status_update" when KOT status changes
        elif mtype == "status_update":
            kot_no = msg.get("kot_no")
            status = msg.get("status")
            if kot_no and status:
                with self._lock:
                    if kot_no in self._kots:
                        self._kots[kot_no]["status"] = status
                self.root.after(0, self._render_cards)

        # v1.1 protocol: terminal sends "kot_status"
        elif mtype == "kot_status":
            kot_no = msg.get("kot_no")
            status = msg.get("status")
            if kot_no and status:
                with self._lock:
                    if kot_no in self._kots:
                        self._kots[kot_no]["status"] = status
                self.root.after(0, self._render_cards)

        # v1.2 protocol: hub sends "initial_state" on connect with today's KOTs
        elif mtype == "initial_state":
            kots_list = msg.get("kots", [])
            with self._lock:
                for kot in kots_list:
                    kot_no = kot.get("kot_no")
                    if kot_no:
                        if kot_no not in self._kots:
                            kot["_arrived"] = datetime.datetime.now()
                            self._kots[kot_no] = kot
                        else:
                            arrived = self._kots[kot_no].get("_arrived")
                            self._kots[kot_no] = kot
                            self._kots[kot_no]["_arrived"] = arrived
            self.root.after(0, self._render_cards)

        # v1.1 protocol: terminal responds with "active_kots"
        elif mtype == "active_kots":
            kots_list = msg.get("kots", [])
            with self._lock:
                for kot in kots_list:
                    kot_no = kot.get("kot_no")
                    if kot_no:
                        if kot_no not in self._kots:
                            kot["_arrived"] = datetime.datetime.now()
                            self._kots[kot_no] = kot
                        else:
                            arrived = self._kots[kot_no].get("_arrived")
                            self._kots[kot_no] = kot
                            self._kots[kot_no]["_arrived"] = arrived
            self.root.after(0, self._render_cards)

    # ──────────────────────────────────── CARD RENDERING ───

    def _render_cards(self):
        for w in self._card_area.winfo_children():
            w.destroy()

        with self._lock:
            kots = list(self._kots.values())

        # Filter
        if self._filter == "pending":
            kots = [k for k in kots if k.get("status") == "pending"]
        elif self._filter == "active":
            kots = [k for k in kots if k.get("status") in ("pending","preparing")]
        elif self._filter == "ready":
            kots = [k for k in kots if k.get("status") == "ready"]
        else: # "all"
            kots = [k for k in kots if k.get("status") != "served"]


        # Sort: pending first, then preparing, then ready, then served; by time
        STATUS_ORDER = {"pending":0, "preparing":1, "ready":2, "served":3}
        kots.sort(key=lambda k: (STATUS_ORDER.get(k.get("status","served"), 3),
                                  k.get("time", "")))

        # Update counts
        all_kots = list(self._kots.values())
        def count(s): return sum(1 for k in all_kots if k.get("status") == s)
        self._stat_pending.config(text=f"{t('Pending', 'Pending')}: {count('pending')}")
        self._stat_preparing.config(text=f"{t('Preparing', 'Preparing')}: {count('preparing')}")
        self._stat_ready.config(text=f"{t('Ready', 'Ready')}: {count('ready')}")
        self._stat_served.config(text=f"{t('Served', 'Served')}: {count('served')}")

        if not kots:
            tk.Label(self._card_area, text=t("No KOTs to display", "No KOTs to display"),
                     bg=KC["bg"], fg=KC["muted"],
                     font=("Segoe UI", 16), pady=40).pack()
            return

        # Layout cards in rows of 4
        COL = 4
        for i, kot in enumerate(kots):
            r, c = divmod(i, COL)
            self._make_card(kot, r, c)

        for col in range(COL):
            self._card_area.columnconfigure(col, weight=1)

    def _make_card(self, kot: dict, row: int, col: int):
        status = kot.get("status", "pending")
        arrived = kot.get("_arrived", datetime.datetime.now())
        elapsed = int((datetime.datetime.now() - arrived).total_seconds() // 60)

        STATUS_BG = {"pending": KC["card_pending"], "preparing": KC["card_prepare"],
                     "ready": KC["card_ready"], "served": KC["card_served"]}
        STATUS_BD = {"pending": KC["border_pending"], "preparing": KC["border_prepare"],
                     "ready": KC["border_ready"], "served": KC["border_served"]}
        STATUS_LABEL = {"pending": f"🔴 {t('Pending', 'PENDING').upper()}",
                        "preparing": f"🟡 {t('Preparing', 'PREPARING').upper()}",
                        "ready": f"🟢 {t('Ready', 'READY').upper()}",
                        "served": f"✔ {t('Served', 'SERVED').upper()}"}

        bg  = STATUS_BG.get(status,  KC["bg"])
        brd = STATUS_BD.get(status, "#555555")

        card = tk.Frame(self._card_area, bg=bg, relief=tk.SOLID, bd=2,
                        highlightbackground=brd, highlightthickness=2,
                        padx=8, pady=6)
        card.grid(row=row, column=col, padx=6, pady=6, sticky="nsew")

        # Card header
        hdr = tk.Frame(card, bg=bg)
        hdr.pack(fill=tk.X)
        term_tag = f" [T{kot.get('terminal_id', 1)}]"
        tk.Label(hdr, text=f"{t('KOT #', 'KOT #')} {kot.get('kot_no', 0):04d}{term_tag}",
                 bg=bg, fg=KC["header_fg"], font=KFONT_LARGE
                 ).pack(side=tk.LEFT)
        timer_color = KC["timer_warn"] if elapsed >= 10 else KC["timer_ok"]
        tk.Label(hdr, text=f"{elapsed}m", bg=bg, fg=timer_color,
                 font=KFONT_TITLE).pack(side=tk.RIGHT)

        # Order info — v1.3: prominent PACK + source badges + table/time row
        info_row = tk.Frame(card, bg=bg)
        info_row.pack(fill=tk.X, pady=(2, 0))

        # Left side: badges (PACK, Swiggy, Zomato, etc.)
        badges_frame = tk.Frame(info_row, bg=bg)
        badges_frame.pack(side=tk.LEFT)

        # PACK badge (bright orange) — show ONLY when packaging_required is True
        if kot.get("packaging_required"):
            pack_badge = tk.Label(badges_frame, text="📦 PACK",
                                  bg=PACKAGING_BADGE_BG, fg=PACKAGING_BADGE_FG,
                                  font=("Segoe UI", 10, "bold"),
                                  padx=8, pady=2)
            pack_badge.pack(side=tk.LEFT, padx=(0, 4))

        # Source badge (Swiggy orange / Zomato red / etc.) — for aggregator orders
        source = (kot.get("order_source") or "").lower().strip()
        src_style = SOURCE_BADGES.get(source, SOURCE_BADGES[""])
        if src_style["label"]:
            src_badge = tk.Label(badges_frame, text=src_style["label"],
                                 bg=src_style["bg"], fg=src_style["fg"],
                                 font=("Segoe UI", 10, "bold"),
                                 padx=8, pady=2)
            src_badge.pack(side=tk.LEFT, padx=(0, 4))

        # Right side: table number (only for dine-in / walk-in without packaging)
        if not kot.get("packaging_required"):
            tbl = kot.get("table_no","") or kot.get("table","")
            if tbl:
                tk.Label(info_row, text=f"{t('Table', 'Table')}: {tbl}",
                         bg=bg, fg=KC["muted"], font=KFONT_NORMAL
                         ).pack(side=tk.RIGHT)
            else:
                # PLATE label for dine-in without table number
                tk.Label(info_row, text=t("PLATE", "PLATE"),
                         bg=bg, fg=KC["muted"], font=KFONT_NORMAL
                         ).pack(side=tk.RIGHT)

        # Time row (always shown)
        tk.Label(card, text=f"{t('Time', 'Time')}: {kot.get('time','')}",
                 bg=bg, fg=KC["muted"],
                 font=KFONT_SMALL).pack(anchor=tk.W, pady=(2, 0))

        # Customer / aggregator order ID (if any)
        if kot.get("customer_name"):
            cust_label = kot["customer_name"]
            # If aggregator order, show order ID prefix
            agg_order_id = kot.get("aggregator_order_id", "")
            if agg_order_id:
                cust_label = f"{cust_label}  ({agg_order_id})"
            tk.Label(card, text=cust_label, bg=bg, fg=KC["muted"],
                     font=KFONT_SMALL).pack(anchor=tk.W)

        if kot.get("notes"):
            tk.Label(card, text=f"{t('NOTE:', 'NOTE:')} {kot['notes']}", bg=bg, fg="#FFCC33",
                     font=KFONT_SMALL, wraplength=180, justify=tk.LEFT).pack(anchor=tk.W)

        # Separator
        tk.Frame(card, bg=brd, height=1).pack(fill=tk.X, pady=4)

        # Items
        items = kot.get("items", [])
        for it in items:
            name = it.get("item_name") or it.get("name","")
            translated_name = t(name, name)
            qty  = it.get("quantity") or it.get("qty", 1)
            # v1.2: no per-item parcel suffix (packaging is per-order)
            row_f = tk.Frame(card, bg=bg)
            row_f.pack(fill=tk.X, pady=1)
            tk.Label(row_f, text=translated_name, bg=bg, fg=KC["item_text"],
                     font=KFONT_ITEM, anchor=tk.W
                     ).pack(side=tk.LEFT, fill=tk.X, expand=True)
            tk.Label(row_f, text=f"×{qty}", bg=bg, fg=KC["header_fg"],
                     font=KFONT_QTY, width=3).pack(side=tk.RIGHT)

            # If the item has notes, display them on KDS below the item name
            note_item = it.get("notes", "")
            if note_item:
                note_row = tk.Frame(card, bg=bg)
                note_row.pack(fill=tk.X, pady=(0, 2))
                tk.Label(note_row, text=f"  ↳ {note_item}", bg=bg, fg="#FFCC33",
                         font=KFONT_SMALL, anchor=tk.W).pack(side=tk.LEFT, padx=(10, 0))

        # Separator
        tk.Frame(card, bg=brd, height=1).pack(fill=tk.X, pady=4)

        # Status label
        tk.Label(card, text=STATUS_LABEL.get(status,""), bg=bg,
                 fg=brd, font=KFONT_TITLE).pack(anchor=tk.CENTER, pady=2)

        # Action buttons
        btn_frame = tk.Frame(card, bg=bg)
        btn_frame.pack(fill=tk.X, pady=2)

        kot_no = kot.get("kot_no")
        if status == "pending":
            tk.Button(btn_frame, text=t("Start Preparing", "Start Preparing"), font=KFONT_TITLE,
                      bg="#D48B06", fg="white", relief=tk.FLAT, cursor="hand2",
                      pady=8, command=lambda n=kot_no: self._set_status(n, "preparing")
                      ).pack(side=tk.LEFT, padx=2, fill=tk.X, expand=True)
        elif status == "preparing":
            tk.Button(btn_frame, text=t("Mark READY", "Mark READY"), font=KFONT_TITLE,
                      bg="#1E6B1E", fg="white", relief=tk.FLAT, cursor="hand2",
                      pady=8, command=lambda n=kot_no: self._set_status(n, "ready")
                      ).pack(side=tk.LEFT, padx=2, fill=tk.X, expand=True)
        elif status == "ready":
            tk.Button(btn_frame, text=t("Mark Served", "Mark Served"), font=KFONT_TITLE,
                      bg="#444466", fg="white", relief=tk.FLAT, cursor="hand2",
                      pady=8, command=lambda n=kot_no: self._set_status(n, "served")
                      ).pack(side=tk.LEFT, padx=2, fill=tk.X, expand=True)

        tk.Button(btn_frame, text=t("Print KOT", "Print KOT"), font=KFONT_TITLE,
                  bg="#333366", fg="white", relief=tk.FLAT, cursor="hand2",
                  padx=12, pady=8, command=lambda k=kot: self._print_kot(k)
                  ).pack(side=tk.RIGHT, padx=2)

    def _set_status(self, kot_no: int, status: str):
        with self._lock:
            if kot_no in self._kots:
                self._kots[kot_no]["status"] = status
        # v1.2 protocol: hub expects "status_update" message type
        self._client.send({"type": "status_update", "kot_no": kot_no, "status": status})
        # v1.1 protocol fallback: also send legacy "kot_status" type (harmless if hub ignores)
        self._client.send({"type": "kot_status", "kot_no": kot_no, "status": status})
        self._render_cards()

    def _print_kot(self, kot: dict):
        text = pr.format_kot(kot)
        ok   = pr.print_text(text, CFG.get("printer_name",""),
                              copies=int(CFG.get("print_copies_kot", 1)))
        if not ok:
            # Show preview if print fails
            win = tk.Toplevel(self.root)
            win.title("KOT Preview")
            win.geometry("440x500")
            txt = tk.Text(win, font=KFONT_MONO, width=48, bg="#111", fg="#EEE")
            txt.pack(fill=tk.BOTH, expand=True, padx=8, pady=8)
            txt.insert("1.0", text)
            txt.config(state=tk.DISABLED)
            tk.Button(win, text="Close", command=win.destroy,
                      font=KFONT_NORMAL, padx=16).pack(pady=4)

    # ──────────────────────────────────── CLOCK / TICK ─────

    def _tick(self):
        now = datetime.datetime.now().strftime("%H:%M:%S  %d %b %Y")
        self._clock_lbl.config(text=now)
        # Re-render to update timers every 30s
        if int(datetime.datetime.now().second) % 30 == 0:
            self._render_cards()
        self.root.after(1000, self._tick)
