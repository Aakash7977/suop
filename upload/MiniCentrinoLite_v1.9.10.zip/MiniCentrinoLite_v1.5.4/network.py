"""
Mini Centrino Lite v1.2 - Network Layer
v1.2 additions:
  - HubServer: TCP server used by the hub service. Accepts both POS and KDS clients.
  - Existing TerminalServer / KDSClient kept for v1.1 backward compat.
Protocol: newline-delimited JSON messages.
"""
import socket, threading, json, time, logging

log = logging.getLogger("mcl.network")


# ─────────────────────────────────────────────────────────────
#  v1.2 HubServer — used by hub.py
# ─────────────────────────────────────────────────────────────

class HubServer:
    """
    TCP server used by the Hub service. Accepts both POS and KDS clients.
    Broadcasts events to all connected clients.
    """

    def __init__(self, host="0.0.0.0", port=9999):
        self.host = host
        self.port = port
        self._clients: list[socket.socket] = []
        self._lock = threading.Lock()
        self._running = False
        self.on_message = None   # callback(msg: dict, conn: socket)

    def start(self):
        self._running = True
        t = threading.Thread(target=self._listen, daemon=True, name="hub-accept")
        t.start()
        log.info("Hub server started on %s:%s", self.host, self.port)

    def stop(self):
        self._running = False
        with self._lock:
            for c in self._clients:
                try:
                    c.close()
                except Exception:
                    pass
            self._clients.clear()

    def _listen(self):
        srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        srv.settimeout(1.0)
        try:
            srv.bind((self.host, self.port))
            srv.listen(32)
            while self._running:
                try:
                    conn, addr = srv.accept()
                    log.info("Client connected from %s", addr)
                    with self._lock:
                        self._clients.append(conn)
                    threading.Thread(target=self._handle, args=(conn, addr),
                                     daemon=True, name=f"hub-{addr[0]}:{addr[1]}").start()
                except socket.timeout:
                    continue
        except Exception as e:
            log.error("Hub server listen error: %s", e)
        finally:
            srv.close()

    def _handle(self, conn: socket.socket, addr):
        buf = ""
        try:
            while self._running:
                chunk = conn.recv(8192)
                if not chunk:
                    break
                buf += chunk.decode("utf-8", errors="replace")
                while "\n" in buf:
                    line, buf = buf.split("\n", 1)
                    line = line.strip()
                    if line and self.on_message:
                        try:
                            self.on_message(json.loads(line), conn)
                        except Exception as e:
                            log.warning("Bad message from client %s: %s", addr, e)
        except Exception as e:
            log.debug("Client %s disconnected: %s", addr, e)
        finally:
            with self._lock:
                self._clients = [c for c in self._clients if c is not conn]
            try:
                conn.close()
            except Exception:
                pass
            log.info("Client %s removed", addr)

    def send_to(self, conn: socket.socket, msg: dict):
        """Send a message directly to a specific client."""
        try:
            data = (json.dumps(msg) + "\n").encode("utf-8")
            conn.sendall(data)
        except Exception as e:
            log.warning("Direct send error: %s", e)

    def broadcast(self, msg: dict, exclude: socket.socket = None):
        """Send a message to all connected clients (optionally excluding one)."""
        data = (json.dumps(msg) + "\n").encode("utf-8")
        with self._lock:
            dead = []
            for c in self._clients:
                if exclude is not None and c is exclude:
                    continue
                try:
                    c.sendall(data)
                except Exception:
                    dead.append(c)
            for c in dead:
                self._clients.remove(c)

    @property
    def client_count(self):
        with self._lock:
            return len(self._clients)


# ─────────────────────────────────────────────────────────────
#  v1.1 TerminalServer — kept for backward compat (single-POS mode)
# ─────────────────────────────────────────────────────────────

class TerminalServer:
    """
    Runs on the main billing terminal.
    Pushes KOT events to all connected KDS clients.
    Receives status updates from KDS.
    """

    def __init__(self, host="0.0.0.0", port=9999):
        self.host = host
        self.port = port
        self._clients: list[socket.socket] = []
        self._lock = threading.Lock()
        self._running = False
        self.on_message = None   # callback(msg: dict)

    def start(self):
        self._running = True
        t = threading.Thread(target=self._listen, daemon=True, name="srv-accept")
        t.start()
        log.info("Terminal server started on %s:%s", self.host, self.port)

    def stop(self):
        self._running = False

    def _listen(self):
        srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        srv.settimeout(1.0)
        try:
            srv.bind((self.host, self.port))
            srv.listen(16)
            while self._running:
                try:
                    conn, addr = srv.accept()
                    log.info("KDS connected from %s", addr)
                    with self._lock:
                        self._clients.append(conn)
                    threading.Thread(target=self._handle, args=(conn, addr),
                                     daemon=True, name=f"kds-{addr[0]}").start()
                except socket.timeout:
                    continue
        finally:
            srv.close()

    def _handle(self, conn: socket.socket, addr):
        buf = ""
        try:
            while self._running:
                chunk = conn.recv(8192)
                if not chunk:
                    break
                buf += chunk.decode("utf-8", errors="replace")
                while "\n" in buf:
                    line, buf = buf.split("\n", 1)
                    line = line.strip()
                    if line and self.on_message:
                        try:
                            self.on_message(json.loads(line), conn)
                        except Exception as e:
                            log.warning("Bad message from KDS: %s", e)
        except Exception as e:
            log.debug("KDS %s disconnected: %s", addr, e)
        finally:
            with self._lock:
                self._clients = [c for c in self._clients if c is not conn]
            try:
                conn.close()
            except Exception:
                pass
            log.info("KDS %s removed", addr)

    def send_to(self, conn: socket.socket, msg: dict):
        """Send a message directly to a specific connected KDS instance."""
        try:
            data = (json.dumps(msg) + "\n").encode("utf-8")
            conn.sendall(data)
        except Exception as e:
            log.warning("Direct send error: %s", e)

    def broadcast(self, msg: dict):
        """Send a message to all connected KDS instances."""
        data = (json.dumps(msg) + "\n").encode("utf-8")
        with self._lock:
            dead = []
            for c in self._clients:
                try:
                    c.sendall(data)
                except Exception:
                    dead.append(c)
            for c in dead:
                self._clients.remove(c)

    @property
    def client_count(self):
        with self._lock:
            return len(self._clients)


class KDSClient:
    """
    Runs on the KDS machine.
    Auto-reconnects to the terminal server on disconnect.
    v1.2: Can connect to either the legacy TerminalServer or the new Hub.
    """

    def __init__(self, host, port=9999):
        self.host = host
        self.port = port
        self._conn: socket.socket | None = None
        self._running = False
        self.connected = False

        # Callbacks (called from background thread — schedule via root.after in GUI)
        self.on_message    = None   # (msg: dict) -> None
        self.on_connect    = None   # () -> None
        self.on_disconnect = None   # () -> None

    def start(self):
        self._running = True
        threading.Thread(target=self._loop, daemon=True, name="kds-client").start()

    def stop(self):
        self._running = False
        if self._conn:
            try:
                self._conn.close()
            except Exception:
                pass

    def _loop(self):
        while self._running:
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(5.0)
                sock.connect((self.host, self.port))
                sock.settimeout(None)
                self._conn = sock
                self.connected = True
                # Send KDS handshake so hub knows we're a KDS
                try:
                    sock.sendall((json.dumps({"type": "kds_connect",
                                              "station_id": _read_kds_station_id()}) + "\n").encode("utf-8"))
                except Exception:
                    pass
                if self.on_connect:
                    self.on_connect()
                log.info("KDS connected to terminal %s:%s", self.host, self.port)
                self._recv(sock)
            except Exception as e:
                log.debug("KDS connect error: %s", e)
            finally:
                self.connected = False
                if self.on_disconnect:
                    self.on_disconnect()
                try:
                    if self._conn:
                        self._conn.close()
                except Exception:
                    pass
                self._conn = None
            if self._running:
                time.sleep(4)

    def _recv(self, sock: socket.socket):
        buf = ""
        while self._running:
            chunk = sock.recv(8192)
            if not chunk:
                break
            buf += chunk.decode("utf-8", errors="replace")
            while "\n" in buf:
                line, buf = buf.split("\n", 1)
                line = line.strip()
                if line and self.on_message:
                    try:
                        self.on_message(json.loads(line))
                    except Exception as e:
                        log.warning("Bad server message: %s", e)

    def send(self, msg: dict):
        if self._conn and self.connected:
            try:
                self._conn.sendall((json.dumps(msg) + "\n").encode("utf-8"))
            except Exception as e:
                log.warning("KDS send error: %s", e)


def _read_kds_station_id() -> str:
    """Helper to read KDS station ID from config without circular import at module load."""
    try:
        from config import CFG
        return CFG.get("kds_station_id", "KDS-01")
    except Exception:
        return "KDS-01"
