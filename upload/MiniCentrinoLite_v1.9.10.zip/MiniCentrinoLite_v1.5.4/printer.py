"""
Mini Centrino Lite - Printer Utilities
Formats receipts and KOTs as monospaced plain text for 80mm thermal printers.
Printing via win32print (Windows) or lpr (Linux/Mac) or temp-file fallback.
"""
import sys, os, tempfile, subprocess, textwrap, datetime
from config import CFG
from locales import t

W = CFG.get("thermal_chars", 42)  # characters per line on 80mm roll


# ─────────────────────────────────────────────────────────────
#  Formatting helpers
# ─────────────────────────────────────────────────────────────

def _line(char="-"):
    return char * W

def _center(text):
    return text.center(W)

def _lr(left, right, width=None):
    w = width or W
    right = str(right)
    left_w = w - len(right) - 1
    return f"{str(left)[:left_w]:<{left_w}} {right}"

def _wrap(text, indent=2):
    return textwrap.fill(text, W, subsequent_indent=" " * indent)


# ─────────────────────────────────────────────────────────────
#  Bill receipt
# ─────────────────────────────────────────────────────────────

def format_bill(bill: dict) -> str:
    lines = []
    a = lines.append

    a(_center(CFG.get("restaurant_name", "SUDHAMRIT FOOD JOINT")))
    a(_center(CFG.get("restaurant_address", "Thane, Maharashtra")))
    tag = CFG.get("tagline", "")
    if tag:
        a(_center(tag))

    gstin = CFG.get("gstin", "")
    if gstin:
        a(_center(f"GSTIN: {gstin}"))

    a(_line("─"))
    a(_center(t("BILL / INVOICE", "BILL / INVOICE")))
    a(_line("─"))

    term_id = bill.get("terminal_id", 1)
    a(_lr(f"{t('Bill No', 'Bill No')}: #{str(bill['bill_no']).zfill(4)}", f"{bill['date']}"))
    # v1.2: Packaging flag replaces Dine-in / Parcel distinction
    pkg_str = t("Packaging: Yes", "Packaging: Yes") if bill.get("packaging_required") else t("Packaging: No", "Packaging: No")
    # v1.3: Include aggregator source if present
    source = (bill.get("order_source") or "").lower().strip()
    if source and source not in ("walkin", ""):
        pkg_str = f"{pkg_str}  [{source.upper()}]"
    a(_lr(f"{t('Time', 'Time')}: {bill['time']} | {t('Term', 'Term')}: T{term_id}", pkg_str))
    if bill.get("table_no"):
        a(f"{t('Table', 'Table')}  : {bill['table_no']}")
    if bill.get("customer_name"):
        a(f"{t('Name', 'Name')}   : {bill['customer_name']}")
    # v1.3: Aggregator order ID (if present)
    agg_id = bill.get("aggregator_order_id", "")
    if agg_id:
        a(f"{t('Aggregator ID', 'Aggregator ID')}: {agg_id}")

    a(_line("─"))
    # Header row
    item_hdr = f"{t('Item', 'Item'):<24} {t('Qty', 'Qty'):>3} {t('Rate', 'Rate'):>5} {t('Amt', 'Amt'):>6}"
    a(item_hdr)
    a(_line("─"))

    for it in bill.get("items", []):
        name  = it.get("item_name") or it.get("name", "")
        translated_name = t(name, name)
        qty   = it.get("quantity") or it.get("qty", 1)
        price = it.get("unit_price") or it.get("price", 0)
        amt   = qty * price

        # v1.2: no parcel suffix per-item — packaging is per-order now
        # Handle long names — wrap to next line
        if len(translated_name) <= 24:
            a(f"{translated_name:<24} {qty:>3} {price:>5} {amt:>6}")
        else:
            a(f"{translated_name[:24]:<24}")
            a(f"{'':24} {qty:>3} {price:>5} {amt:>6}")

    a(_line("─"))
    a(_lr(t("Subtotal", "Subtotal"), f"Rs.{bill['subtotal']:.2f}"))
    if bill.get('discount_amount', 0.0) > 0.0:
        pct_str = f" ({bill['discount_percentage']}%)" if bill.get('discount_percentage', 0.0) > 0.0 else ""
        a(_lr(f"{t('Discount', 'Discount')}{pct_str}", f"-Rs.{bill['discount_amount']:.2f}"))
    a(_lr(t("CGST @2.5%", "CGST @2.5%"), f"Rs.{bill['cgst']:.2f}"))
    a(_lr(t("SGST @2.5%", "SGST @2.5%"), f"Rs.{bill['sgst']:.2f}"))
    if bill.get('packaging_charge', 0.0) > 0.0:
        a(_lr(t("Packaging Charges", "Packaging Charges"), f"Rs.{bill['packaging_charge']:.2f}"))
    if bill.get('delivery_charges', 0.0) > 0.0:
        a(_lr(t("Delivery Charges", "Delivery Charges"), f"Rs.{bill['delivery_charges']:.2f}"))
    a(_line("═"))
    a(_lr(t("GRAND TOTAL", "GRAND TOTAL"), f"Rs.{bill['total']:.2f}"))
    a(_line("═"))

    pm_val = bill.get("payment_mode", "cash")
    if pm_val == "split":
        a(_center(f"{t('Payment', 'Payment')}: {t('SPLIT', 'SPLIT')}"))
        if bill.get("split_cash", 0.0) > 0.0:
            a(_lr(t("Cash Pay", "Cash Pay"), f"Rs.{bill['split_cash']:.2f}"))
        if bill.get("split_card", 0.0) > 0.0:
            a(_lr(t("Card Pay", "Card Pay"), f"Rs.{bill['split_card']:.2f}"))
        if bill.get("split_upi", 0.0) > 0.0:
            a(_lr(t("UPI Pay", "UPI Pay"), f"Rs.{bill['split_upi']:.2f}"))
        if bill.get("split_other", 0.0) > 0.0:
            a(_lr(t("Other Pay", "Other Pay"), f"Rs.{bill['split_other']:.2f}"))
    else:
        pm = t(pm_val.capitalize(), pm_val.upper()).upper()
        a(_center(f"{t('Payment', 'Payment')}: {pm}"))


    # Pine Labs card payment details
    if bill.get("pl_approval_code") or bill.get("pl_txn_id"):
        a(_line("─"))
        if bill.get("pl_card_scheme"):
            a(_lr(t("Card type", "Card type"), bill["pl_card_scheme"]))
        if bill.get("pl_masked_card"):
            a(_lr(t("Card no.", "Card no."), bill["pl_masked_card"]))
        if bill.get("pl_approval_code"):
            a(_lr(t("Approval code", "Approval code"), bill["pl_approval_code"]))
        if bill.get("pl_txn_id"):
            a(_lr(t("Transaction ID", "Transaction ID"), bill["pl_txn_id"]))
        if bill.get("pl_invoice_no"):
            a(_lr(t("EDC invoice", "EDC invoice"), bill["pl_invoice_no"]))
    if bill.get("pl_voided"):
        a(_line("═"))
        a(_center(t("*** VOID / CANCELLED ***", "*** VOID / CANCELLED ***")))
        a(_line("═"))

    a("")
    a(_center(t("Thank you for dining with us!", "Thank you for dining with us!")))
    a(_center(t("TASTY  |  FAST  |  HOT", "TASTY  |  FAST  |  HOT")))
    a("")
    a(_center("─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─"))
    a("")

    return "\n".join(lines)


# ─────────────────────────────────────────────────────────────
#  Held bill receipt
# ─────────────────────────────────────────────────────────────

def format_held_bill(bill: dict) -> str:
    lines = []
    a = lines.append

    a(_center(CFG.get("restaurant_name", "SUDHAMRIT FOOD JOINT")))
    a(_center(CFG.get("restaurant_address", "Thane, Maharashtra")))
    tag = CFG.get("tagline", "")
    if tag:
        a(_center(tag))

    a(_line("─"))
    a(_center(t("*** HOLD SLIP (DRAFT) ***", "*** HOLD SLIP (DRAFT) ***")))
    a(_center(t("NOT A FINAL BILL", "NOT A FINAL BILL")))
    a(_line("─"))

    term_id = bill.get("terminal_id", 1)
    a(_lr(f"{t('Hold Ref', 'Hold Ref')}: #H{str(bill.get('id', 0)).zfill(4)}", f"{bill['date']}"))
    # v1.2: Packaging flag
    pkg_str = t("Packaging: Yes", "Packaging: Yes") if bill.get("packaging_required") else t("Packaging: No", "Packaging: No")
    a(_lr(f"{t('Time', 'Time')}: {bill['time']} | {t('Term', 'Term')}: T{term_id}", pkg_str))
    if bill.get("table_no"):
        a(f"{t('Table', 'Table')}  : {bill['table_no']}")
    if bill.get("customer_name"):
        a(f"{t('Name', 'Name')}   : {bill['customer_name']}")

    a(_line("─"))
    item_hdr = f"{t('Item', 'Item'):<24} {t('Qty', 'Qty'):>3} {t('Rate', 'Rate'):>5} {t('Amt', 'Amt'):>6}"
    a(item_hdr)
    a(_line("─"))

    for it in bill.get("items", []):
        name  = it.get("item_name") or it.get("name", "")
        translated_name = t(name, name)
        qty   = it.get("quantity") or it.get("qty", 1)
        price = it.get("unit_price") or it.get("price", 0)
        amt   = qty * price

        # v1.2: no per-item parcel suffix
        if len(translated_name) <= 24:
            a(f"{translated_name:<24} {qty:>3} {price:>5} {amt:>6}")
        else:
            a(f"{translated_name[:24]:<24}")
            a(f"{'':24} {qty:>3} {price:>5} {amt:>6}")

    a(_line("─"))
    a(_lr(t("Subtotal", "Subtotal"), f"Rs.{bill['subtotal']:.2f}"))
    if bill.get('discount_amount', 0.0) > 0.0:
        pct_str = f" ({bill['discount_percentage']}%)" if bill.get('discount_percentage', 0.0) > 0.0 else ""
        a(_lr(f"{t('Discount', 'Discount')}{pct_str}", f"-Rs.{bill['discount_amount']:.2f}"))
    a(_lr(t("CGST @2.5%", "CGST @2.5%"), f"Rs.{bill['cgst']:.2f}"))
    a(_lr(t("SGST @2.5%", "SGST @2.5%"), f"Rs.{bill['sgst']:.2f}"))
    if bill.get('packaging_charge', 0.0) > 0.0:
        a(_lr(t("Packaging Charges", "Packaging Charges"), f"Rs.{bill['packaging_charge']:.2f}"))
    if bill.get('delivery_charges', 0.0) > 0.0:
        a(_lr(t("Delivery Charges", "Delivery Charges"), f"Rs.{bill['delivery_charges']:.2f}"))
    a(_line("═"))
    a(_lr(t("EST. TOTAL", "EST. TOTAL"), f"Rs.{bill['total']:.2f}"))
    a(_line("═"))
    a("")
    a(_center(t("Please pay at the counter", "Please pay at the counter")))
    a(_center("─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─"))
    a("")

    return "\n".join(lines)


# ─────────────────────────────────────────────────────────────
#  KOT (Kitchen Order Ticket)
# ─────────────────────────────────────────────────────────────


def format_kot(kot: dict) -> str:
    lines = []
    a = lines.append

    a(_line("═"))
    a(_center(t("*** KOT — KITCHEN ORDER ***", "*** KOT — KITCHEN ORDER ***")))
    a(_center(f"{t('KOT #', 'KOT #')} {str(kot['kot_no']).zfill(4)}"))
    a(_line("═"))

    term_id = kot.get("terminal_id", 1)
    # v1.2: PACK / PLATE badge replaces DINE-IN / PARCEL header
    ot = t("PACK", "PACK") if kot.get("packaging_required") else t("PLATE", "PLATE")
    # v1.3: Include aggregator source if present
    source = (kot.get("order_source") or "").lower().strip()
    if source and source not in ("walkin", ""):
        ot = f"{ot}  [{source.upper()}]"
    a(_lr(f"{t('Date', 'Date')}: {kot['date']}", f"{t('Time', 'Time')}: {kot['time']}"))
    a(_lr(f"{t('Type', 'Type')}: {ot}", f"{t('Term', 'Term')}: T{term_id}"))
    if not kot.get("packaging_required") and kot.get("table_no"):
        a(_lr(f"{t('Table', 'Table')}: {kot.get('table_no','-')}", ""))
    if kot.get("customer_name"):
        a(f"{t('Name', 'Name')} : {kot['customer_name']}")
    # v1.3: Aggregator order ID (if present)
    agg_id = kot.get("aggregator_order_id", "")
    if agg_id:
        a(f"{t('Aggregator ID', 'Aggregator ID')}: {agg_id}")

    a(_line("─"))
    a(f"{t('ITEM', 'ITEM'):<32} {t('QTY', 'QTY'):>4}")
    a(_line("─"))

    for it in kot.get("items", []):
        name = it.get("item_name") or it.get("name", "")
        translated_name = t(name, name)
        qty  = it.get("quantity") or it.get("qty", 1)
        note = it.get("notes", "")

        # v1.2: no per-item parcel suffix
        if len(translated_name) <= 32:
            a(f"{translated_name:<32} {qty:>4}")
        else:
            a(f"{translated_name[:32]}")
            a(f"{'':32} {qty:>4}")
        if note:
            a(f"  [{note}]")

    a(_line("─"))
    if kot.get("notes"):
        a(f"{t('NOTE', 'NOTE')}: {kot['notes']}")
    a(_center(t("─ END OF KOT ─", "─ END OF KOT ─")))
    a("")

    return "\n".join(lines)


# ─────────────────────────────────────────────────────────────
#  Sales Report Layout
# ─────────────────────────────────────────────────────────────

def format_sales_report(report: dict, item_sales: list) -> str:
    lines = []
    a = lines.append

    a(_center(CFG.get("restaurant_name", "SUDHAMRIT FOOD JOINT")))
    a(_center(t("DAILY SALES REPORT", "DAILY SALES REPORT")))
    a(_line("─"))
    
    report_date_lbl = f"{t('Report Date', 'Report Date')}: {report['date']}"
    print_lbl = f"{t('Print', 'Print')}: {datetime.datetime.now().strftime('%d/%m/%Y %H:%M')}"
    a(_lr(report_date_lbl, print_lbl))
    a(_line("─"))
    
    a(_lr(t("Bills Issued", "Bills Issued"), report['bills']))
    a(_lr(t("Voided Bills", "Voided Bills"), report.get('voided', 0)))
    a(_lr(t("KOTs Raised", "KOTs Raised"), report['kots']))
    a(_line("─"))
    a(_lr(t("Gross Revenue", "Gross Revenue"), f"Rs.{report['total']:.2f}"))
    a(_lr(t("GST Collected", "GST Collected"), f"Rs.{report['gst']:.2f}"))
    a(_lr(t("Net Subtotal", "Net Subtotal"), f"Rs.{report['subtotal']:.2f}"))
    a(_line("─"))
    a(_lr(t("Cash Sales", "Cash Sales"), f"Rs.{report['cash']:.2f}"))
    a(_lr(t("Card / UPI Sales", "Card / UPI Sales"), f"Rs.{report['card']:.2f}"))
    
    a(_line("─"))
    a(_center(t("ITEM-WISE SALES", "ITEM-WISE SALES")))
    a(_line("─"))
    a(f"{t('Item Name', 'Item Name'):<24} {t('Qty', 'Qty'):>6} {t('Amount', 'Amount'):>10}")
    a(_line("─"))
    
    for it in item_sales:
        name = it['item_name']
        translated_name = t(name, name)
        qty = it['quantity']
        amt = it['amount']
        
        amt_str = f"{amt:.2f}"
        if len(translated_name) <= 24:
            a(f"{translated_name:<24} {qty:>6} {amt_str:>10}")
        else:
            a(f"{translated_name[:24]:<24}")
            a(f"{'':24} {qty:>6} {amt_str:>10}")
            
    a(_line("─"))
    a(_center(t("─ END OF REPORT ─", "─ END OF REPORT ─")))
    a("")
    
    return "\n".join(lines)


# ─────────────────────────────────────────────────────────────
#  Actual printing
# ─────────────────────────────────────────────────────────────

def print_text(text: str, printer_name: str = None, copies: int = 1) -> bool:
    """
    Send plain text to a printer.
    On Windows: uses win32print for direct RAW mode (best for ESC/POS thermal).
    Fallback on Windows: opens Notepad /p (visible, user closes).
    On Linux/Mac: uses lpr.
    Returns True on success, False on failure.
    """
    for _ in range(max(1, copies)):
        ok = _do_print(text, printer_name)
        if not ok:
            return False
    return True

def _do_print(text: str, printer_name: str = None) -> bool:
    if sys.platform == "win32":
        return _print_win(text, printer_name)
    else:
        return _print_unix(text)

def _print_win(text: str, printer_name: str = None) -> bool:
    try:
        import win32print, win32api  # type: ignore
        pname = printer_name or win32print.GetDefaultPrinter()
        if not pname:
            return False
        hp = win32print.OpenPrinter(pname)
        try:
            hj = win32print.StartDocPrinter(hp, 1, ("MCL Receipt", None, "RAW"))
            win32print.StartPagePrinter(hp)
            
            # Translate Unicode to CP437/ASCII compatible chars
            clean_text = text.replace("─", "-").replace("═", "=").replace("—", "-").replace("₹", "Rs.").replace("’", "'").replace("‘", "'")
            raw_bytes = clean_text.encode("cp437", errors="replace")
            
            # Feed 5 lines and send ESC/POS cut command (GS V 1 for half cut)
            cut_bytes = b"\n\n\n\n\n\x1d\x56\x01"
            
            win32print.WritePrinter(hp, raw_bytes + cut_bytes)
            win32print.EndPagePrinter(hp)
            win32print.EndDocPrinter(hp)
        finally:
            win32print.ClosePrinter(hp)
        return True
    except Exception as e:
        print(f"[Printer] Error: {e}")
        return False

def _print_win_notepad(text: str) -> bool:
    """Fallback: write to temp file, open Notepad for printing."""
    try:
        fd, path = tempfile.mkstemp(suffix=".txt", prefix="mcl_")
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(text)
        subprocess.Popen(["notepad.exe", "/p", path])
        return True
    except Exception as e:
        print(f"[Printer] Notepad fallback error: {e}")
        return False

def _print_unix(text: str) -> bool:
    try:
        clean_text = text.replace("─", "-").replace("═", "=").replace("—", "-").replace("₹", "Rs.").replace("’", "'").replace("‘", "'")
        raw_bytes = clean_text.encode("cp437", errors="replace") + b"\n\n\n\n\n\x1d\x56\x01"
        proc = subprocess.run(["lpr"], input=raw_bytes,
                              capture_output=True, timeout=10)
        return proc.returncode == 0
    except Exception as e:
        print(f"[Printer] lpr error: {e}")
        return False

def get_printers() -> list[str]:
    """Return list of available printer names."""
    names = []
    if sys.platform == "win32":
        try:
            import win32print  # type: ignore
            for _, _, name, _ in win32print.EnumPrinters(
                    win32print.PRINTER_ENUM_LOCAL | win32print.PRINTER_ENUM_CONNECTIONS):
                names.append(name)
        except Exception:
            pass
    return names
