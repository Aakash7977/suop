"""
Mini Centrino Lite - Database Layer (SQLite)
All persistence goes through this module.
"""
import sqlite3, threading, datetime
from config import DB_PATH, BASE_DIR

_lock = threading.Lock()

def get_conn():
    BASE_DIR.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(DB_PATH), check_same_thread=False, timeout=10)
    conn.row_factory = sqlite3.Row
    from config import CFG
    # SQLite WAL mode is not supported over network shared drives (leads to locking errors).
    # Use DELETE rollback mode if we are on a network shared path (UNC/network drive) or running as secondary.
    is_network = str(DB_PATH).startswith("\\\\") or (CFG.get("db_path") and not CFG.get("is_primary", True))
    if is_network:
        conn.execute("PRAGMA journal_mode=DELETE")
    else:
        conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn

def init_db():
    with _lock:
        conn = get_conn()
        c = conn.cursor()

        c.executescript("""
        CREATE TABLE IF NOT EXISTS counters (
            name  TEXT PRIMARY KEY,
            value INTEGER NOT NULL DEFAULT 0
        );

        CREATE TABLE IF NOT EXISTS bills (
            id            INTEGER PRIMARY KEY AUTOINCREMENT,
            bill_no       INTEGER UNIQUE NOT NULL,
            date          TEXT NOT NULL,
            time          TEXT NOT NULL,
            table_no      TEXT DEFAULT '',
            customer_name TEXT DEFAULT '',
            order_type    TEXT NOT NULL,
            subtotal      REAL NOT NULL,
            cgst          REAL NOT NULL,
            sgst          REAL NOT NULL,
            total         REAL NOT NULL,
            discount_percentage REAL DEFAULT 0.0,
            discount_amount     REAL DEFAULT 0.0,
            delivery_charges    REAL DEFAULT 0.0,
            payment_mode  TEXT DEFAULT 'cash',
            notes         TEXT DEFAULT '',
            created_at    TEXT DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS bill_items (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            bill_id    INTEGER NOT NULL,
            item_name  TEXT NOT NULL,
            section    TEXT DEFAULT '',
            unit_price REAL NOT NULL,
            quantity   INTEGER NOT NULL,
            amount     REAL NOT NULL,
            FOREIGN KEY (bill_id) REFERENCES bills(id)
        );

        CREATE TABLE IF NOT EXISTS kots (
            id            INTEGER PRIMARY KEY AUTOINCREMENT,
            kot_no        INTEGER UNIQUE NOT NULL,
            bill_id       INTEGER,
            date          TEXT NOT NULL,
            time          TEXT NOT NULL,
            table_no      TEXT DEFAULT '',
            customer_name TEXT DEFAULT '',
            order_type    TEXT NOT NULL,
            status        TEXT DEFAULT 'pending',
            notes         TEXT DEFAULT '',
            created_at    TEXT DEFAULT CURRENT_TIMESTAMP,
            updated_at    TEXT DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS kot_items (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            kot_id     INTEGER NOT NULL,
            item_name  TEXT NOT NULL,
            quantity   INTEGER NOT NULL,
            notes      TEXT DEFAULT '',
            packaging_type TEXT DEFAULT '',
            FOREIGN KEY (kot_id) REFERENCES kots(id)
        );

        CREATE TABLE IF NOT EXISTS sessions (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            opened_at   TEXT,
            closed_at   TEXT,
            total_sales REAL DEFAULT 0,
            total_bills INTEGER DEFAULT 0
        );

        CREATE TABLE IF NOT EXISTS menu_sections (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            name       TEXT UNIQUE NOT NULL,
            sort_order INTEGER DEFAULT 0,
            is_active  INTEGER DEFAULT 1
        );

        CREATE TABLE IF NOT EXISTS menu_items (
            id            INTEGER PRIMARY KEY AUTOINCREMENT,
            section_id    INTEGER NOT NULL,
            name          TEXT NOT NULL,
            code          TEXT UNIQUE,
            dine_in_price INTEGER NOT NULL DEFAULT 0,
            parcel_price  INTEGER NOT NULL DEFAULT 0,
            is_active     INTEGER DEFAULT 1,
            sort_order    INTEGER DEFAULT 0,
            FOREIGN KEY (section_id) REFERENCES menu_sections(id) ON DELETE CASCADE
        );

        CREATE TABLE IF NOT EXISTS held_bills (
            id            INTEGER PRIMARY KEY AUTOINCREMENT,
            date          TEXT NOT NULL,
            time          TEXT NOT NULL,
            table_no      TEXT DEFAULT '',
            customer_name TEXT DEFAULT '',
            order_type    TEXT NOT NULL,
            subtotal      REAL NOT NULL,
            cgst          REAL NOT NULL,
            sgst          REAL NOT NULL,
            total         REAL NOT NULL,
            discount_percentage REAL DEFAULT 0.0,
            discount_amount     REAL DEFAULT 0.0,
            delivery_charges    REAL DEFAULT 0.0,
            payment_mode  TEXT DEFAULT 'cash',
            notes         TEXT DEFAULT '',
            created_at    TEXT DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS held_bill_items (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            held_bill_id INTEGER NOT NULL,
            item_name    TEXT NOT NULL,
            section      TEXT DEFAULT '',
            unit_price   REAL NOT NULL,
            quantity     INTEGER NOT NULL,
            amount       REAL NOT NULL,
            item_type    TEXT DEFAULT 'dine-in',
            FOREIGN KEY (held_bill_id) REFERENCES held_bills(id) ON DELETE CASCADE
        );
        """)

        # v1.2.1 fix: use explicit column names so this works even if the user's
        # existing data.db has a `counters` table with extra columns from an
        # older app version. Positional VALUES ('bill', 0) would fail with
        # "table counters has 4 columns but 2 values were supplied".
        c.execute("INSERT OR IGNORE INTO counters (name, value) VALUES ('bill', 0)")
        c.execute("INSERT OR IGNORE INTO counters (name, value) VALUES ('kot', 0)")
        conn.commit()
        conn.close()

    # Non-destructive migration: add Pine Labs columns if upgrading
    _migrate_add_pinelabs_columns()
    # Non-destructive migration: add item type columns if upgrading
    _migrate_add_item_type_columns()
    # Non-destructive migration: add discount and delivery columns if upgrading
    _migrate_add_discount_delivery_columns()
    # ── v1.2 migrations (must run BEFORE _seed_menu_if_empty) ──
    _migrate_v12_add_price_column()
    _migrate_v12_add_packaging_required_columns()
    _migrate_v12_create_hub_sync_log()
    # v1.2.1 fix: ensure counters table has only the 2 expected columns.
    _migrate_v121_normalize_counters_table()
    # v1.3: add order_source column (for Swiggy / Zomato / Zepto / Blinkit aggregator orders)
    _migrate_v13_add_order_source_column()
    # Seed menu from defaults if table is empty
    _seed_menu_if_empty()
    # Now populate price column for any existing items (v1.1 upgrade path)
    _migrate_v12_seed_price_column()
    # Non-destructive migration: add 4-digit code column to menu_items if upgrading
    _migrate_add_code_column()
    # Non-destructive migration: add terminal_id columns if upgrading
    _migrate_add_terminal_id_columns()
    # Non-destructive migration: add split payment columns if upgrading
    _migrate_add_split_payment_columns()
    # Non-destructive migration: add notes to bill_items and held_bill_items if upgrading
    _migrate_add_item_notes_columns()
    # Non-destructive migration: add packaging_charge column to bills if upgrading
    _migrate_add_packaging_charge_column()
    # Create packaging tables (idempotent)
    _create_packaging_tables()
    # Non-destructive migration: add code column to packaging_types if upgrading
    _migrate_add_packaging_code_column()
    # Non-destructive migration: add stock columns to menu_items if upgrading
    _migrate_add_stock_columns()
    # Add packaging_charge to save_bill and save_held_bill INSERT statements
    _migrate_update_bill_insert_packaging()
    # Non-destructive migration: add stock columns to packaging_types for packaging inventory
    _migrate_add_packaging_stock_columns()
    # Non-destructive migration: add packaging_type column to kot_items
    _migrate_add_kot_packaging_type_column()



def _migrate_v12_add_price_column():
    """v1.2: Add single `price` column to menu_items (alongside legacy dine_in_price/parcel_price)."""
    with _lock:
        conn = get_conn()
        try:
            conn.execute("ALTER TABLE menu_items ADD COLUMN price INTEGER DEFAULT 0")
            conn.commit()
        except Exception:
            pass  # column already exists
        conn.close()


def _migrate_v12_add_packaging_required_columns():
    """v1.2: Add packaging_required column to bills and kots (0 = plate, 1 = pack)."""
    with _lock:
        conn = get_conn()
        try:
            conn.execute("ALTER TABLE bills ADD COLUMN packaging_required INTEGER DEFAULT 0")
            conn.commit()
        except Exception:
            pass
        try:
            conn.execute("ALTER TABLE kots ADD COLUMN packaging_required INTEGER DEFAULT 0")
            conn.commit()
        except Exception:
            pass
        try:
            conn.execute("ALTER TABLE held_bills ADD COLUMN packaging_required INTEGER DEFAULT 0")
            conn.commit()
        except Exception:
            pass
        conn.close()


def _migrate_v12_seed_price_column():
    """v1.2: Populate `price` from middle of (dine_in_price + parcel_price) rounded to nearest 5."""
    with _lock:
        conn = get_conn()
        try:
            rows = conn.execute(
                "SELECT id, dine_in_price, parcel_price, price FROM menu_items"
            ).fetchall()
            for r in rows:
                if r["price"] and r["price"] > 0:
                    continue  # already populated
                dine = r["dine_in_price"] or 0
                parcel = r["parcel_price"] or 0
                if dine == 0 and parcel == 0:
                    continue
                mid = (dine + parcel) // 2 + ((dine + parcel) % 2)
                price = 5 * round(mid / 5)
                conn.execute("UPDATE menu_items SET price=? WHERE id=?", (price, r["id"]))
            conn.commit()
        except Exception as e:
            print(f"[v1.2 seed price] warning: {e}")
        conn.close()


def _migrate_v12_create_hub_sync_log():
    """v1.2: Create hub_sync_log table for tracking received menu_update events (idempotency)."""
    with _lock:
        conn = get_conn()
        conn.executescript("""
            CREATE TABLE IF NOT EXISTS hub_sync_log (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                event_type  TEXT NOT NULL,
                payload     TEXT,
                received_at TEXT DEFAULT CURRENT_TIMESTAMP
            );
        """)
        conn.commit()
        conn.close()


def _migrate_v121_normalize_counters_table():
    """
    v1.2.1 fix: Some legacy data.db files have a `counters` table with extra
    columns (from an even older app version). This causes INSERT statements
    using only (name, value) to fail with:
        sqlite3.OperationalError: table counters has 4 columns but 2 values were supplied

    This migration rebuilds the counters table with the standard 2-column
    schema (name, value), preserving existing rows' name+value data.
    """
    with _lock:
        conn = get_conn()
        try:
            cols = [r[1] for r in conn.execute("PRAGMA table_info(counters)").fetchall()]
            if len(cols) <= 2:
                return  # already standard, nothing to do
            # Backup existing data (only name + value columns)
            log_msg = f"[v1.2.1] Normalizing counters table (was {len(cols)} cols: {cols})"
            print(log_msg)
            # Use transaction to rebuild table
            conn.executescript("""
                CREATE TABLE IF NOT EXISTS counters_v121_backup (name TEXT, value INTEGER);
                INSERT INTO counters_v121_backup (name, value)
                    SELECT name, value FROM counters WHERE name IS NOT NULL;
                DROP TABLE counters;
                CREATE TABLE counters (
                    name  TEXT PRIMARY KEY,
                    value INTEGER NOT NULL DEFAULT 0
                );
                INSERT OR IGNORE INTO counters (name, value)
                    SELECT name, value FROM counters_v121_backup WHERE name IS NOT NULL;
                DROP TABLE counters_v121_backup;
            """)
            conn.commit()
            print("[v1.2.1] counters table normalized to (name, value) schema.")
        except Exception as e:
            print(f"[v1.2.1 normalize_counters] warning: {e}")
            try:
                conn.rollback()
            except Exception:
                pass
        finally:
            conn.close()


def _migrate_v13_add_order_source_column():
    """
    v1.3: Add order_source column to kots / bills / held_bills tables.
    Tracks the source of the order: walkin (default) / swiggy / zomato / zepto / blinkit.
    Used to show aggregator badges on KDS cards.
    Also adds aggregator_order_id column for the aggregator's order reference number.
    """
    with _lock:
        conn = get_conn()
        for table in ("kots", "bills", "held_bills"):
            try:
                conn.execute(f"ALTER TABLE {table} ADD COLUMN order_source TEXT DEFAULT 'walkin'")
                conn.commit()
            except Exception:
                pass  # column already exists
            try:
                conn.execute(f"ALTER TABLE {table} ADD COLUMN aggregator_order_id TEXT DEFAULT ''")
                conn.commit()
            except Exception:
                pass
        conn.close()


def _migrate_add_pinelabs_columns():
    """
    Safe upgrade migration: add Pine Labs payment columns to the bills table.
    Uses try/except to silently skip columns that already exist.
    """
    new_cols = [
        ("pl_txn_id",        "TEXT DEFAULT ''"),
        ("pl_approval_code", "TEXT DEFAULT ''"),
        ("pl_card_scheme",   "TEXT DEFAULT ''"),
        ("pl_masked_card",   "TEXT DEFAULT ''"),
        ("pl_invoice_no",    "TEXT DEFAULT ''"),
        ("pl_batch_no",      "TEXT DEFAULT ''"),
        ("pl_voided",        "INTEGER DEFAULT 0"),
    ]
    conn = get_conn()
    for col, defn in new_cols:
        try:
            conn.execute(f"ALTER TABLE bills ADD COLUMN {col} {defn}")
            conn.commit()
        except Exception:
            pass   # Column already exists — safe to ignore
    conn.close()

def _migrate_add_item_type_columns():
    """
    Non-destructive migration to add item_type column to bill_items and kot_items tables.
    """
    conn = get_conn()
    for table, col, defn in [("bill_items", "item_type", "TEXT DEFAULT 'dine-in'"),
                              ("kot_items", "item_type", "TEXT DEFAULT 'dine-in'")]:
        try:
            conn.execute(f"ALTER TABLE {table} ADD COLUMN {col} {defn}")
            conn.commit()
        except Exception:
            pass
    conn.close()


def _migrate_add_discount_delivery_columns():
    """
    Non-destructive migration to add discount_percentage, discount_amount,
    and delivery_charges columns to bills and held_bills tables, and
    item_type column to held_bill_items.
    """
    conn = get_conn()
    for table in ["bills", "held_bills"]:
        for col, defn in [
            ("discount_percentage", "REAL DEFAULT 0.0"),
            ("discount_amount", "REAL DEFAULT 0.0"),
            ("delivery_charges", "REAL DEFAULT 0.0")
        ]:
            try:
                conn.execute(f"ALTER TABLE {table} ADD COLUMN {col} {defn}")
                conn.commit()
            except Exception:
                pass
                
    try:
        conn.execute("ALTER TABLE held_bill_items ADD COLUMN item_type TEXT DEFAULT 'dine-in'")
        conn.commit()
    except Exception:
        pass
        
    conn.close()


def _migrate_add_code_column():
    """
    Non-destructive migration to add 'code' column to menu_items table
    and auto-populate empty codes with unique 4-digit numbers starting from 1001.
    """
    conn = get_conn()
    try:
        conn.execute("ALTER TABLE menu_items ADD COLUMN code TEXT")
        conn.commit()
    except Exception:
        pass
        
    # Check if there are any items without codes and assign them sequentially
    try:
        items = conn.execute("SELECT id FROM menu_items WHERE code IS NULL OR code = '' ORDER BY id").fetchall()
        if items:
            # Find the maximum numeric code currently assigned
            max_code_row = conn.execute("SELECT MAX(CAST(code AS INTEGER)) FROM menu_items WHERE code GLOB '[0-9][0-9][0-9][0-9]'").fetchone()
            start_code = 1001
            if max_code_row and max_code_row[0] is not None:
                start_code = max(start_code, max_code_row[0] + 1)
            
            for row in items:
                code_str = str(start_code).zfill(4)
                conn.execute("UPDATE menu_items SET code = ? WHERE id = ?", (code_str, row["id"]))
                start_code += 1
            conn.commit()
    except Exception:
        pass
    conn.close()


def _migrate_add_terminal_id_columns():
    """
    Non-destructive migration to add terminal_id column to bills, kots, and held_bills tables.
    """
    conn = get_conn()
    for table in ["bills", "kots", "held_bills"]:
        try:
            conn.execute(f"ALTER TABLE {table} ADD COLUMN terminal_id INTEGER DEFAULT 1")
            conn.commit()
        except Exception:
            pass
    conn.close()


def _migrate_add_split_payment_columns():
    """
    Non-destructive migration to add split payment columns to bills and held_bills tables.
    """
    conn = get_conn()
    for table in ["bills", "held_bills"]:
        for col, defn in [
            ("split_cash", "REAL DEFAULT 0.0"),
            ("split_card", "REAL DEFAULT 0.0"),
            ("split_upi", "REAL DEFAULT 0.0"),
            ("split_other", "REAL DEFAULT 0.0")
        ]:
            try:
                conn.execute(f"ALTER TABLE {table} ADD COLUMN {col} {defn}")
                conn.commit()
            except Exception:
                pass
    conn.close()


def _migrate_add_item_notes_columns():
    """
    Non-destructive migration to add notes column to bill_items and held_bill_items tables.
    """
    conn = get_conn()
    for table in ["bill_items", "held_bill_items"]:
        try:
            conn.execute(f"ALTER TABLE {table} ADD COLUMN notes TEXT DEFAULT ''")
            conn.commit()
        except Exception:
            pass
    conn.close()



def _migrate_add_packaging_charge_column():
    """
    Non-destructive migration to add packaging_charge column to bills and held_bills tables.
    """
    conn = get_conn()
    for table in ["bills", "held_bills"]:
        try:
            conn.execute(f"ALTER TABLE {table} ADD COLUMN packaging_charge REAL DEFAULT 0.0")
            conn.commit()
        except Exception:
            pass
    # Add packaging_type column to bill_items and held_bill_items
    for table in ["bill_items", "held_bill_items"]:
        try:
            conn.execute(f"ALTER TABLE {table} ADD COLUMN packaging_type TEXT DEFAULT ''")
            conn.commit()
        except Exception:
            pass
    conn.close()


def _migrate_add_packaging_code_column():
    """
    Non-destructive migration to add 'code' column to packaging_types table.
    Auto-populates empty codes with PKGxxx format.
    """
    conn = get_conn()
    try:
        conn.execute("ALTER TABLE packaging_types ADD COLUMN code TEXT DEFAULT ''")
        conn.commit()
    except Exception:
        pass  # Column already exists
    
    # Auto-assign codes to existing packaging types that don't have one
    try:
        rows = conn.execute("SELECT id FROM packaging_types WHERE code IS NULL OR code = '' ORDER BY id").fetchall()
        for i, row in enumerate(rows):
            code = f"PKG{i+1:03d}"
            # Make sure code is unique
            existing = conn.execute("SELECT id FROM packaging_types WHERE code=?", (code,)).fetchone()
            if not existing:
                conn.execute("UPDATE packaging_types SET code=? WHERE id=?", (code, row["id"]))
        conn.commit()
    except Exception:
        pass
    conn.close()


def _migrate_add_stock_columns():
    """
    Non-destructive migration to add stock_quantity and low_stock_threshold
    columns to menu_items table.
    """
    conn = get_conn()
    for col, defn in [("stock_quantity", "INTEGER DEFAULT -1"),
                      ("low_stock_threshold", "INTEGER DEFAULT 10")]:
        try:
            conn.execute(f"ALTER TABLE menu_items ADD COLUMN {col} {defn}")
            conn.commit()
        except Exception:
            pass  # Column already exists
    conn.close()


def _migrate_update_bill_insert_packaging():
    """
    This is a logical migration marker. The save_bill and save_held_bill
    functions have been updated to include packaging_charge in their
    INSERT statements. No schema change needed since the column already
    exists from _migrate_add_packaging_charge_column().
    """
    pass  # Handled in save_bill() directly


def _migrate_add_packaging_stock_columns():
    """
    Non-destructive migration to add stock_quantity and low_stock_threshold
    columns to packaging_types table for packaging inventory tracking.
    """
    conn = get_conn()
    for col, defn in [("stock_quantity", "INTEGER DEFAULT -1"),
                      ("low_stock_threshold", "INTEGER DEFAULT 10")]:
        try:
            conn.execute(f"ALTER TABLE packaging_types ADD COLUMN {col} {defn}")
            conn.commit()
        except Exception:
            pass  # Column already exists
    conn.close()


def _migrate_add_kot_packaging_type_column():
    """
    Non-destructive migration to add packaging_type column to kot_items table.
    This stores the assigned packaging type name so KDS and KOT reprints
    can show it even when loaded from DB.
    """
    conn = get_conn()
    try:
        conn.execute("ALTER TABLE kot_items ADD COLUMN packaging_type TEXT DEFAULT ''")
        conn.commit()
    except Exception:
        pass  # Column already exists
    conn.close()


# ──────────────────────────────────────────────
# INVENTORY / STOCK MANAGEMENT
# ──────────────────────────────────────────────

def get_inventory(section_id: int = None):
    """
    Get inventory data for all items or items in a specific section.
    Returns list of dicts with stock info joined with item and section names.
    stock_quantity = -1 means stock tracking not initialized yet.
    """
    conn = get_conn()
    if section_id:
        rows = conn.execute("""
            SELECT mi.id, mi.name, mi.code, mi.section_id, ms.name AS section_name,
                   mi.dine_in_price, mi.parcel_price, mi.is_active,
                   COALESCE(mi.stock_quantity, -1) AS stock_quantity,
                   COALESCE(mi.low_stock_threshold, 10) AS low_stock_threshold
            FROM menu_items mi
            JOIN menu_sections ms ON mi.section_id = ms.id
            WHERE mi.section_id=?
            ORDER BY ms.sort_order, mi.sort_order, mi.id
        """, (section_id,)).fetchall()
    else:
        rows = conn.execute("""
            SELECT mi.id, mi.name, mi.code, mi.section_id, ms.name AS section_name,
                   mi.dine_in_price, mi.parcel_price, mi.is_active,
                   COALESCE(mi.stock_quantity, -1) AS stock_quantity,
                   COALESCE(mi.low_stock_threshold, 10) AS low_stock_threshold
            FROM menu_items mi
            JOIN menu_sections ms ON mi.section_id = ms.id
            ORDER BY ms.sort_order, ms.name, mi.sort_order, mi.id
        """).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_low_stock_items(threshold_multiplier: float = 1.0):
    """
    Get all items where stock is at or below the low stock threshold.
    threshold_multiplier: allows checking items at e.g. 1.5x threshold for early warning.
    Returns list of dicts.
    """
    conn = get_conn()
    rows = conn.execute("""
        SELECT mi.id, mi.name, mi.code, ms.name AS section_name,
               COALESCE(mi.stock_quantity, -1) AS stock_quantity,
               COALESCE(mi.low_stock_threshold, 10) AS low_stock_threshold
        FROM menu_items mi
        JOIN menu_sections ms ON mi.section_id = ms.id
        WHERE mi.is_active = 1
          AND mi.stock_quantity IS NOT NULL
          AND mi.stock_quantity >= 0
          AND mi.stock_quantity <= CAST(mi.low_stock_threshold AS REAL) * ?
        ORDER BY mi.stock_quantity ASC, ms.name, mi.name
    """, (threshold_multiplier,)).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def update_stock(item_id: int, new_quantity: int):
    """Set the stock quantity for an item to an absolute value."""
    with _lock:
        conn = get_conn()
        conn.execute("UPDATE menu_items SET stock_quantity=? WHERE id=?",
                     (new_quantity, item_id))
        conn.commit()
        conn.close()


def adjust_stock(item_id: int, delta: int):
    """Add (positive delta) or reduce (negative delta) stock for an item."""
    with _lock:
        conn = get_conn()
        current = conn.execute("SELECT COALESCE(stock_quantity, 0) FROM menu_items WHERE id=?",
                               (item_id,)).fetchone()
        if current:
            new_qty = max(0, current[0] + delta)
            conn.execute("UPDATE menu_items SET stock_quantity=? WHERE id=?",
                         (new_qty, item_id))
            conn.commit()
        conn.close()


def set_low_stock_threshold(item_id: int, threshold: int):
    """Set the low stock alert threshold for an item."""
    with _lock:
        conn = get_conn()
        conn.execute("UPDATE menu_items SET low_stock_threshold=? WHERE id=?",
                     (threshold, item_id))
        conn.commit()
        conn.close()


def init_stock_for_item(item_id: int, quantity: int, threshold: int = 10):
    """Initialize stock tracking for a single item (set quantity + threshold)."""
    with _lock:
        conn = get_conn()
        conn.execute("UPDATE menu_items SET stock_quantity=?, low_stock_threshold=? WHERE id=?",
                     (quantity, threshold, item_id))
        conn.commit()
        conn.close()


def init_stock_for_section(section_id: int, default_quantity: int = 50, default_threshold: int = 10):
    """Initialize stock for all items in a section that haven't been initialized yet."""
    with _lock:
        conn = get_conn()
        conn.execute("""
            UPDATE menu_items SET stock_quantity=?, low_stock_threshold=?
            WHERE section_id=? AND (stock_quantity IS NULL OR stock_quantity = -1)
        """, (default_quantity, default_threshold, section_id))
        conn.commit()
        conn.close()


def get_stock_summary():
    """Get inventory summary stats: total items, tracked items, low stock count, out of stock count."""
    conn = get_conn()
    total = conn.execute("SELECT COUNT(*) FROM menu_items WHERE is_active=1").fetchone()[0]
    tracked = conn.execute("SELECT COUNT(*) FROM menu_items WHERE is_active=1 AND stock_quantity >= 0").fetchone()[0]
    low = conn.execute("""
        SELECT COUNT(*) FROM menu_items
        WHERE is_active=1 AND stock_quantity >= 0 AND stock_quantity <= low_stock_threshold
    """).fetchone()[0]
    out = conn.execute("""
        SELECT COUNT(*) FROM menu_items
        WHERE is_active=1 AND stock_quantity = 0
    """).fetchone()[0]
    untracked = total - tracked
    conn.close()
    return {
        "total_items": total,
        "tracked_items": tracked,
        "low_stock_count": low,
        "out_of_stock_count": out,
        "untracked_count": untracked
    }


def get_item_stock(item_name: str) -> dict:
    """
    Get stock info for a single item by name.
    Returns dict with: id, name, stock_quantity, low_stock_threshold, is_tracked
    stock_quantity = -1 means not tracked (unlimited).
    """
    conn = get_conn()
    row = conn.execute("""
        SELECT id, name, COALESCE(stock_quantity, -1) AS stock_quantity,
               COALESCE(low_stock_threshold, 10) AS low_stock_threshold
        FROM menu_items WHERE name=?
    """, (item_name,)).fetchone()
    conn.close()
    if not row:
        return {"id": None, "name": item_name, "stock_quantity": -1,
                "low_stock_threshold": 10, "is_tracked": False}
    return {
        "id": row["id"],
        "name": row["name"],
        "stock_quantity": row["stock_quantity"],
        "low_stock_threshold": row["low_stock_threshold"],
        "is_tracked": row["stock_quantity"] >= 0
    }


def _create_packaging_tables():
    """
    Create packaging-related tables if they don't exist.
    - packaging_types: defines available packaging types (Box, Pouch, Tray, etc.)
    - section_packaging: maps sections to their default packaging types
    - product_packaging: maps specific products to packaging types (overrides section default)
    """
    with _lock:
        conn = get_conn()
        c = conn.cursor()
        c.executescript("""
            CREATE TABLE IF NOT EXISTS packaging_types (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                name        TEXT UNIQUE NOT NULL,
                code        TEXT DEFAULT '',
                description TEXT DEFAULT '',
                charge      REAL NOT NULL DEFAULT 0.0,
                is_active   INTEGER DEFAULT 1,
                stock_quantity INTEGER DEFAULT -1,
                low_stock_threshold INTEGER DEFAULT 10
            );

            CREATE TABLE IF NOT EXISTS section_packaging (
                id               INTEGER PRIMARY KEY AUTOINCREMENT,
                section_id       INTEGER NOT NULL,
                packaging_type_id INTEGER NOT NULL,
                is_default       INTEGER DEFAULT 0,
                FOREIGN KEY (section_id) REFERENCES menu_sections(id) ON DELETE CASCADE,
                FOREIGN KEY (packaging_type_id) REFERENCES packaging_types(id) ON DELETE CASCADE,
                UNIQUE(section_id, packaging_type_id)
            );

            CREATE TABLE IF NOT EXISTS product_packaging (
                id               INTEGER PRIMARY KEY AUTOINCREMENT,
                item_id          INTEGER NOT NULL,
                packaging_type_id INTEGER NOT NULL,
                charge_override  REAL DEFAULT NULL,
                is_default       INTEGER DEFAULT 0,
                FOREIGN KEY (item_id) REFERENCES menu_items(id) ON DELETE CASCADE,
                FOREIGN KEY (packaging_type_id) REFERENCES packaging_types(id) ON DELETE CASCADE,
                UNIQUE(item_id, packaging_type_id)
            );
        """)
        # Seed some default packaging types if the table is empty
        count = c.execute("SELECT COUNT(*) FROM packaging_types").fetchone()[0]
        if count == 0:
            defaults = [
                ("Box", "PKG001", "Cardboard box for parcels", 10.0),
                ("Pouch", "PKG002", "Plastic pouch / bag", 5.0),
                ("Tray", "PKG003", "Foam / foil tray with lid", 15.0),
                ("Container", "PKG004", "Plastic container with lid", 12.0),
                ("Bag", "PKG005", "Paper carry bag", 8.0),
                ("Cup", "PKG006", "Paper / plastic cup", 6.0),
                ("None", "PKG000", "No packaging (dine-in)", 0.0),
            ]
            for name, code, desc, charge in defaults:
                c.execute("INSERT OR IGNORE INTO packaging_types (name, code, description, charge) VALUES (?,?,?,?)",
                          (name, code, desc, charge))
        conn.commit()
        conn.close()


# ──────────────────────────────────────────────
# PACKAGING TYPES CRUD
# ──────────────────────────────────────────────

def get_packaging_types():
    """Return all packaging types (including inactive) with stock info."""
    conn = get_conn()
    rows = conn.execute(
        "SELECT id, name, code, description, charge, is_active, COALESCE(stock_quantity, -1) AS stock_quantity, COALESCE(low_stock_threshold, 10) AS low_stock_threshold FROM packaging_types ORDER BY id"
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_active_packaging_types():
    """Return only active packaging types with stock info."""
    conn = get_conn()
    rows = conn.execute(
        "SELECT id, name, code, description, charge, COALESCE(stock_quantity, -1) AS stock_quantity, COALESCE(low_stock_threshold, 10) AS low_stock_threshold FROM packaging_types WHERE is_active=1 ORDER BY id"
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_next_packaging_code() -> str:
    """Get the next available packaging code (PKGxxx format)."""
    conn = get_conn()
    row = conn.execute(
        "SELECT MAX(CAST(REPLACE(code, 'PKG', '') AS INTEGER)) FROM packaging_types WHERE code LIKE 'PKG%'"
    ).fetchone()
    conn.close()
    next_num = 1
    if row and row[0] is not None:
        next_num = row[0] + 1
    return f"PKG{next_num:03d}"


def add_packaging_type(name: str, description: str = "", charge: float = 0.0, code: str = "") -> int:
    """Add a new packaging type. Returns its id."""
    if not code:
        code = get_next_packaging_code()
    with _lock:
        conn = get_conn()
        conn.execute("INSERT INTO packaging_types (name, code, description, charge) VALUES (?,?,?,?)",
                     (name.strip(), code.strip(), description.strip(), charge))
        conn.commit()
        pkg_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
        conn.close()
    return pkg_id


def update_packaging_type(pkg_id: int, name: str, description: str = "",
                          charge: float = 0.0, is_active: int = 1, code: str = ""):
    with _lock:
        conn = get_conn()
        conn.execute("UPDATE packaging_types SET name=?, code=?, description=?, charge=?, is_active=? WHERE id=?",
                     (name.strip(), code.strip(), description.strip(), charge, is_active, pkg_id))
        conn.commit()
        conn.close()


def delete_packaging_type(pkg_id: int):
    """Deletes a packaging type and its mappings."""
    with _lock:
        conn = get_conn()
        conn.execute("DELETE FROM section_packaging WHERE packaging_type_id=?", (pkg_id,))
        conn.execute("DELETE FROM product_packaging WHERE packaging_type_id=?", (pkg_id,))
        conn.execute("DELETE FROM packaging_types WHERE id=?", (pkg_id,))
        conn.commit()
        conn.close()


def adjust_packaging_stock(packaging_type_id: int, delta: int):
    """Add (positive) or reduce (negative) packaging stock quantity.
    Only works if stock is already tracked (>= 0). Use set_packaging_stock()
    to initialize stock for a new packaging type."""
    with _lock:
        conn = get_conn()
        current = conn.execute("SELECT COALESCE(stock_quantity, -1) FROM packaging_types WHERE id=?",
                               (packaging_type_id,)).fetchone()
        if current and current[0] >= 0:
            new_qty = max(0, current[0] + delta)
            conn.execute("UPDATE packaging_types SET stock_quantity=? WHERE id=?",
                         (new_qty, packaging_type_id))
            conn.commit()
        conn.close()


def set_packaging_stock(packaging_type_id: int, quantity: int, low_stock_threshold: int = None):
    """v1.3.1: Set the absolute stock quantity for a packaging type.
    Use this to initialize stock for new packaging types (which default to -1 = untracked).
    Pass quantity=-1 to mark as untracked.
    Optionally also set the low_stock_threshold."""
    with _lock:
        conn = get_conn()
        if low_stock_threshold is not None:
            conn.execute("UPDATE packaging_types SET stock_quantity=?, low_stock_threshold=? WHERE id=?",
                         (quantity, low_stock_threshold, packaging_type_id))
        else:
            conn.execute("UPDATE packaging_types SET stock_quantity=? WHERE id=?",
                         (quantity, packaging_type_id))
        conn.commit()
        conn.close()


def get_packaging_stock(packaging_type_id: int) -> dict:
    """Get stock info for a packaging type."""
    conn = get_conn()
    row = conn.execute("""
        SELECT id, name, code, COALESCE(stock_quantity, -1) AS stock_quantity,
               COALESCE(low_stock_threshold, 10) AS low_stock_threshold
        FROM packaging_types WHERE id=?
    """, (packaging_type_id,)).fetchone()
    conn.close()
    if not row:
        return {"id": None, "stock_quantity": -1, "low_stock_threshold": 10, "is_tracked": False}
    return {
        "id": row["id"], "name": row["name"], "code": row["code"],
        "stock_quantity": row["stock_quantity"],
        "low_stock_threshold": row["low_stock_threshold"],
        "is_tracked": row["stock_quantity"] >= 0
    }


def get_packaging_stock_summary():
    """Get packaging inventory summary: total types, tracked, low stock, out of stock."""
    conn = get_conn()
    total = conn.execute("SELECT COUNT(*) FROM packaging_types WHERE is_active=1").fetchone()[0]
    tracked = conn.execute("SELECT COUNT(*) FROM packaging_types WHERE is_active=1 AND stock_quantity >= 0").fetchone()[0]
    low = conn.execute("""
        SELECT COUNT(*) FROM packaging_types
        WHERE is_active=1 AND stock_quantity >= 0 AND stock_quantity <= low_stock_threshold
    """).fetchone()[0]
    out = conn.execute("""
        SELECT COUNT(*) FROM packaging_types
        WHERE is_active=1 AND stock_quantity = 0
    """).fetchone()[0]
    conn.close()
    return {"total_types": total, "tracked_types": tracked,
            "low_stock_count": low, "out_of_stock_count": out}


def deduct_packaging_stock_for_order(items: list) -> list:
    """
    v1.3.1: Deduct packaging stock based on each item's mapped packaging types.
    Called when a bill is finalized with packaging_required=True.

    Each item in `items` should be a dict with at least:
      - 'name' (item name)
      - 'qty' (quantity ordered)

    For each item:
      1. Look up its mapped packaging types via product_packaging table
      2. For each packaging type, deduct qty × item_qty from stock
      3. If stock is untracked (-1), skip deduction

    Returns list of deductions made (for logging):
      [{'item_name': 'Misal Pav', 'qty': 2, 'pkg_name': 'Small Box', 'pkg_deducted': 2}, ...]
    """
    deductions = []
    if not items:
        return deductions
    with _lock:
        conn = get_conn()
        try:
            for it in items:
                name = it.get('name') or it.get('item_name') or ''
                qty = it.get('qty') or it.get('quantity') or 1
                if not name or qty <= 0:
                    continue
                # Look up the item by name
                item_row = conn.execute(
                    "SELECT id FROM menu_items WHERE name=?", (name,)
                ).fetchone()
                if not item_row:
                    continue
                item_id = item_row["id"]
                # Get all packaging types mapped to this item
                pkg_rows = conn.execute("""
                    SELECT pp.packaging_type_id, pt.name AS pkg_name,
                           COALESCE(pt.stock_quantity, -1) AS stock_quantity
                    FROM product_packaging pp
                    JOIN packaging_types pt ON pp.packaging_type_id = pt.id
                    WHERE pp.item_id=? AND pt.is_active=1
                """, (item_id,)).fetchall()
                for pkg in pkg_rows:
                    pkg_id = pkg["packaging_type_id"]
                    pkg_name = pkg["pkg_name"]
                    current_stock = pkg["stock_quantity"]
                    if current_stock < 0:
                        continue  # untracked, skip
                    new_stock = max(0, current_stock - qty)
                    conn.execute(
                        "UPDATE packaging_types SET stock_quantity=? WHERE id=?",
                        (new_stock, pkg_id)
                    )
                    deductions.append({
                        'item_name': name,
                        'qty': qty,
                        'pkg_name': pkg_name,
                        'pkg_deducted': qty,
                        'pkg_remaining': new_stock,
                    })
            conn.commit()
        except Exception as e:
            print(f"[deduct_packaging_stock_for_order] error: {e}")
            try:
                conn.rollback()
            except Exception:
                pass
        finally:
            conn.close()
    return deductions


# ──────────────────────────────────────────────
# SECTION PACKAGING CRUD
# ──────────────────────────────────────────────

def get_section_packaging(section_id: int):
    """Get all packaging types assigned to a section."""
    conn = get_conn()
    rows = conn.execute("""
        SELECT sp.id, sp.section_id, sp.packaging_type_id, sp.is_default,
               pt.name AS pkg_name, pt.code AS pkg_code, pt.charge AS pkg_charge, pt.description AS pkg_desc
        FROM section_packaging sp
        JOIN packaging_types pt ON sp.packaging_type_id = pt.id
        WHERE sp.section_id=?
        ORDER BY sp.is_default DESC, pt.name
    """, (section_id,)).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def add_section_packaging(section_id: int, packaging_type_id: int, is_default: int = 0):
    """Assign a packaging type to a section."""
    with _lock:
        conn = get_conn()
        try:
            conn.execute("INSERT INTO section_packaging (section_id, packaging_type_id, is_default) VALUES (?,?,?)",
                         (section_id, packaging_type_id, is_default))
            conn.commit()
        except Exception:
            pass  # Already exists
        conn.close()


def remove_section_packaging(sp_id: int):
    """Remove a packaging assignment from a section."""
    with _lock:
        conn = get_conn()
        conn.execute("DELETE FROM section_packaging WHERE id=?", (sp_id,))
        conn.commit()
        conn.close()


def set_section_default_packaging(section_id: int, packaging_type_id: int):
    """Set a specific packaging type as the default for a section (unsets others)."""
    with _lock:
        conn = get_conn()
        conn.execute("UPDATE section_packaging SET is_default=0 WHERE section_id=?", (section_id,))
        conn.execute("UPDATE section_packaging SET is_default=1 WHERE section_id=? AND packaging_type_id=?",
                     (section_id, packaging_type_id))
        conn.commit()
        conn.close()


# ──────────────────────────────────────────────
# PRODUCT PACKAGING CRUD
# ──────────────────────────────────────────────

def get_product_packaging(item_id: int):
    """Get all packaging types assigned to a product."""
    conn = get_conn()
    rows = conn.execute("""
        SELECT pp.id, pp.item_id, pp.packaging_type_id, pp.charge_override, pp.is_default,
               pt.name AS pkg_name, pt.code AS pkg_code, pt.charge AS pkg_charge, pt.description AS pkg_desc
        FROM product_packaging pp
        JOIN packaging_types pt ON pp.packaging_type_id = pt.id
        WHERE pp.item_id=?
        ORDER BY pp.is_default DESC, pt.name
    """, (item_id,)).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def add_product_packaging(item_id: int, packaging_type_id: int,
                          charge_override: float = None, is_default: int = 0):
    """Assign a packaging type to a product with optional charge override."""
    with _lock:
        conn = get_conn()
        try:
            conn.execute("INSERT INTO product_packaging (item_id, packaging_type_id, charge_override, is_default) VALUES (?,?,?,?)",
                         (item_id, packaging_type_id, charge_override, is_default))
            conn.commit()
        except Exception:
            pass  # Already exists
        conn.close()


def remove_product_packaging(pp_id: int):
    """Remove a packaging assignment from a product."""
    with _lock:
        conn = get_conn()
        conn.execute("DELETE FROM product_packaging WHERE id=?", (pp_id,))
        conn.commit()
        conn.close()


def set_product_default_packaging(item_id: int, packaging_type_id: int):
    """Set a specific packaging type as the default for a product (unsets others)."""
    with _lock:
        conn = get_conn()
        conn.execute("UPDATE product_packaging SET is_default=0 WHERE item_id=?", (item_id,))
        conn.execute("UPDATE product_packaging SET is_default=1 WHERE item_id=? AND packaging_type_id=?",
                     (item_id, packaging_type_id))
        conn.commit()
        conn.close()


# ──────────────────────────────────────────────
# PACKAGING LOOKUP (for billing)
# ──────────────────────────────────────────────

def get_packaging_for_item(item_name: str, order_type: str = "parcel") -> dict:
    """
    Resolve packaging for an item.
    TEMPORARY: Returns flat ₹5 per parcel item.
    Dine-in returns ₹0.

    Returns dict with: packaging_type_name, packaging_type_code, packaging_charge,
                       packaging_type_id, item_id, section_id
    """
    FLAT_PKG_CHARGE = 5.0
    
    if order_type == "dine-in":
        return {"packaging_type_name": "None", "packaging_type_code": "",
                "packaging_charge": 0.0, "packaging_type_id": None,
                "item_id": None, "section_id": None}

    # For parcel orders, return flat ₹5 packaging charge
    # Also look up the assigned packaging type name, code & id for reference
    conn = get_conn()
    pkg_type_name = "Standard"
    pkg_type_code = ""
    pkg_type_id = None
    item_id = None
    section_id = None
    
    item_row = conn.execute("SELECT id, section_id FROM menu_items WHERE name=?", (item_name,)).fetchone()
    if item_row:
        item_id = item_row["id"]
        section_id = item_row["section_id"]
        
        # Try product-specific default
        prod_pkg = conn.execute("""
            SELECT pt.name, pt.code, pt.id AS pkg_id
            FROM product_packaging pp
            JOIN packaging_types pt ON pp.packaging_type_id = pt.id
            WHERE pp.item_id=? AND pp.is_default=1
            LIMIT 1
        """, (item_id,)).fetchone()
        if prod_pkg:
            pkg_type_name = prod_pkg["name"]
            pkg_type_code = prod_pkg["code"] or ""
            pkg_type_id = prod_pkg["pkg_id"]
        else:
            # Try section default
            sec_pkg = conn.execute("""
                SELECT pt.name, pt.code, pt.id AS pkg_id
                FROM section_packaging sp
                JOIN packaging_types pt ON sp.packaging_type_id = pt.id
                WHERE sp.section_id=? AND sp.is_default=1
                LIMIT 1
            """, (section_id,)).fetchone()
            if sec_pkg:
                pkg_type_name = sec_pkg["name"]
                pkg_type_code = sec_pkg["code"] or ""
                pkg_type_id = sec_pkg["pkg_id"]
    
    conn.close()
    return {"packaging_type_name": pkg_type_name, "packaging_type_code": pkg_type_code,
            "packaging_charge": FLAT_PKG_CHARGE, "packaging_type_id": pkg_type_id,
            "item_id": item_id, "section_id": section_id}


def get_packaging_stock_for_item(item_name: str) -> dict:
    """
    Get packaging stock info for an item's assigned packaging type.
    Returns dict with: packaging_type_id, packaging_type_name, stock_quantity,
                       low_stock_threshold, is_tracked, is_available
    For dine-in items, returns empty (no packaging needed).
    """
    pkg_info = get_packaging_for_item(item_name, 'parcel')
    pkg_type_id = pkg_info.get('packaging_type_id')
    if not pkg_type_id:
        return {"packaging_type_id": None, "packaging_type_name": pkg_info.get('packaging_type_name', 'Standard'),
                "stock_quantity": -1, "low_stock_threshold": 10,
                "is_tracked": False, "is_available": True}
    
    pkg_stock = get_packaging_stock(pkg_type_id)
    available = pkg_stock.get("stock_quantity", -1)
    return {
        "packaging_type_id": pkg_type_id,
        "packaging_type_name": pkg_info.get('packaging_type_name', 'Standard'),
        "stock_quantity": available,
        "low_stock_threshold": pkg_stock.get("low_stock_threshold", 10),
        "is_tracked": pkg_stock.get("is_tracked", False),
        "is_available": (not pkg_stock.get("is_tracked", False)) or (available > 0)
    }


def _next(name):
    """Atomic counter increment. Returns new value."""
    conn = get_conn()
    with _lock:
        conn.execute("UPDATE counters SET value = value + 1 WHERE name = ?", (name,))
        conn.commit()
        val = conn.execute("SELECT value FROM counters WHERE name = ?", (name,)).fetchone()[0]
        conn.close()
    return val

def today():
    return datetime.date.today().strftime("%d/%m/%Y")

def now_time():
    return datetime.datetime.now().strftime("%H:%M")

def _generate_unique_bill_no(conn, bill_date: str) -> int:
    from config import CFG
    term_id = int(CFG.get("terminal_id", 1))
    term_id = max(1, min(99, term_id))
    
    try:
        parsed_dt = datetime.datetime.strptime(bill_date, "%d/%m/%Y")
        yymmdd = parsed_dt.strftime("%y%m%d")
    except Exception:
        yymmdd = datetime.date.today().strftime("%y%m%d")
    
    # Base prefix: YYMMDDTT0000 (e.g. 260529010000)
    prefix_val = int(f"{yymmdd}{term_id:02d}0000")
    max_val = int(f"{yymmdd}{term_id:02d}9999")
    
    # Query maximum bill number for this terminal and date
    row = conn.execute("SELECT MAX(bill_no) FROM bills WHERE bill_no >= ? AND bill_no <= ?", (prefix_val, max_val)).fetchone()
    if row and row[0] is not None:
        new_bill_no = row[0] + 1
    else:
        new_bill_no = prefix_val + 1
    return new_bill_no

# ──────────────────────────────────────────────
# BILLS
# ──────────────────────────────────────────────

def save_bill(meta: dict, items: list) -> dict:
    """
    meta keys: order_type, table_no, customer_name, subtotal, cgst, sgst, total,
               payment_mode, notes
    items: list of {name, section, price, qty}
    Returns enriched bill dict with bill_no and id.
    """
    date    = meta.get('date', today())
    time_   = meta.get('time', now_time())

    with _lock:
        conn = get_conn()
        bill_no = _generate_unique_bill_no(conn, date)
        from config import CFG
        term_id = meta.get('terminal_id')
        if term_id is None:
            term_id = int(CFG.get("terminal_id", 1))

        c = conn.cursor()
        c.execute("""
            INSERT INTO bills (bill_no, date, time, table_no, customer_name, order_type,
                               subtotal, cgst, sgst, total, payment_mode, notes,
                               pl_txn_id, pl_approval_code, pl_card_scheme,
                               pl_masked_card, pl_invoice_no, pl_batch_no,
                               discount_percentage, discount_amount, delivery_charges, terminal_id,
                               split_cash, split_card, split_upi, split_other,
                               packaging_charge)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """, (bill_no, date, time_,
              meta.get('table_no',''), meta.get('customer_name',''),
              meta.get('order_type','dine-in'),
              meta['subtotal'], meta['cgst'], meta['sgst'], meta['total'],
              meta.get('payment_mode','cash'), meta.get('notes',''),
              meta.get('pl_txn_id',''), meta.get('pl_approval_code',''),
              meta.get('pl_card_scheme',''), meta.get('pl_masked_card',''),
              meta.get('pl_invoice_no',''), meta.get('pl_batch_no',''),
              meta.get('discount_percentage', 0.0),
              meta.get('discount_amount', 0.0),
              meta.get('delivery_charges', 0.0),
              term_id,
              meta.get('split_cash', 0.0),
              meta.get('split_card', 0.0),
              meta.get('split_upi', 0.0),
              meta.get('split_other', 0.0),
              meta.get('packaging_charge', 0.0)))
        bill_id = c.lastrowid

        for it in items:
            c.execute("""
                INSERT INTO bill_items (bill_id, item_name, section, unit_price, quantity, amount, item_type, notes, packaging_type)
                VALUES (?,?,?,?,?,?,?,?,?)
            """, (bill_id, it['name'], it.get('section',''),
                  it['price'], it['qty'], it['price'] * it['qty'], it.get('type','dine-in'), it.get('notes',''), it.get('packaging_type','')))
        conn.commit()
        conn.close()

    return {**meta, 'bill_no': bill_no, 'bill_id': bill_id,
            'date': date, 'time': time_, 'items': items, 'terminal_id': term_id}

def get_bills(date=None, limit=200):
    conn = get_conn()
    if date:
        rows = conn.execute("SELECT * FROM bills WHERE date=? ORDER BY bill_no DESC", (date,)).fetchall()
    else:
        rows = conn.execute("SELECT * FROM bills ORDER BY bill_no DESC LIMIT ?", (limit,)).fetchall()
    result = []
    for row in rows:
        b = dict(row)
        b['items'] = [dict(r) for r in conn.execute(
            "SELECT * FROM bill_items WHERE bill_id=?", (b['id'],))]
        result.append(b)
    conn.close()
    return result

def get_bill(bill_no):
    conn = get_conn()
    row = conn.execute("SELECT * FROM bills WHERE bill_no=?", (bill_no,)).fetchone()
    if not row:
        conn.close()
        return None
    b = dict(row)
    b['items'] = [dict(r) for r in conn.execute(
        "SELECT * FROM bill_items WHERE bill_id=?", (b['id'],))]
    conn.close()
    return b

def mark_bill_voided(bill_no: int):
    """Flag a bill as voided after a successful Pine Labs void transaction."""
    with _lock:
        conn = get_conn()
        conn.execute("UPDATE bills SET pl_voided=1 WHERE bill_no=?", (bill_no,))
        conn.commit()
        conn.close()

# ──────────────────────────────────────────────
# KOTs
# ──────────────────────────────────────────────

def save_kot(meta: dict, items: list) -> dict:
    """
    meta keys: order_type, table_no, customer_name, notes
    items: list of {name, qty, notes}
    Returns enriched KOT dict.
    """
    kot_no = _next('kot')
    date   = meta.get('date', today())
    time_  = meta.get('time', now_time())

    from config import CFG
    term_id = meta.get('terminal_id')
    if term_id is None:
        term_id = int(CFG.get("terminal_id", 1))

    with _lock:
        conn = get_conn()
        c = conn.cursor()
        c.execute("""
            INSERT INTO kots (kot_no, date, time, table_no, customer_name,
                              order_type, status, notes, terminal_id)
            VALUES (?,?,?,?,?,?,?,?,?)
        """, (kot_no, date, time_,
              meta.get('table_no',''), meta.get('customer_name',''),
              meta.get('order_type','dine-in'), 'pending',
              meta.get('notes',''), term_id))
        kot_id = c.lastrowid
        for it in items:
            c.execute("""
                INSERT INTO kot_items (kot_id, item_name, quantity, notes, item_type, packaging_type)
                VALUES (?,?,?,?,?,?)
            """, (kot_id, it['name'], it['qty'], it.get('notes',''), it.get('type','dine-in'), it.get('packaging_type','')))
        conn.commit()
        conn.close()

    return {**meta, 'kot_no': kot_no, 'kot_id': kot_id,
            'date': date, 'time': time_, 'items': items, 'status': 'pending', 'terminal_id': term_id}

def save_kot_sync(kot: dict):
    """
    Saves a KOT received from another terminal/KDS directly with its given kot_no,
    to keep databases in sync.
    """
    kot_no = kot['kot_no']
    date = kot.get('date', today())
    time_ = kot.get('time', now_time())
    term_id = kot.get('terminal_id', 1)
    status = kot.get('status', 'pending')
    table_no = kot.get('table_no', '')
    customer_name = kot.get('customer_name', '')
    order_type = kot.get('order_type', 'dine-in')
    notes = kot.get('notes', '')
    
    with _lock:
        conn = get_conn()
        c = conn.cursor()
        # Check if already exists to avoid duplicate entries
        existing = c.execute("SELECT id FROM kots WHERE kot_no=?", (kot_no,)).fetchone()
        if existing:
            # Update
            c.execute("""
                UPDATE kots 
                SET date=?, time=?, table_no=?, customer_name=?, order_type=?, status=?, notes=?, terminal_id=?
                WHERE kot_no=?
            """, (date, time_, table_no, customer_name, order_type, status, notes, term_id, kot_no))
            kot_id = existing[0]
            # Delete existing items to recreate them
            c.execute("DELETE FROM kot_items WHERE kot_id=?", (kot_id,))
        else:
            # Insert new
            c.execute("""
                INSERT INTO kots (kot_no, date, time, table_no, customer_name, order_type, status, notes, terminal_id)
                VALUES (?,?,?,?,?,?,?,?,?)
            """, (kot_no, date, time_, table_no, customer_name, order_type, status, notes, term_id))
            kot_id = c.lastrowid
            
        for it in kot.get('items', []):
            name = it.get('item_name') or it.get('name', '')
            qty = it.get('quantity') or it.get('qty', 1)
            notes_item = it.get('notes', '')
            itype = it.get('item_type') or it.get('type', 'dine-in')
            pkg_type = it.get('packaging_type', '')
            c.execute("""
                INSERT INTO kot_items (kot_id, item_name, quantity, notes, item_type, packaging_type)
                VALUES (?,?,?,?,?,?)
            """, (kot_id, name, qty, notes_item, itype, pkg_type))
        conn.commit()
        conn.close()

def get_kots(date=None, status=None, limit=200):
    conn = get_conn()
    q, params = "SELECT * FROM kots WHERE 1=1", []
    if date:   q += " AND date=?";   params.append(date)
    if status: q += " AND status=?"; params.append(status)
    q += " ORDER BY kot_no DESC LIMIT ?"
    params.append(limit)
    rows = conn.execute(q, params).fetchall()
    result = []
    for row in rows:
        k = dict(row)
        k['items'] = [dict(r) for r in conn.execute(
            "SELECT * FROM kot_items WHERE kot_id=?", (k['id'],))]
        result.append(k)
    conn.close()
    return result

def update_kot_status(kot_no, status):
    ts = datetime.datetime.now().isoformat()
    with _lock:
        conn = get_conn()
        conn.execute("UPDATE kots SET status=?, updated_at=? WHERE kot_no=?",
                     (status, ts, kot_no))
        conn.commit()
        conn.close()

def get_kot_by_no(kot_no: int):
    """Fetch a single KOT by its number. No LIMIT. Used for reprint."""
    conn = get_conn()
    row = conn.execute("SELECT * FROM kots WHERE kot_no=?", (kot_no,)).fetchone()
    if not row:
        conn.close()
        return None
    k = dict(row)
    k['items'] = [dict(r) for r in conn.execute(
        "SELECT * FROM kot_items WHERE kot_id=?", (k['id'],))]
    conn.close()
    return k

def get_active_kots():
    """KOTs that are pending or preparing — shown on KDS."""
    return get_kots(status=None) # We filter in caller for pending/preparing

# ──────────────────────────────────────────────
# REPORTS
# ──────────────────────────────────────────────

def daily_report(date):
    conn = get_conn()
    bills = conn.execute("SELECT * FROM bills WHERE date=? AND (pl_voided IS NULL OR pl_voided = 0)", (date,)).fetchall()
    voided_count = conn.execute("SELECT COUNT(*) FROM bills WHERE date=? AND pl_voided = 1", (date,)).fetchone()[0]
    kc    = conn.execute("SELECT COUNT(*) FROM kots WHERE date=?", (date,)).fetchone()[0]
    conn.close()
    subtotal = sum(b['subtotal'] for b in bills)
    gst      = sum(b['cgst'] + b['sgst'] for b in bills)
    total    = sum(b['total'] for b in bills)
    
    cash = 0.0
    card = 0.0
    for b in bills:
        # Check if the split columns exist in the Row and are non-zero.
        # We index using row dictionary format.
        s_cash = b['split_cash'] if b['split_cash'] is not None else 0.0
        s_card = b['split_card'] if b['split_card'] is not None else 0.0
        s_upi = b['split_upi'] if b['split_upi'] is not None else 0.0
        s_other = b['split_other'] if b['split_other'] is not None else 0.0
        
        if s_cash > 0.0 or s_card > 0.0 or s_upi > 0.0 or s_other > 0.0:
            cash += s_cash
            card += s_card + s_upi + s_other
        else:
            if b['payment_mode'] == 'cash':
                cash += b['total']
            else:
                card += b['total']
                
    return {
        'date': date, 'bills': len(bills), 'voided': voided_count, 'kots': kc,
        'subtotal': round(subtotal, 2), 'gst': round(gst, 2),
        'total': round(total, 2), 'cash': round(cash, 2), 'card': round(card, 2),
    }



def get_item_sales_report(date):
    conn = get_conn()
    rows = conn.execute("""
        SELECT bi.item_name, SUM(bi.quantity) as quantity, SUM(bi.amount) as amount
        FROM bill_items bi
        JOIN bills b ON bi.bill_id = b.id
        WHERE b.date=? AND (b.pl_voided IS NULL OR b.pl_voided = 0)
        GROUP BY bi.item_name
        ORDER BY quantity DESC
    """, (date,)).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def date_list():
    conn = get_conn()
    rows = conn.execute("SELECT DISTINCT date FROM bills ORDER BY date DESC LIMIT 90").fetchall()
    conn.close()
    return [r[0] for r in rows]


# ──────────────────────────────────────────────
# MENU MANAGEMENT  (sections + items in DB)
# ──────────────────────────────────────────────

def _seed_menu_if_empty():
    """Populate DB menu tables from menu_data.py defaults on first run.
    v1.2: menu_data.py has single-price tuples (name, price)."""
    conn = get_conn()
    count = conn.execute("SELECT COUNT(*) FROM menu_sections").fetchone()[0]
    conn.close()
    if count > 0:
        return  # Already seeded
    from menu_data import MENU as DEFAULT_MENU
    with _lock:
        conn = get_conn()
        c = conn.cursor()
        for sort_idx, (sec_name, items) in enumerate(DEFAULT_MENU):
            c.execute("INSERT OR IGNORE INTO menu_sections (name, sort_order) VALUES (?,?)",
                      (sec_name, sort_idx))
            sec_id = c.execute("SELECT id FROM menu_sections WHERE name=?", (sec_name,)).fetchone()[0]
            for item_idx, item_tuple in enumerate(items):
                # v1.2: tuple is (name, price)
                if len(item_tuple) == 2:
                    item_name, price = item_tuple
                    dine = parcel = price  # legacy columns mirror price for old reports
                else:  # v1.1 fallback (name, dine, parcel)
                    item_name, dine, parcel = item_tuple
                    price = (dine + parcel) // 2
                c.execute("""INSERT OR IGNORE INTO menu_items
                             (section_id, name, dine_in_price, parcel_price, price, sort_order)
                             VALUES (?,?,?,?,?,?)""",
                          (sec_id, item_name, dine, parcel, price, item_idx))
        conn.commit()
        conn.close()


def get_menu_db():
    """
    v1.2: Returns list of (section_name, [(name, price, code), ...])
    Only active sections and items, ordered by sort_order.
    """
    conn = get_conn()
    sections = conn.execute(
        "SELECT id, name FROM menu_sections WHERE is_active=1 ORDER BY sort_order, id"
    ).fetchall()
    result = []
    for sec in sections:
        items = conn.execute(
            """SELECT name, price, dine_in_price, parcel_price, code
               FROM menu_items
               WHERE section_id=? AND is_active=1
               ORDER BY sort_order, id""",
            (sec["id"],)
        ).fetchall()
        out = []
        for r in items:
            price = r["price"] if r["price"] and r["price"] > 0 else (r["dine_in_price"] or r["parcel_price"] or 0)
            out.append((r["name"], price, r["code"] or ""))
        result.append((sec["name"], out))
    conn.close()
    return result


def get_sections_db():
    """All sections (incl. inactive), for management UI."""
    conn = get_conn()
    rows = conn.execute(
        "SELECT id, name, sort_order, is_active FROM menu_sections ORDER BY sort_order, id"
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_items_for_section(section_id: int):
    """All items (incl. inactive) for a section, including stock info.
    v1.2: also returns `price` column (single price)."""
    conn = get_conn()
    rows = conn.execute(
        """SELECT id, name, code, dine_in_price, parcel_price, price, is_active, sort_order,
                  COALESCE(stock_quantity, -1) AS stock_quantity,
                  COALESCE(low_stock_threshold, 10) AS low_stock_threshold
           FROM menu_items WHERE section_id=? ORDER BY sort_order, id""",
        (section_id,)
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


# ─── Sections ───

def add_section(name: str) -> int:
    """Add a new section. Returns its id."""
    with _lock:
        conn = get_conn()
        max_order = conn.execute("SELECT COALESCE(MAX(sort_order),0) FROM menu_sections").fetchone()[0]
        conn.execute("INSERT INTO menu_sections (name, sort_order) VALUES (?,?)",
                     (name.strip(), max_order + 1))
        conn.commit()
        sec_id = conn.execute("SELECT id FROM menu_sections WHERE name=?", (name.strip(),)).fetchone()[0]
        conn.close()
    return sec_id


def update_section(section_id: int, name: str, is_active: int = 1):
    with _lock:
        conn = get_conn()
        conn.execute("UPDATE menu_sections SET name=?, is_active=? WHERE id=?",
                     (name.strip(), is_active, section_id))
        conn.commit()
        conn.close()


def delete_section(section_id: int):
    """Deletes section and all its items (cascade)."""
    with _lock:
        conn = get_conn()
        conn.execute("DELETE FROM menu_items WHERE section_id=?", (section_id,))
        conn.execute("DELETE FROM menu_sections WHERE id=?", (section_id,))
        conn.commit()
        conn.close()


def reorder_section(section_id: int, direction: str):
    """Move section up or down in sort order."""
    conn = get_conn()
    rows = conn.execute("SELECT id, sort_order FROM menu_sections ORDER BY sort_order, id").fetchall()
    ids = [r["id"] for r in rows]
    conn.close()
    idx = ids.index(section_id) if section_id in ids else -1
    if idx < 0:
        return
    swap_idx = idx - 1 if direction == "up" else idx + 1
    if 0 <= swap_idx < len(ids):
        with _lock:
            conn = get_conn()
            conn.execute("UPDATE menu_sections SET sort_order=? WHERE id=?", (swap_idx, ids[idx]))
            conn.execute("UPDATE menu_sections SET sort_order=? WHERE id=?", (idx, ids[swap_idx]))
            conn.commit()
            conn.close()


# ─── Items ───

def check_duplicate_code(code: str, exclude_id: int = None) -> bool:
    conn = get_conn()
    if exclude_id:
        row = conn.execute("SELECT COUNT(*) FROM menu_items WHERE code = ? AND id != ?", (code, exclude_id)).fetchone()
    else:
        row = conn.execute("SELECT COUNT(*) FROM menu_items WHERE code = ?", (code,)).fetchone()
    conn.close()
    return row[0] > 0

def get_next_item_code() -> str:
    conn = get_conn()
    code = _get_next_item_code_internal(conn)
    conn.close()
    return code

def _get_next_item_code_internal(conn) -> str:
    max_code_row = conn.execute("SELECT MAX(CAST(code AS INTEGER)) FROM menu_items WHERE code GLOB '[0-9][0-9][0-9][0-9]'").fetchone()
    start_code = 1001
    if max_code_row and max_code_row[0] is not None:
        start_code = max(start_code, max_code_row[0] + 1)
    return str(start_code).zfill(4)

def add_item(section_id: int, name: str, dine_in: int = None, parcel: int = None, code: str = None, price: int = None) -> int:
    """Add an item to a section. v1.2: single price (pass `price=`).
    For backward compat, can still pass dine_in/parcel — middle is stored in `price`.
    Returns its id."""
    with _lock:
        conn = get_conn()
        max_order = conn.execute(
            "SELECT COALESCE(MAX(sort_order),0) FROM menu_items WHERE section_id=?",
            (section_id,)).fetchone()[0]
        if not code:
            code = _get_next_item_code_internal(conn)
        # Resolve single price
        if price is None:
            if dine_in is not None and parcel is not None:
                price = (dine_in + parcel) // 2
            elif dine_in is not None:
                price = dine_in
            elif parcel is not None:
                price = parcel
            else:
                price = 0
        dine_in = dine_in if dine_in is not None else price
        parcel = parcel if parcel is not None else price
        conn.execute(
            """INSERT INTO menu_items (section_id, name, code, dine_in_price, parcel_price, price, sort_order)
               VALUES (?,?,?,?,?,?,?)""",
            (section_id, name.strip(), code, dine_in, parcel, price, max_order + 1))
        conn.commit()
        item_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
        conn.close()
    return item_id


def update_item(item_id: int, name: str, dine_in: int = None, parcel: int = None, code: str = None, is_active: int = 1, price: int = None):
    """Update an item. v1.2: pass `price=` for single-price update."""
    with _lock:
        conn = get_conn()
        # Resolve single price
        if price is None:
            if dine_in is not None and parcel is not None:
                price = (dine_in + parcel) // 2
            elif dine_in is not None:
                price = dine_in
            elif parcel is not None:
                price = parcel
            else:
                # Fetch existing
                existing = conn.execute("SELECT price FROM menu_items WHERE id=?", (item_id,)).fetchone()
                price = existing["price"] if existing else 0
        dine_in = dine_in if dine_in is not None else price
        parcel = parcel if parcel is not None else price
        if code:
            conn.execute(
                "UPDATE menu_items SET name=?, dine_in_price=?, parcel_price=?, price=?, is_active=?, code=? WHERE id=?",
                (name.strip(), dine_in, parcel, price, is_active, code, item_id))
        else:
            conn.execute(
                "UPDATE menu_items SET name=?, dine_in_price=?, parcel_price=?, price=?, is_active=? WHERE id=?",
                (name.strip(), dine_in, parcel, price, is_active, item_id))
        conn.commit()
        conn.close()


def update_item_price(item_id: int, new_price: int):
    """v1.2: Quick price-only update (used by hub menu sync). Also mirrors to legacy columns."""
    with _lock:
        conn = get_conn()
        conn.execute(
            "UPDATE menu_items SET price=?, dine_in_price=?, parcel_price=? WHERE id=?",
            (new_price, new_price, new_price, item_id))
        conn.commit()
        conn.close()


def toggle_item_active(item_id: int, is_active: int):
    """v1.2: Toggle item active state (used by hub menu sync)."""
    with _lock:
        conn = get_conn()
        conn.execute("UPDATE menu_items SET is_active=? WHERE id=?", (is_active, item_id))
        conn.commit()
        conn.close()


def delete_item(item_id: int):
    with _lock:
        conn = get_conn()
        conn.execute("DELETE FROM menu_items WHERE id=?", (item_id,))
        conn.commit()
        conn.close()


def reorder_item(item_id: int, direction: str):
    """Move item up or down within its section."""
    conn = get_conn()
    sec = conn.execute("SELECT section_id FROM menu_items WHERE id=?", (item_id,)).fetchone()
    if not sec:
        conn.close()
        return
    rows = conn.execute(
        "SELECT id FROM menu_items WHERE section_id=? ORDER BY sort_order, id",
        (sec["section_id"],)).fetchall()
    ids = [r["id"] for r in rows]
    conn.close()
    idx = ids.index(item_id) if item_id in ids else -1
    if idx < 0:
        return
    swap_idx = idx - 1 if direction == "up" else idx + 1
    if 0 <= swap_idx < len(ids):
        with _lock:
            conn = get_conn()
            conn.execute("UPDATE menu_items SET sort_order=? WHERE id=?", (swap_idx, ids[idx]))
            conn.execute("UPDATE menu_items SET sort_order=? WHERE id=?", (idx, ids[swap_idx]))
            conn.commit()
            conn.close()


# ──────────────────────────────────────────────
# HELD BILLS
# ──────────────────────────────────────────────

def save_held_bill(meta: dict, items: list) -> int:
    """
    Saves a bill on hold.
    meta: order_type, table_no, customer_name, subtotal, cgst, sgst, total, payment_mode, notes
    items: list of {name, section, price, qty}
    Returns held_bill_id.
    """
    date = meta.get('date', today())
    time_ = meta.get('time', now_time())
    from config import CFG
    term_id = meta.get('terminal_id')
    if term_id is None:
        term_id = int(CFG.get("terminal_id", 1))

    with _lock:
        conn = get_conn()
        c = conn.cursor()
        c.execute("""
            INSERT INTO held_bills (date, time, table_no, customer_name, order_type,
                                    subtotal, cgst, sgst, total, payment_mode, notes,
                                    discount_percentage, discount_amount, delivery_charges, terminal_id,
                                    split_cash, split_card, split_upi, split_other,
                                    packaging_charge)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """, (date, time_,
              meta.get('table_no',''), meta.get('customer_name',''),
              meta.get('order_type','dine-in'),
              meta['subtotal'], meta['cgst'], meta['sgst'], meta['total'],
              meta.get('payment_mode','cash'), meta.get('notes',''),
              meta.get('discount_percentage', 0.0),
              meta.get('discount_amount', 0.0),
              meta.get('delivery_charges', 0.0),
              term_id,
              meta.get('split_cash', 0.0),
              meta.get('split_card', 0.0),
              meta.get('split_upi', 0.0),
              meta.get('split_other', 0.0),
              meta.get('packaging_charge', 0.0)))
        held_id = c.lastrowid

        for it in items:
            c.execute("""
                INSERT INTO held_bill_items (held_bill_id, item_name, section, unit_price, quantity, amount, item_type, notes, packaging_type)
                VALUES (?,?,?,?,?,?,?,?,?)
            """, (held_id, it['name'], it.get('section',''),
                  it['price'], it['qty'], it['price'] * it['qty'], it.get('type','dine-in'), it.get('notes',''), it.get('packaging_type','')))
        conn.commit()
        conn.close()
    return held_id

def get_held_bills():
    conn = get_conn()
    rows = conn.execute("SELECT * FROM held_bills ORDER BY id DESC").fetchall()
    result = []
    for row in rows:
        b = dict(row)
        b['items'] = [dict(r) for r in conn.execute(
            "SELECT * FROM held_bill_items WHERE held_bill_id=?", (b['id'],))]
        result.append(b)
    conn.close()
    return result

def get_held_bill(held_id):
    conn = get_conn()
    row = conn.execute("SELECT * FROM held_bills WHERE id=?", (held_id,)).fetchone()
    if not row:
        conn.close()
        return None
    b = dict(row)
    b['items'] = [dict(r) for r in conn.execute(
        "SELECT * FROM held_bill_items WHERE held_bill_id=?", (b['id'],))]
    conn.close()
    return b

def delete_held_bill(held_id):
    with _lock:
        conn = get_conn()
        conn.execute("DELETE FROM held_bills WHERE id=?", (held_id,))
        conn.commit()
        conn.close()


# ──────────────────────────────────────────────
# MENU IMPORT (CSV / EXCEL)
# ──────────────────────────────────────────────

def import_menu_from_csv(file_path: str) -> tuple[int, int]:
    """
    Imports sections and items from a CSV file.
    CSV columns: Section, Item Name, Dine-in Price, Parcel Price, [Code]
    Returns (sections_added, items_added).
    """
    import csv
    sections_added = 0
    items_added = 0
    
    # Keep track of existing sections to avoid duplicates
    existing_sections = {s['name'].lower(): s['id'] for s in get_sections_db()}
    
    with open(file_path, newline='', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        headers = {h.lower().strip().replace('_', ' '): h for h in reader.fieldnames or []}
        
        sec_col = headers.get('section')
        name_col = headers.get('item name') or headers.get('name')
        dine_col = headers.get('dine-in price') or headers.get('dine in price') or headers.get('dine_in')
        parcel_col = headers.get('parcel price') or headers.get('parcel')
        code_col = headers.get('code') or headers.get('item code') or headers.get('item_code')
        
        if not (sec_col and name_col and dine_col and parcel_col):
            raise ValueError("CSV must contain columns: Section, Item Name, Dine-in Price, Parcel Price")
        
        for row in reader:
            sec_name = row[sec_col].strip()
            item_name = row[name_col].strip()
            item_code = row[code_col].strip() if (code_col and row.get(code_col)) else None
            try:
                dine_price = int(float(row[dine_col].strip()))
                parcel_price = int(float(row[parcel_col].strip()))
            except ValueError:
                continue # Skip invalid rows
                
            if not sec_name or not item_name:
                continue
                
            sec_key = sec_name.lower()
            if sec_key in existing_sections:
                sec_id = existing_sections[sec_key]
            else:
                sec_id = add_section(sec_name)
                existing_sections[sec_key] = sec_id
                sections_added += 1
                
            # Check if item exists in section
            existing_items = {it['name'].lower(): it['id'] for it in get_items_for_section(sec_id)}
            if item_name.lower() in existing_items:
                item_id = existing_items[item_name.lower()]
                update_item(item_id, item_name, dine_price, parcel_price, item_code)
            else:
                add_item(sec_id, item_name, dine_price, parcel_price, item_code)
                items_added += 1
                
    return sections_added, items_added


def import_menu_from_excel(file_path: str) -> tuple[int, int]:
    """
    Imports sections and items from an Excel file (.xlsx).
    Returns (sections_added, items_added).
    """
    try:
        import openpyxl
    except ImportError:
        raise ImportError("To import Excel files directly, please install openpyxl first via: pip install openpyxl\nAlternatively, save your Excel file as CSV and import it.")
        
    wb = openpyxl.load_workbook(file_path, read_only=True)
    sheet = wb.active
    
    rows = list(sheet.iter_rows(values_only=True))
    wb.close()
    if not rows:
        raise ValueError("Excel file is empty")
        
    headers = [str(cell).lower().strip().replace('_', ' ') for cell in rows[0]]
    
    try:
        sec_idx = headers.index('section')
        name_idx = headers.index('item name') if 'item name' in headers else headers.index('name')
        dine_idx = headers.index('dine-in price') if 'dine-in price' in headers else (
                   headers.index('dine in price') if 'dine in price' in headers else headers.index('dine_in'))
        parcel_idx = headers.index('parcel price') if 'parcel price' in headers else headers.index('parcel')
    except ValueError:
        raise ValueError("Excel must contain headers: Section, Item Name, Dine-in Price, Parcel Price")
        
    code_idx = headers.index('code') if 'code' in headers else (
               headers.index('item code') if 'item code' in headers else (
               headers.index('item_code') if 'item_code' in headers else -1))
               
    sections_added = 0
    items_added = 0
    existing_sections = {s['name'].lower(): s['id'] for s in get_sections_db()}
    
    for row in rows[1:]:
        if len(row) <= max(sec_idx, name_idx, dine_idx, parcel_idx):
            continue
        sec_name = str(row[sec_idx] or '').strip()
        item_name = str(row[name_idx] or '').strip()
        item_code = str(row[code_idx]).strip() if (code_idx >= 0 and len(row) > code_idx and row[code_idx] is not None) else None
        try:
            dine_price = int(float(row[dine_idx]))
            parcel_price = int(float(row[parcel_idx]))
        except (ValueError, TypeError):
            continue
            
        if not sec_name or not item_name:
            continue
            
        sec_key = sec_name.lower()
        if sec_key in existing_sections:
            sec_id = existing_sections[sec_key]
        else:
            sec_id = add_section(sec_name)
            existing_sections[sec_key] = sec_id
            sections_added += 1
            
        existing_items = {it['name'].lower(): it['id'] for it in get_items_for_section(sec_id)}
        if item_name.lower() in existing_items:
            item_id = existing_items[item_name.lower()]
            update_item(item_id, item_name, dine_price, parcel_price, item_code)
        else:
            add_item(sec_id, item_name, dine_price, parcel_price, item_code)
            items_added += 1
            
    return sections_added, items_added


def import_menu_from_pdf(file_path: str) -> tuple[int, int]:
    """
    Imports sections and items from a text-based PDF menu card.
    Expects sections and items with prices.
    Returns (sections_added, items_added).
    """
    try:
        import pypdf
    except ImportError:
        raise ImportError(
            "To import PDF files directly, please install pypdf first via:\n"
            "pip install pypdf\n\n"
            "Alternatively, save/convert your menu to CSV or Excel."
        )
        
    reader = pypdf.PdfReader(file_path)
    text_lines = []
    for page in reader.pages:
        text = page.extract_text()
        if text:
            text_lines.extend(text.split('\n'))
            
    import re
    sections_added = 0
    items_added = 0
    
    existing_sections = {s['name'].lower(): s['id'] for s in get_sections_db()}
    current_sec_id = None
    
    if existing_sections:
        current_sec_id = list(existing_sections.values())[0]
        
    for line in text_lines:
        line = line.strip().rstrip('.')
        if not line:
            continue
            
        tokens = line.split()
        if not tokens:
            continue
            
        prices = []
        name_tokens = list(tokens)
        
        def is_price_token(t):
            clean = t.replace('Rs.', '').replace('Rs', '').replace('₹', '').replace('$', '').strip()
            clean = clean.strip('.,-')
            try:
                float(clean)
                return True
            except ValueError:
                return False
        
        def get_price_val(t):
            clean = t.replace('Rs.', '').replace('Rs', '').replace('₹', '').replace('$', '').strip()
            clean = clean.strip('.,-')
            return int(float(clean))
            
        while len(prices) < 2 and name_tokens:
            last = name_tokens[-1]
            if last.strip('.-=') == '':
                name_tokens.pop()
                continue
            if is_price_token(last):
                prices.insert(0, get_price_val(name_tokens.pop()))
                if name_tokens and name_tokens[-1].lower().strip('.,-') in ('rs', '₹', '$', 'inr'):
                    name_tokens.pop()
            else:
                break
                
        if not prices:
            name = " ".join(name_tokens).strip()
            name = re.sub(r'[\s\.\-:=]+$', '', name).strip()
            if not name:
                continue
            name_lower = name.lower()
            if name_lower in ("page", "menu", "menu card", "price list") or name_lower.startswith("page "):
                continue
            
            sec_key = name_lower
            if sec_key in existing_sections:
                current_sec_id = existing_sections[sec_key]
            else:
                current_sec_id = add_section(name)
                existing_sections[sec_key] = current_sec_id
                sections_added += 1
        else:
            name = " ".join(name_tokens).strip()
            name = re.sub(r'[\s\.\-]+$', '', name).strip()
            if not name:
                continue
            name_lower = name.lower()
            if name_lower in ("page", "menu", "menu card", "price list") or name_lower.startswith("page "):
                continue
                
            dine_price = prices[0]
            parcel_price = prices[1] if len(prices) > 1 else prices[0]
            
            if current_sec_id is None:
                sec_name = "General"
                sec_key = "general"
                if sec_key in existing_sections:
                    current_sec_id = existing_sections[sec_key]
                else:
                    current_sec_id = add_section(sec_name)
                    existing_sections[sec_key] = current_sec_id
                    sections_added += 1
                    
            existing_items = {it['name'].lower(): it['id'] for it in get_items_for_section(current_sec_id)}
            if name.lower() in existing_items:
                item_id = existing_items[name.lower()]
                update_item(item_id, name, dine_price, parcel_price)
            else:
                add_item(current_sec_id, name, dine_price, parcel_price)
                items_added += 1
                
    return sections_added, items_added


# ──────────────────────────────────────────────
# v1.2 HUB SYNC FUNCTIONS
# ──────────────────────────────────────────────

def apply_menu_update(action: str, payload: dict):
    """
    v1.2: Apply a menu_update event received from the hub.
    Actions: 'price_change', 'add_item', 'delete_item', 'toggle_active',
             'add_section', 'update_section', 'delete_section'
    """
    with _lock:
        conn = get_conn()
        try:
            if action == "price_change":
                conn.execute("UPDATE menu_items SET price=?, dine_in_price=?, parcel_price=? WHERE id=?",
                             (payload["new_price"], payload["new_price"], payload["new_price"], payload["item_id"]))
            elif action == "add_item":
                sec = conn.execute("SELECT id FROM menu_sections WHERE name=?", (payload["section"],)).fetchone()
                if sec:
                    sec_id = sec["id"]
                    max_order = conn.execute(
                        "SELECT COALESCE(MAX(sort_order),0) FROM menu_items WHERE section_id=?",
                        (sec_id,)).fetchone()[0]
                    conn.execute(
                        """INSERT OR IGNORE INTO menu_items (section_id, name, code, dine_in_price, parcel_price, price, sort_order)
                           VALUES (?,?,?,?,?,?,?)""",
                        (sec_id, payload["name"], payload.get("code", ""),
                         payload["price"], payload["price"], payload["price"], max_order + 1))
            elif action == "delete_item":
                conn.execute("DELETE FROM menu_items WHERE id=?", (payload["item_id"],))
            elif action == "toggle_active":
                conn.execute("UPDATE menu_items SET is_active=? WHERE id=?",
                             (payload["is_active"], payload["item_id"]))
            elif action == "add_section":
                max_order = conn.execute("SELECT COALESCE(MAX(sort_order),0) FROM menu_sections").fetchone()[0]
                conn.execute("INSERT OR IGNORE INTO menu_sections (name, sort_order, is_active) VALUES (?,?,1)",
                             (payload["name"], max_order + 1))
            elif action == "update_section":
                conn.execute("UPDATE menu_sections SET name=?, is_active=? WHERE id=?",
                             (payload["name"], payload.get("is_active", 1), payload["section_id"]))
            elif action == "delete_section":
                conn.execute("DELETE FROM menu_items WHERE section_id=?", (payload["section_id"],))
                conn.execute("DELETE FROM menu_sections WHERE id=?", (payload["section_id"],))
            conn.commit()
            # Log the event for idempotency
            conn.execute("INSERT INTO hub_sync_log (event_type, payload) VALUES (?,?)",
                         (f"menu_{action}", str(payload)[:500]))
            conn.commit()
        except Exception as e:
            print(f"[v1.2 apply_menu_update] error: {e}")
        finally:
            conn.close()


def get_menu_snapshot() -> dict:
    """v1.2: Return full menu snapshot for POS startup sync."""
    conn = get_conn()
    sections = conn.execute(
        "SELECT id, name, sort_order, is_active FROM menu_sections ORDER BY sort_order, id"
    ).fetchall()
    out_sections = []
    out_items = []
    for sec in sections:
        out_sections.append(dict(sec))
        items = conn.execute(
            """SELECT id, section_id, name, code, price, dine_in_price, parcel_price,
                      is_active, sort_order FROM menu_items WHERE section_id=?
               ORDER BY sort_order, id""",
            (sec["id"],)
        ).fetchall()
        for it in items:
            out_items.append(dict(it))
    conn.close()
    return {"sections": out_sections, "items": out_items}


def save_bill_with_packaging(meta: dict, items: list) -> dict:
    """v1.2: Save bill with packaging_required flag. Wraps save_bill.
    v1.3: Also persists order_source (walkin / swiggy / zomato / etc.)."""
    bill = save_bill(meta, items)
    needs_update = ('packaging_required' in meta) or ('order_source' in meta) or ('aggregator_order_id' in meta)
    if needs_update:
        with _lock:
            conn = get_conn()
            try:
                if 'packaging_required' in meta:
                    conn.execute("UPDATE bills SET packaging_required=? WHERE id=?",
                                 (1 if meta['packaging_required'] else 0, bill['bill_id']))
                if 'order_source' in meta:
                    conn.execute("UPDATE bills SET order_source=? WHERE id=?",
                                 (meta.get('order_source', 'walkin') or 'walkin', bill['bill_id']))
                if 'aggregator_order_id' in meta:
                    conn.execute("UPDATE bills SET aggregator_order_id=? WHERE id=?",
                                 (meta.get('aggregator_order_id', ''), bill['bill_id']))
                conn.commit()
            except Exception:
                pass
            finally:
                conn.close()
        bill['packaging_required'] = meta.get('packaging_required', 0)
        bill['order_source'] = meta.get('order_source', 'walkin')
        bill['aggregator_order_id'] = meta.get('aggregator_order_id', '')
    else:
        bill['packaging_required'] = 0
        bill['order_source'] = 'walkin'
        bill['aggregator_order_id'] = ''
    return bill


def save_kot_with_packaging(meta: dict, items: list) -> dict:
    """v1.2: Save KOT with packaging_required flag. Wraps save_kot.
    v1.3: Also persists order_source (walkin / swiggy / zomato / etc.)."""
    kot = save_kot(meta, items)
    needs_update = ('packaging_required' in meta) or ('order_source' in meta) or ('aggregator_order_id' in meta)
    if needs_update:
        with _lock:
            conn = get_conn()
            try:
                if 'packaging_required' in meta:
                    conn.execute("UPDATE kots SET packaging_required=? WHERE id=?",
                                 (1 if meta['packaging_required'] else 0, kot['kot_id']))
                if 'order_source' in meta:
                    conn.execute("UPDATE kots SET order_source=? WHERE id=?",
                                 (meta.get('order_source', 'walkin') or 'walkin', kot['kot_id']))
                if 'aggregator_order_id' in meta:
                    conn.execute("UPDATE kots SET aggregator_order_id=? WHERE id=?",
                                 (meta.get('aggregator_order_id', ''), kot['kot_id']))
                conn.commit()
            except Exception:
                pass
            finally:
                conn.close()
        kot['packaging_required'] = meta.get('packaging_required', 0)
        kot['order_source'] = meta.get('order_source', 'walkin')
        kot['aggregator_order_id'] = meta.get('aggregator_order_id', '')
    else:
        kot['packaging_required'] = 0
        kot['order_source'] = 'walkin'
        kot['aggregator_order_id'] = ''
    return kot


def save_bill_sync(bill: dict):
    """v1.2: Save/overwrite a bill received from hub (used by POS clients for live sync)."""
    with _lock:
        conn = get_conn()
        try:
            existing = conn.execute("SELECT id FROM bills WHERE bill_no=?", (bill['bill_no'],)).fetchone()
            if existing:
                # Bill already exists; skip (don't overwrite)
                pass
            else:
                # Insert minimal bill record for display purposes
                conn.execute("""
                    INSERT INTO bills (bill_no, date, time, table_no, customer_name, order_type,
                                       subtotal, cgst, sgst, total, payment_mode, notes, terminal_id,
                                       packaging_required)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                """, (bill['bill_no'], bill.get('date', ''), bill.get('time', ''),
                      bill.get('table_no', ''), bill.get('customer_name', ''),
                      bill.get('order_type', 'standard'),
                      bill.get('subtotal', 0), bill.get('cgst', 0), bill.get('sgst', 0),
                      bill.get('total', 0), bill.get('payment_mode', 'cash'),
                      bill.get('notes', ''), bill.get('terminal_id', 1),
                      1 if bill.get('packaging_required') else 0))
                conn.commit()
        except Exception as e:
            print(f"[v1.2 save_bill_sync] error: {e}")
        finally:
            conn.close()


def get_all_bills_today() -> list:
    """v1.2: Get all bills from today (for hub broadcast on POS startup)."""
    return get_bills(date=today())


def get_all_kots_today() -> list:
    """v1.2: Get all KOTs from today (for hub broadcast on POS startup)."""
    return get_kots(date=today())

