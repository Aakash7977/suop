"""
Mini Centrino Lite — Icon Generator
Called by build_windows.bat if assets/icon.ico is missing.
Can also be run manually: python generate_icon.py
"""
import os
from pathlib import Path

def generate():
    os.makedirs("assets", exist_ok=True)
    icon_path = Path("assets/icon.ico")

    try:
        from PIL import Image, ImageDraw, ImageFont

        def make_frame(sz):
            img = Image.new("RGBA", (sz, sz), (0, 0, 0, 0))
            d   = ImageDraw.Draw(img)
            # Rounded background
            margin = max(1, sz // 12)
            d.ellipse([margin, margin, sz - margin, sz - margin],
                      fill=(107, 46, 0, 255), outline=(255, 215, 0, 255),
                      width=max(1, sz // 20))
            # "MCL" text
            text     = "MCL"
            font_sz  = max(8, sz * 36 // 64)
            try:
                font = ImageFont.truetype("arial.ttf", font_sz)
            except Exception:
                font = ImageFont.load_default()
            bbox = d.textbbox((0, 0), text, font=font)
            tw   = bbox[2] - bbox[0]
            th   = bbox[3] - bbox[1]
            tx   = (sz - tw) // 2 - bbox[0]
            ty   = (sz - th) // 2 - bbox[1]
            d.text((tx, ty), text, fill=(255, 215, 0, 255), font=font)
            return img

        sizes  = [16, 32, 48, 64, 128]
        frames = [make_frame(s) for s in sizes]
        frames[0].save(str(icon_path), format="ICO",
                       sizes=[(s, s) for s in sizes],
                       append_images=frames[1:])
        print(f"Icon saved to {icon_path}  ({icon_path.stat().st_size} bytes)")

    except ImportError:
        # PIL not available — write a minimal valid 16×16 ICO binary
        # (RIFF-style ICO with a single 16x16 all-brown image)
        _write_minimal_ico(icon_path)
        print(f"Minimal icon saved to {icon_path} (Pillow not installed)")

def _write_minimal_ico(path):
    """Write a tiny but valid .ico file without Pillow."""
    import struct
    # 16x16 BGRA bitmap, all pixels = amber (#FFD700 = B=0 G=215 R=255 A=255)
    W = H = 16
    pixel = bytes([0, 215, 255, 255])   # BGRA
    pixels = pixel * (W * H)
    # BMP header for ICO entry (BITMAPINFOHEADER)
    bmp_header = struct.pack("<IiiHHIIiiII",
        40,        # header size
        W, H * 2,  # width, height*2 (ICO convention)
        1,         # planes
        32,        # bpp
        0,         # compression (BI_RGB)
        len(pixels),
        0, 0, 0, 0)
    img_data = bmp_header + pixels
    # ICO file header + directory entry
    ico_header = struct.pack("<HHH", 0, 1, 1)   # reserved, type=1 (ICO), count=1
    entry = struct.pack("<BBBBHHII",
        W, H, 0, 0,         # width, height, color count, reserved
        1, 32,               # planes, bpp
        len(img_data),       # size of image data
        6 + 16)              # offset to image data (header 6 + entry 16)
    with open(path, "wb") as f:
        f.write(ico_header + entry + img_data)

if __name__ == "__main__":
    generate()
